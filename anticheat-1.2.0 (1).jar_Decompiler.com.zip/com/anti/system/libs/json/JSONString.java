package com.anti.system.libs.json;

public interface JSONString {
   String toJSONString();
}
