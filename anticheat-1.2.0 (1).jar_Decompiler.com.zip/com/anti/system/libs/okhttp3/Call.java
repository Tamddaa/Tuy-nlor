package com.anti.system.libs.okhttp3;

import com.anti.system.libs.okio.Timeout;
import java.io.IOException;

public interface Call extends Cloneable {
   Request request();

   Response execute() throws IOException;

   void enqueue(Callback var1);

   void cancel();

   boolean isExecuted();

   boolean isCanceled();

   Timeout timeout();

   Call clone();

   public interface Factory {
      Call newCall(Request var1);
   }
}
