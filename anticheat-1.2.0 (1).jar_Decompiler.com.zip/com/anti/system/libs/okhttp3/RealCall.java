package com.anti.system.libs.okhttp3;

import com.anti.system.libs.okhttp3.internal.NamedRunnable;
import com.anti.system.libs.okhttp3.internal.Util;
import com.anti.system.libs.okhttp3.internal.cache.CacheInterceptor;
import com.anti.system.libs.okhttp3.internal.connection.ConnectInterceptor;
import com.anti.system.libs.okhttp3.internal.connection.Exchange;
import com.anti.system.libs.okhttp3.internal.connection.Transmitter;
import com.anti.system.libs.okhttp3.internal.http.BridgeInterceptor;
import com.anti.system.libs.okhttp3.internal.http.CallServerInterceptor;
import com.anti.system.libs.okhttp3.internal.http.RealInterceptorChain;
import com.anti.system.libs.okhttp3.internal.http.RetryAndFollowUpInterceptor;
import com.anti.system.libs.okhttp3.internal.platform.Platform;
import com.anti.system.libs.okio.Timeout;
import java.io.Closeable;
import java.io.IOException;
import java.io.InterruptedIOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.atomic.AtomicInteger;

final class RealCall implements Call {
   final OkHttpClient client;
   private Transmitter transmitter;
   final Request originalRequest;
   final boolean forWebSocket;
   private boolean executed;

   private RealCall(OkHttpClient client, Request originalRequest, boolean forWebSocket) {
      this.client = client;
      this.originalRequest = originalRequest;
      this.forWebSocket = forWebSocket;
   }

   static RealCall newRealCall(OkHttpClient client, Request originalRequest, boolean forWebSocket) {
      RealCall call = new RealCall(client, originalRequest, forWebSocket);
      call.transmitter = new Transmitter(client, call);
      return call;
   }

   public Request request() {
      return this.originalRequest;
   }

   public Response execute() throws IOException {
      synchronized(this) {
         if (this.executed) {
            throw new IllegalStateException("Already Executed");
         }

         this.executed = true;
      }

      this.transmitter.timeoutEnter();
      this.transmitter.callStart();

      Response var1;
      try {
         this.client.dispatcher().executed(this);
         var1 = this.getResponseWithInterceptorChain();
      } finally {
         this.client.dispatcher().finished(this);
      }

      return var1;
   }

   public void enqueue(Callback responseCallback) {
      synchronized(this) {
         if (this.executed) {
            throw new IllegalStateException("Already Executed");
         }

         this.executed = true;
      }

      this.transmitter.callStart();
      this.client.dispatcher().enqueue(new AsyncCall(responseCallback));
   }

   public void cancel() {
      this.transmitter.cancel();
   }

   public Timeout timeout() {
      return this.transmitter.timeout();
   }

   public synchronized boolean isExecuted() {
      return this.executed;
   }

   public boolean isCanceled() {
      return this.transmitter.isCanceled();
   }

   public RealCall clone() {
      return newRealCall(this.client, this.originalRequest, this.forWebSocket);
   }

   String toLoggableString() {
      return (this.isCanceled() ? "canceled " : "") + (this.forWebSocket ? "web socket" : "call") + " to " + this.redactedUrl();
   }

   String redactedUrl() {
      return this.originalRequest.url().redact();
   }

   Response getResponseWithInterceptorChain() throws IOException {
      List<Interceptor> interceptors = new ArrayList();
      interceptors.addAll(this.client.interceptors());
      interceptors.add(new RetryAndFollowUpInterceptor(this.client));
      interceptors.add(new BridgeInterceptor(this.client.cookieJar()));
      interceptors.add(new CacheInterceptor(this.client.internalCache()));
      interceptors.add(new ConnectInterceptor(this.client));
      if (!this.forWebSocket) {
         interceptors.addAll(this.client.networkInterceptors());
      }

      interceptors.add(new CallServerInterceptor(this.forWebSocket));
      Interceptor.Chain chain = new RealInterceptorChain(interceptors, this.transmitter, (Exchange)null, 0, this.originalRequest, this, this.client.connectTimeoutMillis(), this.client.readTimeoutMillis(), this.client.writeTimeoutMillis());
      boolean calledNoMoreExchanges = false;

      Response var5;
      try {
         Response response = chain.proceed(this.originalRequest);
         if (this.transmitter.isCanceled()) {
            Util.closeQuietly((Closeable)response);
            throw new IOException("Canceled");
         }

         var5 = response;
      } catch (IOException e) {
         calledNoMoreExchanges = true;
         throw this.transmitter.noMoreExchanges(e);
      } finally {
         if (!calledNoMoreExchanges) {
            this.transmitter.noMoreExchanges((IOException)null);
         }

      }

      return var5;
   }

   final class AsyncCall extends NamedRunnable {
      private final Callback responseCallback;
      private volatile AtomicInteger callsPerHost = new AtomicInteger(0);

      AsyncCall(Callback responseCallback) {
         super("OkHttp %s", RealCall.this.redactedUrl());
         this.responseCallback = responseCallback;
      }

      AtomicInteger callsPerHost() {
         return this.callsPerHost;
      }

      void reuseCallsPerHostFrom(AsyncCall other) {
         this.callsPerHost = other.callsPerHost;
      }

      String host() {
         return RealCall.this.originalRequest.url().host();
      }

      Request request() {
         return RealCall.this.originalRequest;
      }

      RealCall get() {
         return RealCall.this;
      }

      void executeOn(ExecutorService executorService) {
         assert !Thread.holdsLock(RealCall.this.client.dispatcher());

         boolean success = false;

         try {
            executorService.execute(this);
            success = true;
         } catch (RejectedExecutionException e) {
            InterruptedIOException ioException = new InterruptedIOException("executor rejected");
            ioException.initCause(e);
            RealCall.this.transmitter.noMoreExchanges(ioException);
            this.responseCallback.onFailure(RealCall.this, ioException);
         } finally {
            if (!success) {
               RealCall.this.client.dispatcher().finished(this);
            }

         }

      }

      protected void execute() {
         boolean signalledCallback = false;
         RealCall.this.transmitter.timeoutEnter();

         try {
            Response response = RealCall.this.getResponseWithInterceptorChain();
            signalledCallback = true;
            this.responseCallback.onResponse(RealCall.this, response);
         } catch (IOException e) {
            if (signalledCallback) {
               Platform.get().log(4, "Callback failure for " + RealCall.this.toLoggableString(), e);
            } else {
               this.responseCallback.onFailure(RealCall.this, e);
            }
         } catch (Throwable var9) {
            RealCall.this.cancel();
            if (!signalledCallback) {
               IOException canceledException = new IOException("canceled due to " + var9);
               canceledException.addSuppressed(var9);
               this.responseCallback.onFailure(RealCall.this, canceledException);
            }

            throw var9;
         } finally {
            RealCall.this.client.dispatcher().finished(this);
         }

      }
   }
}
