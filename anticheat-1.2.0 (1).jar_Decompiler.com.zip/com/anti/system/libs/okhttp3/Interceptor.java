package com.anti.system.libs.okhttp3;

import java.io.IOException;
import java.util.concurrent.TimeUnit;
import javax.annotation.Nullable;

public interface Interceptor {
   Response intercept(Chain var1) throws IOException;

   public interface Chain {
      Request request();

      Response proceed(Request var1) throws IOException;

      @Nullable
      Connection connection();

      Call call();

      int connectTimeoutMillis();

      Chain withConnectTimeout(int var1, TimeUnit var2);

      int readTimeoutMillis();

      Chain withReadTimeout(int var1, TimeUnit var2);

      int writeTimeoutMillis();

      Chain withWriteTimeout(int var1, TimeUnit var2);
   }
}
