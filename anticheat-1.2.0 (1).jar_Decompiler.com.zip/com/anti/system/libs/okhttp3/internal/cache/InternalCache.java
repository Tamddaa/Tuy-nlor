package com.anti.system.libs.okhttp3.internal.cache;

import com.anti.system.libs.okhttp3.Request;
import com.anti.system.libs.okhttp3.Response;
import java.io.IOException;
import javax.annotation.Nullable;

public interface InternalCache {
   @Nullable
   Response get(Request var1) throws IOException;

   @Nullable
   CacheRequest put(Response var1) throws IOException;

   void remove(Request var1) throws IOException;

   void update(Response var1, Response var2);

   void trackConditionalCacheHit();

   void trackResponse(CacheStrategy var1);
}
