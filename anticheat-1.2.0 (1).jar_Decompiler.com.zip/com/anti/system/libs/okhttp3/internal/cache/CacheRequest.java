package com.anti.system.libs.okhttp3.internal.cache;

import com.anti.system.libs.okio.Sink;
import java.io.IOException;

public interface CacheRequest {
   Sink body() throws IOException;

   void abort();
}
