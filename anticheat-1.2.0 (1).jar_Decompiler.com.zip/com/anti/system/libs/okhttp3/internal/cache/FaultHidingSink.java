package com.anti.system.libs.okhttp3.internal.cache;

import com.anti.system.libs.okio.Buffer;
import com.anti.system.libs.okio.ForwardingSink;
import com.anti.system.libs.okio.Sink;
import java.io.IOException;

class FaultHidingSink extends ForwardingSink {
   private boolean hasErrors;

   FaultHidingSink(Sink delegate) {
      super(delegate);
   }

   public void write(Buffer source, long byteCount) throws IOException {
      if (this.hasErrors) {
         source.skip(byteCount);
      } else {
         try {
            super.write(source, byteCount);
         } catch (IOException e) {
            this.hasErrors = true;
            this.onException(e);
         }

      }
   }

   public void flush() throws IOException {
      if (!this.hasErrors) {
         try {
            super.flush();
         } catch (IOException e) {
            this.hasErrors = true;
            this.onException(e);
         }

      }
   }

   public void close() throws IOException {
      if (!this.hasErrors) {
         try {
            super.close();
         } catch (IOException e) {
            this.hasErrors = true;
            this.onException(e);
         }

      }
   }

   protected void onException(IOException e) {
   }
}
