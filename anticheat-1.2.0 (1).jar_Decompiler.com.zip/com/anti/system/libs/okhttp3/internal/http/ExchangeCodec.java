package com.anti.system.libs.okhttp3.internal.http;

import com.anti.system.libs.okhttp3.Headers;
import com.anti.system.libs.okhttp3.Request;
import com.anti.system.libs.okhttp3.Response;
import com.anti.system.libs.okhttp3.internal.connection.RealConnection;
import com.anti.system.libs.okio.Sink;
import com.anti.system.libs.okio.Source;
import java.io.IOException;
import javax.annotation.Nullable;

public interface ExchangeCodec {
   int DISCARD_STREAM_TIMEOUT_MILLIS = 100;

   RealConnection connection();

   Sink createRequestBody(Request var1, long var2) throws IOException;

   void writeRequestHeaders(Request var1) throws IOException;

   void flushRequest() throws IOException;

   void finishRequest() throws IOException;

   @Nullable
   Response.Builder readResponseHeaders(boolean var1) throws IOException;

   long reportedContentLength(Response var1) throws IOException;

   Source openResponseBodySource(Response var1) throws IOException;

   Headers trailers() throws IOException;

   void cancel();
}
