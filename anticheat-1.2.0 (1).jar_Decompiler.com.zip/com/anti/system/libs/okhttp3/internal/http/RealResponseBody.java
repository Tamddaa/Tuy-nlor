package com.anti.system.libs.okhttp3.internal.http;

import com.anti.system.libs.okhttp3.MediaType;
import com.anti.system.libs.okhttp3.ResponseBody;
import com.anti.system.libs.okio.BufferedSource;
import javax.annotation.Nullable;

public final class RealResponseBody extends ResponseBody {
   @Nullable
   private final String contentTypeString;
   private final long contentLength;
   private final BufferedSource source;

   public RealResponseBody(@Nullable String contentTypeString, long contentLength, BufferedSource source) {
      this.contentTypeString = contentTypeString;
      this.contentLength = contentLength;
      this.source = source;
   }

   public MediaType contentType() {
      return this.contentTypeString != null ? MediaType.parse(this.contentTypeString) : null;
   }

   public long contentLength() {
      return this.contentLength;
   }

   public BufferedSource source() {
      return this.source;
   }
}
