package com.anti.system.libs.okhttp3.internal.platform;

import android.annotation.SuppressLint;
import android.net.ssl.SSLSockets;
import com.anti.system.libs.okhttp3.Protocol;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.List;
import javax.annotation.Nullable;
import javax.net.ssl.SSLParameters;
import javax.net.ssl.SSLSocket;
import org.codehaus.mojo.animal_sniffer.IgnoreJRERequirement;

@SuppressLint({"NewApi"})
class Android10Platform extends AndroidPlatform {
   Android10Platform(Class<?> sslParametersClass) {
      super(sslParametersClass, (Class)null, (Method)null, (Method)null, (Method)null, (Method)null);
   }

   @SuppressLint({"NewApi"})
   @IgnoreJRERequirement
   public void configureTlsExtensions(SSLSocket sslSocket, String hostname, List<Protocol> protocols) throws IOException {
      try {
         this.enableSessionTickets(sslSocket);
         SSLParameters sslParameters = sslSocket.getSSLParameters();
         String[] protocolsArray = (String[])Platform.alpnProtocolNames(protocols).toArray(new String[0]);
         sslParameters.setApplicationProtocols(protocolsArray);
         sslSocket.setSSLParameters(sslParameters);
      } catch (IllegalArgumentException iae) {
         throw new IOException("Android internal error", iae);
      }
   }

   private void enableSessionTickets(SSLSocket sslSocket) {
      if (SSLSockets.isSupportedSocket(sslSocket)) {
         SSLSockets.setUseSessionTickets(sslSocket, true);
      }

   }

   @Nullable
   @IgnoreJRERequirement
   public String getSelectedProtocol(SSLSocket socket) {
      String alpnResult = socket.getApplicationProtocol();
      return alpnResult != null && !alpnResult.isEmpty() ? alpnResult : null;
   }

   @Nullable
   public static Platform buildIfSupported() {
      if (!Platform.isAndroid()) {
         return null;
      } else {
         try {
            if (getSdkInt() >= 29) {
               Class<?> sslParametersClass = Class.forName("com.android.org.conscrypt.SSLParametersImpl");
               return new Android10Platform(sslParametersClass);
            }
         } catch (ReflectiveOperationException var1) {
         }

         return null;
      }
   }
}
