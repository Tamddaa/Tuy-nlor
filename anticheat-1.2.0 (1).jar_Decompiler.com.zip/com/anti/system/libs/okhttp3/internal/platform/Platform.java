package com.anti.system.libs.okhttp3.internal.platform;

import com.anti.system.libs.okhttp3.OkHttpClient;
import com.anti.system.libs.okhttp3.Protocol;
import com.anti.system.libs.okhttp3.internal.Util;
import com.anti.system.libs.okhttp3.internal.tls.BasicCertificateChainCleaner;
import com.anti.system.libs.okhttp3.internal.tls.BasicTrustRootIndex;
import com.anti.system.libs.okhttp3.internal.tls.CertificateChainCleaner;
import com.anti.system.libs.okhttp3.internal.tls.TrustRootIndex;
import com.anti.system.libs.okio.Buffer;
import java.io.IOException;
import java.lang.reflect.Field;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.security.NoSuchAlgorithmException;
import java.security.Security;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.Nullable;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.X509TrustManager;

public class Platform {
   private static final Platform PLATFORM = findPlatform();
   public static final int INFO = 4;
   public static final int WARN = 5;
   private static final Logger logger = Logger.getLogger(OkHttpClient.class.getName());

   public static Platform get() {
      return PLATFORM;
   }

   public String getPrefix() {
      return "OkHttp";
   }

   @Nullable
   protected X509TrustManager trustManager(SSLSocketFactory sslSocketFactory) {
      try {
         Class<?> sslContextClass = Class.forName("sun.security.ssl.SSLContextImpl");
         Object context = readFieldOrNull(sslSocketFactory, sslContextClass, "context");
         return context == null ? null : (X509TrustManager)readFieldOrNull(context, X509TrustManager.class, "trustManager");
      } catch (ClassNotFoundException var4) {
         return null;
      }
   }

   public void configureTlsExtensions(SSLSocket sslSocket, @Nullable String hostname, List<Protocol> protocols) throws IOException {
   }

   public void afterHandshake(SSLSocket sslSocket) {
   }

   @Nullable
   public String getSelectedProtocol(SSLSocket socket) {
      return null;
   }

   public void connectSocket(Socket socket, InetSocketAddress address, int connectTimeout) throws IOException {
      socket.connect(address, connectTimeout);
   }

   public void log(int level, String message, @Nullable Throwable t) {
      Level logLevel = level == 5 ? Level.WARNING : Level.INFO;
      logger.log(logLevel, message, t);
   }

   public boolean isCleartextTrafficPermitted(String hostname) {
      return true;
   }

   @Nullable
   public Object getStackTraceForCloseable(String closer) {
      return logger.isLoggable(Level.FINE) ? new Throwable(closer) : null;
   }

   public void logCloseableLeak(String message, Object stackTrace) {
      if (stackTrace == null) {
         message = message + " To see where this was allocated, set the OkHttpClient logger level to FINE: Logger.getLogger(OkHttpClient.class.getName()).setLevel(Level.FINE);";
      }

      this.log(5, message, (Throwable)stackTrace);
   }

   public static List<String> alpnProtocolNames(List<Protocol> protocols) {
      List<String> names = new ArrayList(protocols.size());
      int i = 0;

      for(int size = protocols.size(); i < size; ++i) {
         Protocol protocol = (Protocol)protocols.get(i);
         if (protocol != Protocol.HTTP_1_0) {
            names.add(protocol.toString());
         }
      }

      return names;
   }

   public CertificateChainCleaner buildCertificateChainCleaner(X509TrustManager trustManager) {
      return new BasicCertificateChainCleaner(this.buildTrustRootIndex(trustManager));
   }

   public CertificateChainCleaner buildCertificateChainCleaner(SSLSocketFactory sslSocketFactory) {
      X509TrustManager trustManager = this.trustManager(sslSocketFactory);
      if (trustManager == null) {
         throw new IllegalStateException("Unable to extract the trust manager on " + get() + ", sslSocketFactory is " + sslSocketFactory.getClass());
      } else {
         return this.buildCertificateChainCleaner(trustManager);
      }
   }

   public static boolean isConscryptPreferred() {
      if ("conscrypt".equals(Util.getSystemProperty("okhttp.platform", (String)null))) {
         return true;
      } else {
         String preferredProvider = Security.getProviders()[0].getName();
         return "Conscrypt".equals(preferredProvider);
      }
   }

   private static Platform findPlatform() {
      return isAndroid() ? findAndroidPlatform() : findJvmPlatform();
   }

   public static boolean isAndroid() {
      return "Dalvik".equals(System.getProperty("java.vm.name"));
   }

   private static Platform findJvmPlatform() {
      if (isConscryptPreferred()) {
         Platform conscrypt = ConscryptPlatform.buildIfSupported();
         if (conscrypt != null) {
            return conscrypt;
         }
      }

      Platform jdk9 = Jdk9Platform.buildIfSupported();
      if (jdk9 != null) {
         return jdk9;
      } else {
         Platform jdkWithJettyBoot = Jdk8WithJettyBootPlatform.buildIfSupported();
         return jdkWithJettyBoot != null ? jdkWithJettyBoot : new Platform();
      }
   }

   private static Platform findAndroidPlatform() {
      Platform android10 = Android10Platform.buildIfSupported();
      if (android10 != null) {
         return android10;
      } else {
         Platform android = AndroidPlatform.buildIfSupported();
         if (android == null) {
            throw new NullPointerException("No platform found on Android");
         } else {
            return android;
         }
      }
   }

   static byte[] concatLengthPrefixed(List<Protocol> protocols) {
      Buffer result = new Buffer();
      int i = 0;

      for(int size = protocols.size(); i < size; ++i) {
         Protocol protocol = (Protocol)protocols.get(i);
         if (protocol != Protocol.HTTP_1_0) {
            result.writeByte(protocol.toString().length());
            result.writeUtf8(protocol.toString());
         }
      }

      return result.readByteArray();
   }

   @Nullable
   static <T> T readFieldOrNull(Object instance, Class<T> fieldType, String fieldName) {
      Class<?> c = instance.getClass();

      while(c != Object.class) {
         try {
            Field field = c.getDeclaredField(fieldName);
            field.setAccessible(true);
            Object value = field.get(instance);
            if (!fieldType.isInstance(value)) {
               return null;
            }

            return (T)fieldType.cast(value);
         } catch (NoSuchFieldException var6) {
            c = c.getSuperclass();
         } catch (IllegalAccessException var7) {
            throw new AssertionError();
         }
      }

      if (!fieldName.equals("delegate")) {
         Object delegate = readFieldOrNull(instance, Object.class, "delegate");
         if (delegate != null) {
            return (T)readFieldOrNull(delegate, fieldType, fieldName);
         }
      }

      return null;
   }

   public SSLContext getSSLContext() {
      try {
         return SSLContext.getInstance("TLS");
      } catch (NoSuchAlgorithmException e) {
         throw new IllegalStateException("No TLS provider", e);
      }
   }

   public TrustRootIndex buildTrustRootIndex(X509TrustManager trustManager) {
      return new BasicTrustRootIndex(trustManager.getAcceptedIssuers());
   }

   public void configureSslSocketFactory(SSLSocketFactory socketFactory) {
   }

   public String toString() {
      return this.getClass().getSimpleName();
   }
}
