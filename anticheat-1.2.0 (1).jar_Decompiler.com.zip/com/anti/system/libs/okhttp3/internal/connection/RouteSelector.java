package com.anti.system.libs.okhttp3.internal.connection;

import com.anti.system.libs.okhttp3.Address;
import com.anti.system.libs.okhttp3.Call;
import com.anti.system.libs.okhttp3.EventListener;
import com.anti.system.libs.okhttp3.HttpUrl;
import com.anti.system.libs.okhttp3.Route;
import com.anti.system.libs.okhttp3.internal.Util;
import java.io.IOException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.SocketAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.net.Proxy.Type;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.NoSuchElementException;

final class RouteSelector {
   private final Address address;
   private final RouteDatabase routeDatabase;
   private final Call call;
   private final EventListener eventListener;
   private List<Proxy> proxies = Collections.emptyList();
   private int nextProxyIndex;
   private List<InetSocketAddress> inetSocketAddresses = Collections.emptyList();
   private final List<Route> postponedRoutes = new ArrayList();

   RouteSelector(Address address, RouteDatabase routeDatabase, Call call, EventListener eventListener) {
      this.address = address;
      this.routeDatabase = routeDatabase;
      this.call = call;
      this.eventListener = eventListener;
      this.resetNextProxy(address.url(), address.proxy());
   }

   public boolean hasNext() {
      return this.hasNextProxy() || !this.postponedRoutes.isEmpty();
   }

   public Selection next() throws IOException {
      if (!this.hasNext()) {
         throw new NoSuchElementException();
      } else {
         List<Route> routes = new ArrayList();

         while(this.hasNextProxy()) {
            Proxy proxy = this.nextProxy();
            int i = 0;

            for(int size = this.inetSocketAddresses.size(); i < size; ++i) {
               Route route = new Route(this.address, proxy, (InetSocketAddress)this.inetSocketAddresses.get(i));
               if (this.routeDatabase.shouldPostpone(route)) {
                  this.postponedRoutes.add(route);
               } else {
                  routes.add(route);
               }
            }

            if (!routes.isEmpty()) {
               break;
            }
         }

         if (routes.isEmpty()) {
            routes.addAll(this.postponedRoutes);
            this.postponedRoutes.clear();
         }

         return new Selection(routes);
      }
   }

   private void resetNextProxy(HttpUrl url, Proxy proxy) {
      if (proxy != null) {
         this.proxies = Collections.singletonList(proxy);
      } else {
         List<Proxy> proxiesOrNull = this.address.proxySelector().select(url.uri());
         this.proxies = proxiesOrNull != null && !proxiesOrNull.isEmpty() ? Util.immutableList(proxiesOrNull) : Util.immutableList(Proxy.NO_PROXY);
      }

      this.nextProxyIndex = 0;
   }

   private boolean hasNextProxy() {
      return this.nextProxyIndex < this.proxies.size();
   }

   private Proxy nextProxy() throws IOException {
      if (!this.hasNextProxy()) {
         throw new SocketException("No route to " + this.address.url().host() + "; exhausted proxy configurations: " + this.proxies);
      } else {
         Proxy result = (Proxy)this.proxies.get(this.nextProxyIndex++);
         this.resetNextInetSocketAddress(result);
         return result;
      }
   }

   private void resetNextInetSocketAddress(Proxy proxy) throws IOException {
      this.inetSocketAddresses = new ArrayList();
      String socketHost;
      int socketPort;
      if (proxy.type() != Type.DIRECT && proxy.type() != Type.SOCKS) {
         SocketAddress proxyAddress = proxy.address();
         if (!(proxyAddress instanceof InetSocketAddress)) {
            throw new IllegalArgumentException("Proxy.address() is not an InetSocketAddress: " + proxyAddress.getClass());
         }

         InetSocketAddress proxySocketAddress = (InetSocketAddress)proxyAddress;
         socketHost = getHostString(proxySocketAddress);
         socketPort = proxySocketAddress.getPort();
      } else {
         socketHost = this.address.url().host();
         socketPort = this.address.url().port();
      }

      if (socketPort >= 1 && socketPort <= 65535) {
         if (proxy.type() == Type.SOCKS) {
            this.inetSocketAddresses.add(InetSocketAddress.createUnresolved(socketHost, socketPort));
         } else {
            this.eventListener.dnsStart(this.call, socketHost);
            List<InetAddress> addresses = this.address.dns().lookup(socketHost);
            if (addresses.isEmpty()) {
               throw new UnknownHostException(this.address.dns() + " returned no addresses for " + socketHost);
            }

            this.eventListener.dnsEnd(this.call, socketHost, addresses);
            int i = 0;

            for(int size = addresses.size(); i < size; ++i) {
               InetAddress inetAddress = (InetAddress)addresses.get(i);
               this.inetSocketAddresses.add(new InetSocketAddress(inetAddress, socketPort));
            }
         }

      } else {
         throw new SocketException("No route to " + socketHost + ":" + socketPort + "; port is out of range");
      }
   }

   static String getHostString(InetSocketAddress socketAddress) {
      InetAddress address = socketAddress.getAddress();
      return address == null ? socketAddress.getHostName() : address.getHostAddress();
   }

   public static final class Selection {
      private final List<Route> routes;
      private int nextRouteIndex = 0;

      Selection(List<Route> routes) {
         this.routes = routes;
      }

      public boolean hasNext() {
         return this.nextRouteIndex < this.routes.size();
      }

      public Route next() {
         if (!this.hasNext()) {
            throw new NoSuchElementException();
         } else {
            return (Route)this.routes.get(this.nextRouteIndex++);
         }
      }

      public List<Route> getAll() {
         return new ArrayList(this.routes);
      }
   }
}
