package com.anti.system.libs.okhttp3.internal.connection;

import com.anti.system.libs.okhttp3.Interceptor;
import com.anti.system.libs.okhttp3.OkHttpClient;
import com.anti.system.libs.okhttp3.Request;
import com.anti.system.libs.okhttp3.Response;
import com.anti.system.libs.okhttp3.internal.http.RealInterceptorChain;
import java.io.IOException;

public final class ConnectInterceptor implements Interceptor {
   public final OkHttpClient client;

   public ConnectInterceptor(OkHttpClient client) {
      this.client = client;
   }

   public Response intercept(Interceptor.Chain chain) throws IOException {
      RealInterceptorChain realChain = (RealInterceptorChain)chain;
      Request request = realChain.request();
      Transmitter transmitter = realChain.transmitter();
      boolean doExtensiveHealthChecks = !request.method().equals("GET");
      Exchange exchange = transmitter.newExchange(chain, doExtensiveHealthChecks);
      return realChain.proceed(request, transmitter, exchange);
   }
}
