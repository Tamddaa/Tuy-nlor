package com.anti.system.libs.okhttp3.internal.connection;

import com.anti.system.libs.okhttp3.ConnectionSpec;
import com.anti.system.libs.okhttp3.internal.Internal;
import java.io.IOException;
import java.io.InterruptedIOException;
import java.net.ProtocolException;
import java.net.UnknownServiceException;
import java.security.cert.CertificateException;
import java.util.Arrays;
import java.util.List;
import javax.net.ssl.SSLException;
import javax.net.ssl.SSLHandshakeException;
import javax.net.ssl.SSLPeerUnverifiedException;
import javax.net.ssl.SSLSocket;

final class ConnectionSpecSelector {
   private final List<ConnectionSpec> connectionSpecs;
   private int nextModeIndex = 0;
   private boolean isFallbackPossible;
   private boolean isFallback;

   ConnectionSpecSelector(List<ConnectionSpec> connectionSpecs) {
      this.connectionSpecs = connectionSpecs;
   }

   ConnectionSpec configureSecureSocket(SSLSocket sslSocket) throws IOException {
      ConnectionSpec tlsConfiguration = null;
      int i = this.nextModeIndex;

      for(int size = this.connectionSpecs.size(); i < size; ++i) {
         ConnectionSpec connectionSpec = (ConnectionSpec)this.connectionSpecs.get(i);
         if (connectionSpec.isCompatible(sslSocket)) {
            tlsConfiguration = connectionSpec;
            this.nextModeIndex = i + 1;
            break;
         }
      }

      if (tlsConfiguration == null) {
         throw new UnknownServiceException("Unable to find acceptable protocols. isFallback=" + this.isFallback + ", modes=" + this.connectionSpecs + ", supported protocols=" + Arrays.toString(sslSocket.getEnabledProtocols()));
      } else {
         this.isFallbackPossible = this.isFallbackPossible(sslSocket);
         Internal.instance.apply(tlsConfiguration, sslSocket, this.isFallback);
         return tlsConfiguration;
      }
   }

   boolean connectionFailed(IOException e) {
      this.isFallback = true;
      if (!this.isFallbackPossible) {
         return false;
      } else if (e instanceof ProtocolException) {
         return false;
      } else if (e instanceof InterruptedIOException) {
         return false;
      } else if (e instanceof SSLHandshakeException && e.getCause() instanceof CertificateException) {
         return false;
      } else {
         return e instanceof SSLPeerUnverifiedException ? false : e instanceof SSLException;
      }
   }

   private boolean isFallbackPossible(SSLSocket socket) {
      for(int i = this.nextModeIndex; i < this.connectionSpecs.size(); ++i) {
         if (((ConnectionSpec)this.connectionSpecs.get(i)).isCompatible(socket)) {
            return true;
         }
      }

      return false;
   }
}
