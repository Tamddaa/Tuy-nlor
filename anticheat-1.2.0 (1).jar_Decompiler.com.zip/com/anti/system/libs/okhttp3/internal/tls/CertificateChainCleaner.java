package com.anti.system.libs.okhttp3.internal.tls;

import com.anti.system.libs.okhttp3.internal.platform.Platform;
import java.security.cert.Certificate;
import java.security.cert.X509Certificate;
import java.util.List;
import javax.net.ssl.SSLPeerUnverifiedException;
import javax.net.ssl.X509TrustManager;

public abstract class CertificateChainCleaner {
   public abstract List<Certificate> clean(List<Certificate> var1, String var2) throws SSLPeerUnverifiedException;

   public static CertificateChainCleaner get(X509TrustManager trustManager) {
      return Platform.get().buildCertificateChainCleaner(trustManager);
   }

   public static CertificateChainCleaner get(X509Certificate... caCerts) {
      return new BasicCertificateChainCleaner(new BasicTrustRootIndex(caCerts));
   }
}
