package com.anti.system.libs.okhttp3;

import com.anti.system.libs.okhttp3.internal.connection.RealConnectionPool;
import java.util.concurrent.TimeUnit;

public final class ConnectionPool {
   final RealConnectionPool delegate;

   public ConnectionPool() {
      this(5, 5L, TimeUnit.MINUTES);
   }

   public ConnectionPool(int maxIdleConnections, long keepAliveDuration, TimeUnit timeUnit) {
      this.delegate = new RealConnectionPool(maxIdleConnections, keepAliveDuration, timeUnit);
   }

   public int idleConnectionCount() {
      return this.delegate.idleConnectionCount();
   }

   public int connectionCount() {
      return this.delegate.connectionCount();
   }

   public void evictAll() {
      this.delegate.evictAll();
   }
}
