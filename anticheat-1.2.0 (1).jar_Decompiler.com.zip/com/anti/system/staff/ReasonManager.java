package com.anti.system.staff;

import com.anti.system.utils.VersionCompatibility;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.logging.Level;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;

public class ReasonManager {
   private final JavaPlugin plugin;
   private final Map<String, List<String>> reasons;
   private FileConfiguration reasonConfig;
   private File reasonFile;

   public ReasonManager(JavaPlugin plugin) {
      this.plugin = plugin;
      this.reasons = new HashMap();
      this.loadReasons();
   }

   private void loadReasons() {
      this.reasonFile = new File(this.plugin.getDataFolder(), "reasons.yml");
      if (!this.reasonFile.exists()) {
         this.createDefaultReasons();
      }

      this.reasonConfig = YamlConfiguration.loadConfiguration(this.reasonFile);

      for(String category : this.reasonConfig.getKeys(false)) {
         List<String> categoryReasons = this.reasonConfig.getStringList(category);
         this.reasons.put(category, new ArrayList(categoryReasons));
      }

   }

   private void createDefaultReasons() {
      try {
         this.reasonFile.getParentFile().mkdirs();
         this.reasonFile.createNewFile();
         YamlConfiguration defaultConfig = YamlConfiguration.loadConfiguration(this.reasonFile);
         defaultConfig.set("chat", Arrays.asList("Spam/Flooding", "Toxic behavior", "Inappropriate language", "Advertising", "Personal information sharing", "Political/Religious discussion"));
         defaultConfig.set("grief", Arrays.asList("Unauthorized building destruction", "Claim violation", "Stealing from containers", "Lava/water griefing", "Crop/animal griefing"));
         defaultConfig.set("hack", Arrays.asList("Movement hacks (fly, speed, bhop)", "Combat hacks (killaura, reach, aimbot)", "X-ray/Cave finder", "Auto-clicker/Macro use", "Inventory hacks", "Packet manipulation"));
         defaultConfig.set("exploit", Arrays.asList("Duplication exploit", "Economy exploit", "Plugin exploit/abuse", "Map exploit", "Bug exploitation"));
         defaultConfig.save(this.reasonFile);
      } catch (IOException e) {
         this.plugin.getLogger().log(Level.SEVERE, "Failed to create default reasons file", e);
      }

   }

   public void openReasonSelector(Player player) {
      Inventory gui = Bukkit.createInventory((InventoryHolder)null, 27, "§1§lSelect Reason Category");
      int slot = 10;

      for(String category : this.reasons.keySet()) {
         ItemStack item = this.getCategoryItem(category);
         gui.setItem(slot++, item);
      }

      player.openInventory(gui);
   }

   private ItemStack getCategoryItem(String category) {
      Material material;
      switch (category.toLowerCase()) {
         case "chat":
            material = Material.PAPER;
            break;
         case "grief":
            material = Material.TNT;
            break;
         case "hack":
            material = Material.REDSTONE;
            break;
         case "exploit":
            material = VersionCompatibility.getCommandBlockMaterial();
            break;
         default:
            material = Material.BOOK;
      }

      ItemStack item = new ItemStack(material);
      ItemMeta meta = item.getItemMeta();
      if (meta != null) {
         meta.setDisplayName("§e§l" + category.toUpperCase());
         ArrayList<String> lore = new ArrayList();
         lore.add("§7Click to view reasons");
         lore.add("");
         List<String> categoryReasons = (List)this.reasons.get(category);

         for(int i = 0; i < Math.min(3, categoryReasons.size()); ++i) {
            lore.add("§f• " + (String)categoryReasons.get(i));
         }

         if (categoryReasons.size() > 3) {
            lore.add("§7... and " + (categoryReasons.size() - 3) + " more");
         }

         meta.setLore(lore);
         item.setItemMeta(meta);
      }

      return item;
   }

   public void openCategoryReasons(Player player, String category) {
      List<String> categoryReasons = (List)this.reasons.get(category);
      if (categoryReasons != null && !categoryReasons.isEmpty()) {
         int size = Math.min(54, (categoryReasons.size() + 8) / 9 * 9);
         Inventory gui = Bukkit.createInventory((InventoryHolder)null, size, "§2§l" + category.toUpperCase() + " Reasons");

         for(int i = 0; i < categoryReasons.size(); ++i) {
            ItemStack item = new ItemStack(VersionCompatibility.getWritableBookMaterial());
            ItemMeta meta = item.getItemMeta();
            if (meta != null) {
               meta.setDisplayName("§a" + (String)categoryReasons.get(i));
               meta.setLore(Arrays.asList("§7Click to use this reason"));
               item.setItemMeta(meta);
            }

            gui.setItem(i, item);
         }

         player.openInventory(gui);
      } else {
         player.sendMessage("§cNo reasons found for category: " + category);
      }
   }

   public void addReason(String category, String reason) {
      ((List)this.reasons.computeIfAbsent(category, (k) -> new ArrayList())).add(reason);
      this.saveReasons();
   }

   public void listReasons(Player player) {
      player.sendMessage("§6§l=== PUNISHMENT REASONS ===");

      for(Map.Entry<String, List<String>> entry : this.reasons.entrySet()) {
         player.sendMessage("§e" + ((String)entry.getKey()).toUpperCase() + ":");

         for(String reason : (List)entry.getValue()) {
            player.sendMessage("§f  • " + reason);
         }
      }

   }

   private void saveReasons() {
      for(Map.Entry<String, List<String>> entry : this.reasons.entrySet()) {
         this.reasonConfig.set((String)entry.getKey(), entry.getValue());
      }

      try {
         this.reasonConfig.save(this.reasonFile);
      } catch (IOException e) {
         this.plugin.getLogger().log(Level.SEVERE, "Failed to save reasons", e);
      }

   }

   public List<String> getReasons(String category) {
      return (List)this.reasons.getOrDefault(category, new ArrayList());
   }

   public Set<String> getCategories() {
      return this.reasons.keySet();
   }
}
