package com.anti.system.staff;

import com.anti.system.anticheat.DatabaseManager;
import com.anti.system.anticheat.DiscordWebhookManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.Duration;
import java.time.Instant;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.logging.Level;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

public class PunishmentManager {
   private final DatabaseManager database;
   private final DiscordWebhookManager discordManager;
   private final Map<UUID, Instant> mutedPlayers = new HashMap();
   private final Map<UUID, Instant> bannedPlayers = new HashMap();
   private final Map<UUID, Integer> warningCounts = new HashMap();
   private static final Pattern DURATION_PATTERN = Pattern.compile("(\\d+)([smhd])");

   public PunishmentManager(DatabaseManager database, DiscordWebhookManager discordManager) {
      this.database = database;
      this.discordManager = discordManager;
      this.loadActivePunishments();
   }

   public PunishmentManager(DatabaseManager database) {
      this.database = database;
      this.discordManager = null;
      this.loadActivePunishments();
   }

   public static long parseDuration(String duration) {
      if (!duration.equalsIgnoreCase("perm") && !duration.equalsIgnoreCase("permanent")) {
         Matcher matcher = DURATION_PATTERN.matcher(duration.toLowerCase());
         if (!matcher.matches()) {
            throw new IllegalArgumentException("Invalid duration format: " + duration);
         } else {
            int amount = Integer.parseInt(matcher.group(1));
            String unit;
            switch (unit = matcher.group(2)) {
               case "s":
                  return (long)amount / 60L;
               case "m":
                  return (long)amount;
               case "h":
                  return (long)amount * 60L;
               case "d":
                  return (long)amount * 60L * 24L;
               default:
                  throw new IllegalArgumentException("Invalid time unit: " + unit);
            }
         }
      } else {
         return -1L;
      }
   }

   public static String formatDuration(long minutes) {
      if (minutes <= 0L) {
         return "Permanent";
      } else if (minutes < 60L) {
         return minutes + " minute" + (minutes == 1L ? "" : "s");
      } else if (minutes < 1440L) {
         long hours = minutes / 60L;
         return hours + " hour" + (hours == 1L ? "" : "s");
      } else {
         long days = minutes / 1440L;
         return days + " day" + (days == 1L ? "" : "s");
      }
   }

   public void mutePlayer(UUID playerUuid, String staffName, String reason, String duration) {
      try {
         long durationMinutes = parseDuration(duration);
         Instant expiry = durationMinutes == -1L ? null : Instant.now().plus(Duration.ofMinutes(durationMinutes));
         this.mutedPlayers.put(playerUuid, expiry);
         this.database.logStaffAction(this.getStaffUUID(staffName), playerUuid, "MUTE", reason, durationMinutes);
         String playerName = this.getPlayerName(playerUuid);
         String durationText = durationMinutes == -1L ? "permanently" : "for " + formatDuration(durationMinutes);
         if (this.discordManager != null && this.discordManager.isEnabled()) {
            String action = "MUTED " + playerName + " " + durationText;
            this.discordManager.sendStaffAction(staffName, action, playerName, reason);
         }

         Player player = Bukkit.getPlayer(playerUuid);
         if (player != null) {
            player.sendMessage("§c§lMUTED\n§7You have been muted " + durationText + "\n§7Reason: " + reason);
         }

         String alertMessage = "§e[STAFF] §7" + staffName + " muted " + playerName + " " + durationText;

         for(Player staff : Bukkit.getOnlinePlayers()) {
            if (staff.hasPermission("antisystem.staff")) {
               staff.sendMessage(alertMessage);
            }
         }
      } catch (IllegalArgumentException var14) {
         Player staff = (Player)Bukkit.getOnlinePlayers().stream().filter((p) -> p.getName().equalsIgnoreCase(staffName)).findFirst().orElse((Object)null);
         if (staff != null) {
            staff.sendMessage("§cInvalid duration format: " + duration);
         }
      }

   }

   public void banPlayer(UUID playerUuid, String staffName, String reason, String duration) {
      try {
         long durationMinutes = parseDuration(duration);
         Instant expiry = durationMinutes == -1L ? null : Instant.now().plus(Duration.ofMinutes(durationMinutes));
         this.bannedPlayers.put(playerUuid, expiry);
         this.database.logStaffAction(this.getStaffUUID(staffName), playerUuid, "BAN", reason, durationMinutes);
         String playerName = this.getPlayerName(playerUuid);
         String durationText = durationMinutes == -1L ? "Permanent" : formatDuration(durationMinutes);
         if (this.discordManager != null && this.discordManager.isEnabled()) {
            String action = "BANNED " + playerName + " for " + durationText;
            this.discordManager.sendStaffAction(staffName, action, playerName, reason);
         }

         Player player = Bukkit.getPlayer(playerUuid);
         if (player != null) {
            player.kickPlayer("§4§lBANNED\n§7Duration: " + durationText + "\n§7Reason: " + reason + "\n§7Appeal at: discord.gg/yourserver");
         }

         String alertMessage = "§4[STAFF] §7" + staffName + " banned " + playerName + " for " + durationText;

         for(Player staff : Bukkit.getOnlinePlayers()) {
            if (staff.hasPermission("antisystem.staff")) {
               staff.sendMessage(alertMessage);
            }
         }
      } catch (IllegalArgumentException var14) {
         Player staff = (Player)Bukkit.getOnlinePlayers().stream().filter((p) -> p.getName().equalsIgnoreCase(staffName)).findFirst().orElse((Object)null);
         if (staff != null) {
            staff.sendMessage("§cInvalid duration format: " + duration);
         }
      }

   }

   public void warnPlayer(UUID playerUuid, String staffName, String reason) {
      int warnings = (Integer)this.warningCounts.getOrDefault(playerUuid, 0) + 1;
      this.warningCounts.put(playerUuid, warnings);
      this.database.logStaffAction(this.getStaffUUID(staffName), playerUuid, "WARN", reason, (Long)null);
      String playerName = this.getPlayerName(playerUuid);
      if (this.discordManager != null && this.discordManager.isEnabled()) {
         String action = "WARNED " + playerName + " (#" + warnings + ")";
         this.discordManager.sendStaffAction(staffName, action, playerName, reason);
      }

      Player player = Bukkit.getPlayer(playerUuid);
      if (player != null) {
         player.sendMessage("§e⚠ WARNING ⚠\n§7Reason: " + reason + "\n§7This is warning #" + warnings + ". Please follow server rules.");
      }

      String alertMessage = "§e[STAFF] §7" + staffName + " warned " + playerName + " (#" + warnings + ")";

      for(Player staff : Bukkit.getOnlinePlayers()) {
         if (staff.hasPermission("antisystem.staff")) {
            staff.sendMessage(alertMessage);
         }
      }

   }

   public boolean isMuted(UUID playerUuid) {
      Instant expiry = (Instant)this.mutedPlayers.get(playerUuid);
      if (expiry == null) {
         return false;
      } else if (Instant.now().isAfter(expiry)) {
         this.mutedPlayers.remove(playerUuid);
         return false;
      } else {
         return true;
      }
   }

   public boolean isBanned(UUID playerUuid) {
      Instant expiry = (Instant)this.bannedPlayers.get(playerUuid);
      if (expiry == null) {
         return false;
      } else if (Instant.now().isAfter(expiry)) {
         this.bannedPlayers.remove(playerUuid);
         return false;
      } else {
         return true;
      }
   }

   public String getRemainingMuteTime(UUID playerUuid) {
      Instant expiry = (Instant)this.mutedPlayers.get(playerUuid);
      if (expiry == null) {
         return "Permanent";
      } else {
         Duration remaining = Duration.between(Instant.now(), expiry);
         if (remaining.isNegative()) {
            return "Expired";
         } else {
            long minutes = remaining.toMinutes();
            return formatDuration(minutes);
         }
      }
   }

   public void unmutePlayer(UUID playerUuid, String staffName) {
      if (this.mutedPlayers.remove(playerUuid) != null) {
         this.database.logStaffAction(this.getStaffUUID(staffName), playerUuid, "UNMUTE", "Unmuted by staff", (Long)null);
         Player player = Bukkit.getPlayer(playerUuid);
         if (player != null) {
            player.sendMessage("§a§lUNMUTED §7You have been unmuted by staff.");
         }

         String alertMessage = "§a[STAFF] §7" + staffName + " unmuted " + this.getPlayerName(playerUuid);

         for(Player staff : Bukkit.getOnlinePlayers()) {
            if (staff.hasPermission("antisystem.staff")) {
               staff.sendMessage(alertMessage);
            }
         }
      }

   }

   public void unbanPlayer(UUID playerUuid, String staffName) {
      if (this.bannedPlayers.remove(playerUuid) != null) {
         this.database.logStaffAction(this.getStaffUUID(staffName), playerUuid, "UNBAN", "Unbanned by staff", (Long)null);
         String alertMessage = "§a[STAFF] §7" + staffName + " unbanned " + this.getPlayerName(playerUuid);

         for(Player staff : Bukkit.getOnlinePlayers()) {
            if (staff.hasPermission("antisystem.staff")) {
               staff.sendMessage(alertMessage);
            }
         }
      }

   }

   public int getWarningCount(UUID playerUuid) {
      return (Integer)this.warningCounts.getOrDefault(playerUuid, 0);
   }

   private void loadActivePunishments() {
      try {
         if (!this.checkDatabaseSchema()) {
            return;
         }

         String muteQuery = "SELECT target_uuid, duration_minutes, timestamp FROM staff_actions WHERE action_type = 'MUTE' AND active = 1 ORDER BY timestamp DESC";
         PreparedStatement stmt = this.database.getConnection().prepareStatement(muteQuery);

         try {
            ResultSet rs = stmt.executeQuery();

            try {
               while(rs.next()) {
                  UUID playerUuid = UUID.fromString(rs.getString("target_uuid"));
                  long durationMinutes = rs.getLong("duration_minutes");
                  long timestamp = rs.getLong("timestamp");
                  if (durationMinutes == -1L) {
                     this.mutedPlayers.put(playerUuid, (Object)null);
                  } else {
                     Instant expiry = Instant.ofEpochMilli(timestamp).plus(Duration.ofMinutes(durationMinutes));
                     if (Instant.now().isBefore(expiry)) {
                        this.mutedPlayers.put(playerUuid, expiry);
                     }
                  }
               }
            } catch (Throwable var21) {
               if (rs != null) {
                  try {
                     rs.close();
                  } catch (Throwable var16) {
                     var21.addSuppressed(var16);
                  }
               }

               throw var21;
            }

            if (rs != null) {
               rs.close();
            }
         } catch (Throwable var22) {
            if (stmt != null) {
               try {
                  stmt.close();
               } catch (Throwable var15) {
                  var22.addSuppressed(var15);
               }
            }

            throw var22;
         }

         if (stmt != null) {
            stmt.close();
         }

         String banQuery = "SELECT target_uuid, duration_minutes, timestamp FROM staff_actions WHERE action_type = 'BAN' AND active = 1 ORDER BY timestamp DESC";
         PreparedStatement stmt = this.database.getConnection().prepareStatement(banQuery);

         try {
            ResultSet rs = stmt.executeQuery();

            try {
               while(rs.next()) {
                  UUID playerUuid = UUID.fromString(rs.getString("target_uuid"));
                  long durationMinutes = rs.getLong("duration_minutes");
                  long timestamp = rs.getLong("timestamp");
                  if (durationMinutes == -1L) {
                     this.bannedPlayers.put(playerUuid, (Object)null);
                  } else {
                     Instant expiry = Instant.ofEpochMilli(timestamp).plus(Duration.ofMinutes(durationMinutes));
                     if (Instant.now().isBefore(expiry)) {
                        this.bannedPlayers.put(playerUuid, expiry);
                     }
                  }
               }
            } catch (Throwable var19) {
               if (rs != null) {
                  try {
                     rs.close();
                  } catch (Throwable var14) {
                     var19.addSuppressed(var14);
                  }
               }

               throw var19;
            }

            if (rs != null) {
               rs.close();
            }
         } catch (Throwable var20) {
            if (stmt != null) {
               try {
                  stmt.close();
               } catch (Throwable var13) {
                  var20.addSuppressed(var13);
               }
            }

            throw var20;
         }

         if (stmt != null) {
            stmt.close();
         }

         String warningQuery = "SELECT target_uuid, COUNT(*) as warning_count FROM staff_actions WHERE action_type = 'WARN' GROUP BY target_uuid";
         PreparedStatement stmt = this.database.getConnection().prepareStatement(warningQuery);

         try {
            ResultSet rs = stmt.executeQuery();

            try {
               while(rs.next()) {
                  UUID playerUuid = UUID.fromString(rs.getString("target_uuid"));
                  int count = rs.getInt("warning_count");
                  this.warningCounts.put(playerUuid, count);
               }
            } catch (Throwable var17) {
               if (rs != null) {
                  try {
                     rs.close();
                  } catch (Throwable var12) {
                     var17.addSuppressed(var12);
                  }
               }

               throw var17;
            }

            if (rs != null) {
               rs.close();
            }
         } catch (Throwable var18) {
            if (stmt != null) {
               try {
                  stmt.close();
               } catch (Throwable var11) {
                  var18.addSuppressed(var11);
               }
            }

            throw var18;
         }

         if (stmt != null) {
            stmt.close();
         }
      } catch (SQLException e) {
         Bukkit.getLogger().log(Level.WARNING, "[AntiSystem] Failed to load active punishments from database", e);
      } catch (IllegalArgumentException e) {
         Bukkit.getLogger().log(Level.WARNING, "[AntiSystem] Invalid data format in punishment records", e);
      }

   }

   private UUID getStaffUUID(String staffName) {
      Player staff = (Player)Bukkit.getOnlinePlayers().stream().filter((p) -> p.getName().equalsIgnoreCase(staffName)).findFirst().orElse((Object)null);
      return staff != null ? staff.getUniqueId() : UUID.randomUUID();
   }

   private String getPlayerName(UUID playerUuid) {
      Player player = Bukkit.getPlayer(playerUuid);
      return player != null ? player.getName() : "Unknown";
   }

   private boolean checkDatabaseSchema() {
      try {
         String testQuery = "SELECT target_uuid FROM staff_actions LIMIT 1";
         PreparedStatement stmt = this.database.getConnection().prepareStatement(testQuery);

         boolean var3;
         try {
            stmt.executeQuery();
            var3 = true;
         } catch (Throwable var6) {
            if (stmt != null) {
               try {
                  stmt.close();
               } catch (Throwable var5) {
                  var6.addSuppressed(var5);
               }
            }

            throw var6;
         }

         if (stmt != null) {
            stmt.close();
         }

         return var3;
      } catch (SQLException var7) {
         return false;
      } catch (Exception var8) {
         return false;
      }
   }

   public void cleanupExpired() {
      Instant now = Instant.now();
      this.mutedPlayers.entrySet().removeIf((entry) -> entry.getValue() != null && now.isAfter((Instant)entry.getValue()));
      this.bannedPlayers.entrySet().removeIf((entry) -> entry.getValue() != null && now.isAfter((Instant)entry.getValue()));
   }
}
