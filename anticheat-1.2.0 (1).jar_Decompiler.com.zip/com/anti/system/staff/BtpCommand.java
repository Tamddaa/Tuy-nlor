package com.anti.system.staff;

import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class BtpCommand implements CommandExecutor {
   private final StaffManager staffManager;

   public BtpCommand(StaffManager staffManager) {
      this.staffManager = staffManager;
   }

   public boolean onCommand(CommandSender sender, Command command, String label, String[] args2) {
      if (sender == null) {
         return true;
      } else if (!(sender instanceof Player)) {
         sender.sendMessage("§cOnly players can use this command!");
         return true;
      } else {
         Player staff = (Player)sender;
         if (!staff.hasPermission("antisystem.staff.btp")) {
            staff.sendMessage("§cNo permission!");
            return true;
         } else if (this.staffManager == null) {
            staff.sendMessage("§cStaff manager not initialized!");
            return true;
         } else {
            Location lastLoc = this.staffManager.getLastLocation(staff);
            if (lastLoc == null) {
               staff.sendMessage("§cNo previous location stored!");
               return true;
            } else {
               staff.teleport(lastLoc);
               staff.sendMessage("§aTeleported back to previous location");
               return true;
            }
         }
      }
   }
}
