package com.anti.system.staff;

import com.anti.system.utils.VersionCompatibility;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class QuickModCommand implements CommandExecutor, TabCompleter {
   public boolean onCommand(CommandSender sender, Command command, String label, String[] args2) {
      if (sender == null) {
         return true;
      } else if (!(sender instanceof Player)) {
         sender.sendMessage("§cOnly players can use this command!");
         return true;
      } else {
         Player staff = (Player)sender;
         if (!staff.hasPermission("antisystem.staff.quickmod")) {
            staff.sendMessage("§cNo permission!");
            return true;
         } else if (args2.length == 0) {
            staff.sendMessage("§cUsage: /quickmod <player>");
            return true;
         } else {
            Player target = (Player)Bukkit.getOnlinePlayers().stream().filter((p) -> p.getName().equalsIgnoreCase(args2[0])).findFirst().orElse((Object)null);
            if (target == null) {
               staff.sendMessage("§cPlayer not found!");
               return true;
            } else {
               this.openQuickModGUI(staff, target);
               return true;
            }
         }
      }
   }

   public void openQuickModGUI(Player staff, Player target) {
      Inventory gui = Bukkit.createInventory((InventoryHolder)null, 27, "§4§lQuickMod: " + target.getName());
      ItemStack warnItem = new ItemStack(VersionCompatibility.getOrangeConcreteMaterial());
      ItemMeta warnMeta = warnItem.getItemMeta();
      warnMeta.setDisplayName("§6§l⚠ Warn Player");
      warnMeta.setLore(Arrays.asList("§7Give this player a warning", "§eClick to select reason"));
      warnItem.setItemMeta(warnMeta);
      gui.setItem(10, warnItem);
      ItemStack muteItem = new ItemStack(VersionCompatibility.getRedConcreteMaterial());
      ItemMeta muteMeta = muteItem.getItemMeta();
      muteMeta.setDisplayName("§c§l\ud83d\udd07 Mute Player");
      muteMeta.setLore(Arrays.asList("§7Mute this player", "§eOptions: 5m, 15m, 1h, 6h"));
      muteItem.setItemMeta(muteMeta);
      gui.setItem(11, muteItem);
      ItemStack kickItem = new ItemStack(VersionCompatibility.getYellowConcreteMaterial());
      ItemMeta kickMeta = kickItem.getItemMeta();
      kickMeta.setDisplayName("§e§l\ud83d\udd28 Kick Player");
      kickMeta.setLore(Arrays.asList("§7Kick this player from server", "§eClick to select reason"));
      kickItem.setItemMeta(kickMeta);
      gui.setItem(12, kickItem);
      ItemStack banItem = new ItemStack(VersionCompatibility.getBlackConcreteMaterial());
      ItemMeta banMeta = banItem.getItemMeta();
      banMeta.setDisplayName("§4§l⛔ Ban Player");
      banMeta.setLore(Arrays.asList("§7Ban this player", "§eOptions: 1d, 7d, 30d, perm"));
      banItem.setItemMeta(banMeta);
      gui.setItem(13, banItem);
      ItemStack notesItem = new ItemStack(VersionCompatibility.getWritableBookMaterial());
      ItemMeta notesMeta = notesItem.getItemMeta();
      notesMeta.setDisplayName("§9§l\ud83d\udcc4 Player Notes");
      notesMeta.setLore(Arrays.asList("§7View/add notes for this player", "§eClick to manage"));
      notesItem.setItemMeta(notesMeta);
      gui.setItem(14, notesItem);
      ItemStack freezeItem = new ItemStack(Material.ICE);
      ItemMeta freezeMeta = freezeItem.getItemMeta();
      freezeMeta.setDisplayName("§b§l\ud83e\uddca Freeze Player");
      freezeMeta.setLore(Arrays.asList("§7Freeze player for screenshare", "§eAuto-sends SS instructions"));
      freezeItem.setItemMeta(freezeMeta);
      gui.setItem(15, freezeItem);
      ItemStack tpItem = new ItemStack(Material.ENDER_PEARL);
      ItemMeta tpMeta = tpItem.getItemMeta();
      tpMeta.setDisplayName("§d§l✈ Teleport");
      tpMeta.setLore(Arrays.asList("§7Teleport options", "§eTo player, bring here, smart TP"));
      tpItem.setItemMeta(tpMeta);
      gui.setItem(16, tpItem);
      ItemStack inspectItem = new ItemStack(VersionCompatibility.getSpyglassMaterial());
      ItemMeta inspectMeta = inspectItem.getItemMeta();
      inspectMeta.setDisplayName("§a§l\ud83d\udd0d Inspect Player");
      inspectMeta.setLore(Arrays.asList("§7View player information", "§eInventory, ender chest, stats"));
      inspectItem.setItemMeta(inspectMeta);
      gui.setItem(19, inspectItem);
      ItemStack playerHead = new ItemStack(VersionCompatibility.getPlayerHeadMaterial());
      ItemMeta headMeta = playerHead.getItemMeta();
      headMeta.setDisplayName("§f§l" + target.getName());
      headMeta.setLore(Arrays.asList("§7Target: " + target.getName(), "§7Online: " + target.isOnline(), "§7World: " + target.getWorld().getName()));
      playerHead.setItemMeta(headMeta);
      gui.setItem(4, playerHead);
      staff.openInventory(gui);
   }

   public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args2) {
      return args2.length == 1 ? (List)Bukkit.getOnlinePlayers().stream().map(OfflinePlayer::getName).filter((name) -> name.toLowerCase().startsWith(args2[0].toLowerCase())).collect(Collectors.toList()) : Arrays.asList();
   }
}
