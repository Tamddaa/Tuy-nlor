package com.anti.system.staff;

import java.util.Arrays;
import java.util.List;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

public class StaffModeCommand implements CommandExecutor, TabCompleter {
   private final StaffManager staffManager;

   public StaffModeCommand(StaffManager staffManager) {
      this.staffManager = staffManager;
   }

   public boolean onCommand(CommandSender sender, Command command, String label, String[] args2) {
      if (command != null && sender != null) {
         if (!(sender instanceof Player)) {
            sender.sendMessage("This command can only be used by players.");
            return true;
         } else {
            Player player = (Player)sender;
            if (!player.isOp() && !player.hasPermission("antisystem.staff.mode")) {
               player.sendMessage("§cYou don't have permission to use staff mode.");
               return true;
            } else {
               if (this.staffManager.isInStaffMode(player)) {
                  this.staffManager.disableStaffMode(player);
                  player.sendMessage("§c§lSTAFF§r §7Staff mode disabled.");
               } else {
                  this.staffManager.enableStaffMode(player);
                  player.sendMessage("§a§lSTAFF§r §7Staff mode enabled. You are now invisible and have special permissions.");
               }

               return true;
            }
         }
      } else {
         return false;
      }
   }

   public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args2) {
      return Arrays.asList();
   }
}
