package com.anti.system.staff;

import java.util.Arrays;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class LocateCommand implements CommandExecutor {
   public boolean onCommand(CommandSender sender, Command command, String label, String[] args2) {
      if (sender == null) {
         return true;
      } else if (!(sender instanceof Player)) {
         sender.sendMessage("§cOnly players can use this command!");
         return true;
      } else {
         Player staff = (Player)sender;
         if (!staff.hasPermission("antisystem.staff.locate")) {
            staff.sendMessage("§cNo permission!");
            return true;
         } else if (args2.length == 0) {
            staff.sendMessage("§cUsage: /locate <player>");
            return true;
         } else {
            Player target = (Player)Bukkit.getOnlinePlayers().stream().filter((p) -> p.getName().equalsIgnoreCase(args2[0])).findFirst().orElse((Object)null);
            if (target == null) {
               staff.sendMessage("§cPlayer not found!");
               return true;
            } else {
               this.showPlayerLocation(staff, target);
               return true;
            }
         }
      }
   }

   private void showPlayerLocation(Player staff, Player target) {
      double distance = staff.getLocation().distance(target.getLocation());
      int x = target.getLocation().getBlockX();
      int y = target.getLocation().getBlockY();
      int z = target.getLocation().getBlockZ();
      String world = target.getWorld().getName();
      String region = this.getRegionName(target);
      staff.sendMessage("§6§l=== PLAYER LOCATION ===");
      staff.sendMessage("§ePlayer: §f" + target.getName());
      staff.sendMessage("§eWorld: §f" + world);
      staff.sendMessage("§eCoordinates: §f" + x + ", " + y + ", " + z);
      staff.sendMessage("§eRegion: §f" + region);
      staff.sendMessage("§eDistance: §f" + String.format("%.1f blocks", distance));
      this.openTeleportGUI(staff, target);
   }

   private void openTeleportGUI(Player staff, Player target) {
      Inventory gui = Bukkit.createInventory((InventoryHolder)null, 9, "§1Teleport Options: " + target.getName());
      ItemStack stpItem = new ItemStack(Material.ENDER_PEARL);
      ItemMeta stpMeta = stpItem.getItemMeta();
      stpMeta.setDisplayName("§a§lSmart Teleport");
      stpMeta.setLore(Arrays.asList("§7Teleport behind player safely", "§eClick to teleport"));
      stpItem.setItemMeta(stpMeta);
      gui.setItem(2, stpItem);
      ItemStack bringItem = new ItemStack(Material.FISHING_ROD);
      ItemMeta bringMeta = bringItem.getItemMeta();
      bringMeta.setDisplayName("§9§lBring Player");
      bringMeta.setLore(Arrays.asList("§7Teleport player to you", "§eClick to bring"));
      bringItem.setItemMeta(bringMeta);
      gui.setItem(4, bringItem);
      ItemStack directItem = new ItemStack(Material.COMPASS);
      ItemMeta directMeta = directItem.getItemMeta();
      directMeta.setDisplayName("§d§lDirect Teleport");
      directMeta.setLore(Arrays.asList("§7Teleport directly to player", "§eClick to teleport"));
      directItem.setItemMeta(directMeta);
      gui.setItem(6, directItem);
      staff.openInventory(gui);
   }

   private String getRegionName(Player player) {
      int x = player.getLocation().getBlockX();
      int z = player.getLocation().getBlockZ();
      if (Math.abs(x) < 100 && Math.abs(z) < 100) {
         return "Spawn Area";
      } else if (Math.abs(x) < 1000 && Math.abs(z) < 1000) {
         return "Central Region";
      } else {
         return Math.abs(x) < 5000 && Math.abs(z) < 5000 ? "Wilderness" : "Far Lands";
      }
   }
}
