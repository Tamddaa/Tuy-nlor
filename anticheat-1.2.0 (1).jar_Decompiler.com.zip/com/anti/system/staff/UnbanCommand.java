package com.anti.system.staff;

import java.util.Arrays;
import java.util.List;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

public class UnbanCommand implements CommandExecutor, TabCompleter {
   private final PunishmentManager punishmentManager;

   public UnbanCommand(PunishmentManager punishmentManager) {
      this.punishmentManager = punishmentManager;
   }

   public boolean onCommand(CommandSender sender, Command command, String label, String[] args2) {
      if (sender != null && sender instanceof Player) {
         Player staff = (Player)sender;
         if (!staff.hasPermission("antisystem.staff.unban")) {
            staff.sendMessage("§cYou don't have permission to unban players.");
            return true;
         } else if (args2.length != 1) {
            staff.sendMessage("§cUsage: /unban <player>");
            return true;
         } else {
            Player onlineTarget = null;

            for(Player player : Bukkit.getOnlinePlayers()) {
               if (player.getName().equalsIgnoreCase(args2[0])) {
                  onlineTarget = player;
                  break;
               }
            }

            String targetName;
            UUID targetUuid;
            if (onlineTarget != null) {
               targetUuid = onlineTarget.getUniqueId();
               targetName = onlineTarget.getName();
            } else {
               OfflinePlayer offlineTarget = null;
               OfflinePlayer[] var15 = Bukkit.getOfflinePlayers();
               int var11 = var15.length;
               int var12 = 0;

               while(true) {
                  if (var12 < var11) {
                     OfflinePlayer op = var15[var12];
                     if (op.getName() == null || !op.getName().equalsIgnoreCase(args2[0])) {
                        ++var12;
                        continue;
                     }

                     offlineTarget = op;
                  }

                  if (offlineTarget == null || !offlineTarget.hasPlayedBefore()) {
                     staff.sendMessage("§cPlayer not found: " + args2[0]);
                     return true;
                  }

                  targetUuid = offlineTarget.getUniqueId();
                  targetName = offlineTarget.getName();
                  break;
               }
            }

            if (!this.punishmentManager.isBanned(targetUuid)) {
               staff.sendMessage("§cPlayer " + targetName + " is not banned.");
               return true;
            } else {
               this.punishmentManager.unbanPlayer(targetUuid, staff.getName());
               staff.sendMessage("§a§lSTAFF§r §7" + targetName + " has been unbanned.");
               return true;
            }
         }
      } else {
         if (sender != null) {
            sender.sendMessage("This command can only be used by players.");
         }

         return true;
      }
   }

   public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args2) {
      return Arrays.asList();
   }
}
