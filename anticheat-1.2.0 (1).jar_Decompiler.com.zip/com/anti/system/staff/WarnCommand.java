package com.anti.system.staff;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class WarnCommand implements CommandExecutor {
   private final PunishmentManager punishmentManager;

   public WarnCommand(PunishmentManager punishmentManager) {
      this.punishmentManager = punishmentManager;
   }

   public boolean onCommand(CommandSender sender, Command command, String label, String[] args2) {
      if (!sender.hasPermission("antisystem.staff.warn")) {
         sender.sendMessage("§cYou don't have permission to use this command.");
         return true;
      } else if (args2.length < 2) {
         sender.sendMessage("§cUsage: /warn <player> <reason>");
         return true;
      } else {
         String targetName = args2[0];
         Player target = null;

         for(Player player : Bukkit.getOnlinePlayers()) {
            if (player.getName().equalsIgnoreCase(targetName)) {
               target = player;
               break;
            }
         }

         if (target == null) {
            sender.sendMessage("§cPlayer not found or not online.");
            return true;
         } else {
            StringBuilder reasonBuilder = new StringBuilder();

            for(int i = 1; i < args2.length; ++i) {
               reasonBuilder.append(args2[i]).append(" ");
            }

            String reason = reasonBuilder.toString().trim();

            try {
               this.punishmentManager.warnPlayer(target.getUniqueId(), sender.getName(), reason);
               sender.sendMessage("§a" + target.getName() + " has been warned for: " + reason);
            } catch (Exception e) {
               sender.sendMessage("§cFailed to warn player: " + e.getMessage());
            }

            return true;
         }
      }
   }
}
