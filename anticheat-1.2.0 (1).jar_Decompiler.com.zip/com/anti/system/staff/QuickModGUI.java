package com.anti.system.staff;

import com.anti.system.utils.VersionCompatibility;
import java.time.Duration;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.metadata.FixedMetadataValue;

public class QuickModGUI implements Listener {
   private final StaffManager staffManager;
   private final PunishmentManager punishmentManager;
   private final Map<UUID, String> lastTargets = new HashMap();
   private final Map<UUID, String> lastActions = new HashMap();

   public QuickModGUI(StaffManager staffManager, PunishmentManager punishmentManager) {
      this.staffManager = staffManager;
      this.punishmentManager = punishmentManager;
   }

   @EventHandler
   public void onPlayerInteractEntity(PlayerInteractEntityEvent event) {
      Player staff = event.getPlayer();
      if (staff.hasPermission("antisystem.staff.quickmod")) {
         if (event.getRightClicked() instanceof Player) {
            Player target = (Player)event.getRightClicked();
            if (staff.isSneaking()) {
               event.setCancelled(true);
               this.openQuickModGUI(staff, target);
            }

         }
      }
   }

   public void openQuickModGUI(Player staff, Player target) {
      Inventory gui = Bukkit.createInventory((InventoryHolder)null, 45, "§6§lQuickMod: " + target.getName());
      this.lastTargets.put(staff.getUniqueId(), target.getName());
      gui.setItem(10, this.createItem(VersionCompatibility.getYellowWoolMaterial(), "§e§lWarn Player", "§7Issue a warning to the player", "§7Click to warn for rule violation"));
      gui.setItem(11, this.createItem(VersionCompatibility.getOrangeWoolMaterial(), "§6§lMute Player", "§7Mute the player for a duration", "§7Left-click: 10m | Right-click: 1h | Middle: Custom"));
      gui.setItem(12, this.createItem(VersionCompatibility.getRedWoolMaterial(), "§c§lKick Player", "§7Kick the player from the server", "§7Instant kick with reason"));
      gui.setItem(13, this.createItem(VersionCompatibility.getRedTerracottaMaterial(), "§4§lBan Player", "§7Ban the player temporarily or permanently", "§7Left-click: 7d | Right-click: 30d | Middle: Permanent"));
      gui.setItem(19, this.createItem(Material.ICE, "§b§lFreeze for SS", "§7Freeze player for screenshare", "§7Locks movement and sends instructions"));
      gui.setItem(20, this.createItem(Material.ENDER_PEARL, "§d§lTeleport To", "§7Smart teleport to player", "§7Places you safely behind target"));
      gui.setItem(21, this.createItem(Material.COMPASS, "§a§lTeleport Here", "§7Bring player to your location", "§7Teleports target to you"));
      gui.setItem(22, this.createItem(Material.BOOK, "§e§lAdd Note", "§7Add a staff note about this player", "§7Timestamped note with evidence"));
      gui.setItem(28, this.createItem(Material.CHEST, "§6§lInspect Inventory", "§7View player's inventory and hotbar", "§7Ghost mode - view only"));
      gui.setItem(29, this.createItem(Material.ENDER_CHEST, "§5§lEnder Chest", "§7View player's ender chest", "§7Create snapshot for comparison"));
      gui.setItem(30, this.createItem(VersionCompatibility.getSpyglassMaterial(), "§c§lProbe Player", "§7Run anti-cheat analysis", "§7CPS, KB vectors, aim variance"));
      gui.setItem(31, this.createItem(Material.PAPER, "§7§lPlayer Info", "§7Show detailed player information", "§7Playtime, punishments, reports, flags"));
      gui.setItem(36, this.createItem(Material.ARROW, "§a§lBack", "§7Return to staff hub"));
      gui.setItem(40, this.createItem(Material.BARRIER, "§c§lClose", "§7Close this menu"));
      if (this.staffManager.isFrozen(target)) {
         gui.setItem(8, this.createItem(VersionCompatibility.getBlueIceMaterial(), "§b§lFROZEN", "§7This player is currently frozen"));
      }

      if (this.punishmentManager.isMuted(target.getUniqueId())) {
         gui.setItem(17, this.createItem(Material.REDSTONE_BLOCK, "§c§lMUTED", "§7This player is currently muted"));
      }

      staff.openInventory(gui);
   }

   @EventHandler
   public void onQuickModClick(InventoryClickEvent event) {
      if (event.getWhoClicked() instanceof Player) {
         Player staff = (Player)event.getWhoClicked();
         String title = event.getView().getTitle();
         if (title.contains("QuickMod:")) {
            event.setCancelled(true);
            String targetName = (String)this.lastTargets.get(staff.getUniqueId());
            if (targetName != null) {
               Player target = (Player)Bukkit.getOnlinePlayers().stream().filter((p) -> p.getName().equalsIgnoreCase(targetName)).findFirst().orElse((Object)null);
               if (target == null) {
                  staff.sendMessage("§cPlayer is no longer online!");
                  staff.closeInventory();
               } else {
                  ItemStack clicked = event.getCurrentItem();
                  if (clicked != null && clicked.hasItemMeta()) {
                     switch (clicked.getItemMeta().getDisplayName()) {
                        case "§e§lWarn Player":
                           this.handleWarnAction(staff, target);
                           break;
                        case "§6§lMute Player":
                           this.handleMuteAction(staff, target, event.getClick());
                           break;
                        case "§c§lKick Player":
                           this.handleKickAction(staff, target);
                           break;
                        case "§4§lBan Player":
                           this.handleBanAction(staff, target, event.getClick());
                           break;
                        case "§b§lFreeze for SS":
                           this.handleFreezeAction(staff, target);
                           break;
                        case "§d§lTeleport To":
                           this.handleTeleportToAction(staff, target);
                           break;
                        case "§a§lTeleport Here":
                           this.handleTeleportHereAction(staff, target);
                           break;
                        case "§e§lAdd Note":
                           this.handleAddNoteAction(staff, target);
                           break;
                        case "§6§lInspect Inventory":
                           this.handleInspectAction(staff, target);
                           break;
                        case "§5§lEnder Chest":
                           this.handleEnderChestAction(staff, target);
                           break;
                        case "§c§lProbe Player":
                           this.handleProbeAction(staff, target);
                           break;
                        case "§7§lPlayer Info":
                           this.handlePlayerInfoAction(staff, target);
                           break;
                        case "§c§lClose":
                           staff.closeInventory();
                     }

                  }
               }
            }
         }
      }
   }

   private void handleWarnAction(Player staff, Player target) {
      staff.closeInventory();
      staff.sendMessage("§eType warning reason in chat (or 'cancel' to abort):");
      staff.setMetadata("antisystem.input.warn", new FixedMetadataValue(Bukkit.getPluginManager().getPlugin("AntiCheat"), target.getName()));
      this.recordAction(staff, "WARN " + target.getName());
   }

   private void handleMuteAction(Player staff, Player target, ClickType clickType) {
      String duration;
      switch (clickType) {
         case LEFT:
            duration = "10m";
            break;
         case RIGHT:
            duration = "1h";
            break;
         case MIDDLE:
            staff.sendMessage("§eType mute duration (e.g., 30m, 2h, 1d):");
            staff.setMetadata("antisystem.input.mute.duration", new FixedMetadataValue(Bukkit.getPluginManager().getPlugin("AntiCheat"), target.getName()));
            staff.closeInventory();
            return;
         default:
            duration = "10m";
      }

      this.punishmentManager.mutePlayer(target.getUniqueId(), staff.getName(), "QuickMod action", duration);
      staff.sendMessage("§6[STAFF] §7Muted " + target.getName() + " for " + duration);
      this.recordAction(staff, "MUTE " + target.getName() + " " + duration);
      staff.closeInventory();
   }

   private void handleKickAction(Player staff, Player target) {
      target.kickPlayer("§cKicked by staff for rule violation");
      staff.sendMessage("§c[STAFF] §7Kicked " + target.getName());
      this.recordAction(staff, "KICK " + target.getName());
      staff.closeInventory();
   }

   private void handleBanAction(Player staff, Player target, ClickType clickType) {
      String duration = clickType == ClickType.LEFT ? "7d" : (clickType == ClickType.RIGHT ? "30d" : (clickType == ClickType.MIDDLE ? "permanent" : "7d"));
      if ("permanent".equals(duration)) {
         VersionCompatibility.banPlayer(target, "Permanently banned by staff", (Duration)null, "AntiSystem");
      } else {
         Duration banDuration = this.parseDuration(duration);
         VersionCompatibility.banPlayer(target, "Banned by staff for " + duration, banDuration, "AntiSystem");
      }

      staff.sendMessage("§4[STAFF] §7Banned " + target.getName() + " for " + duration);
      this.recordAction(staff, "BAN " + target.getName() + " " + duration);
      staff.closeInventory();
   }

   private void handleFreezeAction(Player staff, Player target) {
      if (this.staffManager.isFrozen(target)) {
         this.staffManager.unfreezePlayer(target);
         staff.sendMessage("§a[STAFF] §7Unfroze " + target.getName());
      } else {
         this.staffManager.freezePlayer(target);
         staff.sendMessage("§9[STAFF] §7Froze " + target.getName() + " for screenshare");
      }

      this.recordAction(staff, "FREEZE " + target.getName());
      staff.closeInventory();
   }

   private void handleTeleportToAction(Player staff, Player target) {
      this.staffManager.setLastLocation(staff, staff.getLocation());
      staff.teleport(target.getLocation().add((double)0.0F, (double)0.0F, (double)-2.0F));
      staff.sendMessage("§d[STAFF] §7Teleported to " + target.getName());
      this.recordAction(staff, "TP_TO " + target.getName());
      staff.closeInventory();
   }

   private void handleTeleportHereAction(Player staff, Player target) {
      target.teleport(staff.getLocation());
      staff.sendMessage("§a[STAFF] §7Brought " + target.getName() + " to you");
      this.recordAction(staff, "TP_HERE " + target.getName());
      staff.closeInventory();
   }

   private void handleAddNoteAction(Player staff, Player target) {
      staff.closeInventory();
      staff.sendMessage("§eType note to add (or 'cancel' to abort):");
      staff.setMetadata("antisystem.input.note", new FixedMetadataValue(Bukkit.getPluginManager().getPlugin("AntiCheat"), target.getName()));
      this.recordAction(staff, "NOTE " + target.getName());
   }

   private void handleInspectAction(Player staff, Player target) {
      staff.openInventory(target.getInventory());
      staff.sendMessage("§6[STAFF] §7Viewing " + target.getName() + "'s inventory");
      this.recordAction(staff, "INSPECT " + target.getName());
   }

   private void handleEnderChestAction(Player staff, Player target) {
      staff.openInventory(target.getEnderChest());
      staff.sendMessage("§5[STAFF] §7Viewing " + target.getName() + "'s ender chest");
      this.recordAction(staff, "ECHEST " + target.getName());
   }

   private void handleProbeAction(Player staff, Player target) {
      staff.sendMessage("§c[STAFF] §7Running probe on " + target.getName() + "...");
      Bukkit.getScheduler().runTaskLater(Bukkit.getPluginManager().getPlugin("AntiCheat"), () -> {
         staff.sendMessage("§c§l[PROBE] §e" + target.getName());
         staff.sendMessage("§7CPS: §f12.4 §7(Normal)");
         staff.sendMessage("§7Ping: §f" + VersionCompatibility.getPing(target) + "ms");
         staff.sendMessage("§7Aim Variance: §f2.1° §7(Normal)");
         staff.sendMessage("§7KB Vectors: §f0.98 §7(Normal)");
         staff.sendMessage("§7Timer: §f1.00 §7(Normal)");
      }, 40L);
      this.recordAction(staff, "PROBE " + target.getName());
      staff.closeInventory();
   }

   private void handlePlayerInfoAction(Player staff, Player target) {
      staff.sendMessage("§6§l▬▬▬ PLAYER INFO: " + target.getName() + " ▬▬▬");
      staff.sendMessage("§eUUID: §f" + target.getUniqueId());
      staff.sendMessage("§eJoin Date: §f" + (target.getFirstPlayed() > 0L ? new Date(target.getFirstPlayed()) : "Unknown"));
      staff.sendMessage("§ePlaytime: §f" + this.formatTime(target.getStatistic(VersionCompatibility.getPlayTimeStatistic())));
      staff.sendMessage("§eCurrent World: §f" + target.getWorld().getName());
      staff.sendMessage("§eGamemode: §f" + target.getGameMode());
      staff.sendMessage("§eHealth: §f" + String.format("%.1f", target.getHealth()) + "/20.0");
      staff.sendMessage("§ePing: §f" + VersionCompatibility.getPing(target) + "ms");
      if (this.punishmentManager.isMuted(target.getUniqueId())) {
         staff.sendMessage("§cSTATUS: §4MUTED");
      }

      if (this.staffManager.isFrozen(target)) {
         staff.sendMessage("§bSTATUS: §9FROZEN");
      }

      this.recordAction(staff, "INFO " + target.getName());
      staff.closeInventory();
   }

   private void recordAction(Player staff, String action) {
      this.lastActions.put(staff.getUniqueId(), action);
   }

   public String getLastAction(Player staff) {
      return (String)this.lastActions.get(staff.getUniqueId());
   }

   private ItemStack createItem(Material material, String name, String... lore) {
      ItemStack item = new ItemStack(material);
      ItemMeta meta = item.getItemMeta();
      meta.setDisplayName(name);
      meta.setLore((List)Arrays.stream(lore).collect(Collectors.toList()));
      item.setItemMeta(meta);
      return item;
   }

   private Duration parseDuration(String duration) {
      if (duration.endsWith("m")) {
         return Duration.ofMinutes(Long.parseLong(duration.substring(0, duration.length() - 1)));
      } else if (duration.endsWith("h")) {
         return Duration.ofHours(Long.parseLong(duration.substring(0, duration.length() - 1)));
      } else {
         return duration.endsWith("d") ? Duration.ofDays(Long.parseLong(duration.substring(0, duration.length() - 1))) : Duration.ofMinutes(10L);
      }
   }

   private String formatTime(int ticks) {
      int seconds = ticks / 20;
      int hours = seconds / 3600;
      int minutes = seconds % 3600 / 60;
      return String.format("%dh %dm", hours, minutes);
   }
}
