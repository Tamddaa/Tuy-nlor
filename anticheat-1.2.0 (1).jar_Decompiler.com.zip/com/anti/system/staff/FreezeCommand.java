package com.anti.system.staff;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

public class FreezeCommand implements CommandExecutor, TabCompleter {
   private final StaffManager staffManager;

   public FreezeCommand(StaffManager staffManager) {
      this.staffManager = staffManager;
   }

   public boolean onCommand(CommandSender sender, Command command, String label, String[] args2) {
      if (sender == null) {
         return true;
      } else if (!(sender instanceof Player)) {
         sender.sendMessage("This command can only be used by players.");
         return true;
      } else {
         Player staff = (Player)sender;
         if (!staff.hasPermission("antisystem.staff.freeze")) {
            staff.sendMessage("§cYou don't have permission to freeze players.");
            return true;
         } else if (this.staffManager == null) {
            staff.sendMessage("§cStaff manager not initialized!");
            return true;
         } else if (args2.length != 1) {
            staff.sendMessage("§cUsage: /freeze <player>");
            return true;
         } else {
            Player target = (Player)Bukkit.getOnlinePlayers().stream().filter((p) -> p.getName().equalsIgnoreCase(args2[0])).findFirst().orElse((Object)null);
            if (target == null) {
               staff.sendMessage("§cPlayer not found: " + args2[0]);
               return true;
            } else if (target.hasPermission("antisystem.staff")) {
               staff.sendMessage("§cYou cannot freeze other staff members.");
               return true;
            } else {
               if (this.staffManager.isFrozen(target)) {
                  this.staffManager.unfreezePlayer(target);
                  staff.sendMessage("§a[STAFF] §7" + target.getName() + " has been unfrozen.");
               } else {
                  this.staffManager.freezePlayer(target);
                  staff.sendMessage("§c[STAFF] §7" + target.getName() + " has been frozen for screenshare.");
                  String alertMessage = "§c[STAFF] §7" + staff.getName() + " froze " + target.getName() + " for screenshare.";

                  for(Player onlineStaff : Bukkit.getOnlinePlayers()) {
                     if (onlineStaff.hasPermission("antisystem.staff") && !onlineStaff.equals(staff)) {
                        onlineStaff.sendMessage(alertMessage);
                     }
                  }
               }

               return true;
            }
         }
      }
   }

   public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args2) {
      return args2.length == 1 ? (List)Bukkit.getOnlinePlayers().stream().filter((p) -> !p.hasPermission("antisystem.staff")).map(OfflinePlayer::getName).filter((name) -> name.toLowerCase().startsWith(args2[0].toLowerCase())).collect(Collectors.toList()) : Arrays.asList();
   }
}
