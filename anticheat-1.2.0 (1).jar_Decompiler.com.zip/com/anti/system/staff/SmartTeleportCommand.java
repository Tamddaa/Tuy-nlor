package com.anti.system.staff;

import com.anti.system.utils.VersionCompatibility;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

public class SmartTeleportCommand implements CommandExecutor, TabCompleter {
   private final StaffManager staffManager;

   public SmartTeleportCommand(StaffManager staffManager) {
      this.staffManager = staffManager;
   }

   public boolean onCommand(CommandSender sender, Command command, String label, String[] args2) {
      if (sender == null) {
         return true;
      } else if (!(sender instanceof Player)) {
         sender.sendMessage("This command can only be used by players.");
         return true;
      } else {
         Player staff = (Player)sender;
         if (!staff.hasPermission("antisystem.staff.teleport")) {
            staff.sendMessage("§cYou don't have permission to use teleport commands.");
            return true;
         } else {
            switch (command.getName().toLowerCase()) {
               case "stp":
                  return this.handleSmartTeleport(staff, args2);
               case "btp":
                  return this.handleBackTeleport(staff);
               case "locate":
                  return this.handleLocatePlayer(staff, args2);
               default:
                  return false;
            }
         }
      }
   }

   private boolean handleSmartTeleport(Player staff, String[] args2) {
      if (args2.length != 1) {
         staff.sendMessage("§cUsage: /stp <player>");
         return true;
      } else {
         Player target = (Player)Bukkit.getOnlinePlayers().stream().filter((p) -> p.getName().equalsIgnoreCase(args2[0])).findFirst().orElse((Object)null);
         if (target == null) {
            staff.sendMessage("§cPlayer not found: " + args2[0]);
            return true;
         } else {
            this.staffManager.setLastLocation(staff, staff.getLocation());
            Location targetLoc = target.getLocation();
            Location safeLoc = this.findSafeLocationBehind(targetLoc);
            staff.teleport(safeLoc);
            staff.sendMessage("§d[TELEPORT] §7Smart-teleported to " + target.getName());
            if (target.hasPermission("antisystem.staff")) {
               target.sendMessage("§e[STAFF] §7" + staff.getName() + " teleported to you");
            }

            return true;
         }
      }
   }

   private boolean handleBackTeleport(Player staff) {
      Location lastLoc = this.staffManager.getLastLocation(staff);
      if (lastLoc == null) {
         staff.sendMessage("§cNo previous location to return to.");
         return true;
      } else {
         staff.teleport(lastLoc);
         staff.sendMessage("§a[TELEPORT] §7Returned to previous location");
         return true;
      }
   }

   private boolean handleLocatePlayer(Player staff, String[] args2) {
      if (args2.length != 1) {
         staff.sendMessage("§cUsage: /locate <player>");
         return true;
      } else {
         Player target = (Player)Bukkit.getOnlinePlayers().stream().filter((p) -> p.getName().equalsIgnoreCase(args2[0])).findFirst().orElse((Object)null);
         if (target == null) {
            staff.sendMessage("§cPlayer not found: " + args2[0]);
            return true;
         } else {
            Location targetLoc = target.getLocation();
            Location staffLoc = staff.getLocation();
            double distance = staffLoc.distance(targetLoc);
            String world = targetLoc.getWorld().getName();
            String coords = String.format("%.1f, %.1f, %.1f", targetLoc.getX(), targetLoc.getY(), targetLoc.getZ());
            String region = this.getRegionName(targetLoc);
            staff.sendMessage("§6§l▬▬▬ LOCATE: " + target.getName() + " ▬▬▬");
            staff.sendMessage("§eWorld: §f" + world);
            staff.sendMessage("§eCoordinates: §f" + coords);
            staff.sendMessage("§eRegion: §f" + region);
            staff.sendMessage("§eDistance: §f" + String.format("%.1f", distance) + " blocks");
            staff.sendMessage("§eY-Level: §f" + String.format("%.1f", targetLoc.getY()));
            staff.sendMessage("§eBiome: §f" + targetLoc.getBlock().getBiome().toString());
            staff.sendMessage("§7Use '/stp " + target.getName() + "' to teleport");
            return true;
         }
      }
   }

   private Location findSafeLocationBehind(Location targetLoc) {
      float yaw = targetLoc.getYaw();
      double radians = Math.toRadians((double)(yaw + 180.0F));

      for(int distance = 2; distance <= 5; ++distance) {
         double x = targetLoc.getX() + Math.sin(radians) * (double)distance;
         double z = targetLoc.getZ() - Math.cos(radians) * (double)distance;
         Location testLoc = new Location(targetLoc.getWorld(), x, targetLoc.getY(), z, yaw, 0.0F);
         if (this.isSafeLocation(testLoc)) {
            return testLoc;
         }

         testLoc.add((double)0.0F, (double)1.0F, (double)0.0F);
         if (this.isSafeLocation(testLoc)) {
            return testLoc;
         }

         testLoc.add((double)0.0F, (double)-2.0F, (double)0.0F);
         if (this.isSafeLocation(testLoc)) {
            return testLoc;
         }
      }

      return targetLoc.clone().add((double)0.0F, (double)1.0F, (double)0.0F);
   }

   private boolean isSafeLocation(Location loc) {
      if (!(loc.getY() < (double)0.0F) && !(loc.getY() > (double)320.0F)) {
         Material ground = loc.getBlock().getType();
         Material above = loc.clone().add((double)0.0F, (double)1.0F, (double)0.0F).getBlock().getType();
         Material head = loc.clone().add((double)0.0F, (double)2.0F, (double)0.0F).getBlock().getType();
         boolean groundSolid = ground.isSolid() && !ground.toString().contains("LAVA") && !ground.toString().contains("FIRE");
         boolean spaceAbove = VersionCompatibility.isAir(above) || above == Material.WATER;
         boolean spaceForHead = VersionCompatibility.isAir(head) || head == Material.WATER;
         return groundSolid && spaceAbove && spaceForHead;
      } else {
         return false;
      }
   }

   private String getRegionName(Location loc) {
      int x = loc.getBlockX();
      int z = loc.getBlockZ();
      if (Math.abs(x) < 100 && Math.abs(z) < 100) {
         return "Spawn";
      } else if (Math.abs(x) < 1000 && Math.abs(z) < 1000) {
         return "Central";
      } else {
         return Math.abs(x) < 5000 && Math.abs(z) < 5000 ? "Developed" : "Wilderness";
      }
   }

   public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args2) {
      return args2.length == 1 ? (List)Bukkit.getOnlinePlayers().stream().map(OfflinePlayer::getName).filter((name) -> name.toLowerCase().startsWith(args2[0].toLowerCase())).collect(Collectors.toList()) : Arrays.asList();
   }
}
