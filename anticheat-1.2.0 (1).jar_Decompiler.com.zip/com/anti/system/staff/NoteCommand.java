package com.anti.system.staff;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

public class NoteCommand implements CommandExecutor, TabCompleter {
   private final NoteManager noteManager;

   public NoteCommand(NoteManager noteManager) {
      this.noteManager = noteManager;
   }

   public boolean onCommand(CommandSender sender, Command command, String label, String[] args2) {
      if (sender == null) {
         return true;
      } else if (!(sender instanceof Player)) {
         sender.sendMessage("§cOnly players can use this command!");
         return true;
      } else {
         Player staff = (Player)sender;
         if (!staff.hasPermission("antisystem.staff.notes")) {
            staff.sendMessage("§cNo permission!");
            return true;
         } else if (args2.length < 2) {
            staff.sendMessage("§cUsage: /note <add|view|list> <player> [note]");
            return true;
         } else {
            String action = args2[0].toLowerCase();
            String targetName = args2[1];
            switch (action) {
               case "add":
                  if (args2.length < 3) {
                     staff.sendMessage("§cUsage: /note add <player> <note>");
                     return true;
                  }

                  String note = String.join(" ", (CharSequence[])Arrays.copyOfRange(args2, 2, args2.length));
                  this.noteManager.addNote(targetName, staff.getName(), note);
                  staff.sendMessage("§aNote added for " + targetName);
                  break;
               case "view":
                  this.noteManager.viewNotes(staff, targetName);
                  break;
               case "list":
                  this.noteManager.listPlayersWithNotes(staff);
                  break;
               default:
                  staff.sendMessage("§cUnknown action: " + action);
            }

            return true;
         }
      }
   }

   public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args2) {
      if (args2.length == 1) {
         return (List)Arrays.asList("add", "view", "list").stream().filter((cmd) -> cmd.toLowerCase().startsWith(args2[0].toLowerCase())).collect(Collectors.toList());
      } else {
         return args2.length != 2 || !args2[0].equalsIgnoreCase("add") && !args2[0].equalsIgnoreCase("view") ? Arrays.asList() : (List)Bukkit.getOnlinePlayers().stream().map(OfflinePlayer::getName).filter((name) -> name.toLowerCase().startsWith(args2[1].toLowerCase())).collect(Collectors.toList());
      }
   }
}
