package com.anti.system.staff;

import com.anti.system.utils.VersionCompatibility;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class WhoisCommand implements CommandExecutor, TabCompleter {
   private final StaffManager staffManager;
   private final NoteManager noteManager;

   public WhoisCommand(StaffManager staffManager, NoteManager noteManager) {
      this.staffManager = staffManager;
      this.noteManager = noteManager;
   }

   public boolean onCommand(CommandSender sender, Command command, String label, String[] args2) {
      if (command != null && sender != null) {
         if (!(sender instanceof Player)) {
            sender.sendMessage("§cOnly players can use this command!");
            return true;
         } else {
            Player staff = (Player)sender;
            if (!staff.hasPermission("antisystem.staff.whois")) {
               staff.sendMessage("§cNo permission!");
               return true;
            } else if (args2.length == 0) {
               staff.sendMessage("§cUsage: /whois <player>");
               return true;
            } else {
               String targetName = args2[0];
               Player target = null;

               for(Player player : Bukkit.getOnlinePlayers()) {
                  if (player.getName().equalsIgnoreCase(targetName)) {
                     target = player;
                     break;
                  }
               }

               if (target == null) {
                  this.showOfflinePlayerInfo(staff, targetName);
               } else {
                  this.showPlayerInfo(staff, target);
               }

               return true;
            }
         }
      } else {
         return false;
      }
   }

   private void showPlayerInfo(Player staff, Player target) {
      staff.sendMessage("§6§l=== PLAYER INFORMATION ===");
      staff.sendMessage("§eName: §f" + target.getName());
      staff.sendMessage("§eUUID: §7" + target.getUniqueId().toString());
      staff.sendMessage("§eOnline: §aYes");
      staff.sendMessage("§eWorld: §f" + target.getWorld().getName());
      staff.sendMessage("§eLocation: §f" + String.format("%d, %d, %d", target.getLocation().getBlockX(), target.getLocation().getBlockY(), target.getLocation().getBlockZ()));
      staff.sendMessage("§eHealth: §f" + String.format("%.1f/20.0", target.getHealth()));
      staff.sendMessage("§eFood: §f" + target.getFoodLevel() + "/20");
      if (this.staffManager.isInStaffMode(target)) {
         staff.sendMessage("§eStaff Mode: §cENABLED");
      }

      if (this.staffManager.isFrozen(target)) {
         staff.sendMessage("§eFrozen: §cYES");
      }

      int noteCount;
      if ((noteCount = this.noteManager.getNoteCount(target.getName())) > 0) {
         staff.sendMessage("§eNotes: §6" + noteCount + " notes");
      }

      this.openPlayerInfoGUI(staff, target);
   }

   private void showOfflinePlayerInfo(Player staff, String playerName) {
      staff.sendMessage("§ePlayer " + playerName + " is offline");
      int noteCount = this.noteManager.getNoteCount(playerName);
      if (noteCount > 0) {
         staff.sendMessage("§6Notes: " + noteCount);
      }

   }

   private void openPlayerInfoGUI(Player staff, Player target) {
      Inventory gui = Bukkit.createInventory((InventoryHolder)null, 27, "§1Player Info: " + target.getName());
      ItemStack playerHead = new ItemStack(VersionCompatibility.getPlayerHeadMaterial());
      ItemMeta headMeta = playerHead.getItemMeta();
      headMeta.setDisplayName("§e§l" + target.getName());
      headMeta.setLore(Arrays.asList("§7UUID: " + target.getUniqueId().toString(), "§cHealth: " + String.format("%.1f/20.0", target.getHealth()), "§aFood: " + target.getFoodLevel() + "/20"));
      playerHead.setItemMeta(headMeta);
      gui.setItem(4, playerHead);
      ItemStack invItem = new ItemStack(Material.CHEST);
      ItemMeta invMeta = invItem.getItemMeta();
      invMeta.setDisplayName("§9§lView Inventory");
      invMeta.setLore(Arrays.asList("§7Click to inspect inventory"));
      invItem.setItemMeta(invMeta);
      gui.setItem(10, invItem);
      ItemStack echestItem = new ItemStack(Material.ENDER_CHEST);
      ItemMeta echestMeta = echestItem.getItemMeta();
      echestMeta.setDisplayName("§5§lView Ender Chest");
      echestMeta.setLore(Arrays.asList("§7Click to inspect ender chest"));
      echestItem.setItemMeta(echestMeta);
      gui.setItem(12, echestItem);
      ItemStack notesItem = new ItemStack(VersionCompatibility.getWritableBookMaterial());
      ItemMeta notesMeta = notesItem.getItemMeta();
      notesMeta.setDisplayName("§6§lPlayer Notes");
      int noteCount = this.noteManager.getNoteCount(target.getName());
      notesMeta.setLore(Arrays.asList("§7" + noteCount + " notes on file", "§eClick to view"));
      notesItem.setItemMeta(notesMeta);
      gui.setItem(14, notesItem);
      ItemStack teleportItem = new ItemStack(Material.ENDER_PEARL);
      ItemMeta tpMeta = teleportItem.getItemMeta();
      tpMeta.setDisplayName("§d§lTeleport to Player");
      teleportItem.setItemMeta(tpMeta);
      gui.setItem(16, teleportItem);
      staff.openInventory(gui);
   }

   public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args2) {
      return args2.length == 1 ? (List)Bukkit.getOnlinePlayers().stream().map(OfflinePlayer::getName).filter((name) -> name.toLowerCase().startsWith(args2[0].toLowerCase())).collect(Collectors.toList()) : Arrays.asList();
   }
}
