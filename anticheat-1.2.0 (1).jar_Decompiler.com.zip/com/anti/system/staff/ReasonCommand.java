package com.anti.system.staff;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

public class ReasonCommand implements CommandExecutor, TabCompleter {
   private final ReasonManager reasonManager;

   public ReasonCommand(ReasonManager reasonManager) {
      this.reasonManager = reasonManager;
   }

   public boolean onCommand(CommandSender sender, Command command, String label, String[] args2) {
      if (sender == null) {
         return true;
      } else if (!(sender instanceof Player)) {
         sender.sendMessage("§cOnly players can use this command!");
         return true;
      } else {
         Player player = (Player)sender;
         if (!player.hasPermission("antisystem.staff.reason")) {
            player.sendMessage("§cNo permission!");
            return true;
         } else if (args2.length != 0 && !args2[0].equalsIgnoreCase("select")) {
            if (args2[0].equalsIgnoreCase("add") && args2.length >= 3) {
               String category = args2[1];
               String reason = String.join(" ", (CharSequence[])Arrays.copyOfRange(args2, 2, args2.length));
               this.reasonManager.addReason(category, reason);
               player.sendMessage("§aAdded reason to category " + category + ": " + reason);
               return true;
            } else if (args2[0].equalsIgnoreCase("list")) {
               this.reasonManager.listReasons(player);
               return true;
            } else {
               player.sendMessage("§cUsage: /reason select|add <category> <reason>|list");
               return true;
            }
         } else {
            this.reasonManager.openReasonSelector(player);
            return true;
         }
      }
   }

   public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args2) {
      if (args2.length == 1) {
         return (List)Arrays.asList("select", "add", "list").stream().filter((cmd) -> cmd.toLowerCase().startsWith(args2[0].toLowerCase())).collect(Collectors.toList());
      } else {
         return args2.length == 2 && args2[0].equalsIgnoreCase("add") ? (List)Arrays.asList("chat", "grief", "hack", "exploit", "toxic", "spam").stream().filter((cat) -> cat.toLowerCase().startsWith(args2[1].toLowerCase())).collect(Collectors.toList()) : Arrays.asList();
      }
   }
}
