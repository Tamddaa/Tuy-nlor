package com.anti.system.staff;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

public class MacroCommand implements CommandExecutor, TabCompleter {
   private final MacroManager macroManager;

   public MacroCommand(MacroManager macroManager) {
      this.macroManager = macroManager;
   }

   public boolean onCommand(CommandSender sender, Command command, String label, String[] args2) {
      if (!(sender instanceof Player)) {
         if (sender != null) {
            sender.sendMessage("§cOnly players can use this command!");
         }

         return true;
      } else {
         Player staff = (Player)sender;
         if (!staff.hasPermission("antisystem.staff.macro")) {
            staff.sendMessage("§cNo permission!");
            return true;
         } else if (args2.length == 0) {
            this.macroManager.listMacros(staff);
            return true;
         } else {
            String action = args2[0].toLowerCase();
            if (action.equals("list")) {
               this.macroManager.listMacros(staff);
               return true;
            } else if (action.equals("create") && args2.length >= 3) {
               String macroId = args2[1];
               String commands = String.join(" ", (CharSequence[])Arrays.copyOfRange(args2, 2, args2.length));
               this.macroManager.createMacro(staff, macroId, commands);
               return true;
            } else if (action.equals("delete") && args2.length >= 2) {
               String macroId = args2[1];
               this.macroManager.deleteMacro(staff, macroId);
               return true;
            } else if (action.equals("run") && args2.length >= 2) {
               String macroId = args2[1];
               String targetPlayer = args2.length > 2 ? args2[2] : null;
               this.macroManager.runMacro(staff, macroId, targetPlayer);
               return true;
            } else {
               try {
                  int macroId = Integer.parseInt(action);
                  String targetPlayer = args2.length > 1 ? args2[1] : null;
                  this.macroManager.runMacro(staff, String.valueOf(macroId), targetPlayer);
                  return true;
               } catch (NumberFormatException var9) {
                  staff.sendMessage("§cUsage: /macro <list|create|delete|run|1-9> [args...]");
                  return true;
               }
            }
         }
      }
   }

   public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args2) {
      if (args2.length == 1) {
         List<String> suggestions = Arrays.asList("list", "create", "delete", "run", "1", "2", "3", "4", "5", "6", "7", "8", "9");
         return (List)suggestions.stream().filter((cmd) -> cmd.toLowerCase().startsWith(args2[0].toLowerCase())).collect(Collectors.toList());
      } else if (args2.length != 2 || !args2[0].equalsIgnoreCase("run") && !args2[0].equalsIgnoreCase("delete")) {
         return args2.length < 2 || !args2[0].equalsIgnoreCase("run") && !this.isNumeric(args2[0]) ? Arrays.asList() : (List)Bukkit.getOnlinePlayers().stream().map(OfflinePlayer::getName).filter((name) -> name.toLowerCase().startsWith(args2[args2.length - 1].toLowerCase())).collect(Collectors.toList());
      } else {
         return (List)this.macroManager.getMacroIds().stream().filter((id) -> id.toLowerCase().startsWith(args2[1].toLowerCase())).collect(Collectors.toList());
      }
   }

   private boolean isNumeric(String str) {
      try {
         return Integer.parseInt(str) != Integer.MIN_VALUE;
      } catch (NumberFormatException var3) {
         return false;
      }
   }
}
