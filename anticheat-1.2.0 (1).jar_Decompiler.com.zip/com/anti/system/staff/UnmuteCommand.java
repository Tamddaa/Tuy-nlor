package com.anti.system.staff;

import java.util.Arrays;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

public class UnmuteCommand implements CommandExecutor, TabCompleter {
   private final PunishmentManager punishmentManager;

   public UnmuteCommand(PunishmentManager punishmentManager) {
      this.punishmentManager = punishmentManager;
   }

   public boolean onCommand(CommandSender sender, Command command, String label, String[] args2) {
      if (sender == null) {
         return true;
      } else if (!(sender instanceof Player)) {
         sender.sendMessage("This command can only be used by players.");
         return true;
      } else {
         Player staff = (Player)sender;
         if (!staff.hasPermission("antisystem.staff.unmute")) {
            staff.sendMessage("§cYou don't have permission to unmute players.");
            return true;
         } else if (args2.length != 1) {
            staff.sendMessage("§cUsage: /unmute <player>");
            return true;
         } else {
            Player target = null;

            for(Player player : Bukkit.getOnlinePlayers()) {
               if (player.getName().equalsIgnoreCase(args2[0])) {
                  target = player;
                  break;
               }
            }

            String targetName;
            UUID targetUuid;
            if (target != null) {
               targetUuid = target.getUniqueId();
               targetName = target.getName();
            } else {
               OfflinePlayer offlineTarget = null;
               OfflinePlayer[] var15 = Bukkit.getOfflinePlayers();
               int var11 = var15.length;
               int var12 = 0;

               while(true) {
                  if (var12 < var11) {
                     OfflinePlayer op = var15[var12];
                     if (op.getName() == null || !op.getName().equalsIgnoreCase(args2[0])) {
                        ++var12;
                        continue;
                     }

                     offlineTarget = op;
                  }

                  if (offlineTarget == null || !offlineTarget.hasPlayedBefore()) {
                     staff.sendMessage("§cPlayer not found: " + args2[0]);
                     return true;
                  }

                  targetUuid = offlineTarget.getUniqueId();
                  targetName = offlineTarget.getName();
                  break;
               }
            }

            if (!this.punishmentManager.isMuted(targetUuid)) {
               staff.sendMessage("§cPlayer " + targetName + " is not muted.");
               return true;
            } else {
               this.punishmentManager.unmutePlayer(targetUuid, staff.getName());
               staff.sendMessage("§a§lSTAFF§r §7" + targetName + " has been unmuted.");
               return true;
            }
         }
      }
   }

   public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args2) {
      return args2.length == 1 ? (List)Bukkit.getOnlinePlayers().stream().map(OfflinePlayer::getName).filter((name) -> name.toLowerCase().startsWith(args2[0].toLowerCase())).collect(Collectors.toList()) : Arrays.asList();
   }
}
