package com.anti.system.staff;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

public class HelpOpCommand implements CommandExecutor, TabCompleter {
   private final HelpOpManager helpOpManager;

   public HelpOpCommand(HelpOpManager helpOpManager) {
      this.helpOpManager = helpOpManager;
   }

   public boolean onCommand(CommandSender sender, Command command, String label, String[] args2) {
      if (this.helpOpManager == null) {
         sender.sendMessage("§cHelpOp manager not initialized!");
         return true;
      } else {
         if (sender instanceof Player) {
            Player player = (Player)sender;
            if (args2.length == 0) {
               if (player.hasPermission("antisystem.staff.helpop")) {
                  this.helpOpManager.openInboxGUI(player);
               } else {
                  player.sendMessage("§cUsage: /helpop <message>");
               }

               return true;
            }

            if (args2[0].equalsIgnoreCase("inbox") && player.hasPermission("antisystem.staff.helpop")) {
               this.helpOpManager.openInboxGUI(player);
               return true;
            }

            String message = String.join(" ", args2);
            this.helpOpManager.createHelpRequest(player, message);
            player.sendMessage("§aHelp request sent! Staff will respond shortly.");
         } else if (sender != null) {
            sender.sendMessage("§cOnly players can use this command!");
         }

         return true;
      }
   }

   public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args2) {
      return sender.hasPermission("antisystem.staff.helpop") && args2.length == 1 ? (List)Arrays.asList("inbox").stream().filter((cmd) -> cmd.toLowerCase().startsWith(args2[0].toLowerCase())).collect(Collectors.toList()) : Arrays.asList();
   }
}
