package com.anti.system.staff;

import com.anti.system.utils.VersionCompatibility;
import java.util.Arrays;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class StaffGUIManager implements Listener {
   private final StaffManager staffManager;
   private final NoteManager noteManager;
   private final ReasonManager reasonManager;
   private final HelpOpManager helpOpManager;

   public StaffGUIManager(StaffManager staffManager, NoteManager noteManager, ReasonManager reasonManager, HelpOpManager helpOpManager) {
      this.staffManager = staffManager;
      this.noteManager = noteManager;
      this.reasonManager = reasonManager;
      this.helpOpManager = helpOpManager;
   }

   @EventHandler
   public void onInventoryClick(InventoryClickEvent event) {
      if (event.getWhoClicked() instanceof Player) {
         Player player = (Player)event.getWhoClicked();
         if (event.getCurrentItem() != null) {
            String title = event.getView().getTitle();
            ItemStack item = event.getCurrentItem();
            if (title.startsWith("QuickMod: ") || title.equals("Select Reason Category") || title.endsWith(" Reasons") || title.equals("Help Request Inbox") || title.startsWith("Player Info: ") || title.startsWith("Staff Hub") || title.contains("Staff") || title.contains("Mod")) {
               if (event.getClick().isShiftClick() || event.getClick().isRightClick() || event.getClick().isLeftClick() || event.getAction().name().contains("DROP") || event.getAction().name().contains("PICKUP") || event.getAction().name().contains("MOVE") || event.getAction().name().contains("HOTBAR") || event.getAction().name().contains("SWAP")) {
                  event.setCancelled(true);
               }

               if (title.startsWith("QuickMod: ")) {
                  event.setCancelled(true);
                  this.handleQuickModClick(player, item, title);
               } else if (title.equals("Select Reason Category")) {
                  event.setCancelled(true);
                  this.handleReasonCategoryClick(player, item);
               } else if (title.endsWith(" Reasons")) {
                  event.setCancelled(true);
                  this.handleReasonClick(player, item);
               } else if (title.equals("Help Request Inbox")) {
                  event.setCancelled(true);
                  this.handleHelpRequestClick(player, event);
               } else if (title.startsWith("Player Info: ")) {
                  event.setCancelled(true);
                  this.handlePlayerInfoClick(player, item, title);
               } else if (title.startsWith("Teleport Options: ")) {
                  event.setCancelled(true);
                  this.handleTeleportClick(player, item, title);
               } else {
                  if (title.equals("Staff Hub")) {
                     event.setCancelled(true);
                     this.handleStaffHubClick(player, item);
                  }

               }
            }
         }
      }
   }

   private void handleQuickModClick(Player staff, ItemStack item, String title) {
      String targetName = title.substring(10);
      Player target = this.getOnlinePlayer(targetName);
      if (target == null) {
         staff.sendMessage("§cPlayer is no longer online!");
         staff.closeInventory();
      } else {
         Material type = item.getType();
         if (type == VersionCompatibility.getOrangeConcreteMaterial()) {
            staff.closeInventory();
            staff.sendMessage("§eWarning " + targetName + " for rule violation...");
            staff.performCommand("warn " + targetName + " Rule violation");
         } else if (type == VersionCompatibility.getRedConcreteMaterial()) {
            staff.closeInventory();
            staff.sendMessage("§eMuting " + targetName + " for 10 minutes...");
            staff.performCommand("mute " + targetName + " 10m Rule violation");
         } else if (type == VersionCompatibility.getYellowConcreteMaterial()) {
            staff.closeInventory();
            staff.sendMessage("§eKicking " + targetName + "...");
            staff.performCommand("kick " + targetName + " Kicked by staff");
         } else if (type == VersionCompatibility.getBlackConcreteMaterial()) {
            staff.closeInventory();
            staff.sendMessage("§eBanning " + targetName + " for 1 day...");
            staff.performCommand("ban " + targetName + " 1d Banned by staff");
         } else if (type == VersionCompatibility.getWritableBookMaterial()) {
            staff.closeInventory();
            staff.sendMessage("§eViewing notes for " + targetName + "...");
            this.noteManager.viewNotes(staff, targetName);
         } else if (type == Material.ICE) {
            if (this.staffManager.isFrozen(target)) {
               this.staffManager.unfreezePlayer(target);
               staff.sendMessage("§aUnfroze " + targetName);
            } else {
               this.staffManager.freezePlayer(target);
               staff.sendMessage("§aFroze " + targetName);
            }

            staff.closeInventory();
         } else if (type == Material.ENDER_PEARL) {
            staff.closeInventory();
            staff.sendMessage("§eTeleporting to " + targetName + "...");
            staff.teleport(target);
         } else if (type == VersionCompatibility.getSpyglassMaterial()) {
            staff.closeInventory();
            staff.sendMessage("§eInspecting " + targetName + "...");
            staff.performCommand("whois " + targetName);
         }

      }
   }

   private void handleReasonCategoryClick(Player staff, ItemStack item) {
      String category = "other";
      if (item.getType() == Material.PAPER) {
         category = "chat";
      } else if (item.getType() == Material.TNT) {
         category = "grief";
      } else if (item.getType() == Material.REDSTONE) {
         category = "hack";
      } else if (item.getType() == VersionCompatibility.getCommandBlockMaterial()) {
         category = "exploit";
      }

      this.reasonManager.openCategoryReasons(staff, category);
   }

   private void handleReasonClick(Player staff, ItemStack item) {
      if (item.hasItemMeta() && item.getItemMeta().hasDisplayName()) {
         String reason = item.getItemMeta().getDisplayName();
         staff.closeInventory();
         staff.sendMessage("§aSelected reason: " + reason);
      }

   }

   private void handleHelpRequestClick(Player staff, InventoryClickEvent event) {
      ItemStack item = event.getCurrentItem();
      if (item != null && item.getType() == Material.PAPER) {
         if (event.isLeftClick()) {
            staff.closeInventory();
            staff.sendMessage("§aClaiming help request...");
         } else if (event.isRightClick()) {
            staff.closeInventory();
            String title;
            if (item.hasItemMeta() && item.getItemMeta().hasDisplayName() && (title = item.getItemMeta().getDisplayName()).startsWith("Help Request: ")) {
               String playerName = title.substring(14);
               this.openQuickResponseGUI(staff, playerName);
            }
         }

      } else {
         if (item != null && item.getType() == VersionCompatibility.getClockMaterial()) {
            this.helpOpManager.openInboxGUI(staff);
         }

      }
   }

   private void handlePlayerInfoClick(Player staff, ItemStack item, String title) {
      String targetName = title.substring(13);
      Player target = this.getOnlinePlayer(targetName);
      if (target == null) {
         staff.sendMessage("§cPlayer is no longer online!");
         staff.closeInventory();
      } else {
         Material type = item.getType();
         if (type == Material.CHEST) {
            staff.closeInventory();
            staff.openInventory(target.getInventory());
         } else if (type == Material.ENDER_CHEST) {
            staff.closeInventory();
            staff.openInventory(target.getEnderChest());
         } else if (type == VersionCompatibility.getWritableBookMaterial()) {
            staff.closeInventory();
            this.noteManager.viewNotes(staff, targetName);
         } else if (type == Material.ENDER_PEARL) {
            staff.closeInventory();
            staff.teleport(target.getLocation());
            staff.sendMessage("§aTeleported to " + targetName);
         }

      }
   }

   private void handleTeleportClick(Player staff, ItemStack item, String title) {
      String targetName = title.substring(19);
      Player target = this.getOnlinePlayer(targetName);
      if (target == null) {
         staff.sendMessage("§cPlayer is no longer online!");
         staff.closeInventory();
      } else {
         Material type = item.getType();
         switch (type) {
            case ENDER_PEARL:
               staff.closeInventory();
               Bukkit.dispatchCommand(staff, "stp " + targetName);
               break;
            case FISHING_ROD:
               staff.closeInventory();
               target.teleport(staff.getLocation());
               staff.sendMessage("§aBrought " + targetName + " to you");
               break;
            case COMPASS:
               staff.closeInventory();
               staff.teleport(target.getLocation());
               staff.sendMessage("§aTeleported to " + targetName);
         }

      }
   }

   private void handleStaffHubClick(Player staff, ItemStack item) {
      Material type = item.getType();
      if (type == VersionCompatibility.getPlayerHeadMaterial()) {
         staff.closeInventory();
         this.openOnlinePlayersGUI(staff);
      } else if (type == Material.PAPER) {
         staff.closeInventory();
         this.helpOpManager.openInboxGUI(staff);
      } else if (type == Material.BOOK) {
         staff.closeInventory();
         this.openRecentPunishmentsGUI(staff);
      } else if (type == VersionCompatibility.getSpyglassMaterial()) {
         staff.closeInventory();
         this.openWatchlistGUI(staff);
      }

   }

   private void openOnlinePlayersGUI(Player staff) {
      staff.sendMessage("§aOnline Players: " + Bukkit.getOnlinePlayers().size());

      for(Player player : Bukkit.getOnlinePlayers()) {
         staff.sendMessage("§f• " + player.getName() + " (World: " + player.getWorld().getName() + ")");
      }

   }

   private void openQuickResponseGUI(Player staff, String playerName) {
      Inventory gui = Bukkit.createInventory((InventoryHolder)null, 27, "§5Quick Response: " + playerName);
      ItemStack teleportItem = new ItemStack(Material.ENDER_PEARL);
      ItemMeta teleportMeta = teleportItem.getItemMeta();
      teleportMeta.setDisplayName("§aTeleport to Player");
      teleportMeta.setLore(Arrays.asList("§7Click to teleport to " + playerName));
      teleportItem.setItemMeta(teleportMeta);
      ItemStack bringItem = new ItemStack(Material.FISHING_ROD);
      ItemMeta bringMeta = bringItem.getItemMeta();
      bringMeta.setDisplayName("§9Bring Player Here");
      bringMeta.setLore(Arrays.asList("§7Click to bring " + playerName + " to you"));
      bringItem.setItemMeta(bringMeta);
      ItemStack responseItem = new ItemStack(Material.WRITTEN_BOOK);
      ItemMeta responseMeta = responseItem.getItemMeta();
      responseMeta.setDisplayName("§eSend Message");
      responseMeta.setLore(Arrays.asList("§7Click to send a message to " + playerName));
      responseItem.setItemMeta(responseMeta);
      ItemStack closeItem = new ItemStack(Material.BARRIER);
      ItemMeta closeMeta = closeItem.getItemMeta();
      closeMeta.setDisplayName("§cClose Request");
      closeMeta.setLore(Arrays.asList("§7Mark this request as resolved"));
      closeItem.setItemMeta(closeMeta);
      gui.setItem(10, teleportItem);
      gui.setItem(12, bringItem);
      gui.setItem(14, responseItem);
      gui.setItem(16, closeItem);
      staff.openInventory(gui);
   }

   private void openRecentPunishmentsGUI(Player staff) {
      Inventory gui = Bukkit.createInventory((InventoryHolder)null, 45, "§4Recent Punishments");
      String[] recentPunishments = new String[]{"Hacker123 - Ban - Cheating", "Griefer456 - Mute - Spam", "Toxic789 - Kick - Harassment", "AutoClicker - Kick - Auto-clicking"};

      for(int i = 0; i < Math.min(recentPunishments.length, 35); ++i) {
         String[] parts = recentPunishments[i].split(" - ");
         if (parts.length >= 3) {
            String playerName = parts[0];
            String punishmentType = parts[1];
            String reason = parts[2];
            Material material = Material.PAPER;
            if (punishmentType.equalsIgnoreCase("ban")) {
               material = Material.BARRIER;
            } else if (punishmentType.equalsIgnoreCase("mute")) {
               material = Material.BOOK;
            } else if (punishmentType.equalsIgnoreCase("kick")) {
               material = Material.LEATHER_BOOTS;
            }

            ItemStack item = new ItemStack(material);
            ItemMeta meta = item.getItemMeta();
            meta.setDisplayName("§c" + playerName + " - " + punishmentType);
            meta.setLore(Arrays.asList("§7Reason: " + reason, "§7Time: Recently"));
            item.setItemMeta(meta);
            gui.setItem(i, item);
         }
      }

      ItemStack backItem = new ItemStack(Material.ARROW);
      ItemMeta backMeta = backItem.getItemMeta();
      backMeta.setDisplayName("§eBack to Staff Hub");
      backItem.setItemMeta(backMeta);
      gui.setItem(44, backItem);
      staff.openInventory(gui);
   }

   private void openWatchlistGUI(Player staff) {
      Inventory gui = Bukkit.createInventory((InventoryHolder)null, 36, "§5Player Watchlist");
      String[] watchlistPlayers = new String[]{"SuspiciousUser1 - Potential hacker", "ToxicPlayer2 - Harassment reports", "GrieferAlert3 - Multiple grief reports", "XrayUser5 - Unusual mining patterns"};

      for(int i = 0; i < Math.min(watchlistPlayers.length, 25); ++i) {
         String[] parts = watchlistPlayers[i].split(" - ");
         if (parts.length >= 2) {
            String playerName = parts[0];
            String reason = parts[1];
            ItemStack item = new ItemStack(VersionCompatibility.getPlayerHeadMaterial());
            ItemMeta meta = item.getItemMeta();
            meta.setDisplayName("§c" + playerName);
            meta.setLore(Arrays.asList("§7Reason: " + reason, "§eClick to view player info"));
            item.setItemMeta(meta);
            gui.setItem(i, item);
         }
      }

      ItemStack addItem = new ItemStack(Material.EMERALD);
      ItemMeta addMeta = addItem.getItemMeta();
      addMeta.setDisplayName("§aAdd Player to Watchlist");
      addMeta.setLore(Arrays.asList("§7Click to add a new player"));
      addItem.setItemMeta(addMeta);
      gui.setItem(26, addItem);
      ItemStack backItem = new ItemStack(Material.ARROW);
      ItemMeta backMeta = backItem.getItemMeta();
      backMeta.setDisplayName("§eBack to Staff Hub");
      backItem.setItemMeta(backMeta);
      gui.setItem(35, backItem);
      staff.openInventory(gui);
   }

   @EventHandler
   public void onInventoryDrag(InventoryDragEvent event) {
      String title = event.getView().getTitle();
      if (title.startsWith("QuickMod: ") || title.equals("Select Reason Category") || title.endsWith(" Reasons") || title.equals("Help Request Inbox") || title.startsWith("Player Info: ") || title.startsWith("Staff Hub") || title.contains("Staff") || title.contains("Mod") || title.contains("Quick Response") || title.contains("Recent Punishments") || title.contains("Watchlist")) {
         event.setCancelled(true);
      }

   }

   private Player getOnlinePlayer(String playerName) {
      return (Player)Bukkit.getOnlinePlayers().stream().filter((p) -> p.getName().equalsIgnoreCase(playerName)).findFirst().orElse((Object)null);
   }
}
