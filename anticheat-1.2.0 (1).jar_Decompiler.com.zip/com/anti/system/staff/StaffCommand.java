package com.anti.system.staff;

import com.anti.system.anticheat.DatabaseManager;
import com.anti.system.utils.VersionCompatibility;
import java.lang.reflect.InvocationTargetException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.Server;
import org.bukkit.block.BlockFace;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.util.Vector;

public class StaffCommand implements CommandExecutor, TabCompleter {
   private final DatabaseManager database;
   private final StaffManager staffManager;
   private final PunishmentManager punishmentManager;

   public StaffCommand(DatabaseManager database, StaffManager staffManager) {
      this.database = database;
      this.staffManager = staffManager;
      this.punishmentManager = new PunishmentManager(database);
   }

   public boolean onCommand(CommandSender sender, Command command, String label, String[] args2) {
      if (sender == null) {
         return true;
      } else if (!(sender instanceof Player)) {
         sender.sendMessage("§cThis command can only be used by players.");
         return true;
      } else {
         Player player = (Player)sender;
         if (!player.isOp() && !player.hasPermission("antisystem.staff")) {
            player.sendMessage("§cYou don't have permission to use staff commands.");
            return true;
         } else if (args2.length == 0) {
            this.openStaffHub(player);
            return true;
         } else {
            switch (args2[0].toLowerCase()) {
               case "hub":
               case "menu":
                  this.openStaffHub(player);
                  break;
               case "mode":
                  this.toggleStaffMode(player);
                  break;
               case "quickmod":
                  if (args2.length < 2) {
                     player.sendMessage("§cUsage: /staff quickmod <player>");
                     return true;
                  }

                  this.openQuickMod(player, args2[1]);
                  break;
               case "freeze":
                  if (args2.length < 2) {
                     player.sendMessage("§cUsage: /staff freeze <player>");
                     return true;
                  }

                  this.freezePlayer(player, args2[1]);
                  break;
               case "probe":
                  if (args2.length < 2) {
                     player.sendMessage("§cUsage: /staff probe <player>");
                     return true;
                  }

                  this.probePlayer(player, args2[1]);
                  break;
               case "inspect":
                  if (args2.length < 2) {
                     player.sendMessage("§cUsage: /staff inspect <player>");
                     return true;
                  }

                  this.inspectPlayer(player, args2[1]);
                  break;
               case "note":
                  if (args2.length < 3) {
                     player.sendMessage("§cUsage: /staff note <player> <note>");
                     return true;
                  }

                  this.addPlayerNote(player, args2[1], String.join(" ", (CharSequence[])Arrays.copyOfRange(args2, 2, args2.length)));
                  break;
               case "mute":
                  if (args2.length < 3) {
                     player.sendMessage("§cUsage: /staff mute <player> <duration> [reason]");
                     return true;
                  }

                  this.mutePlayer(player, args2[1], args2[2], args2.length > 3 ? String.join(" ", (CharSequence[])Arrays.copyOfRange(args2, 3, args2.length)) : "No reason provided");
                  break;
               case "ban":
                  if (args2.length < 3) {
                     player.sendMessage("§cUsage: /staff ban <player> <duration> [reason]");
                     return true;
                  }

                  this.banPlayer(player, args2[1], args2[2], args2.length > 3 ? String.join(" ", (CharSequence[])Arrays.copyOfRange(args2, 3, args2.length)) : "No reason provided");
                  break;
               case "warn":
                  if (args2.length < 3) {
                     player.sendMessage("§cUsage: /staff warn <player> <reason>");
                     return true;
                  }

                  this.warnPlayer(player, args2[1], String.join(" ", (CharSequence[])Arrays.copyOfRange(args2, 2, args2.length)));
                  break;
               case "stp":
                  if (args2.length < 2) {
                     player.sendMessage("§cUsage: /staff stp <player>");
                     return true;
                  }

                  this.smartTeleport(player, args2[1]);
                  break;
               case "btp":
                  this.backTeleport(player);
                  break;
               case "helpop":
                  this.openHelpOpQueue(player);
                  break;
               case "watchlist":
                  this.openWatchlist(player);
                  break;
               case "reports":
                  this.openReportsGUI(player);
                  break;
               case "lagkit":
                  this.openLagDiagnostics(player);
                  break;
               default:
                  player.sendMessage("§cUnknown staff command. Use /staff for the main menu.");
            }

            return true;
         }
      }
   }

   private void openStaffHub(Player player) {
      Inventory gui = Bukkit.createInventory(player, 54, "§6§lAntiSystem Staff Hub");
      gui.setItem(10, this.createItem(VersionCompatibility.getPlayerHeadMaterial(), "§a§lQuick Moderation", "§7Right-click any player to open", "§7quick moderation menu"));
      gui.setItem(11, this.createItem(Material.ICE, "§b§lFreeze Player", "§7Lock a player for screenshare", "§e/staff freeze <player>"));
      gui.setItem(12, this.createItem(Material.COMPASS, "§e§lProbe Player", "§7Analyze player for cheats", "§e/staff probe <player>"));
      gui.setItem(13, this.createItem(VersionCompatibility.getEnderEyeMaterial(), "§d§lStaff Mode", "§7Toggle staff utilities", "§e/staff mode"));
      gui.setItem(14, this.createItem(Material.BOOK, "§6§lPlayer Notes", "§7Add/view player notes", "§e/staff note <player> <text>"));
      gui.setItem(15, this.createItem(Material.NETHER_STAR, "§c§lInspect Player", "§7Deep player analysis", "§e/staff inspect <player>"));
      gui.setItem(16, this.createItem(Material.ENDER_CHEST, "§5§lReports Queue", "§7Manage player reports", "§e/staff reports"));
      gui.setItem(19, this.createItem(Material.ENDER_PEARL, "§a§lSmart Teleport", "§7Safe teleport to player", "§e/staff stp <player>"));
      gui.setItem(20, this.createItem(Material.REDSTONE, "§c§lBack Teleport", "§7Return to last location", "§e/staff btp"));
      gui.setItem(21, this.createItem(VersionCompatibility.getBellMaterial(), "§e§lHelpOp Queue", "§7Manage help requests", "§e/staff helpop"));
      gui.setItem(22, this.createItem(VersionCompatibility.getSpyglassMaterial(), "§b§lWatchlist", "§7Monitor flagged players", "§e/staff watchlist"));
      gui.setItem(23, this.createItem(VersionCompatibility.getClockMaterial(), "§6§lLag Diagnostics", "§7Server performance tools", "§e/staff lagkit"));
      gui.setItem(24, this.createItem(VersionCompatibility.getWritableBookMaterial(), "§d§lPunishment Log", "§7View recent punishments", "§e/staff punishments"));
      gui.setItem(25, this.createItem(Material.BARRIER, "§c§lEmergency Tools", "§7Emergency server controls", "§e/staff emergency"));
      int onlineStaff = (int)Bukkit.getOnlinePlayers().stream().filter((p) -> p.hasPermission("antisystem.staff")).count();
      int totalReports = this.database.getTotalReports();
      int activeFlags = this.getActiveAntiCheatFlags();
      gui.setItem(37, this.createItem(VersionCompatibility.getGreenWoolMaterial(), "§a§lOnline Staff", "§7Current: §f" + onlineStaff, "§7Click to view list"));
      gui.setItem(38, this.createItem(VersionCompatibility.getYellowWoolMaterial(), "§e§lPending Reports", "§7Current: §f" + totalReports, "§7Click to manage"));
      gui.setItem(39, this.createItem(VersionCompatibility.getRedWoolMaterial(), "§c§lActive Flags", "§7Current: §f" + activeFlags, "§7Click to investigate"));
      gui.setItem(40, this.createItem(VersionCompatibility.getBlueWoolMaterial(), "§b§lServer Status", "§7TPS: §f" + String.format("%.1f", this.getCurrentTPS()), "§7Click for diagnostics"));
      gui.setItem(49, this.createItem(Material.BARRIER, "§c§lClose", "§7Close this menu"));
      player.openInventory(gui);
   }

   private void openQuickMod(Player player, String targetName) {
      Player target = (Player)Bukkit.getOnlinePlayers().stream().filter((p) -> p.getName().equalsIgnoreCase(targetName)).findFirst().orElse((Object)null);
      if (target == null) {
         player.sendMessage("§cPlayer not found: " + targetName);
      } else {
         Inventory gui = Bukkit.createInventory(player, 27, "§6§lQuick Mod: " + target.getName());
         gui.setItem(10, this.createItem(Material.PAPER, "§e§lWarn Player", "§7Give a warning", "§eClick to warn"));
         gui.setItem(11, this.createItem(Material.REDSTONE, "§c§lMute Player", "§7Temporary mute", "§eClick for options"));
         gui.setItem(12, this.createItem(Material.IRON_DOOR, "§6§lKick Player", "§7Remove from server", "§eClick to kick"));
         gui.setItem(13, this.createItem(Material.BARRIER, "§4§lBan Player", "§7Permanent removal", "§eClick for options"));
         gui.setItem(14, this.createItem(Material.ICE, "§b§lFreeze", "§7Lock for screenshare", "§eClick to freeze"));
         gui.setItem(15, this.createItem(Material.ENDER_PEARL, "§a§lTeleport To", "§7Go to player", "§eClick to teleport"));
         gui.setItem(16, this.createItem(Material.BOOK, "§d§lAdd Note", "§7Add staff note", "§eClick to add"));
         gui.setItem(19, this.createItem(Material.COMPASS, "§e§lProbe", "§7Anti-cheat analysis", "§eClick to probe"));
         gui.setItem(20, this.createItem(Material.CHEST, "§6§lInspect Inventory", "§7View player inventory", "§eClick to inspect"));
         gui.setItem(21, this.createItem(Material.ENDER_CHEST, "§5§lEnder Chest", "§7View ender chest", "§eClick to view"));
         gui.setItem(22, this.createItem(Material.NETHER_STAR, "§c§lFull Inspect", "§7Complete analysis", "§eClick for details"));
         gui.setItem(26, this.createItem(Material.BARRIER, "§c§lClose", "§7Close this menu"));
         player.openInventory(gui);
      }
   }

   private void toggleStaffMode(Player player) {
      if (this.staffManager.isInStaffMode(player)) {
         this.staffManager.disableStaffMode(player);
         player.sendMessage("§c§lSTAFF§r §7Staff mode disabled.");
      } else {
         this.staffManager.enableStaffMode(player);
         player.sendMessage("§a§lSTAFF§r §7Staff mode enabled. You are now invisible and have special permissions.");
      }

   }

   private void freezePlayer(Player player, String targetName) {
      Player target = this.getOnlinePlayer(targetName);
      if (target == null) {
         player.sendMessage("§cPlayer not found: " + targetName);
      } else {
         if (this.staffManager.isFrozen(target)) {
            this.staffManager.unfreezePlayer(target);
            player.sendMessage("§a§lSTAFF§r §7" + target.getName() + " has been unfrozen.");
            target.sendMessage("§a§lFREEZE§r §7You have been unfrozen by staff.");
         } else {
            this.staffManager.freezePlayer(target);
            player.sendMessage("§c§lSTAFF§r §7" + target.getName() + " has been frozen for screenshare.");
            target.sendMessage("§c§l!! FROZEN !! §r§c\n§7You have been frozen by staff for a screenshare.\n§7Join our Discord: discord.gg/yourserver\n§7DO NOT LOG OUT or you will be banned!");

            for(Player staff : Bukkit.getOnlinePlayers()) {
               if (staff.hasPermission("antisystem.staff") && !staff.equals(player)) {
                  staff.sendMessage("§c§lSTAFF§r §e" + player.getName() + " §7froze §e" + target.getName() + " §7for screenshare.");
               }
            }
         }

      }
   }

   private void probePlayer(Player player, String targetName) {
      Player target = this.getOnlinePlayer(targetName);
      if (target == null) {
         player.sendMessage("§cPlayer not found: " + targetName);
      } else {
         player.sendMessage("§e§lPROBE§r §7Analyzing " + target.getName() + "...");
         boolean isBedrock = this.isBedrockPlayer(target);
         int ping = VersionCompatibility.getPing(target);
         String world = target.getWorld().getName();
         int x = (int)target.getLocation().getX();
         int y = (int)target.getLocation().getY();
         int z = (int)target.getLocation().getZ();
         int recentViolations = 0;
         String lastViolationType = "None";

         try {
            PreparedStatement stmt = this.database.getConnection().prepareStatement("SELECT violation_type, COUNT(*) as count FROM anticheat_violations WHERE uuid = ? AND last_violation > ? GROUP BY violation_type ORDER BY count DESC LIMIT 1");

            try {
               stmt.setString(1, target.getUniqueId().toString());
               stmt.setLong(2, System.currentTimeMillis() - 300000L);
               ResultSet rs = stmt.executeQuery();

               try {
                  if (rs.next()) {
                     lastViolationType = rs.getString("violation_type");
                     recentViolations = rs.getInt("count");
                  }
               } catch (Throwable var20) {
                  if (rs != null) {
                     try {
                        rs.close();
                     } catch (Throwable var19) {
                        var20.addSuppressed(var19);
                     }
                  }

                  throw var20;
               }

               if (rs != null) {
                  rs.close();
               }
            } catch (Throwable var21) {
               if (stmt != null) {
                  try {
                     stmt.close();
                  } catch (Throwable var18) {
                     var21.addSuppressed(var18);
                  }
               }

               throw var21;
            }

            if (stmt != null) {
               stmt.close();
            }
         } catch (Exception var22) {
         }

         double speed = target.getVelocity().length();
         boolean isFlying = target.isFlying();
         boolean isOnGround = target.getLocation().getBlock().getRelative(BlockFace.DOWN).getType().isSolid();
         player.sendMessage("§6§l▬▬▬ PROBE RESULTS: " + target.getName() + " ▬▬▬");
         player.sendMessage("§ePlatform: §f" + (isBedrock ? "Bedrock" : "Java"));
         player.sendMessage("§ePing: §f" + ping + "ms" + (ping > 200 ? " §c(HIGH)" : (ping > 100 ? " §e(MEDIUM)" : " §a(LOW)")));
         player.sendMessage("§eLocation: §f" + world + " (" + x + ", " + y + ", " + z + ")");
         player.sendMessage("§eGamemode: §f" + target.getGameMode());
         player.sendMessage("§eFlying: §f" + (isFlying ? "Yes" : "No"));
         player.sendMessage("§eOn Ground: §f" + (isOnGround ? "Yes" : "No"));
         player.sendMessage("§eMovement Speed: §f" + String.format("%.2f", speed));
         if (recentViolations > 0) {
            player.sendMessage("§cRecent Violations: §f" + recentViolations + " §7(" + lastViolationType + ")");
         } else {
            player.sendMessage("§aRecent Violations: §fNone");
         }

         int riskScore = 0;
         if (ping > 300) {
            ++riskScore;
         }

         if (recentViolations > 5) {
            riskScore += 3;
         }

         if (speed > (double)1.0F && !isFlying) {
            riskScore += 2;
         }

         String riskLevel = riskScore >= 4 ? "§cHIGH" : (riskScore >= 2 ? "§eNORMAL" : "§aLOW");
         player.sendMessage("§eRisk Level: " + riskLevel);
         player.sendMessage("§6§l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬");
      }
   }

   private void inspectPlayer(Player player, String targetName) {
      Player target = this.getOnlinePlayer(targetName);
      if (target == null) {
         player.sendMessage("§cPlayer not found: " + targetName);
      } else {
         this.openInspectionGUI(player, target);
      }
   }

   private void openInspectionGUI(Player player, Player target) {
      Inventory gui = Bukkit.createInventory(player, 54, "§c§lInspecting: " + target.getName());
      gui.setItem(4, this.createItem(VersionCompatibility.getPlayerHeadMaterial(), "§e§l" + target.getName(), "§7Platform: §f" + (this.isBedrockPlayer(target) ? "Bedrock" : "Java"), "§7Ping: §f" + VersionCompatibility.getPing(target) + "ms", "§7World: §f" + target.getWorld().getName(), "§7Gamemode: §f" + target.getGameMode()));
      gui.setItem(18, this.createItem(Material.CHEST, "§6§lView Inventory", "§7Click to inspect"));
      gui.setItem(19, this.createItem(Material.ENDER_CHEST, "§5§lEnder Chest", "§7Click to view"));
      gui.setItem(20, this.createItem(Material.COMPASS, "§e§lProbe", "§7Run anti-cheat analysis"));
      gui.setItem(21, this.createItem(Material.ICE, "§b§lFreeze", "§7Lock player"));
      gui.setItem(22, this.createItem(Material.ENDER_PEARL, "§a§lTeleport", "§7Go to player"));
      gui.setItem(23, this.createItem(Material.BOOK, "§d§lNotes", "§7View/add notes"));
      gui.setItem(24, this.createItem(Material.PAPER, "§e§lPunishment History", "§7View past punishments"));
      gui.setItem(25, this.createItem(Material.REDSTONE, "§c§lFlags", "§7View anti-cheat flags"));
      gui.setItem(49, this.createItem(Material.BARRIER, "§c§lClose", "§7Close inspection"));
      player.openInventory(gui);
   }

   private void addPlayerNote(Player player, String targetName, String note) {
      Player target = this.getOnlinePlayer(targetName);
      if (target == null) {
         player.sendMessage("§cPlayer not found: " + targetName);
      } else {
         this.database.addPlayerNote(target.getUniqueId(), player.getUniqueId(), note);
         player.sendMessage("§a§lNOTE§r §7Added note for " + targetName + ": §f" + note);

         for(Player staff : Bukkit.getOnlinePlayers()) {
            if (staff.hasPermission("antisystem.staff") && !staff.equals(player)) {
               staff.sendMessage("§6§lSTAFF§r §e" + player.getName() + " §7added note for §e" + targetName);
            }
         }

      }
   }

   private void mutePlayer(Player player, String targetName, String duration, String reason) {
      Player target = this.getOnlinePlayer(targetName);
      if (target == null) {
         player.sendMessage("§cPlayer not found: " + targetName);
      } else {
         this.punishmentManager.mutePlayer(target.getUniqueId(), player.getName(), reason, duration);
      }
   }

   private void banPlayer(Player player, String targetName, String duration, String reason) {
      Player target = this.getOnlinePlayer(targetName);
      if (target == null) {
         player.sendMessage("§cPlayer not found: " + targetName);
      } else {
         this.punishmentManager.banPlayer(target.getUniqueId(), player.getName(), reason, duration);
      }
   }

   private void warnPlayer(Player player, String targetName, String reason) {
      Player target = this.getOnlinePlayer(targetName);
      if (target == null) {
         player.sendMessage("§cPlayer not found: " + targetName);
      } else {
         this.punishmentManager.warnPlayer(target.getUniqueId(), player.getName(), reason);
      }
   }

   private void smartTeleport(Player player, String targetName) {
      Player target = this.getOnlinePlayer(targetName);
      if (target == null) {
         player.sendMessage("§cPlayer not found: " + targetName);
      } else {
         this.staffManager.setLastLocation(player, player.getLocation());
         Location targetLoc = target.getLocation();
         Vector direction = targetLoc.getDirection().multiply(-2);
         Location safeLoc = targetLoc.add(direction);
         safeLoc.setY(targetLoc.getY());
         player.teleport(safeLoc);
         player.sendMessage("§a§lTP§r §7Teleported to " + target.getName());
      }
   }

   private void backTeleport(Player player) {
      Location lastLoc = this.staffManager.getLastLocation(player);
      if (lastLoc == null) {
         player.sendMessage("§cNo previous location found.");
      } else {
         player.teleport(lastLoc);
         player.sendMessage("§a§lTP§r §7Returned to previous location.");
      }
   }

   private void openHelpOpQueue(Player player) {
      Inventory helpOpGUI = Bukkit.createInventory((InventoryHolder)null, 54, "§e§lHELP REQUESTS");
      List<String> helpRequests = this.database.getPendingHelpRequests();
      if (helpRequests.isEmpty()) {
         helpOpGUI.setItem(22, this.createItem(VersionCompatibility.getGrayStainedGlassPaneMaterial(), "§7No Pending Requests", "§7All help requests have been resolved!"));
      } else {
         int slot = 0;

         for(String request : helpRequests) {
            if (slot >= 45) {
               break;
            }

            helpOpGUI.setItem(slot, this.createItem(Material.PAPER, "§e§lHelp Request #" + (slot + 1), "§7Request: §f" + request, "§7Click to respond"));
            ++slot;
         }
      }

      helpOpGUI.setItem(49, this.createItem(Material.BARRIER, "§c§lClose", "§7Close this menu"));
      player.openInventory(helpOpGUI);
   }

   private void openWatchlist(Player player) {
      Inventory watchlistGUI = Bukkit.createInventory((InventoryHolder)null, 54, "§b§lWATCHLIST");
      Set<UUID> watchedPlayers = this.staffManager.getWatchedPlayers();
      if (watchedPlayers.isEmpty()) {
         watchlistGUI.setItem(22, this.createItem(VersionCompatibility.getGrayStainedGlassPaneMaterial(), "§7No Watched Players", "§7No players are currently on the watchlist."));
      } else {
         int slot = 0;

         for(UUID watchedUUID : watchedPlayers) {
            if (slot >= 45) {
               break;
            }

            Player watchedPlayer = Bukkit.getPlayer(watchedUUID);
            String playerName = watchedPlayer != null ? watchedPlayer.getName() : "Unknown";
            String status = watchedPlayer != null && watchedPlayer.isOnline() ? "§aOnline" : "§cOffline";
            watchlistGUI.setItem(slot, this.createItem(VersionCompatibility.getPlayerHeadMaterial(), "§e§l" + playerName, "§7Status: " + status, "§7Reason: Suspicious behavior", "§7Click to manage"));
            ++slot;
         }
      }

      watchlistGUI.setItem(45, this.createItem(VersionCompatibility.getGreenWoolMaterial(), "§a§lAdd Player", "§7Add a player to watchlist"));
      watchlistGUI.setItem(49, this.createItem(Material.BARRIER, "§c§lClose", "§7Close this menu"));
      player.openInventory(watchlistGUI);
   }

   private void openReportsGUI(Player player) {
      Inventory reportsGUI = Bukkit.createInventory((InventoryHolder)null, 54, "§6§lREPORTS");
      List<String> pendingReports = this.database.getPendingReports();
      if (pendingReports.isEmpty()) {
         reportsGUI.setItem(22, this.createItem(VersionCompatibility.getGrayStainedGlassPaneMaterial(), "§7No Pending Reports", "§7All reports have been handled!"));
      } else {
         int slot = 0;

         for(String report : pendingReports) {
            if (slot >= 45) {
               break;
            }

            reportsGUI.setItem(slot, this.createItem(Material.BOOK, "§6§lReport #" + (slot + 1), "§7Report: §f" + report, "§7Click to investigate"));
            ++slot;
         }
      }

      reportsGUI.setItem(45, this.createItem(VersionCompatibility.getYellowWoolMaterial(), "§e§lAll Reports", "§7Show all pending reports"));
      reportsGUI.setItem(46, this.createItem(VersionCompatibility.getRedWoolMaterial(), "§c§lHigh Priority", "§7Show only urgent reports"));
      reportsGUI.setItem(47, this.createItem(VersionCompatibility.getGreenWoolMaterial(), "§a§lResolved", "§7Show resolved reports"));
      reportsGUI.setItem(49, this.createItem(Material.BARRIER, "§c§lClose", "§7Close this menu"));
      player.openInventory(reportsGUI);
   }

   private void openLagDiagnostics(Player player) {
      double tps = this.getCurrentTPS();
      int onlinePlayers = Bukkit.getOnlinePlayers().size();
      int loadedWorlds = Bukkit.getWorlds().size();
      long maxMemory = Runtime.getRuntime().maxMemory() / 1024L / 1024L;
      long totalMemory = Runtime.getRuntime().totalMemory() / 1024L / 1024L;
      long freeMemory = Runtime.getRuntime().freeMemory() / 1024L / 1024L;
      long usedMemory = totalMemory - freeMemory;
      player.sendMessage("§c§l▬▬▬ LAG DIAGNOSTICS ▬▬▬");
      player.sendMessage("§eTPS: §f" + String.format("%.2f", tps) + (tps < (double)18.0F ? " §c(LOW)" : " §a(GOOD)"));
      player.sendMessage("§eOnline Players: §f" + onlinePlayers);
      player.sendMessage("§eLoaded Worlds: §f" + loadedWorlds);
      player.sendMessage("§eMemory Usage: §f" + usedMemory + "MB / " + maxMemory + "MB §7(" + String.format("%.1f", (double)usedMemory * (double)100.0F / (double)maxMemory) + "%)");
      if (tps < (double)18.0F) {
         player.sendMessage("§c⚠ Low TPS detected! Server may be lagging.");
      }

      if ((double)usedMemory * (double)100.0F / (double)maxMemory > (double)80.0F) {
         player.sendMessage("§c⚠ High memory usage! Consider restarting.");
      }

      if (onlinePlayers > 100) {
         player.sendMessage("§e⚠ High player count may impact performance.");
      }

      player.sendMessage("§c§l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬");
   }

   private ItemStack createItem(Material material, String name, String... lore) {
      ItemStack item = new ItemStack(material);
      ItemMeta meta = item.getItemMeta();
      meta.setDisplayName(name);
      meta.setLore(Arrays.asList(lore));
      item.setItemMeta(meta);
      return item;
   }

   private boolean isBedrockPlayer(Player player) {
      if (player.hasMetadata("floodgate-player")) {
         return true;
      } else {
         try {
            Class<?> geyserApiClass = Class.forName("org.geysermc.geyser.api.GeyserApi");
            Object geyserApi = geyserApiClass.getMethod("api").invoke((Object)null);
            Object isBedrockResult = geyserApiClass.getMethod("isBedrockPlayer", UUID.class).invoke(geyserApi, player.getUniqueId());
            return (Boolean)isBedrockResult;
         } catch (NoSuchMethodException | IllegalAccessException | InvocationTargetException | ClassNotFoundException var6) {
            String name = player.getName();
            if (!name.startsWith(".") && !name.contains(" ")) {
               try {
                  String brand = this.getPlayerClientBrand(player);
                  if (brand != null) {
                     String brand;
                     return (brand = brand.toLowerCase()).contains("mcpe") || brand.contains("bedrock") || brand.contains("pocket");
                  }
               } catch (Exception var5) {
               }

               return false;
            } else {
               return true;
            }
         }
      }
   }

   private String getPlayerClientBrand(Player player) {
      try {
         return player.getClass().getMethod("getClientBrandName").invoke(player).toString();
      } catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException var3) {
         return null;
      }
   }

   private double getCurrentTPS() {
      try {
         Server server = Bukkit.getServer();
         return ((double[])server.getClass().getMethod("getTPS").invoke(server))[0];
      } catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException var2) {
         return (double)20.0F;
      }
   }

   private int getActiveAntiCheatFlags() {
      int flagCount = 0;

      for(Player player : Bukkit.getOnlinePlayers()) {
         if (player.hasMetadata("antisystem.flags")) {
            ++flagCount;
         }
      }

      return flagCount;
   }

   public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args2) {
      if (args2.length == 1) {
         return Arrays.asList("hub", "mode", "quickmod", "freeze", "probe", "inspect", "note", "mute", "ban", "warn", "stp", "btp", "helpop", "watchlist", "reports", "lagkit");
      } else {
         return args2.length != 2 || !args2[0].equalsIgnoreCase("quickmod") && !args2[0].equalsIgnoreCase("freeze") && !args2[0].equalsIgnoreCase("probe") && !args2[0].equalsIgnoreCase("inspect") && !args2[0].equalsIgnoreCase("note") && !args2[0].equalsIgnoreCase("mute") && !args2[0].equalsIgnoreCase("ban") && !args2[0].equalsIgnoreCase("warn") && !args2[0].equalsIgnoreCase("stp") ? Arrays.asList() : (List)Bukkit.getOnlinePlayers().stream().map(OfflinePlayer::getName).collect(Collectors.toList());
      }
   }

   private Player getOnlinePlayer(String playerName) {
      return (Player)Bukkit.getOnlinePlayers().stream().filter((p) -> p.getName().equalsIgnoreCase(playerName)).findFirst().orElse((Object)null);
   }
}
