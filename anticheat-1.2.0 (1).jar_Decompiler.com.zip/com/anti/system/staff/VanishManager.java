package com.anti.system.staff;

import com.anti.system.utils.VersionCompatibility;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityBreedEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.entity.EntityTameEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.hanging.HangingBreakByEntityEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerAdvancementDoneEvent;
import org.bukkit.event.player.PlayerArmorStandManipulateEvent;
import org.bukkit.event.player.PlayerBedEnterEvent;
import org.bukkit.event.player.PlayerBucketEmptyEvent;
import org.bukkit.event.player.PlayerBucketFillEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerCommandSendEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerEggThrowEvent;
import org.bukkit.event.player.PlayerExpChangeEvent;
import org.bukkit.event.player.PlayerFishEvent;
import org.bukkit.event.player.PlayerGameModeChangeEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerItemConsumeEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerLevelChangeEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerPortalEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.player.PlayerShearEntityEvent;
import org.bukkit.plugin.Plugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public class VanishManager implements Listener {
   private final Plugin plugin;
   private final StaffManager staffManager;

   public VanishManager(Plugin plugin, StaffManager staffManager) {
      this.plugin = plugin;
      this.staffManager = staffManager;
   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void onPlayerChat(AsyncPlayerChatEvent event) {
      Player sender = event.getPlayer();
      if (this.staffManager.isVanished(sender)) {
         event.setCancelled(true);
         String message = event.getMessage();

         for(Player staff : Bukkit.getOnlinePlayers()) {
            if (this.isStaff(staff)) {
               staff.sendMessage("§8[§7Vanish Chat§8] §f" + sender.getName() + "§8: §7" + message);
            }
         }

         sender.sendMessage("§8[§7Vanish§8] §7Your message was only visible to staff members.");
      }

   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void onPlayerJoin(PlayerJoinEvent event) {
      Player player = event.getPlayer();
      if (!this.isStaff(player)) {
         for(UUID vanishedUuid : this.staffManager.getVanishedPlayers()) {
            Player vanishedPlayer = Bukkit.getPlayer(vanishedUuid);
            if (vanishedPlayer != null && vanishedPlayer.isOnline()) {
               VersionCompatibility.hidePlayer(player, vanishedPlayer, this.plugin);
            }
         }
      }

      if (this.staffManager.isVanished(player)) {
         String originalMessage = event.getJoinMessage();
         event.setJoinMessage((String)null);
         if (originalMessage != null) {
            String staffMessage = "§7[Vanish] " + originalMessage;

            for(Player staff : Bukkit.getOnlinePlayers()) {
               if (this.isStaff(staff)) {
                  staff.sendMessage(staffMessage);
               }
            }
         }
      }

   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void onPlayerQuit(PlayerQuitEvent event) {
      Player player = event.getPlayer();
      if (this.staffManager.isVanished(player)) {
         String originalMessage = event.getQuitMessage();
         event.setQuitMessage((String)null);
         if (originalMessage != null) {
            String staffMessage = "§7[Vanish] " + originalMessage;

            for(Player staff : Bukkit.getOnlinePlayers()) {
               if (this.isStaff(staff)) {
                  staff.sendMessage(staffMessage);
               }
            }
         }
      }

   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void onPlayerCommandPreprocess(PlayerCommandPreprocessEvent event) {
      Player sender = event.getPlayer();
      String command;
      if (this.staffManager.isVanished(sender) && !(command = event.getMessage().toLowerCase()).startsWith("/tell") && !command.startsWith("/msg") && !command.startsWith("/r") && command.startsWith("/reply")) {
      }

   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void onEntityDamage(EntityDamageEvent event) {
      if (event.getEntity() instanceof Player) {
         Player player = (Player)event.getEntity();
         if (this.staffManager.isVanished(player)) {
            if (event instanceof EntityDamageByEntityEvent) {
               EntityDamageByEntityEvent damageEvent = (EntityDamageByEntityEvent)event;
               if (damageEvent.getDamager() instanceof Player) {
                  Player damager = (Player)damageEvent.getDamager();
                  if (this.isStaff(damager)) {
                     return;
                  }
               }
            }

            event.setCancelled(true);
         }

      }
   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void onEntityDamageByEntity(EntityDamageByEntityEvent event) {
      if (event.getDamager() instanceof Player) {
         Player damager = (Player)event.getDamager();
         if (this.staffManager.isVanished(damager)) {
            event.setCancelled(true);
            damager.sendMessage("§c[Vanish] You cannot attack anything while vanished! (Complete invisibility mode)");
         }

      }
   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void onBlockBreak(BlockBreakEvent event) {
      Player player = event.getPlayer();
      if (this.staffManager.isVanished(player)) {
         player.sendMessage("§e[Vanish] Block breaking may reveal your position to nearby players!");
      }

   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void onBlockPlace(BlockPlaceEvent event) {
      Player player = event.getPlayer();
      if (this.staffManager.isVanished(player)) {
         player.sendMessage("§e[Vanish] Block placing may reveal your position to nearby players!");
      }

   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void onEntityPickupItem(EntityPickupItemEvent event) {
      if (event.getEntity() instanceof Player) {
         Player player = (Player)event.getEntity();
         if (this.staffManager.isVanished(player)) {
            event.setCancelled(true);
         }

      }
   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void onPlayerDropItem(PlayerDropItemEvent event) {
      Player player = event.getPlayer();
      if (this.staffManager.isVanished(player)) {
         event.setCancelled(true);
         player.sendMessage("§c[Vanish] You cannot drop items while vanished!");
      }

   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void onInventoryClick(InventoryClickEvent event) {
      if (event.getWhoClicked() instanceof Player) {
         Player player = (Player)event.getWhoClicked();
         Player owner;
         if (this.staffManager.isVanished(player) && event.getInventory().getHolder() instanceof Player && !(owner = (Player)event.getInventory().getHolder()).equals(player) && !this.isStaff(owner)) {
            event.setCancelled(true);
            player.sendMessage("§c[Vanish] You cannot access other players' inventories while vanished!");
         }

      }
   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void onPlayerMove(PlayerMoveEvent event) {
      Player player = event.getPlayer();
      if (this.staffManager.isVanished(player)) {
      }

   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void onPlayerInteract(PlayerInteractEvent event) {
      Player player = event.getPlayer();
      if (this.staffManager.isVanished(player) && event.getAction().name().contains("BLOCK")) {
         player.sendMessage("§e[Vanish] Block interactions may reveal your presence!");
      }

   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void onPlayerBucketEmpty(PlayerBucketEmptyEvent event) {
      Player player = event.getPlayer();
      if (this.staffManager.isVanished(player)) {
         event.setCancelled(true);
         player.sendMessage("§c[Vanish] You cannot use buckets while vanished!");
      }

   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void onPlayerBucketFill(PlayerBucketFillEvent event) {
      Player player = event.getPlayer();
      if (this.staffManager.isVanished(player)) {
         event.setCancelled(true);
         player.sendMessage("§c[Vanish] You cannot use buckets while vanished!");
      }

   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void onPlayerFish(PlayerFishEvent event) {
      Player player = event.getPlayer();
      if (this.staffManager.isVanished(player)) {
         event.setCancelled(true);
         player.sendMessage("§c[Vanish] You cannot fish while vanished!");
      }

   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void onPlayerItemConsume(PlayerItemConsumeEvent event) {
      Player player = event.getPlayer();
      if (this.staffManager.isVanished(player)) {
         event.setCancelled(true);
         player.sendMessage("§c[Vanish] You cannot consume items while vanished!");
      }

   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void onPlayerBedEnter(PlayerBedEnterEvent event) {
      Player player = event.getPlayer();
      if (this.staffManager.isVanished(player)) {
         event.setCancelled(true);
         player.sendMessage("§c[Vanish] You cannot sleep while vanished!");
      }

   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void onPlayerArmorStandManipulate(PlayerArmorStandManipulateEvent event) {
      Player player = event.getPlayer();
      if (this.staffManager.isVanished(player)) {
         event.setCancelled(true);
         player.sendMessage("§c[Vanish] You cannot interact with armor stands while vanished!");
      }

   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void onPlayerInteractEntity(PlayerInteractEntityEvent event) {
      Player player = event.getPlayer();
      if (this.staffManager.isVanished(player)) {
         event.setCancelled(true);
         player.sendMessage("§c[Vanish] You cannot interact with entities while vanished!");
      }

   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void onPlayerPortal(PlayerPortalEvent event) {
      Player player = event.getPlayer();
      if (this.staffManager.isVanished(player)) {
         event.setCancelled(true);
         player.sendMessage("§c[Vanish] You cannot use portals while vanished!");
      }

   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void onPlayerGameModeChange(PlayerGameModeChangeEvent event) {
      Player player = event.getPlayer();
      if (this.staffManager.isVanished(player)) {
         for(Player online : Bukkit.getOnlinePlayers()) {
            if (!this.isStaff(online) && !online.equals(player)) {
               VersionCompatibility.hidePlayer(online, player, this.plugin);
            }
         }
      }

   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void onPlayerAdvancementDone(PlayerAdvancementDoneEvent event) {
      Player player = event.getPlayer();
      if (this.staffManager.isVanished(player)) {
      }

   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void onPlayerLevelChange(PlayerLevelChangeEvent event) {
      Player player = event.getPlayer();
      if (this.staffManager.isVanished(player)) {
      }

   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void onPlayerShearEntity(PlayerShearEntityEvent event) {
      Player player = event.getPlayer();
      if (this.staffManager.isVanished(player)) {
         event.setCancelled(true);
         player.sendMessage("§c[Vanish] You cannot shear entities while vanished!");
      }

   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void onHangingBreak(HangingBreakByEntityEvent event) {
      Player player;
      if (event.getRemover() instanceof Player && this.staffManager.isVanished(player = (Player)event.getRemover())) {
         event.setCancelled(true);
         player.sendMessage("§c[Vanish] You cannot break hanging entities while vanished!");
      }

   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void onPlayerCommandSend(PlayerCommandSendEvent event) {
      Player player = event.getPlayer();
      if (this.staffManager.isVanished(player)) {
         event.getCommands().removeIf((cmd) -> cmd.startsWith("tell") || cmd.startsWith("msg") || cmd.startsWith("me") || cmd.startsWith("say") || cmd.startsWith("broadcast"));
      }

   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void onPlayerDeath(PlayerDeathEvent event) {
      Player player = event.getEntity();
      if (this.staffManager.isVanished(player)) {
         String originalMessage = event.getDeathMessage();
         event.setDeathMessage((String)null);
         if (originalMessage != null && !originalMessage.isEmpty()) {
            String staffMessage = "§8[Vanish Death] §7" + originalMessage;

            for(Player staff : Bukkit.getOnlinePlayers()) {
               if (this.isStaff(staff)) {
                  staff.sendMessage(staffMessage);
               }
            }
         }
      }

   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void onPlayerChangedWorld(PlayerChangedWorldEvent event) {
      Player player = event.getPlayer();
      if (this.staffManager.isVanished(player)) {
         for(Player other : player.getWorld().getPlayers()) {
            if (!this.isStaff(other) && !other.equals(player)) {
               VersionCompatibility.hidePlayer(other, player, this.plugin);
            }
         }
      }

   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void onPlayerRespawn(PlayerRespawnEvent event) {
      Player player = event.getPlayer();
      if (this.staffManager.isVanished(player)) {
         Bukkit.getScheduler().runTaskLater(this.plugin, () -> {
            for(Player other : Bukkit.getOnlinePlayers()) {
               if (!this.isStaff(other) && !other.equals(player)) {
                  VersionCompatibility.hidePlayer(other, player, this.plugin);
               }
            }

            player.addPotionEffect(new PotionEffect(PotionEffectType.NIGHT_VISION, Integer.MAX_VALUE, 0, true, false));
            player.sendMessage("§8[§7Vanish§8] §aVanish restored after respawn.");
         }, 1L);
      }

   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void onPlayerInteractPhysical(PlayerInteractEvent event) {
      if (event.getAction() == Action.PHYSICAL && this.staffManager.isVanished(event.getPlayer()) && event.getClickedBlock() != null) {
         String blockType = event.getClickedBlock().getType().name();
         if (blockType.contains("PRESSURE_PLATE") || blockType.contains("TRIPWIRE")) {
            event.setCancelled(true);
         }
      }

   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void onPlayerAdvancement(PlayerAdvancementDoneEvent event) {
      Player player = event.getPlayer();
      if (this.staffManager.isVanished(player)) {
      }

   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void onPlayerExpChange(PlayerExpChangeEvent event) {
      Player player = event.getPlayer();
      if (this.staffManager.isVanished(player)) {
      }

   }

   public void applyVanishEffects(Player player) {
      for(Player other : Bukkit.getOnlinePlayers()) {
         if (!this.isStaff(other) && !other.equals(player)) {
            VersionCompatibility.hidePlayer(other, player, this.plugin);
         }
      }

      player.addPotionEffect(new PotionEffect(PotionEffectType.NIGHT_VISION, Integer.MAX_VALUE, 0, true, false));
      player.sendMessage("§8[§7Vanish§8] §aYou are now completely hidden from all players!");
   }

   public void removeVanishEffects(Player player) {
      for(Player other : Bukkit.getOnlinePlayers()) {
         VersionCompatibility.showPlayer(other, player, this.plugin);
      }

      player.removePotionEffect(PotionEffectType.NIGHT_VISION);
      player.sendMessage("§8[§7Vanish§8] §cYou are now visible to all players!");
   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void onEntityDamageByPlayer(EntityDamageByEntityEvent event) {
      Player player;
      if (event.getDamager() instanceof Player && this.staffManager.isVanished(player = (Player)event.getDamager())) {
         event.setCancelled(true);
         player.sendMessage("§c[Vanish] You cannot interact with entities while vanished!");
      }

   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void onPlayerEggThrow(PlayerEggThrowEvent event) {
      Player player = event.getPlayer();
      if (this.staffManager.isVanished(player)) {
         event.setHatching(false);
         player.sendMessage("§c[Vanish] Egg effects disabled while vanished!");
      }

   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void onEntityBreed(EntityBreedEvent event) {
      if (event.getBreeder() instanceof Player) {
         Player player = (Player)event.getBreeder();
         if (player != null && this.staffManager.isVanished(player)) {
            event.setCancelled(true);
            player.sendMessage("§c[Vanish] You cannot breed entities while vanished!");
         }
      }

   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void onEntityTame(EntityTameEvent event) {
      if (event.getOwner() instanceof Player) {
         Player player = (Player)event.getOwner();
         if (this.staffManager.isVanished(player)) {
            event.setCancelled(true);
            player.sendMessage("§c[Vanish] You cannot tame entities while vanished!");
         }
      }

   }

   private boolean isStaff(Player player) {
      return player.isOp() || player.hasPermission("antisystem.staff") || player.hasPermission("antisystem.bypass.all");
   }
}
