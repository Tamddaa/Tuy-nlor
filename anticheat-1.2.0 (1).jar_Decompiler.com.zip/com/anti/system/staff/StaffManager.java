package com.anti.system.staff;

import com.anti.system.utils.VersionCompatibility;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.BanList.Type;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public class StaffManager implements Listener {
   private final Set<UUID> staffModeEnabled = new HashSet();
   private final Map<UUID, ItemStack[]> savedInventories = new HashMap();
   private final Map<UUID, GameMode> savedGameModes = new HashMap();
   private final Map<UUID, Boolean> savedFlight = new HashMap();
   private final Map<UUID, Location> lastLocations = new HashMap();
   private final Set<UUID> frozenPlayers = new HashSet();
   private final Map<UUID, Location> frozenLocations = new HashMap();
   private final Set<UUID> vanishedPlayers = new HashSet();
   private final Set<UUID> watchedPlayers = new HashSet();
   private final File vanishFile = new File(Bukkit.getPluginManager().getPlugin("AntiCheat").getDataFolder(), "vanished.properties");

   public StaffManager() {
      this.loadVanishedPlayers();
   }

   public void enableStaffMode(Player player) {
      UUID uuid = player.getUniqueId();
      if (!this.staffModeEnabled.contains(uuid)) {
         this.savedInventories.put(uuid, player.getInventory().getContents());
         this.savedGameModes.put(uuid, player.getGameMode());
         this.savedFlight.put(uuid, player.getAllowFlight());
         player.getInventory().clear();
         player.setGameMode(GameMode.SPECTATOR);
         player.setAllowFlight(true);
         player.setFlying(true);
         player.addPotionEffect(new PotionEffect(PotionEffectType.NIGHT_VISION, Integer.MAX_VALUE, 0, false, false));
         this.giveStaffItems(player);
         this.staffModeEnabled.add(uuid);

         for(Player online : Bukkit.getOnlinePlayers()) {
            if (!online.hasPermission("antisystem.staff")) {
               online.hidePlayer(player);
            }
         }

      }
   }

   public void disableStaffMode(Player player) {
      UUID uuid = player.getUniqueId();
      if (this.staffModeEnabled.contains(uuid)) {
         player.getInventory().clear();
         if (this.savedInventories.containsKey(uuid)) {
            player.getInventory().setContents((ItemStack[])this.savedInventories.get(uuid));
            this.savedInventories.remove(uuid);
         }

         if (this.savedGameModes.containsKey(uuid)) {
            player.setGameMode((GameMode)this.savedGameModes.get(uuid));
            this.savedGameModes.remove(uuid);
         }

         if (this.savedFlight.containsKey(uuid)) {
            player.setAllowFlight((Boolean)this.savedFlight.get(uuid));
            player.setFlying(false);
            this.savedFlight.remove(uuid);
         }

         player.removePotionEffect(PotionEffectType.NIGHT_VISION);
         this.staffModeEnabled.remove(uuid);

         for(Player online : Bukkit.getOnlinePlayers()) {
            online.showPlayer(player);
         }

      }
   }

   private void giveStaffItems(Player player) {
      player.getInventory().clear();
      ItemStack teleportTool = new ItemStack(Material.ENDER_PEARL);
      ItemMeta teleportMeta = teleportTool.getItemMeta();
      teleportMeta.setDisplayName("§b§lTeleport Tool");
      teleportMeta.setLore(Arrays.asList("§7Right-click a player to teleport", "§7Left-click to teleport through walls"));
      teleportTool.setItemMeta(teleportMeta);
      ItemStack inspectTool = new ItemStack(Material.BOOK);
      ItemMeta inspectMeta = inspectTool.getItemMeta();
      inspectMeta.setDisplayName("§e§lInspect Tool");
      inspectMeta.setLore(Arrays.asList("§7Right-click a player to inspect", "§7Shows detailed player information"));
      inspectTool.setItemMeta(inspectMeta);
      ItemStack freezeTool = new ItemStack(Material.ICE);
      ItemMeta freezeMeta = freezeTool.getItemMeta();
      freezeMeta.setDisplayName("§c§lFreeze Tool");
      freezeMeta.setLore(Arrays.asList("§7Right-click a player to freeze", "§7Used for screenshares"));
      freezeTool.setItemMeta(freezeMeta);
      ItemStack randomTeleport = new ItemStack(Material.COMPASS);
      ItemMeta randomMeta = randomTeleport.getItemMeta();
      randomMeta.setDisplayName("§a§lRandom Teleport");
      randomMeta.setLore(Arrays.asList("§7Click to teleport to random player", "§7Useful for monitoring"));
      randomTeleport.setItemMeta(randomMeta);
      player.getInventory().setItem(0, teleportTool);
      player.getInventory().setItem(1, inspectTool);
      player.getInventory().setItem(2, freezeTool);
      player.getInventory().setItem(8, randomTeleport);
      this.updateVanishItem(player);
   }

   public boolean isInStaffMode(Player player) {
      return this.staffModeEnabled.contains(player.getUniqueId());
   }

   public void freezePlayer(Player player) {
      UUID uuid = player.getUniqueId();
      this.frozenPlayers.add(uuid);
      this.frozenLocations.put(uuid, player.getLocation());
      player.sendMessage("§c§l!! FROZEN !!\n§7You have been frozen by staff for a screenshare.\n§7Join our Discord: discord.gg/yourserver\n§7DO NOT LOG OUT or you will be banned!");
   }

   public void unfreezePlayer(Player player) {
      UUID uuid = player.getUniqueId();
      this.frozenPlayers.remove(uuid);
      this.frozenLocations.remove(uuid);
      player.sendMessage("§a§lFREEZE LIFTED\n§7You have been unfrozen by staff.");
   }

   public boolean isFrozen(Player player) {
      return this.frozenPlayers.contains(player.getUniqueId());
   }

   public void setLastLocation(Player player, Location location) {
      this.lastLocations.put(player.getUniqueId(), location.clone());
   }

   public Location getLastLocation(Player player) {
      return (Location)this.lastLocations.get(player.getUniqueId());
   }

   public void addToWatchlist(Player player) {
      this.watchedPlayers.add(player.getUniqueId());

      for(Player staff : Bukkit.getOnlinePlayers()) {
         if (staff.hasPermission("antisystem.staff")) {
            staff.sendMessage("§e§lWATCHLIST§r §7" + player.getName() + " added to watchlist.");
         }
      }

   }

   public void removeFromWatchlist(Player player) {
      this.watchedPlayers.remove(player.getUniqueId());

      for(Player staff : Bukkit.getOnlinePlayers()) {
         if (staff.hasPermission("antisystem.staff")) {
            staff.sendMessage("§e§lWATCHLIST§r §7" + player.getName() + " removed from watchlist.");
         }
      }

   }

   public boolean isWatched(Player player) {
      return this.watchedPlayers.contains(player.getUniqueId());
   }

   public Set<UUID> getWatchedPlayers() {
      return new HashSet(this.watchedPlayers);
   }

   public void addToWatchlist(UUID playerUuid) {
      this.watchedPlayers.add(playerUuid);
   }

   public void removeFromWatchlist(UUID playerUuid) {
      this.watchedPlayers.remove(playerUuid);
   }

   public boolean isWatched(UUID playerUuid) {
      return this.watchedPlayers.contains(playerUuid);
   }

   @EventHandler
   public void onPlayerMove(PlayerMoveEvent event) {
      Player player = event.getPlayer();
      Location to;
      Location frozenLoc;
      if (this.isFrozen(player) && (frozenLoc = (Location)this.frozenLocations.get(player.getUniqueId())) != null && ((to = event.getTo()).getX() != frozenLoc.getX() || to.getZ() != frozenLoc.getZ() || Math.abs(to.getY() - frozenLoc.getY()) > 0.1)) {
         frozenLoc.setYaw(to.getYaw());
         frozenLoc.setPitch(to.getPitch());
         event.setTo(frozenLoc);
      }

   }

   @EventHandler
   public void onPlayerQuit(PlayerQuitEvent event) {
      Player player = event.getPlayer();
      UUID uuid = player.getUniqueId();
      if (this.isFrozen(player)) {
         for(Player staff : Bukkit.getOnlinePlayers()) {
            if (staff.hasPermission("antisystem.staff")) {
               staff.sendMessage("§c§lALERT§r §7Frozen player " + player.getName() + " logged out! Auto-banning for freeze evasion.");
            }
         }

         String banReason = "Logged out while frozen for screenshare - Freeze Evasion";
         Bukkit.getBanList(Type.NAME).addBan(player.getName(), banReason, (Date)null, "AntiSystem");
         String logTemplate = "[AntiSystem] Auto-banned %s for freeze evasion (logged out while frozen)";
         String logMessage = logTemplate.replace("%s", player.getName());
         Bukkit.getLogger().warning(logMessage);
      }

      if (this.isInStaffMode(player)) {
         this.disableStaffMode(player);
      }

      this.frozenPlayers.remove(uuid);
      this.frozenLocations.remove(uuid);
      this.lastLocations.remove(uuid);
      this.savedInventories.remove(uuid);
      this.savedGameModes.remove(uuid);
      this.savedFlight.remove(uuid);
      this.vanishedPlayers.remove(uuid);
   }

   @EventHandler
   public void onPlayerInteract(PlayerInteractEvent event) {
      Player player = event.getPlayer();
      if (this.isInStaffMode(player)) {
         ItemStack item = event.getItem();
         if (item != null && item.hasItemMeta()) {
            String displayName = item.getItemMeta().getDisplayName();
            if (displayName != null) {
               if (displayName.contains("Vanish Toggle")) {
                  event.setCancelled(true);
                  this.toggleVanish(player);
               }

            }
         }
      }
   }

   @EventHandler
   public void onPlayerJoin(PlayerJoinEvent event) {
      this.handlePlayerJoin(event.getPlayer());
   }

   public int getFrozenPlayersCount() {
      return this.frozenPlayers.size();
   }

   public int getStaffModePlayersCount() {
      return this.staffModeEnabled.size();
   }

   public void toggleVanish(Player player) {
      UUID uuid = player.getUniqueId();
      if (this.vanishedPlayers.contains(uuid)) {
         this.vanishedPlayers.remove(uuid);
         player.removePotionEffect(PotionEffectType.NIGHT_VISION);

         for(Player online : Bukkit.getOnlinePlayers()) {
            online.showPlayer(player);
         }

         this.showInTabList(player);
         player.sendMessage("§7§lVANISH §8» §7You are now §cvisible§7!");
      } else {
         this.vanishedPlayers.add(uuid);
         player.addPotionEffect(new PotionEffect(PotionEffectType.NIGHT_VISION, Integer.MAX_VALUE, 0, true, false));

         for(Player online : Bukkit.getOnlinePlayers()) {
            if (!online.isOp() && !online.hasPermission("antisystem.staff") && !online.hasPermission("antisystem.bypass.all")) {
               online.hidePlayer(player);
            }
         }

         this.hideFromTabList(player);
         player.sendMessage("§7§lVANISH §8» §7You are now §acompletely invisible§7! §8(Chat & combat disabled, persistent through logout)");
      }

      this.saveVanishedPlayers();
      if (this.isInStaffMode(player)) {
         this.updateVanishItem(player);
      }

   }

   public boolean isVanished(Player player) {
      return this.vanishedPlayers.contains(player.getUniqueId());
   }

   private void updateVanishItem(Player player) {
      boolean isVanished = this.isVanished(player);

      Material material;
      try {
         material = isVanished ? VersionCompatibility.getLimeDyeMaterial() : Material.valueOf("GRAY_DYE");
      } catch (Exception var6) {
         material = isVanished ? Material.SLIME_BALL : Material.FLINT;
      }

      ItemStack vanishTool = new ItemStack(material);
      ItemMeta vanishMeta = vanishTool.getItemMeta();
      vanishMeta.setDisplayName("§7§lVanish Toggle");
      vanishMeta.setLore(Arrays.asList("§7Click to toggle vanish mode", "§7Currently: " + (isVanished ? "§aVanished" : "§cVisible")));
      vanishTool.setItemMeta(vanishMeta);
      player.getInventory().setItem(7, vanishTool);
   }

   private void hideFromTabList(Player vanishedPlayer) {
      for(Player online : Bukkit.getOnlinePlayers()) {
         if (!online.isOp() && !online.hasPermission("antisystem.staff") && !online.hasPermission("antisystem.bypass.all")) {
            online.hidePlayer(vanishedPlayer);
         }
      }

   }

   private void showInTabList(Player player) {
      for(Player online : Bukkit.getOnlinePlayers()) {
         online.showPlayer(player);
      }

   }

   public void handlePlayerJoin(Player newPlayer) {
      UUID newPlayerUuid = newPlayer.getUniqueId();
      if (this.vanishedPlayers.contains(newPlayerUuid)) {
         newPlayer.addPotionEffect(new PotionEffect(PotionEffectType.NIGHT_VISION, Integer.MAX_VALUE, 0, true, false));

         for(Player online : Bukkit.getOnlinePlayers()) {
            if (!online.equals(newPlayer) && !online.isOp() && !online.hasPermission("antisystem.staff") && !online.hasPermission("antisystem.bypass.all")) {
               online.hidePlayer(newPlayer);
            }
         }

         this.hideFromTabList(newPlayer);
         newPlayer.sendMessage("§7§lVANISH §8» §aVanish restored! §7You are still invisible.");
      }

      if (!newPlayer.isOp() && !newPlayer.hasPermission("antisystem.staff") && !newPlayer.hasPermission("antisystem.bypass.all")) {
         for(UUID vanishedUuid : this.vanishedPlayers) {
            Player vanishedPlayer = Bukkit.getPlayer(vanishedUuid);
            if (vanishedPlayer != null && vanishedPlayer.isOnline() && !vanishedPlayer.equals(newPlayer)) {
               newPlayer.hidePlayer(vanishedPlayer);
            }
         }
      }

   }

   public Set<UUID> getVanishedPlayers() {
      return new HashSet(this.vanishedPlayers);
   }

   private void loadVanishedPlayers() {
      if (this.vanishFile.exists()) {
         Properties props = new Properties();

         try {
            FileReader reader = new FileReader(this.vanishFile);

            try {
               props.load(reader);

               for(String uuidStr : props.stringPropertyNames()) {
                  try {
                     UUID uuid = UUID.fromString(uuidStr);
                     this.vanishedPlayers.add(uuid);
                  } catch (IllegalArgumentException var7) {
                  }
               }
            } catch (Throwable var8) {
               try {
                  reader.close();
               } catch (Throwable var6) {
                  var8.addSuppressed(var6);
               }

               throw var8;
            }

            reader.close();
         } catch (IOException e) {
            String errorTemplate = "[AntiSystem] Failed to load vanished players: %s";
            String errorMessage = errorTemplate.replace("%s", e.getMessage());
            Bukkit.getLogger().warning(errorMessage);
         }

      }
   }

   private void saveVanishedPlayers() {
      Properties props = new Properties();

      for(UUID uuid : this.vanishedPlayers) {
         props.setProperty(uuid.toString(), "true");
      }

      try {
         this.vanishFile.getParentFile().mkdirs();
         FileWriter writer = new FileWriter(this.vanishFile);

         try {
            props.store(writer, "Vanished Players - Persistent across restarts");
         } catch (Throwable var6) {
            try {
               writer.close();
            } catch (Throwable var5) {
               var6.addSuppressed(var5);
            }

            throw var6;
         }

         writer.close();
      } catch (IOException e) {
         String errorTemplate = "[AntiSystem] Failed to save vanished players: %s";
         String errorMessage = errorTemplate.replace("%s", e.getMessage());
         Bukkit.getLogger().warning(errorMessage);
      }

   }

   public void cleanup() {
      for(UUID uuid : new HashSet(this.staffModeEnabled)) {
         Player player = Bukkit.getPlayer(uuid);
         if (player != null) {
            this.disableStaffMode(player);
         }
      }

      for(UUID uuid : new HashSet(this.frozenPlayers)) {
         Player player = Bukkit.getPlayer(uuid);
         if (player != null) {
            this.unfreezePlayer(player);
         }
      }

      for(UUID uuid : new HashSet(this.vanishedPlayers)) {
         Player player = Bukkit.getPlayer(uuid);
         if (player != null) {
            this.toggleVanish(player);
         }
      }

      this.staffModeEnabled.clear();
      this.savedInventories.clear();
      this.savedGameModes.clear();
      this.savedFlight.clear();
      this.lastLocations.clear();
      this.frozenPlayers.clear();
      this.frozenLocations.clear();
      this.vanishedPlayers.clear();
      this.watchedPlayers.clear();
   }
}
