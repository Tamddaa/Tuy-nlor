package com.anti.system.staff;

import com.anti.system.anticheat.DatabaseManager;
import com.anti.system.utils.VersionCompatibility;
import java.lang.reflect.InvocationTargetException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.Server;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class StaffHubGUI implements Listener {
   private final StaffManager staffManager;
   private final PunishmentManager punishmentManager;
   private final DatabaseManager database;

   public StaffHubGUI(StaffManager staffManager, PunishmentManager punishmentManager, DatabaseManager database) {
      this.staffManager = staffManager;
      this.punishmentManager = punishmentManager;
      this.database = database;
   }

   public void openStaffHub(Player staff) {
      Inventory gui = Bukkit.createInventory((InventoryHolder)null, 54, "§6§lSTAFF HUB");
      gui.setItem(0, this.createItem(VersionCompatibility.getPlayerHeadMaterial(), "§a§lOnline Players", "§7View and manage online players", "§7Sort by: Name, Ping, Flags, Reports"));
      gui.setItem(1, this.createItem(Material.BOOK, "§c§lReports", "§7Manage player reports", "§7Pending: " + this.database.getTotalReports()));
      gui.setItem(2, this.createItem(VersionCompatibility.getClockMaterial(), "§e§lRecent Punishments", "§7View recent staff actions", "§7Last 24 hours"));
      gui.setItem(3, this.createItem(VersionCompatibility.getSpyglassMaterial(), "§b§lWatchlist", "§7Manage watched players", "§7Currently watching: " + this.staffManager.getWatchedPlayers().size()));
      gui.setItem(4, this.createItem(Material.REDSTONE, "§d§lAnti-Cheat", "§7Anti-cheat management", "§7Flags, probes, analysis"));
      int onlineStaff = (int)Bukkit.getOnlinePlayers().stream().filter((p) -> p.hasPermission("antisystem.staff")).count();
      int frozenPlayers = this.staffManager.getFrozenPlayersCount();
      int staffMode = this.staffManager.getStaffModePlayersCount();
      gui.setItem(9, this.createItem(VersionCompatibility.getGreenWoolMaterial(), "§a§lServer Stats", "§7Online Players: §f" + Bukkit.getOnlinePlayers().size(), "§7Staff Online: §f" + onlineStaff, "§7TPS: §f" + String.format("%.1f", this.getCurrentTPS())));
      gui.setItem(10, this.createItem(VersionCompatibility.getBlueWoolMaterial(), "§b§lStaff Stats", "§7Staff in Mode: §f" + staffMode, "§7Frozen Players: §f" + frozenPlayers, "§7Active Investigations: §f" + frozenPlayers));
      gui.setItem(18, this.createItem(Material.COMPASS, "§6§lQuick Actions", "§7Emergency server controls", "§7Lag diagnostics, entity cleanup"));
      gui.setItem(19, this.createItem(VersionCompatibility.getCommandBlockMaterial(), "§c§lMacros", "§7Pre-configured staff macros", "§7One-click common actions"));
      gui.setItem(20, this.createItem(Material.CHEST, "§e§lTemplates", "§7Punishment templates and reasons", "§7Quick-fill common punishments"));
      this.populateOnlinePlayersView(gui);
      staff.openInventory(gui);
   }

   private void populateOnlinePlayersView(Inventory gui) {
      for(int i = 27; i < 54; ++i) {
         gui.setItem(i, (ItemStack)null);
      }

      List<Player> players = (List)Bukkit.getOnlinePlayers().stream().filter((p) -> !p.hasPermission("antisystem.staff")).sorted(Comparator.comparing(OfflinePlayer::getName)).collect(Collectors.toList());
      int slot = 27;

      for(Player player : players) {
         if (slot >= 54) {
            break;
         }

         Material material = VersionCompatibility.getPlayerHeadMaterial();
         String statusColor = "§a";
         if (this.staffManager.isFrozen(player)) {
            material = VersionCompatibility.getBlueIceMaterial();
            statusColor = "§b";
         } else if (this.punishmentManager.isMuted(player.getUniqueId())) {
            material = Material.REDSTONE_BLOCK;
            statusColor = "§c";
         } else if (this.staffManager.isWatched(player)) {
            material = VersionCompatibility.getSpyglassMaterial();
            statusColor = "§e";
         }

         gui.setItem(slot, this.createPlayerItem(material, player, statusColor));
         ++slot;
      }

      gui.setItem(45, this.createItem(Material.ARROW, "§7Sort by Name", "§7Click to sort alphabetically"));
      gui.setItem(46, this.createItem(VersionCompatibility.getClockMaterial(), "§7Sort by Ping", "§7Click to sort by connection"));
      gui.setItem(47, this.createItem(Material.REDSTONE, "§7Sort by Flags", "§7Click to sort by violations"));
      gui.setItem(49, this.createItem(Material.BARRIER, "§c§lClose", "§7Close staff hub"));
   }

   private ItemStack createPlayerItem(Material material, Player player, String statusColor) {
      ItemStack item = new ItemStack(material);
      ItemMeta meta = item.getItemMeta();
      meta.setDisplayName(statusColor + "§l" + player.getName());
      String[] lore = new String[]{"§7Ping: §f" + this.getPlayerPing(player) + "ms", "§7World: §f" + player.getWorld().getName(), "§7Health: §f" + String.format("%.1f", player.getHealth()) + "/20.0", "", "§eLeft-click: QuickMod", "§eRight-click: Teleport to", "§eShift-click: Add to watchlist"};
      if (this.staffManager.isFrozen(player)) {
         lore[0] = "§b§lFROZEN §7for screenshare";
      } else if (this.punishmentManager.isMuted(player.getUniqueId())) {
         lore[0] = "§c§lMUTED §7" + this.punishmentManager.getRemainingMuteTime(player.getUniqueId());
      } else if (this.staffManager.isWatched(player)) {
         lore[0] = "§e§lWATCHED §7suspicious behavior";
      }

      meta.setLore(Arrays.asList(lore));
      item.setItemMeta(meta);
      return item;
   }

   @EventHandler
   public void onStaffHubClick(InventoryClickEvent event) {
      if (event.getWhoClicked() instanceof Player) {
         Player staff = (Player)event.getWhoClicked();
         String title = event.getView().getTitle();
         if (title.equals("STAFF HUB")) {
            event.setCancelled(true);
            ItemStack clicked = event.getCurrentItem();
            if (clicked != null && clicked.hasItemMeta()) {
               String itemName = clicked.getItemMeta().getDisplayName();
               int slot = event.getSlot();
               if (slot >= 0 && slot <= 4) {
                  this.handleTabClick(slot, event.getInventory());
               } else if (slot >= 27 && slot < 54) {
                  this.handlePlayerClick(staff, itemName, event.getClick());
               } else {
                  switch (itemName) {
                     case "§c§lClose":
                        staff.closeInventory();
                        break;
                     case "§6§lQuick Actions":
                        this.openQuickActionsGUI(staff);
                        break;
                     case "§c§lMacros":
                        this.openMacrosGUI(staff);
                        break;
                     case "§e§lTemplates":
                        this.openTemplatesGUI(staff);
                  }

               }
            }
         }
      }
   }

   private void handleTabClick(int tab, Inventory gui) {
      switch (tab) {
         case 0:
            this.populateOnlinePlayersView(gui);
            break;
         case 1:
            this.populateReportsView(gui);
            break;
         case 2:
            this.populateRecentPunishmentsView(gui);
            break;
         case 3:
            this.populateWatchlistView(gui);
            break;
         case 4:
            this.populateAntiCheatView(gui);
      }

   }

   private void populateReportsView(Inventory gui) {
      for(int i = 27; i < 54; ++i) {
         gui.setItem(i, (ItemStack)null);
      }

      List<String> reports = this.database.getPendingReports();
      if (reports.isEmpty()) {
         gui.setItem(40, this.createItem(VersionCompatibility.getGrayStainedGlassPaneMaterial(), "§7No Pending Reports", "§7All reports have been handled!"));
      } else {
         int slot = 27;

         for(String report : reports) {
            if (slot >= 54) {
               break;
            }

            gui.setItem(slot, this.createItem(Material.BOOK, "§c§lReport #" + (slot - 26), "§7" + report, "§eClick to investigate"));
            ++slot;
         }
      }

   }

   private void populateRecentPunishmentsView(Inventory gui) {
      for(int i = 27; i < 54; ++i) {
         gui.setItem(i, (ItemStack)null);
      }

      String[] recentPunishments = new String[]{"TestPlayer1 - Muted 1h - Spam", "TestPlayer2 - Warned - Language", "TestPlayer3 - Kicked - Griefing", "TestPlayer4 - Banned 7d - Hacking"};
      int slot = 27;

      for(String punishment : recentPunishments) {
         gui.setItem(slot, this.createItem(Material.PAPER, "§e§lRecent Action", "§7" + punishment, "§7" + LocalDateTime.now().minusHours((long)(slot - 27)).format(DateTimeFormatter.ofPattern("HH:mm"))));
         ++slot;
      }

   }

   private void populateWatchlistView(Inventory gui) {
      for(int i = 27; i < 54; ++i) {
         gui.setItem(i, (ItemStack)null);
      }

      Set<UUID> watchedPlayers = this.staffManager.getWatchedPlayers();
      if (watchedPlayers.isEmpty()) {
         gui.setItem(40, this.createItem(VersionCompatibility.getGrayStainedGlassPaneMaterial(), "§7No Watched Players", "§7Watchlist is empty"));
      } else {
         int slot = 27;

         for(UUID watchedUUID : watchedPlayers) {
            if (slot >= 54) {
               break;
            }

            Player watched = Bukkit.getPlayer(watchedUUID);
            String playerName = watched != null ? watched.getName() : "Unknown";
            String status = watched != null && watched.isOnline() ? "§aOnline" : "§cOffline";
            gui.setItem(slot, this.createItem(VersionCompatibility.getSpyglassMaterial(), "§e§l" + playerName, "§7Status: " + status, "§7Reason: Suspicious behavior", "§eClick to manage"));
            ++slot;
         }
      }

   }

   private void populateAntiCheatView(Inventory gui) {
      for(int i = 27; i < 54; ++i) {
         gui.setItem(i, (ItemStack)null);
      }

      gui.setItem(30, this.createItem(Material.REDSTONE, "§c§lActive Flags", "§7Players with recent violations", "§7Click to view details"));
      gui.setItem(31, this.createItem(VersionCompatibility.getCommandBlockMaterial(), "§6§lMass Probe", "§7Run probe on all online players", "§7Detects suspicious patterns"));
      gui.setItem(32, this.createItem(Material.BOOK, "§e§lViolation Log", "§7View anti-cheat violation history", "§7Last 24 hours"));
   }

   private void handlePlayerClick(Player staff, String playerName, ClickType clickType) {
      String cleanName = playerName.replaceAll("§[0-9a-fklmnor]", "").replaceAll("§l", "");
      Player target = (Player)Bukkit.getOnlinePlayers().stream().filter((p) -> p.getName().equals(cleanName)).findFirst().orElse((Object)null);
      if (target == null) {
         staff.sendMessage("§cPlayer is no longer online!");
      } else {
         switch (clickType) {
            case LEFT:
               staff.closeInventory();
               if (Bukkit.getPluginManager().getPlugin("AntiCheat") != null) {
                  QuickModGUI quickMod = new QuickModGUI(this.staffManager, this.punishmentManager);
                  quickMod.openQuickModGUI(staff, target);
               }
               break;
            case RIGHT:
               this.staffManager.setLastLocation(staff, staff.getLocation());
               staff.teleport(target.getLocation());
               staff.sendMessage("§d§lTELEPORT §7Teleported to " + target.getName());
               staff.closeInventory();
               break;
            case SHIFT_LEFT:
            case SHIFT_RIGHT:
               if (this.staffManager.isWatched(target)) {
                  this.staffManager.removeFromWatchlist(target);
                  staff.sendMessage("§e§lWATCHLIST §7Removed " + target.getName() + " from watchlist");
               } else {
                  this.staffManager.addToWatchlist(target);
                  staff.sendMessage("§e§lWATCHLIST §7Added " + target.getName() + " to watchlist");
               }

               this.populateOnlinePlayersView(staff.getOpenInventory().getTopInventory());
         }

      }
   }

   private void openQuickActionsGUI(Player staff) {
      Inventory gui = Bukkit.createInventory((InventoryHolder)null, 27, "§6§lQuick Actions");
      gui.setItem(10, this.createItem(Material.REDSTONE, "§c§lLag Diagnostics", "§7Check server performance", "§7TPS, memory, chunks"));
      gui.setItem(11, this.createItem(this.getFireChargeMaterial(), "§6§lEntity Cleanup", "§7Remove excess entities", "§7Items, mobs, projectiles"));
      gui.setItem(12, this.createItem(Material.TNT, "§4§lEmergency Stop", "§7Emergency server controls", "§7Use with caution!"));
      gui.setItem(13, this.createItem(Material.WATER_BUCKET, "§b§lClear Chat", "§7Clear chat for all players", "§7Spam cleanup"));
      gui.setItem(22, this.createItem(Material.BARRIER, "§c§lBack", "§7Return to staff hub"));
      staff.openInventory(gui);
   }

   private void openMacrosGUI(Player staff) {
      Inventory gui = Bukkit.createInventory((InventoryHolder)null, 27, "§c§lStaff Macros");
      gui.setItem(10, this.createItem(Material.ICE, "§b§lFreeze + Alert", "§7Freeze + staff chat + SS instructions", "§7One-click screenshare setup"));
      gui.setItem(11, this.createItem(Material.REDSTONE_BLOCK, "§c§lMute Spam", "§7Mute for spam + warning", "§7Quick spam punishment"));
      gui.setItem(12, this.createItem(Material.BOOK, "§e§lWarning Template", "§7Common warning with reason", "§7Pre-filled common violations"));
      gui.setItem(22, this.createItem(Material.BARRIER, "§c§lBack", "§7Return to staff hub"));
      staff.openInventory(gui);
   }

   private void openTemplatesGUI(Player staff) {
      Inventory gui = Bukkit.createInventory((InventoryHolder)null, 27, "§e§lPunishment Templates");
      gui.setItem(10, this.createItem(VersionCompatibility.getYellowWoolMaterial(), "§e§lBhop Template", "§7Auto-fill bhop punishment", "§7Duration: 1d, Reason: Bhop/Speed hacks"));
      gui.setItem(11, this.createItem(VersionCompatibility.getRedWoolMaterial(), "§c§lKillaura Template", "§7Auto-fill killaura punishment", "§7Duration: 7d, Reason: Combat hacks"));
      gui.setItem(12, this.createItem(VersionCompatibility.getOrangeWoolMaterial(), "§6§lFly Template", "§7Auto-fill fly punishment", "§7Duration: 3d, Reason: Flight hacks"));
      gui.setItem(22, this.createItem(Material.BARRIER, "§c§lBack", "§7Return to staff hub"));
      staff.openInventory(gui);
   }

   private ItemStack createItem(Material material, String name, String... lore) {
      ItemStack item = new ItemStack(material);
      ItemMeta meta = item.getItemMeta();
      meta.setDisplayName(name);
      meta.setLore(Arrays.asList(lore));
      item.setItemMeta(meta);
      return item;
   }

   private double getCurrentTPS() {
      try {
         Server server = Bukkit.getServer();
         return ((double[])server.getClass().getMethod("getTPS").invoke(server))[0];
      } catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException var2) {
         return (double)20.0F;
      }
   }

   private Material getFireChargeMaterial() {
      try {
         return Material.valueOf("FIRE_CHARGE");
      } catch (Exception var4) {
         try {
            return Material.valueOf("FIREBALL");
         } catch (Exception var3) {
            return Material.BLAZE_POWDER;
         }
      }
   }

   private int getPlayerPing(Player player) {
      try {
         Object handle = player.getClass().getMethod("getHandle").invoke(player);
         Object ping = handle.getClass().getField("ping").get(handle);
         return (Integer)ping;
      } catch (IllegalAccessException | NoSuchFieldException | InvocationTargetException | NoSuchMethodException var8) {
         try {
            Object handle = player.getClass().getMethod("getHandle").invoke(player);
            Object playerConnection = handle.getClass().getField("playerConnection").get(handle);
            Object networkManager = playerConnection.getClass().getField("networkManager").get(playerConnection);
            Object ping = networkManager.getClass().getMethod("getAverageLatency").invoke(networkManager);
            return (Integer)ping;
         } catch (IllegalAccessException | NoSuchFieldException | InvocationTargetException | NoSuchMethodException var7) {
            return 0;
         }
      }
   }
}
