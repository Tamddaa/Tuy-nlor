package com.anti.system.staff;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class KickCommand implements CommandExecutor {
   public boolean onCommand(CommandSender sender, Command command, String label, String[] args2) {
      if (!sender.hasPermission("antisystem.staff.kick")) {
         sender.sendMessage("§cYou don't have permission to use this command.");
         return true;
      } else if (args2.length < 1) {
         sender.sendMessage("§cUsage: /kick <player> [reason]");
         return true;
      } else {
         String targetName = args2[0];
         Player target = (Player)Bukkit.getOnlinePlayers().stream().filter((p) -> p.getName().equalsIgnoreCase(targetName)).findFirst().orElse((Object)null);
         if (target == null) {
            sender.sendMessage("§cPlayer not found or not online.");
            return true;
         } else {
            String reason = "No reason specified";
            if (args2.length >= 2) {
               StringBuilder reasonBuilder = new StringBuilder();

               for(int i = 1; i < args2.length; ++i) {
                  reasonBuilder.append(args2[i]).append(" ");
               }

               reason = reasonBuilder.toString().trim();
            }

            target.kickPlayer("§c§lKICKED\n§7Reason: " + reason + "\n§7By: " + sender.getName());
            sender.sendMessage("§a" + target.getName() + " has been kicked for: " + reason);
            String announcement = "§c[STAFF] " + sender.getName() + " kicked " + target.getName() + " for: " + reason;

            for(Player staff : Bukkit.getOnlinePlayers()) {
               if (staff.hasPermission("antisystem.staff") && !staff.equals(sender)) {
                  staff.sendMessage(announcement);
               }
            }

            return true;
         }
      }
   }
}
