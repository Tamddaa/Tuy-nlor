package com.anti.system.staff;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

public class MacroManager {
   private final Map<String, String> macros = new HashMap();
   private final Map<String, String> macroDescriptions = new HashMap();

   public MacroManager() {
      this.loadDefaultMacros();
   }

   private void loadDefaultMacros() {
      this.macros.put("1", "freeze %player% & staffchat %player% frozen for SS & msg %player% §cYou have been frozen for screenshare. Join our Discord: discord.gg/server");
      this.macroDescriptions.put("1", "Freeze player for screenshare");
      this.macros.put("2", "ban %player% 1d Hacking (Auto-detected) & staffchat Banned %player% for hacking");
      this.macroDescriptions.put("2", "Ban player for 1 day - Hacking");
      this.macros.put("3", "mute %player% 15m Toxic behavior & staffchat Muted %player% for toxicity");
      this.macroDescriptions.put("3", "Mute player for 15 minutes - Toxic");
      this.macros.put("4", "kick %player% Read the rules! & staffchat Kicked %player% for rule violation");
      this.macroDescriptions.put("4", "Kick player with rules reminder");
      this.macros.put("5", "warn %player% First warning for rule breaking & note add %player% Warned for rule violation");
      this.macroDescriptions.put("5", "Warn player and add note");
      this.macros.put("lag", "bc §c[AntiSystem] §eFixing server lag... & clearlag & gc");
      this.macroDescriptions.put("lag", "Lag fix broadcast and cleanup");
      this.macros.put("ss", "freeze %player% & staffchat %player% frozen for screenshare - respond ASAP & msg %player% §c§lFROZEN for Screenshare\\n§eJoin Discord: discord.gg/server\\n§eDo not log out or you will be banned!");
      this.macroDescriptions.put("ss", "Full screenshare freeze protocol");
   }

   public void createMacro(Player staff, String id, String commands) {
      this.macros.put(id, commands);
      this.macroDescriptions.put(id, "Custom macro by " + staff.getName());
      staff.sendMessage("§aCreated macro '" + id + "': " + commands);
   }

   public void deleteMacro(Player staff, String id) {
      if (this.macros.containsKey(id)) {
         this.macros.remove(id);
         this.macroDescriptions.remove(id);
         staff.sendMessage("§aDeleted macro: " + id);
      } else {
         staff.sendMessage("§cMacro not found: " + id);
      }

   }

   public void runMacro(Player staff, String id, String targetPlayer) {
      String commands = (String)this.macros.get(id);
      if (commands == null) {
         staff.sendMessage("§cMacro not found: " + id);
      } else {
         commands = targetPlayer != null ? commands.replace("%player%", targetPlayer) : commands.replace("%player%", "");
         commands = commands.replace("%staff%", staff.getName());
         String[] finalCommands = commands.split(" & ");

         for(String cmd : finalCommands) {
            if (!(cmd = cmd.trim()).isEmpty()) {
               this.executeCommand(staff, cmd);
            }
         }

         staff.sendMessage("§aExecuted macro: " + id);
      }
   }

   private void executeCommand(Player staff, String command) {
      if (command.startsWith("staffchat ")) {
         String message = command.substring(10);
         String staffMsg = "§c[STAFF] §e" + staff.getName() + "§f: " + message;

         for(Player onlineStaff : Bukkit.getOnlinePlayers()) {
            if (onlineStaff.hasPermission("antisystem.staff")) {
               onlineStaff.sendMessage(staffMsg);
            }
         }
      } else if (command.startsWith("msg ")) {
         String[] parts = command.split(" ", 3);
         if (parts.length >= 3) {
            Player target = (Player)Bukkit.getOnlinePlayers().stream().filter((p) -> p.getName().equalsIgnoreCase(parts[1])).findFirst().orElse((Object)null);
            if (target != null) {
               target.sendMessage("§e" + parts[2].replace("\\n", "\n"));
            }
         }
      } else if (command.startsWith("bc ")) {
         String message = command.substring(3);
         Bukkit.broadcastMessage("§e" + message);
      } else if (command.equals("clearlag")) {
         Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "minecraft:kill @e[type=!minecraft:player]");
      } else if (command.equals("gc")) {
         System.gc();
      } else {
         Bukkit.dispatchCommand(staff, command);
      }

   }

   public void listMacros(Player staff) {
      staff.sendMessage("§6=== AVAILABLE MACROS ===");

      for(Map.Entry<String, String> entry : this.macros.entrySet()) {
         String description = (String)this.macroDescriptions.getOrDefault(entry.getKey(), "No description");
         staff.sendMessage("§e/" + (String)entry.getKey() + " - §f" + description);
      }

      staff.sendMessage("§7Usage: /macro <id> [player]");
   }

   public Set<String> getMacroIds() {
      return this.macros.keySet();
   }

   public String getMacro(String id) {
      return (String)this.macros.get(id);
   }
}
