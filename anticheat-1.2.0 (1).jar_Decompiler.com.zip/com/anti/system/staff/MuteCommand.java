package com.anti.system.staff;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class MuteCommand implements CommandExecutor {
   private final PunishmentManager punishmentManager;

   public MuteCommand(PunishmentManager punishmentManager) {
      this.punishmentManager = punishmentManager;
   }

   public boolean onCommand(CommandSender sender, Command command, String label, String[] args2) {
      if (!sender.hasPermission("antisystem.staff.mute")) {
         sender.sendMessage("§cYou don't have permission to use this command.");
         return true;
      } else if (args2.length < 1) {
         sender.sendMessage("§cUsage: /mute <player> [time] [reason]");
         sender.sendMessage("§cExample: /mute Player123 1h Spamming chat");
         return true;
      } else {
         String targetName = args2[0];
         Player target = (Player)Bukkit.getOnlinePlayers().stream().filter((p) -> p.getName().equalsIgnoreCase(targetName)).findFirst().orElse((Object)null);
         if (target == null) {
            sender.sendMessage("§cPlayer not found or not online.");
            return true;
         } else {
            String duration = "perm";
            String reason = "No reason specified";
            if (args2.length >= 2) {
               String timeStr = args2[1];
               if (this.isValidTimeFormat(timeStr)) {
                  duration = timeStr;
                  if (args2.length >= 3) {
                     StringBuilder reasonBuilder = new StringBuilder();

                     for(int i = 2; i < args2.length; ++i) {
                        reasonBuilder.append(args2[i]).append(" ");
                     }

                     reason = reasonBuilder.toString().trim();
                  }
               } else {
                  StringBuilder reasonBuilder = new StringBuilder();

                  for(int i = 1; i < args2.length; ++i) {
                     reasonBuilder.append(args2[i]).append(" ");
                  }

                  reason = reasonBuilder.toString().trim();
               }
            }

            try {
               this.punishmentManager.mutePlayer(target.getUniqueId(), sender.getName(), reason, duration);
               sender.sendMessage("§a" + target.getName() + " has been muted for: " + reason);
            } catch (Exception e) {
               sender.sendMessage("§cFailed to mute player: " + e.getMessage());
            }

            return true;
         }
      }
   }

   private boolean isValidTimeFormat(String timeStr) {
      return !timeStr.equalsIgnoreCase("perm") && !timeStr.equalsIgnoreCase("permanent") ? timeStr.matches("\\d+[smhdw]") : true;
   }
}
