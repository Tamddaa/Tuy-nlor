package com.anti.system.staff;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.metadata.FixedMetadataValue;

public class StaffGUIListener implements Listener {
   private final StaffManager staffManager;

   public StaffGUIListener(StaffManager staffManager) {
      this.staffManager = staffManager;
   }

   @EventHandler
   public void onInventoryClick(InventoryClickEvent event) {
      if (event.getWhoClicked() instanceof Player) {
         Player player = (Player)event.getWhoClicked();
         String titleString = event.getView().getTitle();
         if (titleString.contains("Staff Hub") || titleString.contains("Quick Mod") || titleString.contains("Inspecting")) {
            event.setCancelled(true);
            ItemStack clicked = event.getCurrentItem();
            if (clicked != null && clicked.getType() != Material.AIR) {
               if (clicked.getItemMeta() != null && clicked.getItemMeta().getDisplayName() != null) {
                  String itemName = clicked.getItemMeta().getDisplayName();
                  if (titleString.contains("Staff Hub")) {
                     this.handleStaffHubClick(player, itemName);
                  } else if (titleString.contains("Quick Mod")) {
                     String targetName = this.extractTargetName(titleString);
                     this.handleQuickModClick(player, targetName, itemName);
                  } else if (titleString.contains("Inspecting")) {
                     String targetName = this.extractTargetName(titleString);
                     this.handleInspectionClick(player, targetName, itemName);
                  }

               }
            }
         }
      }
   }

   private void handleStaffHubClick(Player player, String itemName) {
      switch (itemName.toLowerCase()) {
         case "close":
            player.closeInventory();
            break;
         case "staff mode":
            if (this.staffManager.isInStaffMode(player)) {
               this.staffManager.disableStaffMode(player);
            } else {
               this.staffManager.enableStaffMode(player);
            }

            player.closeInventory();
            break;
         case "lag diagnostics":
            player.performCommand("staff lagkit");
            break;
         case "watchlist":
            player.performCommand("staff watchlist");
            break;
         case "reports queue":
            player.performCommand("staff reports");
            break;
         case "helpop queue":
            player.performCommand("staff helpop");
      }

   }

   private void handleQuickModClick(Player player, String targetName, String itemName) {
      Player target = this.getOnlinePlayer(targetName);
      if (target == null) {
         player.sendMessage("§cTarget player is no longer online.");
         player.closeInventory();
      } else {
         switch (itemName.toLowerCase()) {
            case "close":
               player.closeInventory();
               break;
            case "warn player":
               player.closeInventory();
               player.performCommand("warn " + targetName + " Rule violation");
               player.sendMessage("§e" + targetName + " has been warned.");
               break;
            case "mute player":
               player.closeInventory();
               player.performCommand("mute " + targetName + " 10m Rule violation");
               player.sendMessage("§e" + targetName + " has been muted for 10 minutes.");
               break;
            case "kick player":
               player.closeInventory();
               player.performCommand("kick " + targetName + " Kicked by staff");
               player.sendMessage("§e" + targetName + " has been kicked.");
               break;
            case "ban player":
               player.closeInventory();
               player.performCommand("ban " + targetName + " 1d Banned by staff");
               player.sendMessage("§e" + targetName + " has been banned for 1 day.");
               break;
            case "freeze":
               if (this.staffManager.isFrozen(target)) {
                  this.staffManager.unfreezePlayer(target);
                  player.sendMessage("§a" + targetName + " has been unfrozen.");
               } else {
                  this.staffManager.freezePlayer(target);
                  player.sendMessage("§c" + targetName + " has been frozen.");
               }

               player.closeInventory();
               break;
            case "teleport to":
               player.teleport(target.getLocation());
               player.sendMessage("§aTeleported to " + targetName);
               player.closeInventory();
               break;
            case "add note":
               player.closeInventory();
               player.sendMessage("§eType the note to add in chat:");
               player.setMetadata("antisystem.input.note", new FixedMetadataValue(Bukkit.getPluginManager().getPlugin("AntiCheat"), targetName));
               break;
            case "probe":
               player.performCommand("staff probe " + targetName);
               player.closeInventory();
               break;
            case "inspect inventory":
               player.openInventory(target.getInventory());
               break;
            case "ender chest":
               player.openInventory(target.getEnderChest());
               break;
            case "full inspect":
               player.performCommand("staff inspect " + targetName);
         }

      }
   }

   private void handleInspectionClick(Player player, String targetName, String itemName) {
      Player target = this.getOnlinePlayer(targetName);
      if (target == null) {
         player.sendMessage("§cTarget player is no longer online.");
         player.closeInventory();
      } else {
         switch (itemName.toLowerCase()) {
            case "close":
               player.closeInventory();
               break;
            case "view inventory":
               player.openInventory(target.getInventory());
               break;
            case "ender chest":
               player.openInventory(target.getEnderChest());
               break;
            case "probe":
               player.performCommand("staff probe " + targetName);
               break;
            case "freeze":
               player.performCommand("staff freeze " + targetName);
               break;
            case "teleport":
               player.performCommand("staff stp " + targetName);
               break;
            case "notes":
               this.openNotesGUI(player, targetName);
               break;
            case "punishment history":
               this.showPunishmentHistory(player, targetName);
               break;
            case "flags":
               this.showAntiCheatFlags(player, targetName);
         }

      }
   }

   private String extractTargetName(String title) {
      String[] parts = title.split(": ");
      return parts.length > 1 ? parts[1].trim() : "";
   }

   private void openNotesGUI(Player staff, String targetName) {
      staff.sendMessage("§eNotes for " + targetName + ":");
      staff.sendMessage("§7• Example note: Player reported for griefing");
      staff.sendMessage("§7• Example note: Warned for spam in chat");
      staff.sendMessage("§7Use /staff note " + targetName + " <note> to add a note");
   }

   private void showPunishmentHistory(Player staff, String targetName) {
      staff.sendMessage("§ePunishment history for " + targetName + ":");
      staff.sendMessage("§7• 2024-08-01: Muted for 1h - Spam");
      staff.sendMessage("§7• 2024-07-28: Warned - Language");
      staff.sendMessage("§7Total punishments: 2");
   }

   private void showAntiCheatFlags(Player staff, String targetName) {
      staff.sendMessage("§eAnti-cheat flags for " + targetName + ":");
      Player target = this.getOnlinePlayer(targetName);
      if (target != null && target.hasMetadata("antisystem.flags")) {
         staff.sendMessage("§c• Recent speed violations: 3");
         staff.sendMessage("§c• Suspicious combat patterns detected");
      } else {
         staff.sendMessage("§7No recent flags detected");
      }

      staff.sendMessage("§7Use /staff probe " + targetName + " for detailed analysis");
   }

   @EventHandler
   public void onInventoryDrag(InventoryDragEvent event) {
      String title = event.getView().getTitle();
      if (title.contains("Staff Hub") || title.contains("Quick Mod") || title.contains("Inspecting")) {
         event.setCancelled(true);
      }

   }

   private Player getOnlinePlayer(String playerName) {
      return (Player)Bukkit.getOnlinePlayers().stream().filter((p) -> p.getName().equalsIgnoreCase(playerName)).findFirst().orElse((Object)null);
   }
}
