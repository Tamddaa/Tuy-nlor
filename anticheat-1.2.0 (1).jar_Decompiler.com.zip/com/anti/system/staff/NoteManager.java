package com.anti.system.staff;

import com.anti.system.anticheat.DatabaseManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

public class NoteManager {
   private final JavaPlugin plugin;
   private final DatabaseManager database;
   private static final DateTimeFormatter DATE_FORMAT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

   public NoteManager(JavaPlugin plugin, DatabaseManager database) {
      this.plugin = plugin;
      this.database = database;
      this.createNotesTable();
   }

   private void createNotesTable() {
      String query = "CREATE TABLE IF NOT EXISTS player_notes (id INTEGER PRIMARY KEY AUTOINCREMENT,player_name TEXT NOT NULL,staff_name TEXT NOT NULL,note TEXT NOT NULL,timestamp INTEGER NOT NULL,created_at DATETIME DEFAULT CURRENT_TIMESTAMP)";

      try {
         PreparedStatement stmt = this.database.getConnection().prepareStatement(query);

         try {
            stmt.executeUpdate();
         } catch (Throwable var6) {
            if (stmt != null) {
               try {
                  stmt.close();
               } catch (Throwable var5) {
                  var6.addSuppressed(var5);
               }
            }

            throw var6;
         }

         if (stmt != null) {
            stmt.close();
         }
      } catch (SQLException e) {
         this.plugin.getLogger().log(Level.SEVERE, "Failed to create notes table", e);
      }

   }

   public void addNote(String playerName, String staffName, String note) {
      long timestamp = System.currentTimeMillis();
      String query = "INSERT INTO player_notes (player_name, staff_name, note, timestamp) VALUES (?, ?, ?, ?)";

      try {
         PreparedStatement stmt = this.database.getConnection().prepareStatement(query);

         try {
            stmt.setString(1, playerName);
            stmt.setString(2, staffName);
            stmt.setString(3, note);
            stmt.setLong(4, timestamp);
            stmt.executeUpdate();
         } catch (Throwable var11) {
            if (stmt != null) {
               try {
                  stmt.close();
               } catch (Throwable var10) {
                  var11.addSuppressed(var10);
               }
            }

            throw var11;
         }

         if (stmt != null) {
            stmt.close();
         }
      } catch (SQLException e) {
         this.plugin.getLogger().log(Level.SEVERE, "Failed to add note", e);
      }

      this.plugin.getLogger().info(String.format("Note added for %s by %s: %s", playerName, staffName, note));
   }

   public void viewNotes(Player staff, String playerName) {
      List<PlayerNote> notes = this.getNotes(playerName);
      if (notes.isEmpty()) {
         staff.sendMessage("§eNo notes found for " + playerName);
      } else {
         staff.sendMessage("§6=== NOTES FOR " + playerName.toUpperCase() + " ===");

         for(PlayerNote note : notes) {
            String dateStr = Instant.ofEpochMilli(note.timestamp()).atZone(ZoneId.systemDefault()).format(DATE_FORMAT);
            staff.sendMessage("§7[" + dateStr + "] §9" + note.staffName() + "§f: " + note.note());
         }

      }
   }

   public void listPlayersWithNotes(Player staff) {
      try {
         PreparedStatement stmt = this.database.getConnection().prepareStatement("SELECT player_name, COUNT(*) as note_count FROM player_notes GROUP BY player_name ORDER BY note_count DESC LIMIT 20");

         try {
            ResultSet rs = stmt.executeQuery();
            staff.sendMessage("§6=== PLAYERS WITH NOTES ===");

            while(rs.next()) {
               String playerName = rs.getString("player_name");
               int noteCount = rs.getInt("note_count");
               staff.sendMessage("§f• " + playerName + " (" + noteCount + " notes)");
            }
         } catch (Throwable var7) {
            if (stmt != null) {
               try {
                  stmt.close();
               } catch (Throwable var6) {
                  var7.addSuppressed(var6);
               }
            }

            throw var7;
         }

         if (stmt != null) {
            stmt.close();
         }
      } catch (SQLException e) {
         this.plugin.getLogger().log(Level.SEVERE, "Error listing players with notes", e);
         staff.sendMessage("§cError retrieving player list");
      }

   }

   public List<PlayerNote> getNotes(String playerName) {
      ArrayList<PlayerNote> notes = new ArrayList();

      try {
         PreparedStatement stmt = this.database.getConnection().prepareStatement("SELECT staff_name, note, timestamp FROM player_notes WHERE player_name = ? ORDER BY timestamp DESC");

         try {
            stmt.setString(1, playerName);
            ResultSet rs = stmt.executeQuery();

            while(rs.next()) {
               notes.add(new PlayerNote(playerName, rs.getString("staff_name"), rs.getString("note"), rs.getLong("timestamp")));
            }
         } catch (Throwable var7) {
            if (stmt != null) {
               try {
                  stmt.close();
               } catch (Throwable var6) {
                  var7.addSuppressed(var6);
               }
            }

            throw var7;
         }

         if (stmt != null) {
            stmt.close();
         }
      } catch (SQLException e) {
         this.plugin.getLogger().log(Level.SEVERE, "Error getting notes for " + playerName, e);
      }

      return notes;
   }

   public int getNoteCount(String playerName) {
      try {
         PreparedStatement stmt = this.database.getConnection().prepareStatement("SELECT COUNT(*) FROM player_notes WHERE player_name = ?");

         int n;
         label48: {
            int var5;
            try {
               stmt.setString(1, playerName);
               ResultSet rs = stmt.executeQuery();
               if (!rs.next()) {
                  n = 0;
                  break label48;
               }

               n = rs.getInt(1);
               var5 = n;
            } catch (Throwable var7) {
               if (stmt != null) {
                  try {
                     stmt.close();
                  } catch (Throwable var6) {
                     var7.addSuppressed(var6);
                  }
               }

               throw var7;
            }

            if (stmt != null) {
               stmt.close();
            }

            return var5;
         }

         if (stmt != null) {
            stmt.close();
         }

         return n;
      } catch (SQLException e) {
         this.plugin.getLogger().log(Level.SEVERE, "Error getting note count for " + playerName, e);
         return 0;
      }
   }

   public static class PlayerNote {
      private final String playerName;
      private final String staffName;
      private final String note;
      private final long timestamp;

      public PlayerNote(String playerName, String staffName, String note, long timestamp) {
         this.playerName = playerName;
         this.staffName = staffName;
         this.note = note;
         this.timestamp = timestamp;
      }

      public String playerName() {
         return this.playerName;
      }

      public String staffName() {
         return this.staffName;
      }

      public String note() {
         return this.note;
      }

      public long timestamp() {
         return this.timestamp;
      }
   }
}
