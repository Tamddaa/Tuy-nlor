package com.anti.system.staff;

import com.anti.system.utils.VersionCompatibility;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

public class StpCommand implements CommandExecutor, TabCompleter {
   private final StaffManager staffManager;

   public StpCommand(StaffManager staffManager) {
      this.staffManager = staffManager;
   }

   public boolean onCommand(CommandSender sender, Command command, String label, String[] args2) {
      if (command != null && sender != null) {
         if (!(sender instanceof Player)) {
            sender.sendMessage("§cOnly players can use this command!");
            return true;
         } else {
            Player staff = (Player)sender;
            if (!staff.hasPermission("antisystem.staff.stp")) {
               staff.sendMessage("§cNo permission!");
               return true;
            } else if (args2.length == 0) {
               staff.sendMessage("§cUsage: /stp <player>");
               return true;
            } else {
               Player target = null;

               for(Player player : Bukkit.getOnlinePlayers()) {
                  if (player.getName().equalsIgnoreCase(args2[0])) {
                     target = player;
                     break;
                  }
               }

               if (target == null) {
                  staff.sendMessage("§cPlayer not found!");
                  return true;
               } else {
                  this.smartTeleport(staff, target);
                  return true;
               }
            }
         }
      } else {
         return false;
      }
   }

   private void smartTeleport(Player staff, Player target) {
      this.staffManager.setLastLocation(staff, staff.getLocation());
      Location targetLoc = target.getLocation();
      Location safeLoc = this.findSafeTeleportLocation(targetLoc);
      if (safeLoc == null) {
         staff.sendMessage("§cCould not find safe teleport location near " + target.getName());
      } else {
         staff.teleport(safeLoc);
         staff.sendMessage("§aTeleported behind " + target.getName() + " safely");
         if (this.staffManager.isInStaffMode(staff)) {
            staff.sendMessage("§eUse /btp to return to your previous location");
         }

      }
   }

   private Location findSafeTeleportLocation(Location targetLoc) {
      double[][] offsets = new double[][]{{(double)-2.0F, (double)0.0F}, {(double)-3.0F, (double)0.0F}, {(double)-1.0F, (double)0.0F}, {(double)-2.0F, (double)-1.0F}, {(double)-2.0F, (double)1.0F}, {(double)-3.0F, (double)-1.0F}, {(double)-3.0F, (double)1.0F}, {(double)0.0F, (double)-2.0F}, {(double)0.0F, (double)2.0F}, {(double)1.0F, (double)-1.0F}, {(double)1.0F, (double)1.0F}};

      for(double[] offset : offsets) {
         Location testLoc = targetLoc.clone().add(offset[0], (double)0.0F, offset[1]);
         Location safeLoc = this.findSafeY(testLoc);
         if (safeLoc != null) {
            return safeLoc;
         }
      }

      return this.findSafeY(targetLoc);
   }

   private Location findSafeY(Location baseLoc) {
      Location testLoc = baseLoc.clone();
      if (this.isSafeLocation(testLoc)) {
         return testLoc;
      } else {
         for(int y = testLoc.getBlockY(); y < testLoc.getBlockY() + 10; ++y) {
            testLoc.setY((double)y);
            if (this.isSafeLocation(testLoc)) {
               return testLoc;
            }
         }

         for(int var4 = baseLoc.getBlockY() - 1; var4 > baseLoc.getBlockY() - 10 && var4 > 0; --var4) {
            testLoc.setY((double)var4);
            if (this.isSafeLocation(testLoc)) {
               return testLoc;
            }
         }

         return null;
      }
   }

   private boolean isSafeLocation(Location loc) {
      if (VersionCompatibility.isAir(loc.clone().subtract((double)0.0F, (double)1.0F, (double)0.0F).getBlock().getType())) {
         return false;
      } else if (VersionCompatibility.isAir(loc.getBlock().getType()) && VersionCompatibility.isAir(loc.clone().add((double)0.0F, (double)1.0F, (double)0.0F).getBlock().getType())) {
         Material blockType = loc.getBlock().getType();
         return !this.isDangerousMaterial(blockType);
      } else {
         return false;
      }
   }

   private boolean isDangerousMaterial(Material material) {
      return material == Material.LAVA || material == Material.FIRE || material == Material.CACTUS || VersionCompatibility.getMajorVersion() >= 13 && material.name().equals("MAGMA_BLOCK") || VersionCompatibility.getMajorVersion() >= 14 && material.name().equals("SWEET_BERRY_BUSH");
   }

   public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args2) {
      return args2.length == 1 ? (List)Bukkit.getOnlinePlayers().stream().map(OfflinePlayer::getName).filter((name) -> name.toLowerCase().startsWith(args2[0].toLowerCase())).collect(Collectors.toList()) : Arrays.asList();
   }
}
