package com.anti.system.staff;

import com.anti.system.anticheat.DatabaseManager;
import com.anti.system.anticheat.DiscordWebhookManager;
import com.anti.system.utils.VersionCompatibility;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.logging.Level;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;

public class HelpOpManager {
   private final JavaPlugin plugin;
   private final DatabaseManager database;
   private final DiscordWebhookManager discordManager;
   private static final DateTimeFormatter DATE_FORMAT = DateTimeFormatter.ofPattern("MM-dd HH:mm");

   public HelpOpManager(JavaPlugin plugin, DatabaseManager database, DiscordWebhookManager discordManager) {
      this.plugin = plugin;
      this.database = database;
      this.discordManager = discordManager;
      this.createHelpRequestTable();
   }

   public HelpOpManager(JavaPlugin plugin, DatabaseManager database) {
      this.plugin = plugin;
      this.database = database;
      this.discordManager = null;
      this.createHelpRequestTable();
   }

   private void createHelpRequestTable() {
      String query = "CREATE TABLE IF NOT EXISTS help_requests (id INTEGER PRIMARY KEY AUTOINCREMENT,player_uuid TEXT NOT NULL,player_name TEXT NOT NULL,request TEXT NOT NULL,timestamp INTEGER NOT NULL,status TEXT DEFAULT 'pending',assigned_staff TEXT,response TEXT,created_at DATETIME DEFAULT CURRENT_TIMESTAMP)";

      try {
         PreparedStatement stmt = this.database.getConnection().prepareStatement(query);

         try {
            stmt.executeUpdate();
         } catch (Throwable var6) {
            if (stmt != null) {
               try {
                  stmt.close();
               } catch (Throwable var5) {
                  var6.addSuppressed(var5);
               }
            }

            throw var6;
         }

         if (stmt != null) {
            stmt.close();
         }
      } catch (SQLException e) {
         this.plugin.getLogger().log(Level.SEVERE, "Failed to create help requests table", e);
      }

   }

   public void createHelpRequest(Player player, String message) {
      String query = "INSERT INTO help_requests (player_uuid, player_name, request, timestamp) VALUES (?, ?, ?, ?)";

      try {
         PreparedStatement stmt = this.database.getConnection().prepareStatement(query);

         try {
            stmt.setString(1, player.getUniqueId().toString());
            stmt.setString(2, player.getName());
            stmt.setString(3, message);
            stmt.setLong(4, System.currentTimeMillis());
            stmt.executeUpdate();
         } catch (Throwable var8) {
            if (stmt != null) {
               try {
                  stmt.close();
               } catch (Throwable var7) {
                  var8.addSuppressed(var7);
               }
            }

            throw var8;
         }

         if (stmt != null) {
            stmt.close();
         }
      } catch (SQLException e) {
         this.plugin.getLogger().log(Level.SEVERE, "Failed to create help request", e);
      }

      if (this.discordManager != null && this.discordManager.isEnabled()) {
         this.discordManager.sendHelpRequest(player, message);
      }

      this.notifyStaff(player, message);
   }

   private void notifyStaff(Player requester, String message) {
      String notification = "§c§l[HELPOP] §e" + requester.getName() + "§f: " + message;

      for(Player staff : Bukkit.getOnlinePlayers()) {
         if (staff.hasPermission("antisystem.staff.helpop")) {
            staff.sendMessage(notification);
         }
      }

   }

   public void openInboxGUI(Player staff) {
      List<HelpRequest> requests = this.getPendingRequests();
      int size = Math.max(9, Math.min(54, (requests.size() + 8) / 9 * 9));
      Inventory gui = Bukkit.createInventory((InventoryHolder)null, size, "§1§lHelp Request Inbox");

      for(int i = 0; i < requests.size() && i < 45; ++i) {
         HelpRequest request = (HelpRequest)requests.get(i);
         ItemStack item = this.createRequestItem(request);
         gui.setItem(i, item);
      }

      ItemStack refreshItem = new ItemStack(VersionCompatibility.getClockMaterial());
      ItemMeta refreshMeta = refreshItem.getItemMeta();
      refreshMeta.setDisplayName("§a§lRefresh");
      refreshMeta.setLore(Arrays.asList("§7Click to refresh inbox"));
      refreshItem.setItemMeta(refreshMeta);
      gui.setItem(size - 1, refreshItem);
      staff.openInventory(gui);
   }

   private ItemStack createRequestItem(HelpRequest request) {
      ItemStack item = new ItemStack(Material.PAPER);
      ItemMeta meta = item.getItemMeta();
      meta.setDisplayName("§e§l" + request.playerName());
      String timeStr = Instant.ofEpochMilli(request.timestamp()).atZone(ZoneId.systemDefault()).format(DATE_FORMAT);
      ArrayList<String> lore = new ArrayList();
      lore.add("§7Time: " + timeStr);
      lore.add("");
      String[] words = request.request().split(" ");
      StringBuilder line = new StringBuilder();

      for(String word : words) {
         if (line.length() + word.length() > 30) {
            lore.add("§f" + line.toString());
            line = new StringBuilder(word);
         } else {
            if (line.length() > 0) {
               line.append(" ");
            }

            line.append(word);
         }
      }

      if (line.length() > 0) {
         lore.add("§f" + line.toString());
      }

      lore.add("");
      lore.add("§aLeft-click: Claim & Teleport");
      lore.add("§9Right-click: Quick Respond");
      meta.setLore(lore);
      item.setItemMeta(meta);
      return item;
   }

   public List<HelpRequest> getPendingRequests() {
      ArrayList<HelpRequest> requests = new ArrayList();
      String query = "SELECT * FROM help_requests WHERE status = 'pending' ORDER BY timestamp DESC LIMIT 20";

      try {
         PreparedStatement stmt = this.database.getConnection().prepareStatement(query);

         try {
            ResultSet rs = stmt.executeQuery();

            try {
               while(rs.next()) {
                  requests.add(new HelpRequest(rs.getInt("id"), rs.getString("player_uuid"), rs.getString("player_name"), rs.getString("request"), rs.getLong("timestamp"), rs.getString("status")));
               }
            } catch (Throwable var9) {
               if (rs != null) {
                  try {
                     rs.close();
                  } catch (Throwable var8) {
                     var9.addSuppressed(var8);
                  }
               }

               throw var9;
            }

            if (rs != null) {
               rs.close();
            }
         } catch (Throwable var10) {
            if (stmt != null) {
               try {
                  stmt.close();
               } catch (Throwable var7) {
                  var10.addSuppressed(var7);
               }
            }

            throw var10;
         }

         if (stmt != null) {
            stmt.close();
         }
      } catch (SQLException e) {
         this.plugin.getLogger().log(Level.SEVERE, "Error getting pending requests", e);
      }

      return requests;
   }

   public void claimRequest(int requestId, String staffName) {
      String query = "UPDATE help_requests SET status = 'claimed', assigned_staff = ? WHERE id = ?";

      try {
         PreparedStatement stmt = this.database.getConnection().prepareStatement(query);

         try {
            stmt.setString(1, staffName);
            stmt.setInt(2, requestId);
            stmt.executeUpdate();
         } catch (Throwable var8) {
            if (stmt != null) {
               try {
                  stmt.close();
               } catch (Throwable var7) {
                  var8.addSuppressed(var7);
               }
            }

            throw var8;
         }

         if (stmt != null) {
            stmt.close();
         }
      } catch (SQLException e) {
         this.plugin.getLogger().log(Level.SEVERE, "Failed to claim request", e);
      }

   }

   public void closeRequest(int requestId, String response) {
      String query = "UPDATE help_requests SET status = 'closed', response = ? WHERE id = ?";

      try {
         PreparedStatement stmt = this.database.getConnection().prepareStatement(query);

         try {
            stmt.setString(1, response);
            stmt.setInt(2, requestId);
            stmt.executeUpdate();
         } catch (Throwable var8) {
            if (stmt != null) {
               try {
                  stmt.close();
               } catch (Throwable var7) {
                  var8.addSuppressed(var7);
               }
            }

            throw var8;
         }

         if (stmt != null) {
            stmt.close();
         }
      } catch (SQLException e) {
         this.plugin.getLogger().log(Level.SEVERE, "Failed to close request", e);
      }

   }

   public static class HelpRequest {
      private final int id;
      private final String playerUuid;
      private final String playerName;
      private final String request;
      private final long timestamp;
      private final String status;

      public HelpRequest(int id, String playerUuid, String playerName, String request, long timestamp, String status) {
         this.id = id;
         this.playerUuid = playerUuid;
         this.playerName = playerName;
         this.request = request;
         this.timestamp = timestamp;
         this.status = status;
      }

      public int id() {
         return this.id;
      }

      public String playerUuid() {
         return this.playerUuid;
      }

      public String playerName() {
         return this.playerName;
      }

      public String request() {
         return this.request;
      }

      public long timestamp() {
         return this.timestamp;
      }

      public String status() {
         return this.status;
      }
   }
}
