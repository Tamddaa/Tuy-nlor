package com.anti.system.staff;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;

public class InvseeCommand implements CommandExecutor, TabCompleter {
   public boolean onCommand(CommandSender sender, Command command, String label, String[] args2) {
      if (sender == null) {
         return true;
      } else if (!(sender instanceof Player)) {
         sender.sendMessage("§cOnly players can use this command!");
         return true;
      } else {
         Player staff = (Player)sender;
         if (!staff.hasPermission("antisystem.staff.invsee")) {
            staff.sendMessage("§cNo permission!");
            return true;
         } else if (args2.length == 0) {
            staff.sendMessage("§cUsage: /invsee <player> [ghost]");
            return true;
         } else {
            Player target = (Player)Bukkit.getOnlinePlayers().stream().filter((p) -> p.getName().equalsIgnoreCase(args2[0])).findFirst().orElse((Object)null);
            if (target == null) {
               staff.sendMessage("§cPlayer not found!");
               return true;
            } else {
               boolean ghostMode = args2.length > 1 && args2[1].equalsIgnoreCase("ghost");
               this.openInventoryInspection(staff, target, ghostMode);
               return true;
            }
         }
      }
   }

   private void openInventoryInspection(Player staff, Player target, boolean ghostMode) {
      if (ghostMode) {
         Inventory ghostInv = Bukkit.createInventory((InventoryHolder)null, 45, "§7\ud83d\udc7b " + target.getName() + "'s Inventory (Ghost Mode)");
         ItemStack[] contents = target.getInventory().getContents();

         for(int i = 0; i < Math.min(36, contents.length); ++i) {
            if (contents[i] != null) {
               ghostInv.setItem(i, contents[i].clone());
            }
         }

         ItemStack[] hotbar = new ItemStack[9];
         System.arraycopy(contents, 0, hotbar, 0, 9);

         for(int i = 0; i < 9; ++i) {
            ghostInv.setItem(36 + i, hotbar[i]);
         }

         staff.openInventory(ghostInv);
         staff.sendMessage("§eViewing " + target.getName() + "'s inventory in ghost mode (read-only)");
      } else {
         staff.openInventory(target.getInventory());
         staff.sendMessage("§aEditing " + target.getName() + "'s inventory (changes are live!)");
      }

   }

   public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args2) {
      if (args2.length == 1) {
         return (List)Bukkit.getOnlinePlayers().stream().map(OfflinePlayer::getName).filter((name) -> name.toLowerCase().startsWith(args2[0].toLowerCase())).collect(Collectors.toList());
      } else {
         return args2.length == 2 ? (List)Arrays.asList("ghost").stream().filter((mode) -> mode.toLowerCase().startsWith(args2[1].toLowerCase())).collect(Collectors.toList()) : Arrays.asList();
      }
   }
}
