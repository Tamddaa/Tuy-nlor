package com.anti.system.staff;

import com.anti.system.utils.MessageUtils;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.metadata.MetadataValue;

public class StaffChatListener implements Listener {
   private final PunishmentManager punishmentManager;

   public StaffChatListener(PunishmentManager punishmentManager) {
      this.punishmentManager = punishmentManager;
   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void onPlayerChat(AsyncPlayerChatEvent event) {
      Player player = event.getPlayer();
      if (!this.handleStaffInput(player, event)) {
         if (this.punishmentManager.isMuted(player.getUniqueId())) {
            event.setCancelled(true);
            String remainingTime = this.punishmentManager.getRemainingMuteTime(player.getUniqueId());
            MessageUtils.sendMessage(player, "&cMUTED &7You are muted. Time remaining: " + remainingTime);
         }

      }
   }

   private boolean handleStaffInput(Player player, AsyncPlayerChatEvent event) {
      String message = event.getMessage();
      if (player.hasMetadata("antisystem.input.warn")) {
         event.setCancelled(true);
         String targetName = ((MetadataValue)player.getMetadata("antisystem.input.warn").get(0)).asString();
         player.removeMetadata("antisystem.input.warn", Bukkit.getPluginManager().getPlugin("AntiCheat"));
         player.performCommand("staff warn " + targetName + " " + message);
         player.sendMessage("§aWarning issued to " + targetName + " for: " + message);
         return true;
      } else if (player.hasMetadata("antisystem.input.ban")) {
         event.setCancelled(true);
         String targetName = ((MetadataValue)player.getMetadata("antisystem.input.ban").get(0)).asString();
         player.removeMetadata("antisystem.input.ban", Bukkit.getPluginManager().getPlugin("AntiCheat"));
         String duration = message.trim();
         player.performCommand("staff ban " + targetName + " " + duration + " Staff decision");
         player.sendMessage("§aBan issued to " + targetName + " for duration: " + duration);
         return true;
      } else if (player.hasMetadata("antisystem.input.note")) {
         event.setCancelled(true);
         String targetName = ((MetadataValue)player.getMetadata("antisystem.input.note").get(0)).asString();
         player.removeMetadata("antisystem.input.note", Bukkit.getPluginManager().getPlugin("AntiCheat"));
         player.performCommand("staff note " + targetName + " " + message);
         player.sendMessage("§aNote added to " + targetName + ": " + message);
         return true;
      } else {
         return false;
      }
   }

   @EventHandler
   public void onPlayerJoin(PlayerJoinEvent event) {
      Player player = event.getPlayer();
      if (this.punishmentManager.isBanned(player.getUniqueId())) {
         MessageUtils.kickPlayer(player, "&4BANNED\n&7You are banned from this server.\n&7Appeal at: discord.gg/yourserver");
      } else {
         int warnings = this.punishmentManager.getWarningCount(player.getUniqueId());
         if (warnings > 0) {
            String warningMessage = "&eSTAFF &7" + player.getName() + " joined with " + warnings + " warning(s).";

            for(Player staff : player.getServer().getOnlinePlayers()) {
               if (staff.hasPermission("antisystem.staff")) {
                  MessageUtils.sendMessage(staff, warningMessage);
               }
            }
         }

      }
   }
}
