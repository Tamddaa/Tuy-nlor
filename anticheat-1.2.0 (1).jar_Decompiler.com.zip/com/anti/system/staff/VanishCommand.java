package com.anti.system.staff;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class VanishCommand implements CommandExecutor {
   private final StaffManager staffManager;

   public VanishCommand(StaffManager staffManager) {
      this.staffManager = staffManager;
   }

   public boolean onCommand(CommandSender sender, Command command, String label, String[] args2) {
      if (!sender.hasPermission("antisystem.staff.vanish")) {
         sender.sendMessage("§cYou don't have permission to use this command.");
         return true;
      } else if (!(sender instanceof Player)) {
         sender.sendMessage("§cOnly players can use this command.");
         return true;
      } else {
         Player player = (Player)sender;
         switch (args2.length) {
            case 0:
               this.staffManager.toggleVanish(player);
               break;
            case 1:
               if (!sender.hasPermission("antisystem.admin.vanish")) {
                  sender.sendMessage("§cYou don't have permission to vanish other players.");
                  return true;
               }

               Player target = null;

               for(Player onlinePlayer : Bukkit.getOnlinePlayers()) {
                  if (onlinePlayer.getName().equalsIgnoreCase(args2[0])) {
                     target = onlinePlayer;
                     break;
                  }
               }

               if (target == null) {
                  sender.sendMessage("§cPlayer not found or not online.");
                  return true;
               }

               this.staffManager.toggleVanish(target);
               String status = this.staffManager.isVanished(target) ? "vanished" : "visible";
               sender.sendMessage("§a" + target.getName() + " is now " + status + ".");
               break;
            default:
               sender.sendMessage("§cUsage: /vanish [player]");
         }

         return true;
      }
   }
}
