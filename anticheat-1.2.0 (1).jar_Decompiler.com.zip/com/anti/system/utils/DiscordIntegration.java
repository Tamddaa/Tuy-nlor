package com.anti.system.utils;

import java.io.IOException;
import java.io.OutputStream;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;
import java.util.regex.Pattern;
import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;

public class DiscordIntegration {
   private static final String USER_AGENT = "AntiCheat-Discord-Integration/2.0";
   private static final Pattern WEBHOOK_PATTERN = Pattern.compile("https://discord(?:app)?\\.com/api/webhooks/[0-9]+/[A-Za-z0-9\\-_]+");
   private final Plugin plugin;
   private final Map<String, String> webhookUrls;
   private final Map<String, WebhookConfig> webhookConfigs;
   private final Set<String> rateLimitedWebhooks;
   private final Map<String, Long> lastAlertTimes;
   private final AlertAggregator alertAggregator;
   private boolean enabled = false;
   private int maxRetries = 3;
   private long retryDelay = 5000L;
   private long rateLimitCooldown = 60000L;
   private final int maxEmbedLength = 4096;
   private boolean enableRichEmbeds = true;
   private boolean enableAvatars = true;
   private String serverIconUrl = "";

   public DiscordIntegration(Plugin plugin) {
      this.plugin = plugin;
      this.webhookUrls = new ConcurrentHashMap();
      this.webhookConfigs = new ConcurrentHashMap();
      this.rateLimitedWebhooks = ConcurrentHashMap.newKeySet();
      this.lastAlertTimes = new ConcurrentHashMap();
      this.alertAggregator = new AlertAggregator();
      this.loadConfiguration();
      this.startCleanupTask();
   }

   private void loadConfiguration() {
      try {
         this.enabled = this.plugin.getConfig().getBoolean("discord.enabled", false);
         this.maxRetries = this.plugin.getConfig().getInt("discord.max-retries", 3);
         this.retryDelay = this.plugin.getConfig().getLong("discord.retry-delay", 5000L);
         this.rateLimitCooldown = this.plugin.getConfig().getLong("discord.rate-limit-cooldown", 60000L);
         this.enableRichEmbeds = this.plugin.getConfig().getBoolean("discord.rich-embeds", true);
         this.enableAvatars = this.plugin.getConfig().getBoolean("discord.avatars", true);
         this.serverIconUrl = this.plugin.getConfig().getString("discord.server-icon-url", "");
         this.loadWebhookConfigurations();
      } catch (Exception e) {
         this.plugin.getLogger().log(Level.WARNING, "Failed to load Discord configuration", e);
      }

   }

   private void loadWebhookConfigurations() {
      this.webhookConfigs.clear();
      if (this.plugin.getConfig().isConfigurationSection("discord.webhooks")) {
         ConfigurationSection webhooksSection = this.plugin.getConfig().getConfigurationSection("discord.webhooks");

         for(String key : webhooksSection.getKeys(false)) {
            try {
               ConfigurationSection webhookSection = webhooksSection.getConfigurationSection(key);
               String url = webhookSection.getString("url");
               if (url != null && this.isValidWebhookUrl(url)) {
                  Set<AlertType> allowedTypes = EnumSet.noneOf(AlertType.class);

                  for(String typeStr : webhookSection.getStringList("allowed-types")) {
                     try {
                        allowedTypes.add(DiscordIntegration.AlertType.valueOf(typeStr.toUpperCase()));
                     } catch (IllegalArgumentException var15) {
                        this.plugin.getLogger().warning(String.format("Invalid alert type: %s", typeStr));
                     }
                  }

                  AlertLevel minimumLevel = DiscordIntegration.AlertLevel.valueOf(webhookSection.getString("minimum-level", "LOW").toUpperCase());
                  boolean enableMentions = webhookSection.getBoolean("enable-mentions", false);
                  String mentionRole = webhookSection.getString("mention-role", "");
                  long cooldownMs = webhookSection.getLong("cooldown-ms", 5000L);
                  int maxPerHour = webhookSection.getInt("max-per-hour", 60);
                  WebhookConfig config = new WebhookConfig(key, url, allowedTypes, minimumLevel, enableMentions, mentionRole, cooldownMs, maxPerHour);
                  this.webhookConfigs.put(key, config);
                  this.webhookUrls.put(key, url);
               } else {
                  this.plugin.getLogger().warning(String.format("Invalid webhook URL for: %s", key));
               }
            } catch (Exception e) {
               this.plugin.getLogger().log(Level.WARNING, "Failed to load webhook config: " + key, e);
            }
         }
      }

   }

   public void sendAlert(DiscordAlert alert) {
      if (this.enabled && !this.webhookConfigs.isEmpty()) {
         this.alertAggregator.addAlert(alert);
      }
   }

   private void sendSingleAlert(DiscordAlert alert) {
      for(WebhookConfig config : this.webhookConfigs.values()) {
         if (this.shouldSendToWebhook(config, alert)) {
            this.sendToWebhook(config, alert);
         }
      }

   }

   private boolean shouldSendToWebhook(WebhookConfig config, DiscordAlert alert) {
      if (this.rateLimitedWebhooks.contains(config.getName())) {
         return false;
      } else if (!config.getAllowedTypes().isEmpty() && !config.getAllowedTypes().contains(alert.getType())) {
         return false;
      } else if (!alert.getLevel().isAtLeast(config.getMinimumLevel())) {
         return false;
      } else {
         String cooldownKey = config.getName() + "_" + alert.getType();
         Long lastAlert = (Long)this.lastAlertTimes.get(cooldownKey);
         return lastAlert == null || System.currentTimeMillis() - lastAlert >= config.getCooldownMs();
      }
   }

   private void sendToWebhook(WebhookConfig config, DiscordAlert alert) {
      CompletableFuture.runAsync(() -> {
         try {
            String payload = this.createWebhookPayload(config, alert);
            boolean success = this.sendWebhookRequest(config.getUrl(), payload);
            if (success) {
               String cooldownKey = config.getName() + "_" + alert.getType();
               this.lastAlertTimes.put(cooldownKey, System.currentTimeMillis());
            }
         } catch (Exception e) {
            this.plugin.getLogger().log(Level.WARNING, "Failed to send Discord webhook", e);
         }

      });
   }

   private String createWebhookPayload(WebhookConfig config, DiscordAlert alert) {
      StringBuilder json = new StringBuilder();
      json.append("{");
      json.append("\"username\":\"AntiCheat\",");
      if (this.enableAvatars && !this.serverIconUrl.isEmpty()) {
         json.append("\"avatar_url\":\"").append(this.serverIconUrl).append("\",");
      }

      if (this.enableRichEmbeds) {
         json.append("\"embeds\":[");
         json.append(this.createEmbedJson(alert));
         json.append("]");
      } else {
         String content = this.createSimpleMessage(config, alert);
         json.append("\"content\":\"").append(this.escapeJson(content)).append("\"");
      }

      json.append("}");
      return json.toString();
   }

   private String createEmbedJson(DiscordAlert alert) {
      StringBuilder embed = new StringBuilder();
      embed.append("{");
      embed.append("\"title\":\"").append(this.escapeJson(alert.getTitle())).append("\",");
      if (alert.getDescription() != null && !alert.getDescription().isEmpty()) {
         String description = alert.getDescription();
         if (description.length() > 4096) {
            description = description.substring(0, 4093) + "...";
         }

         embed.append("\"description\":\"").append(this.escapeJson(description)).append("\",");
      }

      embed.append("\"color\":").append(alert.getType().getColor()).append(",");
      embed.append("\"timestamp\":\"").append(Instant.ofEpochMilli(alert.getTimestamp()).toString()).append("\",");
      if (!alert.getFields().isEmpty()) {
         embed.append("\"fields\":[");
         boolean first = true;

         for(Map.Entry<String, String> field : alert.getFields().entrySet()) {
            if (!first) {
               embed.append(",");
            }

            embed.append("{");
            embed.append("\"name\":\"").append(this.escapeJson((String)field.getKey())).append("\",");
            embed.append("\"value\":\"").append(this.escapeJson((String)field.getValue())).append("\",");
            embed.append("\"inline\":true");
            embed.append("}");
            first = false;
         }

         embed.append("],");
      }

      embed.append("\"footer\":{");
      embed.append("\"text\":\"AntiCheat v2.0 • Server: ").append(Bukkit.getServer().getName()).append("\"");
      embed.append("},");
      if (alert.getPlayer() != null) {
         embed.append("\"author\":{");
         embed.append("\"name\":\"").append(this.escapeJson(alert.getPlayer().getName())).append("\"");
         if (this.enableAvatars) {
            embed.append(",\"icon_url\":\"https://mc-heads.net/avatar/").append(alert.getPlayer().getUniqueId().toString().replace("-", "")).append("/32\"");
         }

         embed.append("}");
      }

      String embedStr = embed.toString();
      if (embedStr.endsWith(",")) {
         embedStr = embedStr.substring(0, embedStr.length() - 1);
      }

      return embedStr + "}";
   }

   private String createSimpleMessage(WebhookConfig config, DiscordAlert alert) {
      StringBuilder message = new StringBuilder();
      message.append(alert.getType().getEmoji()).append(" **").append(alert.getTitle()).append("**\n");
      if (alert.getDescription() != null && !alert.getDescription().isEmpty()) {
         message.append(alert.getDescription()).append("\n");
      }

      if (alert.getPlayer() != null) {
         message.append("**Player:** ").append(alert.getPlayer().getName()).append("\n");
      }

      message.append("**Time:** ").append(DateTimeFormatter.ISO_INSTANT.format(Instant.ofEpochMilli(alert.getTimestamp())));
      if (config.isEnableMentions() && !config.getMentionRole().isEmpty() && alert.getLevel().isAtLeast(DiscordIntegration.AlertLevel.HIGH)) {
         message.append("\n").append(config.getMentionRole());
      }

      return message.toString();
   }

   private boolean sendWebhookRequest(String webhookUrl, String payload) {
      try {
         URL url = new URL(webhookUrl);
         HttpURLConnection connection = (HttpURLConnection)url.openConnection();
         connection.setRequestMethod("POST");
         connection.setRequestProperty("Content-Type", "application/json");
         connection.setRequestProperty("User-Agent", "AntiCheat-Discord-Integration/2.0");
         connection.setDoOutput(true);
         connection.setConnectTimeout(10000);
         connection.setReadTimeout(10000);
         OutputStream os = connection.getOutputStream();

         try {
            byte[] input = payload.getBytes(StandardCharsets.UTF_8);
            os.write(input, 0, input.length);
         } catch (Throwable var9) {
            if (os != null) {
               try {
                  os.close();
               } catch (Throwable var8) {
                  var9.addSuppressed(var8);
               }
            }

            throw var9;
         }

         if (os != null) {
            os.close();
         }

         int responseCode = connection.getResponseCode();
         if (responseCode == 204) {
            return true;
         } else if (responseCode == 429) {
            this.handleRateLimit(webhookUrl);
            return false;
         } else if (responseCode >= 400 && responseCode < 500) {
            this.plugin.getLogger().warning(String.format("Discord webhook client error: %d", responseCode));
            return false;
         } else {
            this.scheduleRetry(webhookUrl, payload, 1);
            return false;
         }
      } catch (IOException e) {
         this.plugin.getLogger().log(Level.WARNING, "Discord webhook request failed", e);
         this.scheduleRetry(webhookUrl, payload, 1);
         return false;
      } catch (Exception e) {
         this.plugin.getLogger().log(Level.WARNING, "Discord webhook unexpected error", e);
         return false;
      }
   }

   private void scheduleRetry(final String webhookUrl, final String payload, final int attempt) {
      if (attempt < this.maxRetries) {
         (new BukkitRunnable() {
            public void run() {
               DiscordIntegration.this.attemptWebhookSend(webhookUrl, payload, attempt);
            }
         }).runTaskLaterAsynchronously(this.plugin, this.retryDelay * (long)attempt / 50L);
      }
   }

   private void attemptWebhookSend(String webhookUrl, String payload, int attempt) {
      try {
         URL url = new URL(webhookUrl);
         HttpURLConnection connection = (HttpURLConnection)url.openConnection();
         connection.setRequestMethod("POST");
         connection.setRequestProperty("Content-Type", "application/json");
         connection.setRequestProperty("User-Agent", "AntiCheat-Discord-Integration/2.0");
         connection.setDoOutput(true);
         connection.setConnectTimeout(10000);
         connection.setReadTimeout(10000);
         OutputStream os = connection.getOutputStream();

         try {
            byte[] input = payload.getBytes(StandardCharsets.UTF_8);
            os.write(input, 0, input.length);
         } catch (Throwable var10) {
            if (os != null) {
               try {
                  os.close();
               } catch (Throwable var9) {
                  var10.addSuppressed(var9);
               }
            }

            throw var10;
         }

         if (os != null) {
            os.close();
         }

         int responseCode = connection.getResponseCode();
         if (responseCode == 204) {
            return;
         }

         if (responseCode == 429) {
            this.handleRateLimit(webhookUrl);
            return;
         }

         if (responseCode >= 400 && responseCode < 500) {
            this.plugin.getLogger().warning(String.format("Discord webhook client error on retry %d: %d", attempt, responseCode));
            return;
         }

         this.scheduleRetry(webhookUrl, payload, attempt + 1);
      } catch (IOException e) {
         this.plugin.getLogger().log(Level.WARNING, String.format("Discord webhook retry %d failed", attempt), e);
         this.scheduleRetry(webhookUrl, payload, attempt + 1);
      } catch (Exception e) {
         this.plugin.getLogger().log(Level.WARNING, String.format("Discord webhook retry %d unexpected error", attempt), e);
      }

   }

   private void handleRateLimit(String webhookUrl) {
      final String webhookName = null;

      for(Map.Entry<String, String> entry : this.webhookUrls.entrySet()) {
         if (((String)entry.getValue()).equals(webhookUrl)) {
            webhookName = (String)entry.getKey();
            break;
         }
      }

      if (webhookName != null) {
         this.rateLimitedWebhooks.add(webhookName);
         (new BukkitRunnable() {
            public void run() {
               DiscordIntegration.this.rateLimitedWebhooks.remove(webhookName);
            }
         }).runTaskLater(this.plugin, this.rateLimitCooldown / 50L);
         this.plugin.getLogger().warning(String.format("Discord webhook rate limited: %s", webhookName));
      }

   }

   private boolean isValidWebhookUrl(String url) {
      return url != null && WEBHOOK_PATTERN.matcher(url).matches();
   }

   private String escapeJson(String input) {
      return input == null ? "" : input.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "\\r").replace("\t", "\\t");
   }

   private void startCleanupTask() {
      (new BukkitRunnable() {
         public void run() {
            long currentTime = System.currentTimeMillis();
            DiscordIntegration.this.lastAlertTimes.entrySet().removeIf((entry) -> currentTime - (Long)entry.getValue() > 3600000L);
         }
      }).runTaskTimerAsynchronously(this.plugin, 1200L, 1200L);
   }

   public void sendViolationAlert(Player player, String checkName, String details, AlertLevel level) {
      DiscordAlert alert = (new DiscordAlert(DiscordIntegration.AlertType.VIOLATION, level, "Cheat Detection: " + checkName, details, player, (String)null)).addField("Check", checkName).addField("Violation Level", level.name()).addField("World", player.getWorld().getName()).addField("Location", player.getLocation().getBlockX() + ", " + player.getLocation().getBlockY() + ", " + player.getLocation().getBlockZ());
      this.sendAlert(alert);
   }

   public void sendBanAlert(Player player, String reason, String duration) {
      DiscordAlert alert = (new DiscordAlert(DiscordIntegration.AlertType.BAN, DiscordIntegration.AlertLevel.HIGH, "Player Banned", "Player has been banned from the server", player, reason)).addField("Reason", reason).addField("Duration", duration).addField("Banned By", "AntiCheat System");
      this.sendAlert(alert);
   }

   public void sendStaffAlert(Player staff, String action, String target) {
      DiscordAlert alert = (new DiscordAlert(DiscordIntegration.AlertType.STAFF_ACTION, DiscordIntegration.AlertLevel.MEDIUM, "Staff Action", action, staff, (String)null)).addField("Action", action).addField("Target", target).addField("Staff Member", staff.getName());
      this.sendAlert(alert);
   }

   public void sendPerformanceAlert(String metric, String value, AlertLevel level) {
      DiscordAlert alert = (new DiscordAlert(DiscordIntegration.AlertType.PERFORMANCE, level, "Performance Alert", "Server performance issue detected", (Player)null, (String)null)).addField("Metric", metric).addField("Value", value).addField("TPS", String.format("%.2f", this.getTPS()));
      this.sendAlert(alert);
   }

   private double getTPS() {
      try {
         Object server = Bukkit.getServer();
         if (VersionCompatibility.isVersionOrHigher(1, 19)) {
            Method getTPS = server.getClass().getMethod("getTPS");
            double[] tpsArray = (double[])getTPS.invoke(server);
            return tpsArray[0];
         } else {
            Object minecraftServer = server.getClass().getMethod("getServer").invoke(server);
            Field tpsField = minecraftServer.getClass().getField("recentTps");
            double[] recentTps = (double[])tpsField.get(minecraftServer);
            return recentTps[0];
         }
      } catch (IllegalAccessException | InvocationTargetException | NoSuchFieldException | NoSuchMethodException var5) {
         return (double)20.0F;
      }
   }

   public boolean isEnabled() {
      return this.enabled;
   }

   public void setEnabled(boolean enabled) {
      this.enabled = enabled;
   }

   public void addWebhook(String name, WebhookConfig config) {
      this.webhookConfigs.put(name, config);
      this.webhookUrls.put(name, config.getUrl());
   }

   public void removeWebhook(String name) {
      this.webhookConfigs.remove(name);
      this.webhookUrls.remove(name);
   }

   public Set<String> getWebhookNames() {
      return new HashSet(this.webhookConfigs.keySet());
   }

   public static class WebhookConfig {
      private final String name;
      private final String url;
      private final Set<AlertType> allowedTypes;
      private final AlertLevel minimumLevel;
      private final boolean enableMentions;
      private final String mentionRole;
      private final long cooldownMs;
      private final int maxPerHour;

      public WebhookConfig(String name, String url, Set<AlertType> allowedTypes, AlertLevel minimumLevel, boolean enableMentions, String mentionRole, long cooldownMs, int maxPerHour) {
         this.name = name;
         this.url = url;
         this.allowedTypes = allowedTypes;
         this.minimumLevel = minimumLevel;
         this.enableMentions = enableMentions;
         this.mentionRole = mentionRole;
         this.cooldownMs = cooldownMs;
         this.maxPerHour = maxPerHour;
      }

      public String getName() {
         return this.name;
      }

      public String getUrl() {
         return this.url;
      }

      public Set<AlertType> getAllowedTypes() {
         return this.allowedTypes;
      }

      public AlertLevel getMinimumLevel() {
         return this.minimumLevel;
      }

      public boolean isEnableMentions() {
         return this.enableMentions;
      }

      public String getMentionRole() {
         return this.mentionRole;
      }

      public long getCooldownMs() {
         return this.cooldownMs;
      }

      public int getMaxPerHour() {
         return this.maxPerHour;
      }
   }

   public static enum AlertType {
      VIOLATION("\ud83d\udea8", 15158332),
      BAN("\ud83d\udd28", 9323693),
      KICK("\ud83d\udc62", 15965202),
      WARNING("⚠️", 15844367),
      STAFF_ACTION("\ud83d\udc6e", 3447003),
      SYSTEM("⚙️", 9807270),
      PERFORMANCE("\ud83d\udcca", 3066993),
      PLAYER_JOIN("\ud83d\udce5", 2600544),
      PLAYER_LEAVE("\ud83d\udce4", 15105570),
      CRITICAL("\ud83d\udca5", 12597547);

      private final String emoji;
      private final int color;

      private AlertType(String emoji, int color) {
         this.emoji = emoji;
         this.color = color;
      }

      public String getEmoji() {
         return this.emoji;
      }

      public int getColor() {
         return this.color;
      }

      // $FF: synthetic method
      private static AlertType[] $values() {
         return new AlertType[]{VIOLATION, BAN, KICK, WARNING, STAFF_ACTION, SYSTEM, PERFORMANCE, PLAYER_JOIN, PLAYER_LEAVE, CRITICAL};
      }
   }

   public static enum AlertLevel {
      LOW(1),
      MEDIUM(2),
      HIGH(3),
      CRITICAL(4);

      private final int priority;

      private AlertLevel(int priority) {
         this.priority = priority;
      }

      public int getPriority() {
         return this.priority;
      }

      public boolean isAtLeast(AlertLevel other) {
         return this.priority >= other.priority;
      }

      // $FF: synthetic method
      private static AlertLevel[] $values() {
         return new AlertLevel[]{LOW, MEDIUM, HIGH, CRITICAL};
      }
   }

   public static class DiscordAlert {
      private final AlertType type;
      private final AlertLevel level;
      private final String title;
      private final String description;
      private final Player player;
      private final String additionalInfo;
      private final long timestamp;
      private final Map<String, String> fields;

      public DiscordAlert(AlertType type, AlertLevel level, String title, String description, Player player, String additionalInfo) {
         this.type = type;
         this.level = level;
         this.title = title;
         this.description = description;
         this.player = player;
         this.additionalInfo = additionalInfo;
         this.timestamp = System.currentTimeMillis();
         this.fields = new HashMap();
      }

      public DiscordAlert addField(String name, String value) {
         this.fields.put(name, value);
         return this;
      }

      public AlertType getType() {
         return this.type;
      }

      public AlertLevel getLevel() {
         return this.level;
      }

      public String getTitle() {
         return this.title;
      }

      public String getDescription() {
         return this.description;
      }

      public Player getPlayer() {
         return this.player;
      }

      public String getAdditionalInfo() {
         return this.additionalInfo;
      }

      public long getTimestamp() {
         return this.timestamp;
      }

      public Map<String, String> getFields() {
         return this.fields;
      }
   }

   private class AlertAggregator {
      private final Map<String, List<DiscordAlert>> pendingAlerts;
      private final long aggregationWindow;

      private AlertAggregator() {
         this.pendingAlerts = new ConcurrentHashMap();
         this.aggregationWindow = 30000L;
      }

      public void addAlert(DiscordAlert alert) {
         final String key = this.generateAggregationKey(alert);
         ((List)this.pendingAlerts.computeIfAbsent(key, (k) -> new ArrayList())).add(alert);
         (new BukkitRunnable() {
            public void run() {
               AlertAggregator.this.processAggregatedAlerts(key);
            }
         }).runTaskLater(DiscordIntegration.this.plugin, 600L);
      }

      private String generateAggregationKey(DiscordAlert alert) {
         return alert.getType() + "_" + (alert.getPlayer() != null ? alert.getPlayer().getName() : "SYSTEM");
      }

      private void processAggregatedAlerts(String key) {
         List<DiscordAlert> alerts = (List)this.pendingAlerts.remove(key);
         if (alerts != null && !alerts.isEmpty()) {
            if (alerts.size() == 1) {
               DiscordIntegration.this.sendSingleAlert((DiscordAlert)alerts.get(0));
            } else {
               this.sendAggregatedAlert(alerts);
            }

         }
      }

      private void sendAggregatedAlert(List<DiscordAlert> alerts) {
         DiscordAlert firstAlert = (DiscordAlert)alerts.get(0);
         String title = firstAlert.getType().getEmoji() + " " + alerts.size() + " " + firstAlert.getType().name().toLowerCase() + " alerts";
         StringBuilder description = new StringBuilder();
         description.append("**Aggregated alerts for: **").append(firstAlert.getPlayer() != null ? firstAlert.getPlayer().getName() : "System").append("\n\n");

         for(DiscordAlert alert : alerts) {
            description.append("• ").append(alert.getTitle()).append("\n");
         }

         DiscordAlert aggregated = new DiscordAlert(firstAlert.getType(), DiscordIntegration.AlertLevel.HIGH, title, description.toString(), firstAlert.getPlayer(), "Aggregated from " + alerts.size() + " alerts");
         DiscordIntegration.this.sendSingleAlert(aggregated);
      }
   }
}
