package com.anti.system.utils;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.time.Duration;
import java.util.Date;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import org.bukkit.BanList;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Statistic;
import org.bukkit.BanList.Type;
import org.bukkit.block.Block;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public class VersionCompatibility {
   private static final String VERSION;
   private static final String NMS_VERSION;
   private static final int MAJOR_VERSION;
   private static final int MINOR_VERSION;
   private static final int PATCH_VERSION;
   private static final boolean IS_PAPER;
   private static final boolean IS_LEGACY;
   private static final boolean SUPPORTS_COMPONENTS;
   private static final boolean SUPPORTS_ADVENTURE;
   private static final Map<String, Method> METHOD_CACHE = new ConcurrentHashMap();
   private static final Map<String, Field> FIELD_CACHE = new ConcurrentHashMap();
   private static final Map<String, Class<?>> CLASS_CACHE = new ConcurrentHashMap();

   public static boolean isVersion(int major, int minor) {
      return MAJOR_VERSION == major && MINOR_VERSION == minor;
   }

   public static boolean isVersionOrHigher(int major, int minor) {
      return MAJOR_VERSION > major || MAJOR_VERSION == major && MINOR_VERSION >= minor;
   }

   public static boolean isVersionOrLower(int major, int minor) {
      return MAJOR_VERSION < major || MAJOR_VERSION == major && MINOR_VERSION <= minor;
   }

   public static boolean isPaper() {
      return IS_PAPER;
   }

   public static boolean isLegacy() {
      return IS_LEGACY;
   }

   public static boolean supportsComponents() {
      return SUPPORTS_COMPONENTS;
   }

   public static boolean supportsAdventure() {
      return SUPPORTS_ADVENTURE;
   }

   public static String getVersion() {
      return VERSION;
   }

   public static String getNMSVersion() {
      return NMS_VERSION;
   }

   public static int getMajorVersion() {
      return MAJOR_VERSION;
   }

   public static int getMinorVersion() {
      return MINOR_VERSION;
   }

   public static int getPatchVersion() {
      return PATCH_VERSION;
   }

   private static Method getMethod(Class<?> clazz, String methodName, Class<?>... parameterTypes) {
      String key = clazz.getName() + "#" + methodName;
      return (Method)METHOD_CACHE.computeIfAbsent(key, (k) -> {
         try {
            Method method = clazz.getDeclaredMethod(methodName, parameterTypes);
            method.setAccessible(true);
            return method;
         } catch (NoSuchMethodException var5) {
            return null;
         }
      });
   }

   private static Field getField(Class<?> clazz, String fieldName) {
      String key = clazz.getName() + "#" + fieldName;
      return (Field)FIELD_CACHE.computeIfAbsent(key, (k) -> {
         try {
            Field field = clazz.getDeclaredField(fieldName);
            field.setAccessible(true);
            return field;
         } catch (NoSuchFieldException var4) {
            return null;
         }
      });
   }

   private static Class<?> getNMSClass(String className) {
      return (Class)CLASS_CACHE.computeIfAbsent(className, (k) -> {
         try {
            return Class.forName("net.minecraft.server." + NMS_VERSION + "." + className);
         } catch (ClassNotFoundException var7) {
            try {
               return Class.forName("net.minecraft.server." + className);
            } catch (ClassNotFoundException var6) {
               try {
                  return Class.forName("net.minecraft." + className);
               } catch (ClassNotFoundException var5) {
                  return null;
               }
            }
         }
      });
   }

   private static Class<?> getCraftBukkitClass(String className) {
      return (Class)CLASS_CACHE.computeIfAbsent("cb_" + className, (k) -> {
         try {
            return Class.forName("org.bukkit.craftbukkit." + NMS_VERSION + "." + className);
         } catch (ClassNotFoundException var3) {
            return null;
         }
      });
   }

   public static void sendActionBar(Player player, String message) {
      if (IS_PAPER && isVersionOrHigher(1, 16)) {
         try {
            Class<?> componentClass = Class.forName("net.kyori.adventure.text.Component");
            Method textMethod = getMethod(componentClass, "text", String.class);
            if (textMethod != null) {
               Object component = textMethod.invoke((Object)null, message);
               Method sendActionBarMethod = getMethod(player.getClass(), "sendActionBar", componentClass);
               if (sendActionBarMethod != null) {
                  sendActionBarMethod.invoke(player, component);
                  return;
               }
            }
         } catch (IllegalAccessException | InvocationTargetException | ClassNotFoundException var13) {
         }
      }

      try {
         Class<?> chatComponentTextClass = getNMSClass("ChatComponentText");
         Class<?> packetPlayOutChatClass = getNMSClass("PacketPlayOutChat");
         Class<?> craftPlayerClass = getCraftBukkitClass("entity.CraftPlayer");
         if (chatComponentTextClass != null && packetPlayOutChatClass != null && craftPlayerClass != null) {
            Object chatComponent = chatComponentTextClass.getConstructor(String.class).newInstance(message);
            Object packet;
            if (isVersionOrHigher(1, 12)) {
               Class<?> chatMessageTypeClass = getNMSClass("ChatMessageType");
               Field gameInfoField = getField(chatMessageTypeClass, "GAME_INFO");
               Object actionBarType = gameInfoField != null ? gameInfoField.get((Object)null) : null;
               packet = packetPlayOutChatClass.getConstructor(chatComponentTextClass, chatMessageTypeClass).newInstance(chatComponent, actionBarType);
            } else {
               packet = packetPlayOutChatClass.getConstructor(chatComponentTextClass, Byte.TYPE).newInstance(chatComponent, 2);
            }

            Object craftPlayer = craftPlayerClass.cast(player);
            Object handle = getMethod(craftPlayer.getClass(), "getHandle").invoke(craftPlayer);
            Field playerConnectionField = getField(handle.getClass(), "playerConnection");
            Object playerConnection = playerConnectionField != null ? playerConnectionField.get(handle) : null;
            if (playerConnection != null) {
               Method sendPacketMethod = getMethod(playerConnection.getClass(), "sendPacket", getNMSClass("Packet"));
               if (sendPacketMethod != null) {
                  sendPacketMethod.invoke(playerConnection, packet);
               }
            }
         }
      } catch (IllegalAccessException | InvocationTargetException | InstantiationException | NoSuchMethodException var12) {
         player.sendMessage(message);
      }

   }

   public static void clearReflectionCache() {
      METHOD_CACHE.clear();
      FIELD_CACHE.clear();
      CLASS_CACHE.clear();
   }

   public static PotionEffectType getSlownessEffect() {
      try {
         return PotionEffectType.getByName("SLOWNESS");
      } catch (Exception var1) {
         return PotionEffectType.getByName("SLOW");
      }
   }

   public static PotionEffectType getJumpBoostEffect() {
      try {
         return PotionEffectType.getByName("JUMP_BOOST");
      } catch (Exception var1) {
         return PotionEffectType.getByName("JUMP");
      }
   }

   public static PotionEffectType getHasteEffect() {
      try {
         return PotionEffectType.getByName("HASTE");
      } catch (Exception var1) {
         return PotionEffectType.getByName("FAST_DIGGING");
      }
   }

   public static PotionEffectType getResistanceEffect() {
      try {
         return PotionEffectType.getByName("RESISTANCE");
      } catch (Exception var1) {
         return PotionEffectType.getByName("DAMAGE_RESISTANCE");
      }
   }

   public static PotionEffectType getLevitationEffect() {
      try {
         return PotionEffectType.getByName("LEVITATION");
      } catch (Exception var1) {
         return null;
      }
   }

   public static PotionEffectType getSlowFallingEffect() {
      try {
         return PotionEffectType.getByName("SLOW_FALLING");
      } catch (Exception var1) {
         return null;
      }
   }

   public static PotionEffectType getDolphinsGraceEffect() {
      try {
         return PotionEffectType.getByName("DOLPHINS_GRACE");
      } catch (Exception var1) {
         return null;
      }
   }

   public static PotionEffectType getConduitPowerEffect() {
      try {
         return PotionEffectType.getByName("CONDUIT_POWER");
      } catch (Exception var1) {
         return null;
      }
   }

   public static PotionEffectType getBadOmenEffect() {
      try {
         return PotionEffectType.getByName("BAD_OMEN");
      } catch (Exception var1) {
         return null;
      }
   }

   public static PotionEffectType getHeroOfTheVillageEffect() {
      try {
         return PotionEffectType.getByName("HERO_OF_THE_VILLAGE");
      } catch (Exception var1) {
         return null;
      }
   }

   public static PotionEffectType getDarknessEffect() {
      try {
         return PotionEffectType.getByName("DARKNESS");
      } catch (Exception var1) {
         return null;
      }
   }

   public static PotionEffectType getTrialOmenEffect() {
      try {
         return PotionEffectType.getByName("TRIAL_OMEN");
      } catch (Exception var1) {
         return null;
      }
   }

   public static PotionEffectType getRaidOmenEffect() {
      try {
         return PotionEffectType.getByName("RAID_OMEN");
      } catch (Exception var1) {
         return getBadOmenEffect();
      }
   }

   public static PotionEffectType getWindChargedEffect() {
      try {
         return PotionEffectType.getByName("WIND_CHARGED");
      } catch (Exception var1) {
         return null;
      }
   }

   public static PotionEffectType getWeavingEffect() {
      try {
         return PotionEffectType.getByName("WEAVING");
      } catch (Exception var1) {
         return null;
      }
   }

   public static PotionEffectType getOozingEffect() {
      try {
         return PotionEffectType.getByName("OOZING");
      } catch (Exception var1) {
         return null;
      }
   }

   public static PotionEffectType getInfestedEffect() {
      try {
         return PotionEffectType.getByName("INFESTED");
      } catch (Exception var1) {
         return null;
      }
   }

   public static Material getEndCrystalMaterial() {
      try {
         return Material.valueOf("END_CRYSTAL");
      } catch (Exception var1) {
         return null;
      }
   }

   public static Material getRespawnAnchorMaterial() {
      try {
         return Material.valueOf("RESPAWN_ANCHOR");
      } catch (Exception var1) {
         return null;
      }
   }

   public static Material getTotemOfUndyingMaterial() {
      try {
         return Material.valueOf("TOTEM_OF_UNDYING");
      } catch (Exception var1) {
         return null;
      }
   }

   public static Material getGlowstoneMaterial() {
      try {
         return Material.valueOf("GLOWSTONE");
      } catch (Exception var3) {
         try {
            return Material.valueOf("GLOWSTONE_DUST");
         } catch (Exception var2) {
            return null;
         }
      }
   }

   public static ItemStack getItemInMainHand(Player player) {
      try {
         Method method = player.getInventory().getClass().getMethod("getItemInMainHand");
         return (ItemStack)method.invoke(player.getInventory());
      } catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException var4) {
         try {
            Method method = player.getInventory().getClass().getMethod("getItemInHand");
            return (ItemStack)method.invoke(player.getInventory());
         } catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException var3) {
            return new ItemStack(Material.AIR);
         }
      }
   }

   public static ItemStack getItemInOffHand(Player player) {
      try {
         Method method = player.getInventory().getClass().getMethod("getItemInOffHand");
         return (ItemStack)method.invoke(player.getInventory());
      } catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException var2) {
         return new ItemStack(Material.AIR);
      }
   }

   public static String getBlockDataString(Block block) {
      try {
         Method method = block.getClass().getMethod("getBlockData");
         Object blockData = method.invoke(block);
         Method asStringMethod = blockData.getClass().getMethod("getAsString");
         return (String)asStringMethod.invoke(blockData);
      } catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException var5) {
         try {
            Method method = block.getClass().getMethod("getData");
            byte data = (Byte)method.invoke(block);
            return "charges=" + data;
         } catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException var4) {
            return "charges=0";
         }
      }
   }

   public static int getPing(Player player) {
      try {
         Method method = player.getClass().getMethod("getPing");
         return (Integer)method.invoke(player);
      } catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException var5) {
         try {
            Object handle = player.getClass().getMethod("getHandle").invoke(player);
            Object playerConnection = handle.getClass().getField("playerConnection").get(handle);
            return (Integer)playerConnection.getClass().getField("ping").get(playerConnection);
         } catch (IllegalAccessException | InvocationTargetException | NoSuchFieldException | NoSuchMethodException var4) {
            return 0;
         }
      }
   }

   public static PotionEffect getPotionEffect(Player player, PotionEffectType effectType) {
      try {
         Method method = player.getClass().getMethod("getPotionEffect", PotionEffectType.class);
         return (PotionEffect)method.invoke(player, effectType);
      } catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException var6) {
         try {
            for(PotionEffect effect : player.getActivePotionEffects()) {
               if (effect.getType().equals(effectType)) {
                  return effect;
               }
            }

            return null;
         } catch (RuntimeException var5) {
            return null;
         }
      }
   }

   public static Enchantment getEfficiencyEnchantment() {
      try {
         return Enchantment.getByName("EFFICIENCY");
      } catch (IllegalArgumentException var1) {
         return Enchantment.getByName("DIG_SPEED");
      }
   }

   public static Enchantment getUnbreakingEnchantment() {
      try {
         return Enchantment.getByName("UNBREAKING");
      } catch (IllegalArgumentException var1) {
         return Enchantment.getByName("DURABILITY");
      }
   }

   public static Enchantment getSharpnessEnchantment() {
      try {
         return Enchantment.getByName("SHARPNESS");
      } catch (IllegalArgumentException var1) {
         return Enchantment.getByName("DAMAGE_ALL");
      }
   }

   public static Enchantment getSmiteEnchantment() {
      try {
         return Enchantment.getByName("SMITE");
      } catch (IllegalArgumentException var1) {
         return Enchantment.getByName("DAMAGE_UNDEAD");
      }
   }

   public static Enchantment getBaneOfArthropodsEnchantment() {
      try {
         return Enchantment.getByName("BANE_OF_ARTHROPODS");
      } catch (IllegalArgumentException var1) {
         return Enchantment.getByName("DAMAGE_ARTHROPODS");
      }
   }

   public static Enchantment getPowerEnchantment() {
      try {
         return Enchantment.getByName("POWER");
      } catch (IllegalArgumentException var1) {
         return Enchantment.getByName("ARROW_DAMAGE");
      }
   }

   public static Enchantment getDensityEnchantment() {
      try {
         return Enchantment.getByName("DENSITY");
      } catch (IllegalArgumentException var1) {
         return null;
      }
   }

   public static Enchantment getBreachEnchantment() {
      try {
         return Enchantment.getByName("BREACH");
      } catch (IllegalArgumentException var1) {
         return null;
      }
   }

   public static Enchantment getWindBurstEnchantment() {
      try {
         return Enchantment.getByName("WIND_BURST");
      } catch (IllegalArgumentException var1) {
         return null;
      }
   }

   public static Enchantment getLoyaltyEnchantment() {
      try {
         return Enchantment.getByName("LOYALTY");
      } catch (IllegalArgumentException var1) {
         return null;
      }
   }

   public static Enchantment getImpalingEnchantment() {
      try {
         return Enchantment.getByName("IMPALING");
      } catch (IllegalArgumentException var1) {
         return null;
      }
   }

   public static Enchantment getRiptideEnchantment() {
      try {
         return Enchantment.getByName("RIPTIDE");
      } catch (IllegalArgumentException var1) {
         return null;
      }
   }

   public static Enchantment getChannelingEnchantment() {
      try {
         return Enchantment.getByName("CHANNELING");
      } catch (IllegalArgumentException var1) {
         return null;
      }
   }

   public static Enchantment getMultishotEnchantment() {
      try {
         return Enchantment.getByName("MULTISHOT");
      } catch (IllegalArgumentException var1) {
         return null;
      }
   }

   public static Enchantment getQuickChargeEnchantment() {
      try {
         return Enchantment.getByName("QUICK_CHARGE");
      } catch (IllegalArgumentException var1) {
         return null;
      }
   }

   public static Enchantment getPiercingEnchantment() {
      try {
         return Enchantment.getByName("PIERCING");
      } catch (IllegalArgumentException var1) {
         return null;
      }
   }

   public static Enchantment getSoulSpeedEnchantment() {
      try {
         return Enchantment.getByName("SOUL_SPEED");
      } catch (IllegalArgumentException var1) {
         return null;
      }
   }

   public static Enchantment getSwiftSneakEnchantment() {
      try {
         return Enchantment.getByName("SWIFT_SNEAK");
      } catch (IllegalArgumentException var1) {
         return null;
      }
   }

   public static Material getShortGrassMaterial() {
      try {
         return Material.valueOf("SHORT_GRASS");
      } catch (Exception var3) {
         try {
            return Material.valueOf("GRASS");
         } catch (Exception var2) {
            return Material.valueOf("LONG_GRASS");
         }
      }
   }

   public static boolean hasOffHandSupport() {
      return isVersionOrHigher(1, 9);
   }

   public static boolean hasElytrasSupport() {
      return isVersionOrHigher(1, 9);
   }

   public static boolean hasShieldsSupport() {
      return isVersionOrHigher(1, 9);
   }

   public static boolean hasDualWieldSupport() {
      return isVersionOrHigher(1, 9);
   }

   public static boolean hasSwimmingSupport() {
      return isVersionOrHigher(1, 13);
   }

   public static boolean hasSlowFallingSupport() {
      return isVersionOrHigher(1, 13);
   }

   public static boolean hasTridentSupport() {
      return isVersionOrHigher(1, 13);
   }

   public static boolean hasNetherite() {
      return isVersionOrHigher(1, 16);
   }

   public static boolean hasDeepslate() {
      return isVersionOrHigher(1, 17);
   }

   public static boolean hasCrawlingSupport() {
      return isVersionOrHigher(1, 14);
   }

   public static boolean hasSprintSwimmingSupport() {
      return isVersionOrHigher(1, 13);
   }

   public static boolean hasRiptideSupport() {
      return isVersionOrHigher(1, 13);
   }

   public static boolean hasHoneyBlocks() {
      return isVersionOrHigher(1, 15);
   }

   public static boolean hasBundleSupport() {
      return isVersionOrHigher(1, 21);
   }

   public static boolean hasSpyglassSupport() {
      return isVersionOrHigher(1, 17);
   }

   public static boolean hasAmethystSupport() {
      return isVersionOrHigher(1, 17);
   }

   public static boolean hasRawOreSupport() {
      return isVersionOrHigher(1, 17);
   }

   public static boolean hasNewCaveGeneration() {
      return isVersionOrHigher(1, 18);
   }

   public static boolean hasNewMountainGeneration() {
      return isVersionOrHigher(1, 18);
   }

   public static boolean hasAxolotlSupport() {
      return isVersionOrHigher(1, 17);
   }

   public static boolean hasGlowSquidSupport() {
      return isVersionOrHigher(1, 17);
   }

   public static boolean hasGoatSupport() {
      return isVersionOrHigher(1, 17);
   }

   public static boolean hasGlowLichenSupport() {
      return isVersionOrHigher(1, 17);
   }

   public static boolean hasGlowBerriesSupport() {
      return isVersionOrHigher(1, 17);
   }

   public static boolean hasDripstoneSupport() {
      return isVersionOrHigher(1, 17);
   }

   public static boolean hasLightningRodSupport() {
      return isVersionOrHigher(1, 17);
   }

   public static boolean hasCopperSupport() {
      return isVersionOrHigher(1, 17);
   }

   public static boolean hasSporeBlossomSupport() {
      return isVersionOrHigher(1, 17);
   }

   public static boolean hasAzaleaSupport() {
      return isVersionOrHigher(1, 17);
   }

   public static boolean hasBedrockBreakingPatches() {
      return isVersionOrHigher(1, 18);
   }

   public static boolean hasNewPhysicsEngine() {
      return isVersionOrHigher(1, 19);
   }

   public static boolean hasImprovedNetworking() {
      return isVersionOrHigher(1, 20);
   }

   public static boolean hasUpdatedDataPacks() {
      return isVersionOrHigher(1, 20);
   }

   public static boolean hasNewCommandSystem() {
      return isVersionOrHigher(1, 13);
   }

   public static boolean hasUpdatedScoreboardSystem() {
      return isVersionOrHigher(1, 20);
   }

   public static boolean hasDisplayEntities() {
      return isVersionOrHigher(1, 19);
   }

   public static boolean hasInteractionEntities() {
      return isVersionOrHigher(1, 19);
   }

   public static boolean hasAdvancementRewards() {
      return isVersionOrHigher(1, 12);
   }

   public static boolean hasRecipeBookSupport() {
      return isVersionOrHigher(1, 12);
   }

   public static boolean hasAdvancedTooltips() {
      return isVersionOrHigher(1, 14);
   }

   public static boolean hasImprovedBossBar() {
      return isVersionOrHigher(1, 9);
   }

   public static boolean hasCustomModelDataSupport() {
      return isVersionOrHigher(1, 14);
   }

   public static boolean hasItemFrameSupport() {
      return isVersionOrHigher(1, 4);
   }

   public static boolean hasArmorStandSupport() {
      return isVersionOrHigher(1, 8);
   }

   public static boolean hasGoatHorn() {
      return isVersionOrHigher(1, 19);
   }

   public static boolean hasAllaySupport() {
      return isVersionOrHigher(1, 19);
   }

   public static boolean hasWardenSupport() {
      return isVersionOrHigher(1, 19);
   }

   public static boolean hasRecoveryCompass() {
      return isVersionOrHigher(1, 19);
   }

   public static boolean hasEchoShards() {
      return isVersionOrHigher(1, 19);
   }

   public static boolean hasMangroveLogs() {
      return isVersionOrHigher(1, 19);
   }

   public static boolean hasFrogspawn() {
      return isVersionOrHigher(1, 19);
   }

   public static boolean hasSculkBlocks() {
      return isVersionOrHigher(1, 19);
   }

   public static boolean hasBambooBlocks() {
      return isVersionOrHigher(1, 20);
   }

   public static boolean hasArmorTrims() {
      return isVersionOrHigher(1, 20);
   }

   public static boolean hasHangingSigns() {
      return isVersionOrHigher(1, 20);
   }

   public static boolean hasChiseledBookshelf() {
      return isVersionOrHigher(1, 20);
   }

   public static boolean hasCamelSupport() {
      return isVersionOrHigher(1, 20);
   }

   public static boolean hasSnifferSupport() {
      return isVersionOrHigher(1, 20);
   }

   public static boolean hasCherryWood() {
      return isVersionOrHigher(1, 20);
   }

   public static boolean hasArchaeology() {
      return isVersionOrHigher(1, 20);
   }

   public static boolean hasTrialChambers() {
      return isVersionOrHigher(1, 21);
   }

   public static boolean hasBreezeSupport() {
      return isVersionOrHigher(1, 21);
   }

   public static boolean hasWindCharges() {
      return isVersionOrHigher(1, 21);
   }

   public static boolean hasMaceSupport() {
      return isVersionOrHigher(1, 21);
   }

   public static boolean hasVaultBlocks() {
      return isVersionOrHigher(1, 21);
   }

   public static boolean hasBogged() {
      return isVersionOrHigher(1, 21);
   }

   public static boolean hasHeavyCore() {
      return isVersionOrHigher(1, 21);
   }

   public static boolean hasUpdatedWolfVariants() {
      return isVersionOrHigher(1, 20);
   }

   public static boolean hasNewEnchantments() {
      return isVersionOrHigher(1, 21);
   }

   public static Material getPlayerHeadMaterial() {
      return isVersionOrHigher(1, 13) ? Material.valueOf("PLAYER_HEAD") : Material.valueOf("SKULL_ITEM");
   }

   public static Material getRecoveryCompassMaterial() {
      try {
         return Material.valueOf("RECOVERY_COMPASS");
      } catch (Exception var1) {
         return Material.valueOf("COMPASS");
      }
   }

   public static Material getGoatHornMaterial() {
      try {
         return Material.valueOf("GOAT_HORN");
      } catch (Exception var1) {
         return Material.valueOf("STICK");
      }
   }

   public static Material getEchoShardMaterial() {
      try {
         return Material.valueOf("ECHO_SHARD");
      } catch (Exception var1) {
         return Material.valueOf("IRON_INGOT");
      }
   }

   public static Material getDiscFragment5Material() {
      try {
         return Material.valueOf("DISC_FRAGMENT_5");
      } catch (Exception var1) {
         return Material.valueOf("MUSIC_DISC_CAT");
      }
   }

   public static Material getMangroveLogMaterial() {
      try {
         return Material.valueOf("MANGROVE_LOG");
      } catch (Exception var1) {
         return Material.valueOf("OAK_LOG");
      }
   }

   public static Material getSculkMaterial() {
      try {
         return Material.valueOf("SCULK");
      } catch (Exception var1) {
         return Material.valueOf("COAL_ORE");
      }
   }

   public static Material getSculkSensorMaterial() {
      try {
         return Material.valueOf("SCULK_SENSOR");
      } catch (Exception var1) {
         return Material.valueOf("REDSTONE_BLOCK");
      }
   }

   public static Material getSculkShriekerMaterial() {
      try {
         return Material.valueOf("SCULK_SHRIEKER");
      } catch (Exception var1) {
         return Material.valueOf("NOTE_BLOCK");
      }
   }

   public static Material getCalibratedSculkSensorMaterial() {
      try {
         return Material.valueOf("CALIBRATED_SCULK_SENSOR");
      } catch (Exception var1) {
         return getSculkSensorMaterial();
      }
   }

   public static Material getFrogspawnMaterial() {
      try {
         return Material.valueOf("FROGSPAWN");
      } catch (Exception var1) {
         return Material.valueOf("SLIME_BALL");
      }
   }

   public static Material getTadpoleBucketMaterial() {
      try {
         return Material.valueOf("TADPOLE_BUCKET");
      } catch (Exception var1) {
         return Material.valueOf("WATER_BUCKET");
      }
   }

   public static Material getOchreFrogLightMaterial() {
      try {
         return Material.valueOf("OCHRE_FROGLIGHT");
      } catch (Exception var1) {
         return Material.valueOf("GLOWSTONE");
      }
   }

   public static Material getBambooPlanksMaterial() {
      try {
         return Material.valueOf("BAMBOO_PLANKS");
      } catch (Exception var1) {
         return Material.valueOf("OAK_PLANKS");
      }
   }

   public static Material getBambooMosaicMaterial() {
      try {
         return Material.valueOf("BAMBOO_MOSAIC");
      } catch (Exception var1) {
         return getBambooPlanksMaterial();
      }
   }

   public static Material getCherryLogMaterial() {
      try {
         return Material.valueOf("CHERRY_LOG");
      } catch (Exception var1) {
         return Material.valueOf("OAK_LOG");
      }
   }

   public static Material getCherryLeavesMaterial() {
      try {
         return Material.valueOf("CHERRY_LEAVES");
      } catch (Exception var1) {
         return Material.valueOf("OAK_LEAVES");
      }
   }

   public static Material getSuspiciousSandMaterial() {
      try {
         return Material.valueOf("SUSPICIOUS_SAND");
      } catch (Exception var1) {
         return Material.valueOf("SAND");
      }
   }

   public static Material getSuspiciousGravelMaterial() {
      try {
         return Material.valueOf("SUSPICIOUS_GRAVEL");
      } catch (Exception var1) {
         return Material.valueOf("GRAVEL");
      }
   }

   public static Material getBrushMaterial() {
      try {
         return Material.valueOf("BRUSH");
      } catch (Exception var1) {
         return Material.valueOf("STICK");
      }
   }

   public static Material getHangingSignMaterial(String woodType) {
      try {
         return Material.valueOf(woodType.toUpperCase() + "_HANGING_SIGN");
      } catch (Exception var4) {
         try {
            return Material.valueOf(woodType.toUpperCase() + "_SIGN");
         } catch (Exception var3) {
            return Material.valueOf("OAK_SIGN");
         }
      }
   }

   public static Material getChiseledBookshelfMaterial() {
      try {
         return Material.valueOf("CHISELED_BOOKSHELF");
      } catch (Exception var1) {
         return Material.valueOf("BOOKSHELF");
      }
   }

   public static Material getTorchflowerMaterial() {
      try {
         return Material.valueOf("TORCHFLOWER");
      } catch (Exception var1) {
         return Material.valueOf("SUNFLOWER");
      }
   }

   public static Material getPitcherPlantMaterial() {
      try {
         return Material.valueOf("PITCHER_PLANT");
      } catch (Exception var1) {
         return Material.valueOf("LARGE_FERN");
      }
   }

   public static Material getTrialSpawnerMaterial() {
      try {
         return Material.valueOf("TRIAL_SPAWNER");
      } catch (Exception var1) {
         return Material.valueOf("SPAWNER");
      }
   }

   public static Material getVaultMaterial() {
      try {
         return Material.valueOf("VAULT");
      } catch (Exception var1) {
         return Material.valueOf("CHEST");
      }
   }

   public static Material getHeavyCoreMaterial() {
      try {
         return Material.valueOf("HEAVY_CORE");
      } catch (Exception var1) {
         return Material.valueOf("IRON_BLOCK");
      }
   }

   public static Material getMaceMaterial() {
      try {
         return Material.valueOf("MACE");
      } catch (Exception var1) {
         return Material.valueOf("DIAMOND_SWORD");
      }
   }

   public static Material getWindChargeMaterial() {
      try {
         return Material.valueOf("WIND_CHARGE");
      } catch (Exception var1) {
         return Material.valueOf("SNOWBALL");
      }
   }

   public static Material getTuffMaterial() {
      try {
         return Material.valueOf("TUFF");
      } catch (Exception var1) {
         return Material.valueOf("STONE");
      }
   }

   public static Material getTuffBricksMaterial() {
      try {
         return Material.valueOf("TUFF_BRICKS");
      } catch (Exception var1) {
         return getTuffMaterial();
      }
   }

   public static Material getPolishedTuffMaterial() {
      try {
         return Material.valueOf("POLISHED_TUFF");
      } catch (Exception var1) {
         return getTuffMaterial();
      }
   }

   public static Material getOminousBottleMaterial() {
      try {
         return Material.valueOf("OMINOUS_BOTTLE");
      } catch (Exception var1) {
         return Material.valueOf("GLASS_BOTTLE");
      }
   }

   public static Material getFlowBannerPatternMaterial() {
      try {
         return Material.valueOf("FLOW_BANNER_PATTERN");
      } catch (Exception var1) {
         return Material.valueOf("BANNER");
      }
   }

   public static Material getGusterBannerPatternMaterial() {
      try {
         return Material.valueOf("GUSTER_BANNER_PATTERN");
      } catch (Exception var1) {
         return Material.valueOf("BANNER");
      }
   }

   public static Material getSpawnEggMaterial(String mobType) {
      return isVersionOrHigher(1, 13) ? Material.valueOf(mobType.toUpperCase() + "_SPAWN_EGG") : Material.valueOf("MONSTER_EGG");
   }

   public static Material getBarrierMaterial() {
      try {
         return Material.valueOf("BARRIER");
      } catch (Exception var1) {
         return Material.valueOf("BEDROCK");
      }
   }

   public static Material getWaterMaterial() {
      try {
         return Material.valueOf("WATER");
      } catch (Exception var1) {
         return Material.valueOf("STATIONARY_WATER");
      }
   }

   public static Material getLavaMaterial() {
      try {
         return Material.valueOf("LAVA");
      } catch (Exception var1) {
         return Material.valueOf("STATIONARY_LAVA");
      }
   }

   public static boolean isWater(Material material) {
      String name = material.name();
      return name.contains("WATER") || name.equals("WATER");
   }

   public static boolean isLava(Material material) {
      String name = material.name();
      return name.contains("LAVA") || name.equals("LAVA");
   }

   public static boolean supportsHex() {
      return isVersionOrHigher(1, 16);
   }

   public static boolean supportsCustomModelData() {
      return isVersionOrHigher(1, 14);
   }

   public static Material getRepeaterMaterial() {
      try {
         return Material.valueOf("REPEATER");
      } catch (Exception var3) {
         try {
            return Material.valueOf("DIODE");
         } catch (Exception var2) {
            return Material.REDSTONE;
         }
      }
   }

   public static Material getWritableBookMaterial() {
      try {
         return Material.valueOf("WRITABLE_BOOK");
      } catch (Exception var3) {
         try {
            return Material.valueOf("BOOK_AND_QUILL");
         } catch (Exception var2) {
            return Material.BOOK;
         }
      }
   }

   public static Material getClockMaterial() {
      try {
         return Material.valueOf("CLOCK");
      } catch (Exception var3) {
         try {
            return Material.valueOf("WATCH");
         } catch (Exception var2) {
            return Material.valueOf("COMPASS");
         }
      }
   }

   public static Material getLimeDyeMaterial() {
      try {
         return Material.valueOf("LIME_DYE");
      } catch (Exception var3) {
         try {
            return Material.valueOf("INK_SACK");
         } catch (Exception var2) {
            return Material.valueOf("DYE");
         }
      }
   }

   public static Material getYellowDyeMaterial() {
      try {
         return Material.valueOf("YELLOW_DYE");
      } catch (Exception var3) {
         try {
            return Material.valueOf("INK_SACK");
         } catch (Exception var2) {
            return Material.valueOf("DYE");
         }
      }
   }

   public static Material getOrangeDyeMaterial() {
      try {
         return Material.valueOf("ORANGE_DYE");
      } catch (Exception var3) {
         try {
            return Material.valueOf("INK_SACK");
         } catch (Exception var2) {
            return Material.valueOf("DYE");
         }
      }
   }

   public static Material getRedDyeMaterial() {
      try {
         return Material.valueOf("RED_DYE");
      } catch (Exception var3) {
         try {
            return Material.valueOf("INK_SACK");
         } catch (Exception var2) {
            return Material.valueOf("DYE");
         }
      }
   }

   public static Material getOrangeConcreteMaterial() {
      try {
         return Material.valueOf("ORANGE_CONCRETE");
      } catch (Exception var3) {
         try {
            return Material.valueOf("ORANGE_WOOL");
         } catch (Exception var2) {
            return Material.valueOf("WOOL");
         }
      }
   }

   public static Material getRedConcreteMaterial() {
      try {
         return Material.valueOf("RED_CONCRETE");
      } catch (Exception var3) {
         try {
            return Material.valueOf("RED_WOOL");
         } catch (Exception var2) {
            return Material.valueOf("WOOL");
         }
      }
   }

   public static Material getYellowConcreteMaterial() {
      try {
         return Material.valueOf("YELLOW_CONCRETE");
      } catch (Exception var3) {
         try {
            return Material.valueOf("YELLOW_WOOL");
         } catch (Exception var2) {
            return Material.valueOf("WOOL");
         }
      }
   }

   public static Material getBlackConcreteMaterial() {
      try {
         return Material.valueOf("BLACK_CONCRETE");
      } catch (Exception var3) {
         try {
            return Material.valueOf("BLACK_WOOL");
         } catch (Exception var2) {
            return Material.valueOf("WOOL");
         }
      }
   }

   public static Material getSpyglassMaterial() {
      try {
         return Material.valueOf("SPYGLASS");
      } catch (Exception var3) {
         try {
            return Material.valueOf("COMPASS");
         } catch (Exception var2) {
            return Material.valueOf("STICK");
         }
      }
   }

   public static Material getEnderEyeMaterial() {
      try {
         return Material.valueOf("ENDER_EYE");
      } catch (Exception var3) {
         try {
            return Material.valueOf("EYE_OF_ENDER");
         } catch (Exception var2) {
            return Material.valueOf("ENDER_PEARL");
         }
      }
   }

   public static Material getBellMaterial() {
      try {
         return Material.valueOf("BELL");
      } catch (Exception var3) {
         try {
            return Material.valueOf("NOTE_BLOCK");
         } catch (Exception var2) {
            return Material.valueOf("JUKEBOX");
         }
      }
   }

   public static Material getGrayStainedGlassPaneMaterial() {
      try {
         return Material.valueOf("GRAY_STAINED_GLASS_PANE");
      } catch (Exception var3) {
         try {
            return Material.valueOf("STAINED_GLASS_PANE");
         } catch (Exception var2) {
            return Material.valueOf("THIN_GLASS");
         }
      }
   }

   public static Material getGreenWoolMaterial() {
      try {
         return Material.valueOf("GREEN_WOOL");
      } catch (Exception var1) {
         return Material.valueOf("WOOL");
      }
   }

   public static Material getYellowWoolMaterial() {
      try {
         return Material.valueOf("YELLOW_WOOL");
      } catch (Exception var1) {
         return Material.valueOf("WOOL");
      }
   }

   public static Material getRedWoolMaterial() {
      try {
         return Material.valueOf("RED_WOOL");
      } catch (Exception var1) {
         return Material.valueOf("WOOL");
      }
   }

   public static Material getBlueWoolMaterial() {
      try {
         return Material.valueOf("BLUE_WOOL");
      } catch (Exception var1) {
         return Material.valueOf("WOOL");
      }
   }

   public static Material getOrangeWoolMaterial() {
      try {
         return Material.valueOf("ORANGE_WOOL");
      } catch (Exception var1) {
         return Material.valueOf("WOOL");
      }
   }

   public static Material getRedTerracottaMaterial() {
      try {
         return Material.valueOf("RED_TERRACOTTA");
      } catch (Exception var3) {
         try {
            return Material.valueOf("STAINED_CLAY");
         } catch (Exception var2) {
            return Material.valueOf("CLAY");
         }
      }
   }

   public static Statistic getPlayTimeStatistic() {
      try {
         return Statistic.valueOf("PLAY_ONE_MINUTE");
      } catch (Exception var3) {
         try {
            return Statistic.valueOf("PLAY_ONE_TICK");
         } catch (Exception var2) {
            return Statistic.values()[0];
         }
      }
   }

   public static void banPlayer(Player player, String reason, Duration duration, String source) {
      try {
         if (duration == null) {
            Method method = player.getClass().getMethod("ban", String.class, Duration.class, String.class);
            method.invoke(player, reason, null, source);
         } else {
            Method method = player.getClass().getMethod("ban", String.class, Duration.class, String.class);
            method.invoke(player, reason, duration, source);
         }
      } catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException var8) {
         try {
            if (duration == null) {
               Method method = player.getClass().getMethod("setBanned", Boolean.TYPE);
               method.invoke(player, true);
               player.kickPlayer(reason);
            } else {
               BanList banList = Bukkit.getBanList(Type.NAME);
               Date expiry = new Date(System.currentTimeMillis() + duration.toMillis());
               banList.addBan(player.getName(), reason, expiry, source);
               player.kickPlayer(reason);
            }
         } catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException var7) {
            player.kickPlayer(reason);
         }
      }

   }

   public static Material getBlueIceMaterial() {
      try {
         return Material.valueOf("BLUE_ICE");
      } catch (Exception var3) {
         try {
            return Material.valueOf("PACKED_ICE");
         } catch (Exception var2) {
            return Material.valueOf("ICE");
         }
      }
   }

   public static boolean hasBlueIceMaterial() {
      try {
         Material.valueOf("BLUE_ICE");
         return true;
      } catch (Exception var1) {
         return false;
      }
   }

   public static Material getCommandBlockMaterial() {
      try {
         return Material.valueOf("COMMAND_BLOCK");
      } catch (Exception var3) {
         try {
            return Material.valueOf("COMMAND");
         } catch (Exception var2) {
            return Material.valueOf("STONE");
         }
      }
   }

   public static Material getObserverMaterial() {
      try {
         return Material.valueOf("OBSERVER");
      } catch (Exception var3) {
         try {
            return Material.valueOf("REDSTONE_BLOCK");
         } catch (Exception var2) {
            return Material.valueOf("STONE");
         }
      }
   }

   public static Material getComparatorMaterial() {
      try {
         return Material.valueOf("COMPARATOR");
      } catch (Exception var3) {
         try {
            return Material.valueOf("REDSTONE_COMPARATOR");
         } catch (Exception var2) {
            return Material.valueOf("REDSTONE");
         }
      }
   }

   public static Material getChestMinecartMaterial() {
      try {
         return Material.valueOf("CHEST_MINECART");
      } catch (Exception var3) {
         try {
            return Material.valueOf("STORAGE_MINECART");
         } catch (Exception var2) {
            return Material.valueOf("CHEST");
         }
      }
   }

   public static void hidePlayer(Player viewer, Player target, Plugin plugin) {
      try {
         Method hidePlayerMethod = viewer.getClass().getMethod("hidePlayer", Plugin.class, Player.class);
         hidePlayerMethod.invoke(viewer, plugin, target);
      } catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException var6) {
         try {
            Method hidePlayerMethod = viewer.getClass().getMethod("hidePlayer", Player.class);
            hidePlayerMethod.invoke(viewer, target);
         } catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException e2) {
            plugin.getLogger().warning(String.format("Failed to hide player %s from %s: %s", target.getName(), viewer.getName(), ((ReflectiveOperationException)e2).getMessage()));
         }
      }

   }

   public static void showPlayer(Player viewer, Player target, Plugin plugin) {
      try {
         Method showPlayerMethod = viewer.getClass().getMethod("showPlayer", Plugin.class, Player.class);
         showPlayerMethod.invoke(viewer, plugin, target);
      } catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException var6) {
         try {
            Method showPlayerMethod = viewer.getClass().getMethod("showPlayer", Player.class);
            showPlayerMethod.invoke(viewer, target);
         } catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException e2) {
            plugin.getLogger().warning(String.format("Failed to show player %s to %s: %s", target.getName(), viewer.getName(), ((ReflectiveOperationException)e2).getMessage()));
         }
      }

   }

   public static boolean isAir(Material material) {
      try {
         Method isAirMethod = material.getClass().getMethod("isAir");
         return (Boolean)isAirMethod.invoke(material);
      } catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException var2) {
         return material == Material.AIR || material.name().equals("AIR") || material.name().equals("CAVE_AIR") || material.name().equals("VOID_AIR");
      }
   }

   static {
      try {
         String serverName = Bukkit.getName().toLowerCase();
         IS_PAPER = serverName.contains("paper") || serverName.contains("purpur") || serverName.contains("airplane") || serverName.contains("pufferfish");
         String bukkitVersion = Bukkit.getServer().getBukkitVersion();
         if (bukkitVersion.contains("-")) {
            String[] parts = bukkitVersion.split("-")[0].split("\\.");
            MAJOR_VERSION = Integer.parseInt(parts[0]);
            MINOR_VERSION = parts.length > 1 ? Integer.parseInt(parts[1]) : 0;
            PATCH_VERSION = parts.length > 2 ? Integer.parseInt(parts[2]) : 0;
            VERSION = MAJOR_VERSION + "_" + MINOR_VERSION + (PATCH_VERSION > 0 ? "_" + PATCH_VERSION : "");
         } else {
            String packageVersion = Bukkit.getServer().getClass().getPackage().getName().split("\\.")[3];
            String[] versionParts = packageVersion.substring(1).split("_");
            MAJOR_VERSION = Integer.parseInt(versionParts[0]);
            MINOR_VERSION = versionParts.length > 1 ? Integer.parseInt(versionParts[1]) : 0;
            PATCH_VERSION = versionParts.length > 2 ? Integer.parseInt(versionParts[2]) : 0;
            VERSION = packageVersion;
         }

         String nmsVersion;
         try {
            nmsVersion = Bukkit.getServer().getClass().getPackage().getName().split("\\.")[3];
         } catch (Exception var4) {
            nmsVersion = "current";
         }

         NMS_VERSION = nmsVersion;
         IS_LEGACY = MAJOR_VERSION == 1 && MINOR_VERSION <= 12;
         SUPPORTS_COMPONENTS = MAJOR_VERSION > 1 || MAJOR_VERSION == 1 && MINOR_VERSION >= 16;
         SUPPORTS_ADVENTURE = IS_PAPER && (MAJOR_VERSION > 1 || MAJOR_VERSION == 1 && MINOR_VERSION >= 16);
      } catch (ArrayIndexOutOfBoundsException | NumberFormatException e) {
         throw new RuntimeException("Failed to determine server version", e);
      }
   }
}
