package com.anti.system.utils;

import org.bukkit.entity.Player;

public class BypassUtils {
   public static boolean hasAntiCheatBypass(Player player) {
      if (player == null) {
         return false;
      } else {
         return player.hasPermission("antisystem.bypass.all") || player.hasPermission("antisystem.bypass.anticheat") || player.hasPermission("antisystem.admin");
      }
   }

   public static boolean hasCheckBypass(Player player, String checkType) {
      if (player != null && checkType != null) {
         return hasAntiCheatBypass(player) ? true : player.hasPermission("antisystem.bypass." + checkType.toLowerCase());
      } else {
         return false;
      }
   }

   public static boolean hasStaffPermission(Player player) {
      if (player == null) {
         return false;
      } else {
         return player.hasPermission("antisystem.staff") || player.hasPermission("antisystem.admin");
      }
   }

   public static boolean hasCombatBypass(Player player) {
      return hasCheckBypass(player, "combat");
   }

   public static boolean hasAntiSystemBypass(Player player) {
      return hasAntiCheatBypass(player);
   }
}
