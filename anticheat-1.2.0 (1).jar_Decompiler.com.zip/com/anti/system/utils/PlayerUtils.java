package com.anti.system.utils;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public class PlayerUtils {
   public static boolean isGliding(Player player) {
      try {
         Method method = player.getClass().getMethod("isGliding");
         return (Boolean)method.invoke(player);
      } catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException var2) {
         return false;
      }
   }

   public static boolean isHandRaised(Player player) {
      try {
         Method method = player.getClass().getMethod("isHandRaised");
         return (Boolean)method.invoke(player);
      } catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException var2) {
         return false;
      }
   }

   public static ItemStack getItemInMainHand(PlayerInventory inventory) {
      try {
         Method method = inventory.getClass().getMethod("getItemInMainHand");
         return (ItemStack)method.invoke(inventory);
      } catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException var2) {
         return inventory.getItemInHand();
      }
   }

   public static ItemStack getItemInOffHand(PlayerInventory inventory) {
      try {
         Method method = inventory.getClass().getMethod("getItemInOffHand");
         return (ItemStack)method.invoke(inventory);
      } catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException var2) {
         return null;
      }
   }

   public static PotionEffect getPotionEffect(Player player, PotionEffectType type) {
      try {
         Method method = player.getClass().getMethod("getPotionEffect", PotionEffectType.class);
         return (PotionEffect)method.invoke(player, type);
      } catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException var5) {
         for(PotionEffect effect : player.getActivePotionEffects()) {
            if (effect.getType().equals(type)) {
               return effect;
            }
         }

         return null;
      }
   }

   public static boolean hasMaterial(String materialName) {
      try {
         Material.valueOf(materialName);
         return true;
      } catch (IllegalArgumentException var2) {
         return false;
      }
   }

   public static Material getMaterialSafe(String materialName) {
      try {
         return Material.valueOf(materialName);
      } catch (IllegalArgumentException var2) {
         return Material.AIR;
      }
   }

   public static int getPing(Player player) {
      return VersionCompatibility.getPing(player);
   }
}
