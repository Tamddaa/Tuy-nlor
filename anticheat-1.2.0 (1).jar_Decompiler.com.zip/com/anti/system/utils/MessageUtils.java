package com.anti.system.utils;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;

public class MessageUtils {
   private static boolean hasAdventure = false;
   private static boolean hasModernBukkit = false;
   private static JavaPlugin plugin;

   public static void init(JavaPlugin plugin) {
      MessageUtils.plugin = plugin;
   }

   public static void sendMessage(CommandSender sender, String message) {
      if (message != null) {
         sender.sendMessage(ChatColor.translateAlternateColorCodes('&', message));
      }
   }

   public static void sendColoredMessage(CommandSender sender, String message, String color) {
      if (message != null) {
         ChatColor chatColor = getChatColor(color);
         sender.sendMessage(chatColor + ChatColor.translateAlternateColorCodes('&', message));
      }
   }

   public static void broadcast(String message) {
      if (message != null) {
         if (plugin != null) {
            plugin.getServer().broadcastMessage(ChatColor.translateAlternateColorCodes('&', message));
         }

      }
   }

   public static void broadcast(String message, String permission) {
      if (message != null) {
         if (plugin != null) {
            plugin.getServer().broadcast(ChatColor.translateAlternateColorCodes('&', message), permission);
         }

      }
   }

   public static void kickPlayer(Player player, String reason) {
      if (player != null && reason != null) {
         try {
            Method kickMethod = player.getClass().getMethod("kick", String.class);
            kickMethod.invoke(player, ChatColor.translateAlternateColorCodes('&', reason));
         } catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException var5) {
            try {
               player.kickPlayer(ChatColor.translateAlternateColorCodes('&', reason));
            } catch (UnsupportedOperationException | NoSuchMethodError var4) {
               player.getLocation().getWorld().getPlayers().remove(player);
            }
         }

      }
   }

   public static Inventory createInventory(Player player, int size, String title) {
      if (title == null) {
         title = "Inventory";
      }

      return Bukkit.createInventory(player, size, ChatColor.translateAlternateColorCodes('&', title));
   }

   public static void setDisplayName(ItemMeta meta, String name) {
      if (meta != null && name != null) {
         meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', name));
      }
   }

   public static void setLore(ItemMeta meta, List<String> lore) {
      if (meta != null && lore != null) {
         ArrayList<String> coloredLore = new ArrayList();

         for(String line : lore) {
            coloredLore.add(ChatColor.translateAlternateColorCodes('&', line));
         }

         meta.setLore(coloredLore);
      }
   }

   public static String getInventoryTitle(Inventory inventory) {
      if (inventory == null) {
         return "";
      } else {
         try {
            Method getTitleMethod = inventory.getClass().getMethod("getTitle");
            Object result = getTitleMethod.invoke(inventory);
            return result != null ? result.toString() : "";
         } catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException var7) {
            try {
               Method getTopInventoryMethod = inventory.getClass().getMethod("getTopInventory");
               Object topInventory = getTopInventoryMethod.invoke(inventory);
               if (topInventory != null) {
                  Method getNameMethod = topInventory.getClass().getMethod("getName");
                  Object name = getNameMethod.invoke(topInventory);
                  return name != null ? name.toString() : "";
               } else {
                  return "Inventory";
               }
            } catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException var6) {
               return "Inventory";
            }
         }
      }
   }

   public static String getDisplayName(ItemMeta meta) {
      if (meta == null) {
         return "";
      } else {
         try {
            String displayName = meta.getDisplayName();
            return displayName != null ? displayName : "";
         } catch (UnsupportedOperationException var2) {
            return "";
         }
      }
   }

   public static void setDeathMessage(Object event, String message) {
      if (event != null) {
         try {
            Method setDeathMessage = event.getClass().getMethod("setDeathMessage", String.class);
            setDeathMessage.invoke(event, message != null ? ChatColor.translateAlternateColorCodes('&', message) : null);
         } catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException var3) {
         }

      }
   }

   public static String getDeathMessage(Object event) {
      if (event == null) {
         return null;
      } else {
         try {
            Method getDeathMessage = event.getClass().getMethod("getDeathMessage");
            Object result = getDeathMessage.invoke(event);
            return result != null ? result.toString() : null;
         } catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException var3) {
            return null;
         }
      }
   }

   public static double[] getTPS() {
      try {
         Method getTPS = Bukkit.getServer().getClass().getMethod("getTPS");
         return (double[])getTPS.invoke(Bukkit.getServer());
      } catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException var1) {
         return new double[]{(double)20.0F, (double)20.0F, (double)20.0F};
      }
   }

   public static String getClientBrand(Player player) {
      if (player == null) {
         return "unknown";
      } else {
         try {
            Method getClientBrandName = player.getClass().getMethod("getClientBrandName");
            Object result = getClientBrandName.invoke(player);
            return result != null ? result.toString() : "unknown";
         } catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException var3) {
            return "unknown";
         }
      }
   }

   public static void disallowLogin(Object event, String reason) {
      if (event != null && reason != null) {
         try {
            Class<?> eventClass = event.getClass();
            Class<?>[] innerClasses = eventClass.getDeclaredClasses();
            Object kickResult = null;

            for(Class<?> innerClass : innerClasses) {
               if (innerClass.getSimpleName().equals("Result")) {
                  try {
                     kickResult = innerClass.getField("KICK_OTHER").get((Object)null);
                     break;
                  } catch (IllegalAccessException | NoSuchFieldException var13) {
                     try {
                        kickResult = innerClass.getField("DISALLOW").get((Object)null);
                        break;
                     } catch (IllegalAccessException | NoSuchFieldException var12) {
                     }
                  }
               }
            }

            if (kickResult != null) {
               Method disallow = eventClass.getMethod("disallow", kickResult.getClass(), String.class);
               disallow.invoke(event, kickResult, ChatColor.translateAlternateColorCodes('&', reason));
            }
         } catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException var14) {
            try {
               Method[] methods = event.getClass().getMethods();

               for(Method method : methods) {
                  if (method.getName().equals("disallow") && method.getParameterCount() == 2) {
                     method.invoke(event, "KICK_OTHER", ChatColor.translateAlternateColorCodes('&', reason));
                  }
               }
            } catch (InvocationTargetException | IllegalAccessException var11) {
            }
         }

      }
   }

   private static ChatColor getChatColor(String color) {
      if (color == null) {
         return ChatColor.WHITE;
      } else {
         switch (color.toLowerCase()) {
            case "red":
               return ChatColor.RED;
            case "green":
               return ChatColor.GREEN;
            case "blue":
               return ChatColor.BLUE;
            case "yellow":
               return ChatColor.YELLOW;
            case "gold":
               return ChatColor.GOLD;
            case "aqua":
               return ChatColor.AQUA;
            case "light_purple":
               return ChatColor.LIGHT_PURPLE;
            case "gray":
               return ChatColor.GRAY;
            case "dark_gray":
               return ChatColor.DARK_GRAY;
            case "white":
               return ChatColor.WHITE;
            case "black":
               return ChatColor.BLACK;
            case "dark_blue":
               return ChatColor.DARK_BLUE;
            case "dark_green":
               return ChatColor.DARK_GREEN;
            case "dark_aqua":
               return ChatColor.DARK_AQUA;
            case "dark_red":
               return ChatColor.DARK_RED;
            case "dark_purple":
               return ChatColor.DARK_PURPLE;
            default:
               return ChatColor.WHITE;
         }
      }
   }

   public static boolean isModernServer() {
      return hasModernBukkit;
   }

   public static boolean hasAdventureSupport() {
      return hasAdventure;
   }

   public static String componentToString(Object component) {
      if (component == null) {
         return "";
      } else {
         try {
            Class<?> serializerClass = Class.forName("net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer");
            Object serializer = serializerClass.getMethod("plainText").invoke((Object)null);
            Method serializeMethod = serializer.getClass().getMethod("serialize", Class.forName("net.kyori.adventure.text.Component"));
            return (String)serializeMethod.invoke(serializer, component);
         } catch (NoSuchMethodException | IllegalAccessException | InvocationTargetException | ClassNotFoundException var4) {
            return component.toString();
         }
      }
   }

   public static Object stringToComponent(String text) {
      if (text == null) {
         return null;
      } else {
         try {
            Class<?> componentClass = Class.forName("net.kyori.adventure.text.Component");
            return componentClass.getMethod("text", String.class).invoke((Object)null, ChatColor.translateAlternateColorCodes('&', text));
         } catch (NoSuchMethodException | IllegalAccessException | InvocationTargetException | ClassNotFoundException var2) {
            return text;
         }
      }
   }

   static {
      try {
         Class.forName("net.kyori.adventure.text.Component");
         hasAdventure = true;
      } catch (ClassNotFoundException var2) {
         hasAdventure = false;
      }

      try {
         Class.forName("org.bukkit.Material").getField("GRASS_BLOCK");
         hasModernBukkit = true;
      } catch (NoSuchFieldException | ClassNotFoundException var1) {
         hasModernBukkit = false;
      }

   }
}
