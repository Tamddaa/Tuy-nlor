package com.anti.system.utils;

import java.lang.reflect.InvocationTargetException;
import org.bukkit.Bukkit;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.potion.PotionEffectType;

public class VersionUtils {
   private static final String SERVER_VERSION = Bukkit.getVersion();
   private static final String MC_VERSION = extractMinecraftVersion();
   private static final boolean IS_LEGACY = isLegacyVersion();
   private static final boolean IS_1_21_PLUS = is121PlusImpl();

   public static boolean isLegacy() {
      return IS_LEGACY;
   }

   public static boolean isModern() {
      return !IS_LEGACY;
   }

   public static int getPing(Player player) {
      try {
         return (Integer)player.getClass().getMethod("getPing").invoke(player);
      } catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException var4) {
         try {
            Object handle = player.getClass().getMethod("getHandle").invoke(player);
            return (Integer)handle.getClass().getField("ping").get(handle);
         } catch (NoSuchFieldException | IllegalAccessException | InvocationTargetException | NoSuchMethodException var3) {
            return -1;
         }
      }
   }

   public static double[] getTPS() {
      try {
         Class<?> serverClass = Class.forName("org.bukkit.Bukkit");
         return (double[])serverClass.getMethod("getTPS").invoke((Object)null);
      } catch (NoSuchMethodException | IllegalAccessException | InvocationTargetException | ClassNotFoundException var1) {
         return new double[]{(double)20.0F, (double)20.0F, (double)20.0F};
      }
   }

   public static boolean isFlying(Player player) {
      return player.isFlying();
   }

   public static boolean isGliding(Player player) {
      try {
         return (Boolean)player.getClass().getMethod("isGliding").invoke(player);
      } catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException var2) {
         return false;
      }
   }

   public static boolean isSwimming(Player player) {
      try {
         return (Boolean)player.getClass().getMethod("isSwimming").invoke(player);
      } catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException var2) {
         return false;
      }
   }

   private static int getPotionEffectAmplifier(Player player, PotionEffectType effectType) {
      try {
         if (player.hasPotionEffect(effectType)) {
            Object effect = player.getClass().getMethod("getPotionEffect", PotionEffectType.class).invoke(player, effectType);
            if (effect != null) {
               return (Integer)effect.getClass().getMethod("getAmplifier").invoke(effect);
            }
         }
      } catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException var3) {
      }

      return 0;
   }

   private static boolean hasDolphinsGrace(Player player) {
      try {
         PotionEffectType dolphinsGrace = PotionEffectType.getByName("DOLPHINS_GRACE");
         if (dolphinsGrace != null) {
            return player.hasPotionEffect(dolphinsGrace);
         }
      } catch (IllegalArgumentException var2) {
      }

      return false;
   }

   public static double getMovementDelta(PlayerMoveEvent event) {
      return event.getFrom().getWorld() != event.getTo().getWorld() ? (double)0.0F : event.getFrom().distance(event.getTo());
   }

   public static boolean isSameBlock(Block block1, Block block2) {
      if (!IS_LEGACY) {
         return block1.getType() == block2.getType();
      } else {
         boolean sameTypeAndData = block1.getType() == block2.getType() && block1.getData() == block2.getData();
         return sameTypeAndData;
      }
   }

   public static String getMinecraftVersion() {
      return MC_VERSION;
   }

   private static String extractMinecraftVersion() {
      String version = SERVER_VERSION.toLowerCase();
      if (version.contains("1.21.8")) {
         return "1.21.8";
      } else if (version.contains("1.21.7")) {
         return "1.21.7";
      } else if (version.contains("1.21.6")) {
         return "1.21.6";
      } else if (version.contains("1.21.5")) {
         return "1.21.5";
      } else if (version.contains("1.21.4")) {
         return "1.21.4";
      } else if (version.contains("1.21.3")) {
         return "1.21.3";
      } else if (version.contains("1.21.2")) {
         return "1.21.2";
      } else if (version.contains("1.21.1")) {
         return "1.21.1";
      } else if (version.contains("1.21")) {
         return "1.21";
      } else if (version.contains("1.20")) {
         return "1.20";
      } else if (version.contains("1.19")) {
         return "1.19";
      } else if (version.contains("1.18")) {
         return "1.18";
      } else if (version.contains("1.17")) {
         return "1.17";
      } else if (version.contains("1.16")) {
         return "1.16";
      } else if (version.contains("1.15")) {
         return "1.15";
      } else if (version.contains("1.14")) {
         return "1.14";
      } else if (version.contains("1.13")) {
         return "1.13";
      } else if (version.contains("1.12")) {
         return "1.12";
      } else if (version.contains("1.11")) {
         return "1.11";
      } else if (version.contains("1.10")) {
         return "1.10";
      } else if (version.contains("1.9")) {
         return "1.9";
      } else {
         return version.contains("1.8") ? "1.8" : "unknown";
      }
   }

   private static boolean is121PlusImpl() {
      String version = MC_VERSION;
      if (version.equals("unknown")) {
         return false;
      } else {
         String[] parts = version.split("\\.");
         if (parts.length < 2) {
            return false;
         } else {
            try {
               int major = Integer.parseInt(parts[0]);
               int minor = Integer.parseInt(parts[1]);
               return major > 1 || major == 1 && minor >= 21;
            } catch (NumberFormatException var4) {
               return false;
            }
         }
      }
   }

   private static boolean isLegacyVersion() {
      String version = extractMinecraftVersion();
      if (version.equals("unknown")) {
         return true;
      } else {
         String[] parts = version.split("\\.");
         if (parts.length < 2) {
            return true;
         } else {
            try {
               int major = Integer.parseInt(parts[0]);
               int minor = Integer.parseInt(parts[1]);
               return major == 1 && minor <= 12;
            } catch (NumberFormatException var4) {
               return true;
            }
         }
      }
   }

   public static boolean is121Plus() {
      return IS_1_21_PLUS;
   }

   public static boolean supportsFeature(String feature) {
      switch (feature.toLowerCase()) {
         case "elytra":
            return !getMinecraftVersion().equals("1.8");
         case "trident":
            return isVersionAtLeast("1.13");
         case "swimming":
            return isVersionAtLeast("1.13");
         case "crossbow":
            return isVersionAtLeast("1.14");
         case "netherite":
            return isVersionAtLeast("1.16");
         case "bundle":
            return isVersionAtLeast("1.21");
         case "trial_chambers":
            return isVersionAtLeast("1.21");
         default:
            return true;
      }
   }

   private static boolean isVersionAtLeast(String targetVersion) {
      String currentVersion = getMinecraftVersion();
      if (currentVersion.equals("unknown")) {
         return false;
      } else {
         String[] currentParts = currentVersion.split("\\.");
         String[] targetParts = targetVersion.split("\\.");

         try {
            int currentMajor = Integer.parseInt(currentParts[0]);
            int currentMinor = Integer.parseInt(currentParts[1]);
            int currentPatch = currentParts.length > 2 ? Integer.parseInt(currentParts[2]) : 0;
            int targetMajor = Integer.parseInt(targetParts[0]);
            int targetMinor = Integer.parseInt(targetParts[1]);
            int targetPatch = targetParts.length > 2 ? Integer.parseInt(targetParts[2]) : 0;
            if (currentMajor != targetMajor) {
               return currentMajor > targetMajor;
            } else if (currentMinor != targetMinor) {
               return currentMinor > targetMinor;
            } else {
               return currentPatch >= targetPatch;
            }
         } catch (NumberFormatException var10) {
            return false;
         }
      }
   }

   public static double getMaxMovementSpeed(Player player) {
      double baseSpeed = 0.16;
      if (player.isSprinting()) {
         baseSpeed *= 1.28;
      }

      if (player.isFlying()) {
         baseSpeed = (double)(player.getFlySpeed() * 9.0F);
      }

      if (player.hasPotionEffect(PotionEffectType.SPEED)) {
         int amplifier = getPotionEffectAmplifier(player, PotionEffectType.SPEED);
         baseSpeed *= (double)1.0F + 0.18 * (double)Math.min(amplifier + 1, 2);
      }

      if (player.hasPotionEffect(VersionCompatibility.getSlownessEffect())) {
         int amplifier = getPotionEffectAmplifier(player, VersionCompatibility.getSlownessEffect());
         baseSpeed *= Math.max(0.1, (double)1.0F - 0.15 * (double)(amplifier + 1));
      }

      if (supportsFeature("swimming") && isSwimming(player)) {
         baseSpeed *= 0.4;

         try {
            if (hasDolphinsGrace(player)) {
               baseSpeed *= 1.3;
            }
         } catch (NoSuchFieldError var5) {
         }
      }

      return baseSpeed * 1.1;
   }
}
