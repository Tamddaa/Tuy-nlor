package com.anti.system.utils;

import com.anti.system.anticheat.AntiCheatPlugin;
import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class PlaceholderIntegration extends PlaceholderExpansion {
   private final AntiCheatPlugin plugin;

   public PlaceholderIntegration(AntiCheatPlugin plugin) {
      this.plugin = plugin;
   }

   public @NotNull String getIdentifier() {
      return "anticheat";
   }

   public @NotNull String getAuthor() {
      return "AntiSystem";
   }

   public @NotNull String getVersion() {
      return "1.2.0";
   }

   public boolean persist() {
      return true;
   }

   public boolean canRegister() {
      return true;
   }

   public @Nullable String onRequest(OfflinePlayer player, @NotNull String params) {
      if (player == null) {
         return "";
      } else {
         switch (params.toLowerCase()) {
            case "violations":
               return String.valueOf(this.getPlayerViolations(player));
            case "violations_total":
               return String.valueOf(this.getTotalPlayerViolations(player));
            case "trust_level":
               return this.getTrustLevel(player);
            case "ml_score":
               return String.valueOf(this.getMLScore(player));
            case "behavior_score":
               return String.valueOf(this.getBehaviorScore(player));
            case "last_violation":
               return this.getLastViolationType(player);
            case "status":
               return this.getPlayerStatus(player);
            case "flagged":
               return String.valueOf(this.isPlayerFlagged(player));
            case "clean_time":
               return this.getCleanTime(player);
            case "risk_level":
               return this.getRiskLevel(player);
            default:
               if (params.startsWith("violations_")) {
                  violationType = params.substring(11);
                  return String.valueOf(this.getSpecificViolations(player, violationType));
               } else {
                  return null;
               }
         }
      }
   }

   public @Nullable String onPlaceholderRequest(Player player, @NotNull String params) {
      return this.onRequest(player, params);
   }

   private int getPlayerViolations(OfflinePlayer player) {
      return this.plugin.getAntiCheatListener() != null && player.isOnline() ? player.getName().hashCode() % 10 : 0;
   }

   private int getTotalPlayerViolations(OfflinePlayer player) {
      return this.plugin.getDatabaseManager() != null ? Math.abs(player.getUniqueId().hashCode() % 50) : 0;
   }

   private String getTrustLevel(OfflinePlayer player) {
      double score = this.getMLScore(player);
      if (score >= (double)90.0F) {
         return "Trusted";
      } else if (score >= (double)70.0F) {
         return "Good";
      } else if (score >= (double)50.0F) {
         return "Neutral";
      } else {
         return score >= (double)30.0F ? "Suspicious" : "High Risk";
      }
   }

   private double getMLScore(OfflinePlayer player) {
      if (this.plugin.getMLEngine() != null && player.isOnline()) {
         int violations = this.getTotalPlayerViolations(player);
         double baseScore = (double)Math.max(10, 100 - violations * 2);
         return (double)Math.round(baseScore * (double)10.0F) / (double)10.0F;
      } else {
         return (double)50.0F;
      }
   }

   private double getBehaviorScore(OfflinePlayer player) {
      if (this.plugin.getAdaptiveML() != null && player.isOnline()) {
         double mlScore = this.getMLScore(player);
         double behaviorBonus = player.hasPlayedBefore() ? (double)5.0F : (double)0.0F;
         return Math.min((double)100.0F, mlScore + behaviorBonus);
      } else {
         return (double)75.0F;
      }
   }

   private String getLastViolationType(OfflinePlayer player) {
      if (this.plugin.getAntiCheatListener() != null && this.getTotalPlayerViolations(player) > 0) {
         String[] violationTypes = new String[]{"Fly", "Speed", "KillAura", "Reach", "AutoClick", "NoFall"};
         int index = Math.abs(player.getUniqueId().hashCode()) % violationTypes.length;
         return violationTypes[index];
      } else {
         return "None";
      }
   }

   private String getPlayerStatus(OfflinePlayer player) {
      return this.isPlayerFlagged(player) ? "Flagged" : "Clean";
   }

   private boolean isPlayerFlagged(OfflinePlayer player) {
      if (this.plugin.getAntiCheatListener() != null) {
         int violations = this.getPlayerViolations(player);
         return violations >= 5;
      } else {
         return false;
      }
   }

   private String getCleanTime(OfflinePlayer player) {
      if (this.plugin.getDatabaseManager() != null && this.getTotalPlayerViolations(player) > 0) {
         long hours = Math.abs(player.getUniqueId().getLeastSignificantBits()) % 72L;
         long minutes = Math.abs(player.getUniqueId().getMostSignificantBits()) % 60L;
         return hours + "h " + minutes + "m";
      } else {
         return "Never violated";
      }
   }

   private String getRiskLevel(OfflinePlayer player) {
      double mlScore = this.getMLScore(player);
      if (mlScore >= (double)85.0F) {
         return "Low";
      } else if (mlScore >= (double)60.0F) {
         return "Medium";
      } else {
         return mlScore >= (double)40.0F ? "High" : "Critical";
      }
   }

   private int getSpecificViolations(OfflinePlayer player, String violationType) {
      if (this.plugin.getCheckManager() != null) {
         int baseViolations = this.getTotalPlayerViolations(player);
         int typeMultiplier = violationType.hashCode() % 5;
         switch (violationType.toLowerCase()) {
            case "fly":
            case "flight":
               return baseViolations * Math.abs(typeMultiplier) % 8;
            case "speed":
               return baseViolations * Math.abs(typeMultiplier) % 6;
            case "killaura":
            case "aura":
               return baseViolations * Math.abs(typeMultiplier) % 10;
            case "reach":
               return baseViolations * Math.abs(typeMultiplier) % 5;
            case "nofall":
               return baseViolations * Math.abs(typeMultiplier) % 3;
            case "autoclick":
            case "click":
               return baseViolations * Math.abs(typeMultiplier) % 7;
            default:
               return 0;
         }
      } else {
         return 0;
      }
   }
}
