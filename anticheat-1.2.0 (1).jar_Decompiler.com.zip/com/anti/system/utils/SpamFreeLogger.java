package com.anti.system.utils;

import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;
import org.bukkit.plugin.java.JavaPlugin;

public class SpamFreeLogger {
   private static final Logger logger = Logger.getLogger(SpamFreeLogger.class.getName());
   private final Map<String, Long> lastLogTime;
   private final long cooldownMs;
   private final String prefix;

   public SpamFreeLogger(JavaPlugin plugin, long cooldownMs) {
      this.lastLogTime = new HashMap();
      this.prefix = "[" + plugin.getName() + "] ";
      this.cooldownMs = cooldownMs;
   }

   public SpamFreeLogger(JavaPlugin plugin) {
      this(plugin, 5000L);
   }

   public SpamFreeLogger(String prefix, long cooldownMs) {
      this.lastLogTime = new HashMap();
      this.prefix = prefix != null ? prefix : "";
      this.cooldownMs = cooldownMs;
   }

   public SpamFreeLogger(String prefix) {
      this(prefix, 5000L);
   }

   public void info(String category, String message) {
      this.logWithCooldown(category, "INFO", message, false);
   }

   public void warning(String category, String message) {
      this.logWithCooldown(category, "WARNING", message, true);
   }

   public void severe(String category, String message) {
      this.logWithCooldown(category, "SEVERE", message, true);
   }

   private void logWithCooldown(String category, String level, String message, boolean isWarning) {
      String key = category + ":" + level;
      long currentTime = System.currentTimeMillis();
      Long lastTime = (Long)this.lastLogTime.get(key);
      if (lastTime == null || currentTime - lastTime > this.cooldownMs) {
         this.lastLogTime.put(key, currentTime);
         String formattedMessage = String.format("%s[%s] %s", this.prefix, category, message);
         if (isWarning) {
            if (level.equals("SEVERE")) {
               logger.severe(formattedMessage);
            } else {
               logger.warning(formattedMessage);
            }
         } else {
            logger.info(formattedMessage);
         }
      }

   }

   public void clearCooldowns() {
      this.lastLogTime.clear();
   }

   public void setCooldown(String category, String level, long timeMs) {
      String key = category + ":" + level;
      this.lastLogTime.put(key, timeMs);
   }
}
