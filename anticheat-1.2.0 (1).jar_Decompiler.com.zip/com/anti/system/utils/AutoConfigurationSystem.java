package com.anti.system.utils;

import java.lang.management.ManagementFactory;
import java.lang.management.MemoryMXBean;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;
import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;

public class AutoConfigurationSystem {
   private final Plugin plugin;
   private final Map<String, ConfigProfile> profiles;
   private final ServerAnalytics analytics;
   private final PerformanceMonitor performanceMonitor;
   private ConfigProfile currentProfile;
   private static final String[] CONFIG_CATEGORIES = new String[]{"movement", "combat", "block", "world", "performance", "ml"};

   public AutoConfigurationSystem(Plugin plugin) {
      this.plugin = plugin;
      this.profiles = new ConcurrentHashMap();
      this.analytics = new ServerAnalytics();
      this.performanceMonitor = new PerformanceMonitor();
      this.initializeProfiles();
      this.startAnalysisTask();
   }

   private void initializeProfiles() {
      this.profiles.put("high_performance", (new ConfigProfile("High Performance", "Optimized for servers with high memory and CPU", AutoConfigurationSystem.ServerType.SURVIVAL, 0, 200, 4096L, (double)19.0F)).setSetting("movement.max-violations-per-second", 15).setSetting("movement.check-interval-ticks", 1).setSetting("combat.max-cps", 20).setSetting("combat.reach-distance", 3.8).setSetting("ml.enabled", true).setSetting("ml.advanced-features", true).setSetting("ml.training-enabled", true).setSetting("performance.async-checks", true).setSetting("performance.cache-size", 10000));
      this.profiles.put("balanced", (new ConfigProfile("Balanced", "Balanced performance and detection accuracy", AutoConfigurationSystem.ServerType.SURVIVAL, 0, 100, 2048L, (double)18.0F)).setSetting("movement.max-violations-per-second", 10).setSetting("movement.check-interval-ticks", 2).setSetting("combat.max-cps", 15).setSetting("combat.reach-distance", 3.6).setSetting("ml.enabled", true).setSetting("ml.advanced-features", false).setSetting("ml.training-enabled", true).setSetting("performance.async-checks", true).setSetting("performance.cache-size", 5000));
      this.profiles.put("performance", (new ConfigProfile("Performance", "Optimized for low-resource servers", AutoConfigurationSystem.ServerType.SURVIVAL, 0, 50, 1024L, (double)16.0F)).setSetting("movement.max-violations-per-second", 8).setSetting("movement.check-interval-ticks", 3).setSetting("combat.max-cps", 12).setSetting("combat.reach-distance", 3.4).setSetting("ml.enabled", false).setSetting("ml.advanced-features", false).setSetting("ml.training-enabled", false).setSetting("performance.async-checks", true).setSetting("performance.cache-size", 2000));
      this.profiles.put("pvp_optimized", (new ConfigProfile("PvP Optimized", "Optimized for PvP servers with strict combat detection", AutoConfigurationSystem.ServerType.PVP, 0, 150, 2048L, (double)18.0F)).setSetting("movement.max-violations-per-second", 12).setSetting("movement.check-interval-ticks", 1).setSetting("combat.max-cps", 12).setSetting("combat.reach-distance", 3.2).setSetting("combat.strict-timing", true).setSetting("ml.enabled", true).setSetting("ml.advanced-features", true).setSetting("ml.pvp-focus", true).setSetting("performance.async-checks", true).setSetting("performance.cache-size", 7500));
      this.profiles.put("creative", (new ConfigProfile("Creative", "Relaxed settings for creative servers", AutoConfigurationSystem.ServerType.CREATIVE, 0, 100, 1024L, (double)17.0F)).setSetting("movement.max-violations-per-second", 20).setSetting("movement.check-interval-ticks", 5).setSetting("movement.flight-allowed", true).setSetting("block.break-speed-multiplier", (double)10.0F).setSetting("block.place-speed-multiplier", (double)10.0F).setSetting("ml.enabled", false).setSetting("performance.async-checks", true).setSetting("performance.cache-size", 3000));
   }

   private void startAnalysisTask() {
      (new BukkitRunnable() {
         public void run() {
            try {
               AutoConfigurationSystem.this.updatePerformanceMetrics();
               if (AutoConfigurationSystem.this.performanceMonitor.isPerformanceDegraded()) {
                  AutoConfigurationSystem.this.optimizeForPerformance();
               }
            } catch (Exception e) {
               AutoConfigurationSystem.this.plugin.getLogger().log(Level.WARNING, "Error in auto-configuration analysis", e);
            }

         }
      }).runTaskTimerAsynchronously(this.plugin, 1200L, 1200L);
      (new BukkitRunnable() {
         public void run() {
            AutoConfigurationSystem.this.performInitialAnalysis();
         }
      }).runTaskLaterAsynchronously(this.plugin, 100L);
   }

   public void performInitialAnalysis() {
      this.plugin.getLogger().info("Performing automatic server analysis...");
      this.analytics.analyzeServer();
      ConfigProfile optimalProfile = this.determineOptimalProfile();
      if (optimalProfile != null) {
         this.applyProfile(optimalProfile);
         this.plugin.getLogger().info(String.format("Applied auto-configuration profile: %s", optimalProfile.getName()));
      } else {
         this.plugin.getLogger().warning("No suitable configuration profile found, using defaults");
      }

   }

   public ConfigProfile determineOptimalProfile() {
      ServerType serverType = this.analytics.getDetectedType();
      int playerCount = this.analytics.getAveragePlayerCount();
      long memoryMB = this.analytics.getAvailableMemoryMB();
      double tps = this.analytics.getAverageTPS();
      ConfigProfile bestProfile = null;
      int bestScore = -1;

      for(ConfigProfile profile : this.profiles.values()) {
         int score = this.calculateProfileScore(profile, serverType, playerCount, memoryMB, tps);
         if (score > bestScore) {
            bestScore = score;
            bestProfile = profile;
         }
      }

      return bestProfile;
   }

   private int calculateProfileScore(ConfigProfile profile, ServerType serverType, int playerCount, long memoryMB, double tps) {
      int score = 0;
      if (profile.getTargetType() == serverType) {
         score += 50;
      } else if (profile.getTargetType() == AutoConfigurationSystem.ServerType.SURVIVAL && serverType != AutoConfigurationSystem.ServerType.CREATIVE) {
         score += 25;
      }

      if (playerCount >= profile.getMinPlayers() && playerCount <= profile.getMaxPlayers()) {
         score += 30;
      } else if (playerCount < profile.getMinPlayers()) {
         score += Math.max(0, 30 - (profile.getMinPlayers() - playerCount));
      } else {
         score += Math.max(0, 30 - (playerCount - profile.getMaxPlayers()) / 10);
      }

      if (memoryMB >= profile.getMinMemoryMB()) {
         score += 20;
      } else {
         score -= (int)((profile.getMinMemoryMB() - memoryMB) / 100L);
      }

      if (tps >= profile.getMinTPS()) {
         score += 15;
      } else {
         score -= (int)((profile.getMinTPS() - tps) * (double)10.0F);
      }

      return Math.max(0, score);
   }

   public void applyProfile(ConfigProfile profile) {
      this.currentProfile = profile;
      this.plugin.getLogger().info(String.format("Applying configuration profile: %s", profile.getName()));
      this.plugin.getLogger().info(String.format("  %s", profile.getDescription()));

      for(Map.Entry<String, Object> entry : profile.getSettings().entrySet()) {
         String path = (String)entry.getKey();
         Object value = entry.getValue();

         try {
            this.plugin.getConfig().set(path, value);
            this.plugin.getLogger().fine(String.format("Set %s = %s", path, value));
         } catch (Exception var7) {
            this.plugin.getLogger().warning(String.format("Failed to set config value: %s = %s", path, value));
         }
      }

      this.plugin.saveConfig();
      this.plugin.getLogger().info("Configuration profile applied successfully!");
   }

   private void updatePerformanceMetrics() {
      double currentTPS = this.getCurrentTPS();
      this.performanceMonitor.recordTPS(currentTPS);
      MemoryMXBean memoryBean = ManagementFactory.getMemoryMXBean();
      long usedMemoryMB = memoryBean.getHeapMemoryUsage().getUsed() / 1048576L;
      this.performanceMonitor.recordMemoryUsage(usedMemoryMB);
   }

   private double getCurrentTPS() {
      try {
         Object server = Bukkit.getServer();
         if (VersionCompatibility.isVersionOrHigher(1, 19)) {
            Method getTPS = server.getClass().getMethod("getTPS");
            double[] tpsArray = (double[])getTPS.invoke(server);
            return tpsArray[0];
         } else {
            Object minecraftServer = server.getClass().getMethod("getServer").invoke(server);
            Field tpsField = minecraftServer.getClass().getField("recentTps");
            double[] recentTps = (double[])tpsField.get(minecraftServer);
            return recentTps[0];
         }
      } catch (IllegalAccessException | InvocationTargetException | NoSuchFieldException | NoSuchMethodException var5) {
         return (double)20.0F;
      }
   }

   private void optimizeForPerformance() {
      List<String> recommendations = this.performanceMonitor.getPerformanceRecommendations();
      if (!recommendations.isEmpty()) {
         this.plugin.getLogger().warning("Performance degradation detected. Applying optimizations:");

         for(String recommendation : recommendations) {
            this.plugin.getLogger().warning(String.format("  • %s", recommendation));
            this.applyPerformanceOptimization(recommendation);
         }
      }

   }

   private void applyPerformanceOptimization(String recommendation) {
      if (recommendation.contains("check frequency")) {
         this.plugin.getConfig().set("movement.check-interval-ticks", Math.min(this.plugin.getConfig().getInt("movement.check-interval-ticks", 2) + 1, 5));
      } else if (recommendation.contains("ML features")) {
         this.plugin.getConfig().set("ml.advanced-features", false);
      } else if (recommendation.contains("cache sizes")) {
         int currentSize = this.plugin.getConfig().getInt("performance.cache-size", 5000);
         this.plugin.getConfig().set("performance.cache-size", Math.max(currentSize / 2, 1000));
      } else if (recommendation.contains("logging")) {
         this.plugin.getConfig().set("logging.verbose", false);
      }

      this.plugin.saveConfig();
   }

   public List<String> getConfigurationRecommendations() {
      List<String> recommendations = new ArrayList();
      ServerType serverType = this.analytics.getDetectedType();
      long memoryMB = this.analytics.getAvailableMemoryMB();
      int playerCount = this.analytics.getAveragePlayerCount();
      double tps = this.performanceMonitor.getAverageTPS();
      if (memoryMB < 2048L) {
         recommendations.add("Consider disabling ML features to reduce memory usage");
         recommendations.add("Reduce cache sizes for better memory efficiency");
      } else if (memoryMB > 8192L) {
         recommendations.add("Enable advanced ML features for better detection");
         recommendations.add("Increase cache sizes for better performance");
      }

      if (playerCount > 100) {
         recommendations.add("Enable async processing for all checks");
         recommendations.add("Consider increasing check intervals slightly");
      } else if (playerCount < 10) {
         recommendations.add("Enable more strict detection settings");
         recommendations.add("Reduce check intervals for faster detection");
      }

      if (tps < (double)18.0F) {
         recommendations.add("Increase check intervals to reduce CPU load");
         recommendations.add("Disable non-essential checks temporarily");
      }

      switch (serverType.ordinal()) {
         case 0:
            recommendations.add("Enable standard survival checks");
            recommendations.add("Monitor resource gathering");
            break;
         case 1:
            recommendations.add("Enable strict combat checks");
            recommendations.add("Reduce combat reach distance");
            recommendations.add("Enable advanced timing checks");
            break;
         case 2:
            recommendations.add("Adjust checks for mini-game mechanics");
            recommendations.add("Allow special movement for games");
            break;
         case 3:
            recommendations.add("Allow flight and fast movement");
            recommendations.add("Increase block interaction speeds");
            recommendations.add("Disable most combat checks");
            break;
         case 4:
            recommendations.add("Allow void teleportation");
            recommendations.add("Adjust fall damage checks");
            break;
         case 5:
            recommendations.add("Enable mining-specific checks");
            recommendations.add("Monitor block break patterns");
            break;
         case 6:
            recommendations.add("Enable PvP and raiding checks");
            recommendations.add("Monitor territorial boundaries");
            break;
         case 7:
            recommendations.add("Reduce check sensitivity");
            recommendations.add("Allow more aggressive gameplay");
            break;
         case 8:
            recommendations.add("Adapt checks for modded content");
            recommendations.add("Allow custom block interactions");
            break;
         case 9:
         default:
            recommendations.add("Use default configuration");
            recommendations.add("Monitor for server type patterns");
      }

      return recommendations;
   }

   public ServerAnalytics getAnalytics() {
      return this.analytics;
   }

   public PerformanceMonitor getPerformanceMonitor() {
      return this.performanceMonitor;
   }

   public ConfigProfile getCurrentProfile() {
      return this.currentProfile;
   }

   public Map<String, ConfigProfile> getProfiles() {
      return new HashMap(this.profiles);
   }

   public void forceReAnalysis() {
      (new BukkitRunnable() {
         public void run() {
            AutoConfigurationSystem.this.performInitialAnalysis();
         }
      }).runTaskAsynchronously(this.plugin);
   }

   public ConfigProfile exportCurrentConfig(String name, String description) {
      ConfigProfile profile = new ConfigProfile(name, description, this.analytics.getDetectedType(), 0, 999, 0L, (double)0.0F);

      for(String category : CONFIG_CATEGORIES) {
         if (this.plugin.getConfig().isConfigurationSection(category)) {
            ConfigurationSection section = this.plugin.getConfig().getConfigurationSection(category);

            for(String key : section.getKeys(true)) {
               String fullPath = category + "." + key;
               profile.setSetting(fullPath, this.plugin.getConfig().get(fullPath));
            }
         }
      }

      return profile;
   }

   public static class ConfigProfile {
      private final String name;
      private final String description;
      private final Map<String, Object> settings;
      private final ServerType targetType;
      private final int minPlayers;
      private final int maxPlayers;
      private final long minMemoryMB;
      private final double minTPS;

      public ConfigProfile(String name, String description, ServerType targetType, int minPlayers, int maxPlayers, long minMemoryMB, double minTPS) {
         this.name = name;
         this.description = description;
         this.settings = new HashMap();
         this.targetType = targetType;
         this.minPlayers = minPlayers;
         this.maxPlayers = maxPlayers;
         this.minMemoryMB = minMemoryMB;
         this.minTPS = minTPS;
      }

      public ConfigProfile setSetting(String path, Object value) {
         this.settings.put(path, value);
         return this;
      }

      public String getName() {
         return this.name;
      }

      public String getDescription() {
         return this.description;
      }

      public Map<String, Object> getSettings() {
         return this.settings;
      }

      public ServerType getTargetType() {
         return this.targetType;
      }

      public int getMinPlayers() {
         return this.minPlayers;
      }

      public int getMaxPlayers() {
         return this.maxPlayers;
      }

      public long getMinMemoryMB() {
         return this.minMemoryMB;
      }

      public double getMinTPS() {
         return this.minTPS;
      }
   }

   public static enum ServerType {
      SURVIVAL("Survival", "General survival gameplay"),
      PVP("PvP", "Player vs Player focused"),
      MINIGAMES("Minigames", "Mini-games and events"),
      CREATIVE("Creative", "Creative building"),
      SKYBLOCK("Skyblock", "Skyblock gameplay"),
      PRISON("Prison", "Prison server"),
      FACTION("Factions", "Faction warfare"),
      ANARCHY("Anarchy", "No rules anarchy"),
      MODDED("Modded", "Modded server"),
      UNKNOWN("Unknown", "Unknown server type");

      private final String displayName;
      private final String description;

      private ServerType(String displayName, String description) {
         this.displayName = displayName;
         this.description = description;
      }

      public String getDisplayName() {
         return this.displayName;
      }

      public String getDescription() {
         return this.description;
      }

      // $FF: synthetic method
      private static ServerType[] $values() {
         return new ServerType[]{SURVIVAL, PVP, MINIGAMES, CREATIVE, SKYBLOCK, PRISON, FACTION, ANARCHY, MODDED, UNKNOWN};
      }
   }

   public class ServerAnalytics {
      private ServerType detectedType;
      private int averagePlayerCount;
      private long availableMemoryMB;
      private final double averageTPS;
      private boolean isPaper;
      private String serverVersion;
      private final Map<String, Integer> worldTypeCounts;
      private final Map<String, Integer> pluginCategories;

      public ServerAnalytics() {
         this.detectedType = AutoConfigurationSystem.ServerType.UNKNOWN;
         this.averagePlayerCount = 0;
         this.availableMemoryMB = 0L;
         this.averageTPS = (double)20.0F;
         this.isPaper = false;
         this.serverVersion = "";
         this.worldTypeCounts = new HashMap();
         this.pluginCategories = new HashMap();
      }

      public void analyzeServer() {
         this.detectServerSoftware();
         this.analyzeMemory();
         this.analyzeWorlds();
         this.analyzePlugins();
         this.detectServerType();
         this.calculateAverages();
         AutoConfigurationSystem.this.plugin.getLogger().info("Server Analysis Complete:");
         AutoConfigurationSystem.this.plugin.getLogger().info(String.format("Type: %s", this.detectedType.getDisplayName()));
         AutoConfigurationSystem.this.plugin.getLogger().info(String.format("Software: %s", this.isPaper ? "Paper" : "Bukkit/Spigot"));
         AutoConfigurationSystem.this.plugin.getLogger().info(String.format("Version: %s", this.serverVersion));
         AutoConfigurationSystem.this.plugin.getLogger().info(String.format("Memory: %dMB", this.availableMemoryMB));
         AutoConfigurationSystem.this.plugin.getLogger().info(String.format("Avg Players: %d", this.averagePlayerCount));
         AutoConfigurationSystem.this.plugin.getLogger().info(String.format("Avg TPS: %.2f", (double)20.0F));
      }

      private void detectServerSoftware() {
         String serverName = Bukkit.getServer().getName().toLowerCase();
         String version = Bukkit.getServer().getVersion();
         this.isPaper = VersionCompatibility.isPaper();
         this.serverVersion = Bukkit.getVersion();
         AutoConfigurationSystem.this.plugin.getLogger().info(String.format("Detected server: %s %s", serverName, version));
      }

      private void analyzeMemory() {
         MemoryMXBean memoryBean = ManagementFactory.getMemoryMXBean();
         long maxMemory = memoryBean.getHeapMemoryUsage().getMax();
         this.availableMemoryMB = maxMemory / 1048576L;
         AutoConfigurationSystem.this.plugin.getLogger().info(String.format("Available memory: %dMB", this.availableMemoryMB));
      }

      private void analyzeWorlds() {
         this.worldTypeCounts.clear();

         for(World world : Bukkit.getWorlds()) {
            String environmentName = world.getEnvironment().name().toLowerCase();
            this.worldTypeCounts.merge(environmentName, 1, Integer::sum);
            String generator = world.getGenerator() != null ? world.getGenerator().getClass().getSimpleName() : "default";
            if (!generator.toLowerCase().contains("void") && !generator.toLowerCase().contains("skyblock")) {
               if (generator.toLowerCase().contains("flat")) {
                  this.worldTypeCounts.merge("creative", 1, Integer::sum);
               }
            } else {
               this.worldTypeCounts.merge("skyblock", 1, Integer::sum);
            }
         }

      }

      private void analyzePlugins() {
         this.pluginCategories.clear();

         for(Plugin p : Bukkit.getPluginManager().getPlugins()) {
            String pluginName = p.getName().toLowerCase();
            if (!pluginName.contains("pvp") && !pluginName.contains("combat") && !pluginName.contains("war") && !pluginName.contains("battle")) {
               if (!pluginName.contains("prison") && !pluginName.contains("mine")) {
                  if (!pluginName.contains("faction") && !pluginName.contains("clan")) {
                     if (!pluginName.contains("skyblock") && !pluginName.contains("island")) {
                        if (!pluginName.contains("creative") && !pluginName.contains("plot") && !pluginName.contains("worldedit")) {
                           if (pluginName.contains("mini") || pluginName.contains("game") || pluginName.contains("arena")) {
                              this.pluginCategories.merge("minigame", 1, Integer::sum);
                           }
                        } else {
                           this.pluginCategories.merge("creative", 1, Integer::sum);
                        }
                     } else {
                        this.pluginCategories.merge("skyblock", 1, Integer::sum);
                     }
                  } else {
                     this.pluginCategories.merge("faction", 1, Integer::sum);
                  }
               } else {
                  this.pluginCategories.merge("prison", 1, Integer::sum);
               }
            } else {
               this.pluginCategories.merge("pvp", 1, Integer::sum);
            }
         }

      }

      private void detectServerType() {
         Map<ServerType, Integer> scores = new EnumMap(ServerType.class);

         for(ServerType type : AutoConfigurationSystem.ServerType.values()) {
            scores.put(type, 0);
         }

         for(Map.Entry<String, Integer> entry : this.pluginCategories.entrySet()) {
            String category = (String)entry.getKey();
            int count = (Integer)entry.getValue();
            switch (category) {
               case "pvp":
                  scores.merge(AutoConfigurationSystem.ServerType.PVP, count * 3, Integer::sum);
                  scores.merge(AutoConfigurationSystem.ServerType.FACTION, count * 2, Integer::sum);
                  break;
               case "prison":
                  scores.merge(AutoConfigurationSystem.ServerType.PRISON, count * 4, Integer::sum);
                  break;
               case "faction":
                  scores.merge(AutoConfigurationSystem.ServerType.FACTION, count * 4, Integer::sum);
                  break;
               case "skyblock":
                  scores.merge(AutoConfigurationSystem.ServerType.SKYBLOCK, count * 4, Integer::sum);
                  break;
               case "creative":
                  scores.merge(AutoConfigurationSystem.ServerType.CREATIVE, count * 3, Integer::sum);
                  break;
               case "minigame":
                  scores.merge(AutoConfigurationSystem.ServerType.MINIGAMES, count * 3, Integer::sum);
            }
         }

         for(Map.Entry<String, Integer> entry : this.worldTypeCounts.entrySet()) {
            String worldType = (String)entry.getKey();
            int count = (Integer)entry.getValue();
            if (worldType.contains("skyblock")) {
               scores.merge(AutoConfigurationSystem.ServerType.SKYBLOCK, count * 2, Integer::sum);
            } else if (!worldType.contains("creative") && !worldType.equals("flat")) {
               if (worldType.equals("normal")) {
                  scores.merge(AutoConfigurationSystem.ServerType.SURVIVAL, count, Integer::sum);
               }
            } else {
               scores.merge(AutoConfigurationSystem.ServerType.CREATIVE, count * 2, Integer::sum);
            }
         }

         this.detectedType = (ServerType)scores.entrySet().stream().max(Entry.comparingByValue()).map(Map.Entry::getKey).orElse(AutoConfigurationSystem.ServerType.SURVIVAL);
      }

      private void calculateAverages() {
         List<Player> players = new ArrayList(Bukkit.getOnlinePlayers());
         this.averagePlayerCount = players.size();
      }

      public ServerType getDetectedType() {
         return this.detectedType;
      }

      public int getAveragePlayerCount() {
         return this.averagePlayerCount;
      }

      public long getAvailableMemoryMB() {
         return this.availableMemoryMB;
      }

      public double getAverageTPS() {
         return (double)20.0F;
      }
   }

   public static class PerformanceMonitor {
      private final Queue<Double> tpsHistory = new LinkedList();
      private final Queue<Long> memoryHistory = new LinkedList();
      private double averageTPS = (double)20.0F;
      private long averageMemoryUsage = 0L;

      public void recordTPS(double tps) {
         this.tpsHistory.offer(tps);
         if (this.tpsHistory.size() > 60) {
            this.tpsHistory.poll();
         }

         this.averageTPS = this.tpsHistory.stream().mapToDouble(Double::doubleValue).average().orElse((double)20.0F);
      }

      public void recordMemoryUsage(long memoryMB) {
         this.memoryHistory.offer(memoryMB);
         if (this.memoryHistory.size() > 60) {
            this.memoryHistory.poll();
         }

         this.averageMemoryUsage = (long)this.memoryHistory.stream().mapToLong(Long::longValue).average().orElse((double)0.0F);
      }

      public boolean isPerformanceDegraded() {
         Runtime runtime = Runtime.getRuntime();
         long maxMemory = runtime.maxMemory() / 1048576L;
         return this.averageTPS < (double)18.0F || (double)this.averageMemoryUsage > (double)maxMemory * 0.85;
      }

      public List<String> getPerformanceRecommendations() {
         List<String> recommendations = new ArrayList();
         if (this.averageTPS < (double)15.0F) {
            recommendations.add("Reduce check frequency for non-critical checks");
            recommendations.add("Increase async processing");
            recommendations.add("Consider disabling ML features temporarily");
         } else if (this.averageTPS < (double)18.0F) {
            recommendations.add("Optimize movement check intervals");
            recommendations.add("Reduce logging verbosity");
         }

         if ((double)this.averageMemoryUsage > (double)(Runtime.getRuntime().maxMemory() / 1048576L) * 0.9) {
            recommendations.add("Clear old violation data");
            recommendations.add("Reduce cache sizes");
            recommendations.add("Optimize ML model memory usage");
         }

         return recommendations;
      }

      public double getAverageTPS() {
         return this.averageTPS;
      }
   }
}
