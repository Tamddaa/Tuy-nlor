package com.anti.system.anticheat;

import com.anti.system.utils.VersionCompatibility;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;

public class ReportSystem {
   private final JavaPlugin plugin;
   private final DatabaseManager database;
   private final DiscordWebhookManager discordManager;
   private static final String[] REPORT_CATEGORIES = new String[]{"Cheating/Hacks", "Toxicity/Harassment", "Griefing", "Spam", "Inappropriate Name/Skin", "Bug Exploitation", "Other"};

   public ReportSystem(JavaPlugin plugin, DatabaseManager database, DiscordWebhookManager discordManager) {
      this.plugin = plugin;
      this.database = database;
      this.discordManager = discordManager;
      this.initializeDatabase();
   }

   private void initializeDatabase() {
      try {
         Connection conn = this.database.getConnection();

         try {
            Statement stmt = conn.createStatement();

            try {
               stmt.execute("CREATE TABLE IF NOT EXISTS player_reports (id INTEGER PRIMARY KEY AUTOINCREMENT, reporter_uuid VARCHAR(36) NOT NULL, reporter_name VARCHAR(16) NOT NULL, reported_uuid VARCHAR(36) NOT NULL, reported_name VARCHAR(16) NOT NULL, category VARCHAR(50) NOT NULL, priority INTEGER NOT NULL, reason TEXT NOT NULL, evidence TEXT, server_name VARCHAR(50), world_name VARCHAR(50), location TEXT, timestamp BIGINT NOT NULL, status VARCHAR(20) DEFAULT 'OPEN', assigned_staff VARCHAR(36), staff_notes TEXT, resolution TEXT, resolved_timestamp BIGINT, resolved_by VARCHAR(36))");
               stmt.execute("CREATE TABLE IF NOT EXISTS report_actions (id INTEGER PRIMARY KEY AUTOINCREMENT, report_id INTEGER NOT NULL, staff_uuid VARCHAR(36) NOT NULL, staff_name VARCHAR(16) NOT NULL, action VARCHAR(50) NOT NULL, details TEXT, timestamp BIGINT NOT NULL, FOREIGN KEY (report_id) REFERENCES player_reports(id))");
            } catch (Throwable var7) {
               if (stmt != null) {
                  try {
                     stmt.close();
                  } catch (Throwable var6) {
                     var7.addSuppressed(var6);
                  }
               }

               throw var7;
            }

            if (stmt != null) {
               stmt.close();
            }
         } catch (Throwable var8) {
            if (conn != null) {
               try {
                  conn.close();
               } catch (Throwable var5) {
                  var8.addSuppressed(var5);
               }
            }

            throw var8;
         }

         if (conn != null) {
            conn.close();
         }
      } catch (SQLException e) {
         this.plugin.getLogger().severe("Failed to initialize report database");
         this.plugin.getLogger().severe(e.getMessage());
      }

   }

   public boolean submitReport(Player reporter, String reportedPlayerName, String category, String reason, ReportPriority priority) {
      Player reportedPlayer = (Player)Bukkit.getOnlinePlayers().stream().filter((p) -> p.getName().equalsIgnoreCase(reportedPlayerName)).findFirst().orElse((Object)null);
      if (reportedPlayer == null) {
         reporter.sendMessage("§cPlayer not found or not online!");
         return false;
      } else if (reporter.equals(reportedPlayer)) {
         reporter.sendMessage("§cYou cannot report yourself!");
         return false;
      } else if (this.hasRecentReports(reporter, 3)) {
         reporter.sendMessage("§cYou have submitted too many reports recently. Please wait before submitting another.");
         return false;
      } else {
         try {
            long timestamp = System.currentTimeMillis();
            String location = String.format("%.1f, %.1f, %.1f", reportedPlayer.getLocation().getX(), reportedPlayer.getLocation().getY(), reportedPlayer.getLocation().getZ());
            PreparedStatement stmt = this.database.getConnection().prepareStatement("INSERT INTO player_reports (reporter_uuid, reporter_name, reported_uuid, reported_name, category, priority, reason, server_name, world_name, location, timestamp) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            stmt.setString(1, reporter.getUniqueId().toString());
            stmt.setString(2, reporter.getName());
            stmt.setString(3, reportedPlayer.getUniqueId().toString());
            stmt.setString(4, reportedPlayer.getName());
            stmt.setString(5, category);
            stmt.setInt(6, priority.getLevel());
            stmt.setString(7, reason);
            stmt.setString(8, "Server");
            stmt.setString(9, reportedPlayer.getWorld().getName());
            stmt.setString(10, location);
            stmt.setLong(11, timestamp);
            int result = stmt.executeUpdate();
            if (result > 0) {
               ResultSet generatedKeys = stmt.getGeneratedKeys();
               int reportId = 0;
               if (generatedKeys.next()) {
                  reportId = generatedKeys.getInt(1);
               }

               this.notifyStaffOfReport(reportId, reporter, reportedPlayer, category, priority, reason);
               this.sendDiscordNotification(reportId, reporter, reportedPlayer, category, priority, reason);
               reporter.sendMessage("§aReport submitted successfully! Report ID: #" + reportId);
               return true;
            }
         } catch (SQLException e) {
            this.plugin.getLogger().severe("Failed to submit report");
            this.plugin.getLogger().severe(e.getMessage());
            reporter.sendMessage("§cFailed to submit report. Please try again.");
         }

         return false;
      }
   }

   private boolean hasRecentReports(Player reporter, int maxReports) {
      try {
         long oneHourAgo = System.currentTimeMillis() - 3600000L;
         PreparedStatement stmt = this.database.getConnection().prepareStatement("SELECT COUNT(*) FROM player_reports WHERE reporter_uuid = ? AND timestamp > ?");
         stmt.setString(1, reporter.getUniqueId().toString());
         stmt.setLong(2, oneHourAgo);
         ResultSet rs = stmt.executeQuery();
         if (rs.next()) {
            return rs.getInt(1) >= maxReports;
         }
      } catch (SQLException e) {
         this.plugin.getLogger().warning("Failed to check recent reports");
         this.plugin.getLogger().warning(e.getMessage());
      }

      return false;
   }

   private void notifyStaffOfReport(int reportId, Player reporter, Player reported, String category, ReportPriority priority, String reason) {
      String message = String.format("§c§l[REPORT] §r%s§7 New %s report (#%d)\n§7Reporter: §f%s §7| Reported: §f%s\n§7Category: §f%s §7| Priority: %s\n§7Reason: §f%s", priority.getDisplay(), priority.getDisplay().toLowerCase(), reportId, reporter.getName(), reported.getName(), category, priority.getDisplay(), reason);

      for(Player staff : Bukkit.getOnlinePlayers()) {
         if (staff.hasPermission("antisystem.staff.reports")) {
            staff.sendMessage(message);
            staff.sendMessage("§7Click to manage: §b/reports view " + reportId);
         }
      }

   }

   private void sendDiscordNotification(int reportId, Player reporter, Player reported, String category, ReportPriority priority, String reason) {
      if (this.discordManager != null) {
         try {
            String message = String.format("**New Player Report #%d**\n**Reporter:** %s\n**Reported:** %s\n**Category:** %s\n**Priority:** %s\n**Reason:** %s", reportId, reporter.getName(), reported.getName(), category, priority.name(), reason);
            DiscordWebhookManager.AlertLevel level = DiscordWebhookManager.AlertLevel.WARNING;
            if (priority == ReportSystem.ReportPriority.URGENT) {
               level = DiscordWebhookManager.AlertLevel.CRITICAL;
            }

            this.discordManager.sendServerAlert("Player Report", message, level);
         } catch (Exception e) {
            this.plugin.getLogger().warning("Failed to send Discord notification");
            this.plugin.getLogger().warning(e.getMessage());
         }

      }
   }

   public void openReportGUI(Player player) {
      Inventory gui = Bukkit.createInventory((InventoryHolder)null, 54, "§c§lReport Player");
      int slot = 0;

      for(Player onlinePlayer : Bukkit.getOnlinePlayers()) {
         if (!onlinePlayer.equals(player)) {
            if (slot >= 45) {
               break;
            }

            ItemStack playerHead = new ItemStack(VersionCompatibility.getPlayerHeadMaterial());
            ItemMeta meta = playerHead.getItemMeta();
            meta.setDisplayName("§f" + onlinePlayer.getName());
            meta.setLore(Arrays.asList("§7Click to report this player", "§7Status: §a" + (onlinePlayer.isOnline() ? "Online" : "Offline"), "§7World: §e" + onlinePlayer.getWorld().getName()));
            playerHead.setItemMeta(meta);
            gui.setItem(slot++, playerHead);
         }
      }

      ItemStack info = new ItemStack(Material.BOOK);
      ItemMeta infoMeta = info.getItemMeta();
      infoMeta.setDisplayName("§6§lReport Information");
      infoMeta.setLore(Arrays.asList("§7Select a player to report", "§7Available categories:", "§8• §7Cheating/Hacks", "§8• §7Toxicity/Harassment", "§8• §7Griefing", "§8• §7Spam", "§8• §7Inappropriate Name/Skin", "§8• §7Bug Exploitation", "§8• §7Other"));
      info.setItemMeta(infoMeta);
      gui.setItem(49, info);
      ItemStack close = new ItemStack(Material.BARRIER);
      ItemMeta closeMeta = close.getItemMeta();
      closeMeta.setDisplayName("§c§lClose");
      close.setItemMeta(closeMeta);
      gui.setItem(53, close);
      player.openInventory(gui);
   }

   public void openCategoryGUI(Player reporter, String reportedPlayerName) {
      Inventory gui = Bukkit.createInventory((InventoryHolder)null, 27, "§c§lSelect Report Category");
      int slot = 10;

      for(String category : REPORT_CATEGORIES) {
         Material material = this.getCategoryMaterial(category);
         ItemStack item = new ItemStack(material);
         ItemMeta meta = item.getItemMeta();
         meta.setDisplayName("§f" + category);
         meta.setLore(Arrays.asList("§7Click to report for: §e" + category, "§7Reporting: §c" + reportedPlayerName));
         item.setItemMeta(meta);
         gui.setItem(slot++, item);
         if (slot == 17) {
            slot = 19;
         }
      }

      ItemStack back = new ItemStack(Material.ARROW);
      ItemMeta backMeta = back.getItemMeta();
      backMeta.setDisplayName("§7« Back");
      back.setItemMeta(backMeta);
      gui.setItem(18, back);
      ItemStack close = new ItemStack(Material.BARRIER);
      ItemMeta closeMeta = close.getItemMeta();
      closeMeta.setDisplayName("§c§lClose");
      close.setItemMeta(closeMeta);
      gui.setItem(26, close);
      reporter.openInventory(gui);
   }

   private Material getCategoryMaterial(String category) {
      switch (category) {
         case "Cheating/Hacks":
            return Material.DIAMOND_SWORD;
         case "Toxicity/Harassment":
            return Material.ROTTEN_FLESH;
         case "Griefing":
            return Material.TNT;
         case "Spam":
            return VersionCompatibility.getRepeaterMaterial();
         case "Inappropriate Name/Skin":
            return Material.NAME_TAG;
         case "Bug Exploitation":
            return Material.SPIDER_EYE;
         default:
            return Material.PAPER;
      }
   }

   public List<Report> getOpenReports() {
      ArrayList<Report> reports = new ArrayList();

      try {
         PreparedStatement stmt = this.database.getConnection().prepareStatement("SELECT * FROM player_reports WHERE status = 'OPEN' ORDER BY priority DESC, timestamp DESC");
         ResultSet rs = stmt.executeQuery();

         while(rs.next()) {
            reports.add(new Report(rs.getInt("id"), rs.getString("reporter_name"), rs.getString("reported_name"), rs.getString("category"), ReportSystem.ReportPriority.values()[rs.getInt("priority") - 1], rs.getString("reason"), rs.getLong("timestamp"), rs.getString("status")));
         }
      } catch (SQLException e) {
         this.plugin.getLogger().severe("Failed to get open reports");
         this.plugin.getLogger().severe(e.getMessage());
      }

      return reports;
   }

   public void openStaffReportsGUI(Player staff) {
      List<Report> openReports = this.getOpenReports();
      int size = Math.max(27, (openReports.size() + 8) / 9 * 9);
      if (size > 54) {
         size = 54;
      }

      Inventory gui = Bukkit.createInventory((InventoryHolder)null, size, "§4§lReport Management");
      int slot = 0;

      for(Report report : openReports) {
         if (slot >= size - 9) {
            break;
         }

         ItemStack item = new ItemStack(Material.PAPER);
         ItemMeta meta = item.getItemMeta();
         meta.setDisplayName("§c§lReport #" + report.getId());
         String timeAgo = this.getTimeAgo(report.getTimestamp());
         meta.setLore(Arrays.asList("§7Reporter: §f" + report.getReporterName(), "§7Reported: §c" + report.getReportedName(), "§7Category: §e" + report.getCategory(), "§7Priority: " + report.getPriority().getDisplay(), "§7Time: §7" + timeAgo, "§7Reason: §f" + (report.getReason().length() > 30 ? report.getReason().substring(0, 30) + "..." : report.getReason()), "", "§aClick to manage this report"));
         item.setItemMeta(meta);
         gui.setItem(slot++, item);
      }

      ItemStack refresh = new ItemStack(Material.EMERALD);
      ItemMeta refreshMeta = refresh.getItemMeta();
      refreshMeta.setDisplayName("§a§lRefresh");
      refreshMeta.setLore(Arrays.asList("§7Click to refresh the report list"));
      refresh.setItemMeta(refreshMeta);
      gui.setItem(size - 9, refresh);
      ItemStack stats = new ItemStack(Material.BOOK);
      ItemMeta statsMeta = stats.getItemMeta();
      statsMeta.setDisplayName("§6§lReport Statistics");
      statsMeta.setLore(Arrays.asList("§7Click to view report statistics"));
      stats.setItemMeta(statsMeta);
      gui.setItem(size - 8, stats);
      ItemStack close = new ItemStack(Material.BARRIER);
      ItemMeta closeMeta = close.getItemMeta();
      closeMeta.setDisplayName("§c§lClose");
      close.setItemMeta(closeMeta);
      gui.setItem(size - 1, close);
      staff.openInventory(gui);
   }

   public Report getReportById(int reportId) {
      try {
         PreparedStatement stmt = this.database.getConnection().prepareStatement("SELECT r.*, ra.action, ra.details as action_details, ra.timestamp as action_timestamp, ra.staff_name FROM player_reports r LEFT JOIN report_actions ra ON r.id = ra.report_id WHERE r.id = ? ORDER BY ra.timestamp DESC LIMIT 1");
         stmt.setInt(1, reportId);
         ResultSet rs = stmt.executeQuery();
         if (rs.next()) {
            ReportPriority priority = ReportSystem.ReportPriority.values()[rs.getInt("priority") - 1];
            return new Report(rs.getInt("id"), rs.getString("reporter_name"), rs.getString("reported_name"), rs.getString("category"), priority, rs.getString("reason"), rs.getLong("timestamp"), rs.getString("status"));
         }
      } catch (SQLException e) {
         this.plugin.getLogger().warning("Failed to get report by ID");
         this.plugin.getLogger().warning(e.getMessage());
      }

      return null;
   }

   public ReportStatistics getReportStatistics() {
      try {
         Connection conn = this.database.getConnection();
         PreparedStatement totalStmt = conn.prepareStatement("SELECT COUNT(*) FROM player_reports");
         ResultSet totalRs = totalStmt.executeQuery();
         int totalReports = totalRs.next() ? totalRs.getInt(1) : 0;
         PreparedStatement openStmt = conn.prepareStatement("SELECT COUNT(*) FROM player_reports WHERE status = 'OPEN'");
         ResultSet openRs = openStmt.executeQuery();
         int openReports = openRs.next() ? openRs.getInt(1) : 0;
         long todayStart = System.currentTimeMillis() - System.currentTimeMillis() % 86400000L;
         PreparedStatement todayStmt = conn.prepareStatement("SELECT COUNT(*) FROM player_reports WHERE timestamp >= ?");
         todayStmt.setLong(1, todayStart);
         ResultSet todayRs = todayStmt.executeQuery();
         int reportsToday = todayRs.next() ? todayRs.getInt(1) : 0;
         PreparedStatement resolvedStmt = conn.prepareStatement("SELECT COUNT(*) FROM player_reports WHERE status = 'RESOLVED'");
         ResultSet resolvedRs = resolvedStmt.executeQuery();
         int resolvedReports = resolvedRs.next() ? resolvedRs.getInt(1) : 0;
         HashMap<ReportPriority, Integer> priorityStats = new HashMap();

         for(ReportPriority priority : ReportSystem.ReportPriority.values()) {
            PreparedStatement priorityStmt = conn.prepareStatement("SELECT COUNT(*) FROM player_reports WHERE priority = ?");
            priorityStmt.setInt(1, priority.getLevel());
            ResultSet priorityRs = priorityStmt.executeQuery();
            priorityStats.put(priority, priorityRs.next() ? priorityRs.getInt(1) : 0);
         }

         return new ReportStatistics(totalReports, openReports, reportsToday, resolvedReports, priorityStats);
      } catch (SQLException e) {
         this.plugin.getLogger().warning("Failed to get report statistics");
         this.plugin.getLogger().warning(e.getMessage());
         return new ReportStatistics(0, 0, 0, 0, new HashMap());
      }
   }

   public void openReportDetailGUI(Player staff, int reportId) {
      if (!staff.hasPermission("antisystem.staff.reports")) {
         staff.sendMessage("§cNo permission!");
      } else {
         Report report = this.getReportById(reportId);
         if (report == null) {
            staff.sendMessage("§cReport #" + reportId + " not found!");
         } else {
            Inventory gui = Bukkit.createInventory((InventoryHolder)null, 54, "§c§lReport #" + reportId + " Details");
            ItemStack reportInfo = new ItemStack(Material.PAPER);
            ItemMeta reportMeta = reportInfo.getItemMeta();
            reportMeta.setDisplayName("§6§lReport Information");
            reportMeta.setLore(Arrays.asList("§7Report ID: §e#" + report.getId(), "§7Reporter: §f" + report.getReporterName(), "§7Reported: §c" + report.getReportedName(), "§7Category: §e" + report.getCategory(), "§7Priority: " + report.getPriority().getDisplay(), "§7Status: §e" + report.getStatus(), "§7Submitted: §7" + this.getTimeAgo(report.getTimestamp()), "", "§7Reason: §f" + report.getReason()));
            reportInfo.setItemMeta(reportMeta);
            gui.setItem(13, reportInfo);
            ItemStack teleport = new ItemStack(Material.ENDER_PEARL);
            ItemMeta teleportMeta = teleport.getItemMeta();
            teleportMeta.setDisplayName("§b§lTeleport to Player");
            teleportMeta.setLore(Arrays.asList("§7Click to teleport to the reported player", "§7Target: §c" + report.getReportedName()));
            teleport.setItemMeta(teleportMeta);
            gui.setItem(20, teleport);
            ItemStack punish = new ItemStack(Material.IRON_SWORD);
            ItemMeta punishMeta = punish.getItemMeta();
            punishMeta.setDisplayName("§c§lPunish Player");
            punishMeta.setLore(Arrays.asList("§7Click to open punishment menu", "§7Target: §c" + report.getReportedName()));
            punish.setItemMeta(punishMeta);
            gui.setItem(21, punish);
            ItemStack resolve = new ItemStack(Material.EMERALD);
            ItemMeta resolveMeta = resolve.getItemMeta();
            resolveMeta.setDisplayName("§a§lResolve Report");
            resolveMeta.setLore(Arrays.asList("§7Click to mark this report as resolved", "§7This will close the report"));
            resolve.setItemMeta(resolveMeta);
            gui.setItem(22, resolve);
            ItemStack dismiss = new ItemStack(Material.REDSTONE);
            ItemMeta dismissMeta = dismiss.getItemMeta();
            dismissMeta.setDisplayName("§c§lDismiss Report");
            dismissMeta.setLore(Arrays.asList("§7Click to dismiss this report", "§7Use for false reports"));
            dismiss.setItemMeta(dismissMeta);
            gui.setItem(23, dismiss);
            ItemStack assign = new ItemStack(Material.NAME_TAG);
            ItemMeta assignMeta = assign.getItemMeta();
            assignMeta.setDisplayName("§e§lAssign to Me");
            assignMeta.setLore(Arrays.asList("§7Click to assign this report to yourself", "§7This will mark you as the handling staff"));
            assign.setItemMeta(assignMeta);
            gui.setItem(24, assign);
            ItemStack back = new ItemStack(Material.ARROW);
            ItemMeta backMeta = back.getItemMeta();
            backMeta.setDisplayName("§7« Back to Reports");
            back.setItemMeta(backMeta);
            gui.setItem(45, back);
            ItemStack close = new ItemStack(Material.BARRIER);
            ItemMeta closeMeta = close.getItemMeta();
            closeMeta.setDisplayName("§c§lClose");
            close.setItemMeta(closeMeta);
            gui.setItem(53, close);
            staff.openInventory(gui);
         }
      }
   }

   public void showReportStatisticsGUI(Player staff) {
      if (!staff.hasPermission("antisystem.staff.reports")) {
         staff.sendMessage("§cNo permission!");
      } else {
         ReportStatistics stats = this.getReportStatistics();
         Inventory gui = Bukkit.createInventory((InventoryHolder)null, 27, "§6§lReport Statistics");
         ItemStack total = new ItemStack(Material.BOOK);
         ItemMeta totalMeta = total.getItemMeta();
         totalMeta.setDisplayName("§6§lTotal Reports");
         totalMeta.setLore(Arrays.asList("§7Total reports submitted: §e" + stats.getTotalReports(), "§7All time report count"));
         total.setItemMeta(totalMeta);
         gui.setItem(10, total);
         ItemStack open = new ItemStack(VersionCompatibility.getWritableBookMaterial());
         ItemMeta openMeta = open.getItemMeta();
         openMeta.setDisplayName("§c§lOpen Reports");
         openMeta.setLore(Arrays.asList("§7Currently open reports: §c" + stats.getOpenReports(), "§7Reports waiting for staff action"));
         open.setItemMeta(openMeta);
         gui.setItem(12, open);
         ItemStack today = new ItemStack(VersionCompatibility.getClockMaterial());
         ItemMeta todayMeta = today.getItemMeta();
         todayMeta.setDisplayName("§e§lToday's Reports");
         todayMeta.setLore(Arrays.asList("§7Reports submitted today: §e" + stats.getReportsToday(), "§7Since midnight"));
         today.setItemMeta(todayMeta);
         gui.setItem(14, today);
         ItemStack resolved = new ItemStack(Material.EMERALD);
         ItemMeta resolvedMeta = resolved.getItemMeta();
         resolvedMeta.setDisplayName("§a§lResolved Reports");
         resolvedMeta.setLore(Arrays.asList("§7Total resolved reports: §a" + stats.getResolvedReports(), "§7Successfully handled reports"));
         resolved.setItemMeta(resolvedMeta);
         gui.setItem(16, resolved);
         ItemStack priority = new ItemStack(Material.COMPASS);
         ItemMeta priorityMeta = priority.getItemMeta();
         priorityMeta.setDisplayName("§b§lPriority Breakdown");
         ArrayList<String> priorityLore = new ArrayList();
         priorityLore.add("§7Reports by priority level:");

         for(ReportPriority p : ReportSystem.ReportPriority.values()) {
            int count = (Integer)stats.getPriorityStats().getOrDefault(p, 0);
            priorityLore.add(p.getDisplay() + "§7: §f" + count);
         }

         priorityMeta.setLore(priorityLore);
         priority.setItemMeta(priorityMeta);
         gui.setItem(22, priority);
         ItemStack close = new ItemStack(Material.BARRIER);
         ItemMeta closeMeta = close.getItemMeta();
         closeMeta.setDisplayName("§c§lClose");
         close.setItemMeta(closeMeta);
         gui.setItem(26, close);
         staff.openInventory(gui);
      }
   }

   public boolean resolveReport(int reportId, Player staff, String resolution) {
      try {
         PreparedStatement stmt = this.database.getConnection().prepareStatement("UPDATE player_reports SET status = 'RESOLVED', resolved_by = ?, resolution = ?, resolved_timestamp = ? WHERE id = ?");
         stmt.setString(1, staff.getUniqueId().toString());
         stmt.setString(2, resolution);
         stmt.setLong(3, System.currentTimeMillis());
         stmt.setInt(4, reportId);
         int result = stmt.executeUpdate();
         if (result > 0) {
            this.logReportAction(reportId, staff, "RESOLVED", resolution);
            return true;
         }
      } catch (SQLException e) {
         this.plugin.getLogger().warning("Failed to resolve report");
         this.plugin.getLogger().warning(e.getMessage());
      }

      return false;
   }

   public boolean dismissReport(int reportId, Player staff, String reason) {
      try {
         PreparedStatement stmt = this.database.getConnection().prepareStatement("UPDATE player_reports SET status = 'DISMISSED', resolved_by = ?, resolution = ?, resolved_timestamp = ? WHERE id = ?");
         stmt.setString(1, staff.getUniqueId().toString());
         stmt.setString(2, reason);
         stmt.setLong(3, System.currentTimeMillis());
         stmt.setInt(4, reportId);
         int result = stmt.executeUpdate();
         if (result > 0) {
            this.logReportAction(reportId, staff, "DISMISSED", reason);
            return true;
         }
      } catch (SQLException e) {
         this.plugin.getLogger().warning("Failed to dismiss report");
         this.plugin.getLogger().warning(e.getMessage());
      }

      return false;
   }

   public boolean assignReport(int reportId, Player staff) {
      try {
         PreparedStatement stmt = this.database.getConnection().prepareStatement("UPDATE player_reports SET assigned_staff = ? WHERE id = ?");
         stmt.setString(1, staff.getUniqueId().toString());
         stmt.setInt(2, reportId);
         int result = stmt.executeUpdate();
         if (result > 0) {
            this.logReportAction(reportId, staff, "ASSIGNED", "Report assigned to " + staff.getName());
            return true;
         }
      } catch (SQLException e) {
         this.plugin.getLogger().warning("Failed to assign report");
         this.plugin.getLogger().warning(e.getMessage());
      }

      return false;
   }

   private void logReportAction(int reportId, Player staff, String action, String details) {
      try {
         PreparedStatement stmt = this.database.getConnection().prepareStatement("INSERT INTO report_actions (report_id, staff_uuid, staff_name, action, details, timestamp) VALUES (?, ?, ?, ?, ?, ?)");
         stmt.setInt(1, reportId);
         stmt.setString(2, staff.getUniqueId().toString());
         stmt.setString(3, staff.getName());
         stmt.setString(4, action);
         stmt.setString(5, details);
         stmt.setLong(6, System.currentTimeMillis());
         stmt.executeUpdate();
      } catch (SQLException e) {
         this.plugin.getLogger().warning("Failed to log report action");
         this.plugin.getLogger().warning(e.getMessage());
      }

   }

   private String getTimeAgo(long timestamp) {
      long diff = System.currentTimeMillis() - timestamp;
      long minutes = diff / 60000L;
      long hours = minutes / 60L;
      long days = hours / 24L;
      if (days > 0L) {
         return days + " day" + (days == 1L ? "" : "s") + " ago";
      } else if (hours > 0L) {
         return hours + " hour" + (hours == 1L ? "" : "s") + " ago";
      } else {
         return minutes > 0L ? minutes + " minute" + (minutes == 1L ? "" : "s") + " ago" : "Just now";
      }
   }

   public static enum ReportPriority {
      LOW(1, "§7Low"),
      MEDIUM(2, "§eNormal"),
      HIGH(3, "§6High"),
      URGENT(4, "§cUrgent");

      private final int level;
      private final String display;

      private ReportPriority(int level, String display) {
         this.level = level;
         this.display = display;
      }

      public int getLevel() {
         return this.level;
      }

      public String getDisplay() {
         return this.display;
      }

      // $FF: synthetic method
      private static ReportPriority[] $values() {
         return new ReportPriority[]{LOW, MEDIUM, HIGH, URGENT};
      }
   }

   public static class Report {
      private final int id;
      private final String reporterName;
      private final String reportedName;
      private final String category;
      private final ReportPriority priority;
      private final String reason;
      private final long timestamp;
      private final String status;

      public Report(int id, String reporterName, String reportedName, String category, ReportPriority priority, String reason, long timestamp, String status) {
         this.id = id;
         this.reporterName = reporterName;
         this.reportedName = reportedName;
         this.category = category;
         this.priority = priority;
         this.reason = reason;
         this.timestamp = timestamp;
         this.status = status;
      }

      public int getId() {
         return this.id;
      }

      public String getReporterName() {
         return this.reporterName;
      }

      public String getReportedName() {
         return this.reportedName;
      }

      public String getCategory() {
         return this.category;
      }

      public ReportPriority getPriority() {
         return this.priority;
      }

      public String getReason() {
         return this.reason;
      }

      public long getTimestamp() {
         return this.timestamp;
      }

      public String getStatus() {
         return this.status;
      }
   }

   public static class ReportStatistics {
      private final int totalReports;
      private final int openReports;
      private final int reportsToday;
      private final int resolvedReports;
      private final Map<ReportPriority, Integer> priorityStats;

      public ReportStatistics(int totalReports, int openReports, int reportsToday, int resolvedReports, Map<ReportPriority, Integer> priorityStats) {
         this.totalReports = totalReports;
         this.openReports = openReports;
         this.reportsToday = reportsToday;
         this.resolvedReports = resolvedReports;
         this.priorityStats = priorityStats;
      }

      public int getTotalReports() {
         return this.totalReports;
      }

      public int getOpenReports() {
         return this.openReports;
      }

      public int getReportsToday() {
         return this.reportsToday;
      }

      public int getResolvedReports() {
         return this.resolvedReports;
      }

      public Map<ReportPriority, Integer> getPriorityStats() {
         return this.priorityStats;
      }
   }
}
