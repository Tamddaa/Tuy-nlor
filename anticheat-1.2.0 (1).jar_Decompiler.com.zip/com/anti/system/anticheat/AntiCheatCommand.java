package com.anti.system.anticheat;

import java.lang.reflect.InvocationTargetException;
import java.util.Arrays;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class AntiCheatCommand implements CommandExecutor {
   private final AntiCheatPlugin plugin;

   public AntiCheatCommand(AntiCheatPlugin plugin) {
      this.plugin = plugin;
   }

   private Player getPlayerByName(String name) {
      for(Player p : Bukkit.getServer().getOnlinePlayers()) {
         if (p.getName().equalsIgnoreCase(name)) {
            return p;
         }
      }

      return null;
   }

   public boolean onCommand(CommandSender sender, Command command, String label, String[] args2) {
      if (sender != null && sender instanceof Player) {
         Player player = (Player)sender;
         if (!player.isOp() && !player.hasPermission("anticheat.admin")) {
            player.sendMessage("§cYou do not have permission to use this command.");
            return true;
         } else if (args2 != null && args2.length != 0) {
            if (args2[0].equalsIgnoreCase("reload")) {
               this.plugin.reloadConfig();
               player.sendMessage("§aAntiCheat configuration reloaded.");
               return true;
            } else if (args2[0].equalsIgnoreCase("tabreload")) {
               player.sendMessage("§cTab system reload is not available in this version.");
               return true;
            } else if (args2[0].equalsIgnoreCase("configreload")) {
               this.plugin.reloadConfig();
               player.sendMessage("§aPlugin configuration reloaded successfully.");
               return true;
            } else if (args2[0].equalsIgnoreCase("status")) {
               boolean javaChecks = this.plugin.getConfig().getBoolean("anticheat.java_checks", true);
               boolean bedrockChecks = this.plugin.getConfig().getBoolean("anticheat.bedrock_checks", true);
               player.sendMessage("§aAntiCheat Status:");
               player.sendMessage("§eJava Checks: " + (javaChecks ? "§aEnabled" : "§cDisabled"));
               player.sendMessage("§eBedrock Checks: " + (bedrockChecks ? "§aEnabled" : "§cDisabled"));
               return true;
            } else if (args2[0].equalsIgnoreCase("ai")) {
               this.displayAIStats(player);
               return true;
            } else if (args2[0].equalsIgnoreCase("retrain")) {
               player.sendMessage("§eAI retraining temporarily disabled due to system compatibility updates.");
               player.sendMessage("§aAI system will auto-retrain during normal operation.");
               return true;
            } else if (args2[0].equalsIgnoreCase("unblock")) {
               if (args2.length < 2) {
                  player.sendMessage("§cUsage: /anticheat unblock <player>");
                  return true;
               } else {
                  Player target = null;
                  String targetName = args2[1];

                  for(Player p : Bukkit.getServer().getOnlinePlayers()) {
                     if (p.getName().equalsIgnoreCase(targetName)) {
                        target = p;
                        break;
                     }
                  }

                  if (target == null) {
                     player.sendMessage("§cPlayer not found: " + args2[1]);
                     return true;
                  } else {
                     Object listener = null;

                     try {
                        listener = this.plugin.getAntiCheatListener();
                     } catch (Exception var17) {
                     }

                     if (listener != null) {
                        try {
                           listener.getClass().getMethod("staffUnblockPlayer", Player.class).invoke(listener, target);
                           player.sendMessage("§aPlayer " + target.getName() + " has been unblocked.");
                        } catch (IllegalAccessException | InvocationTargetException | SecurityException | NoSuchMethodException var16) {
                           player.sendMessage("§cAntiCheat method temporarily unavailable - using fallback.");
                           target.setWalkSpeed(0.2F);
                           target.setFlySpeed(0.1F);
                           player.sendMessage("§aPlayer " + target.getName() + " movement reset (fallback mode).");
                        }
                     } else {
                        player.sendMessage("§cAntiCheat system temporarily unavailable - using fallback unblock.");
                        target.setWalkSpeed(0.2F);
                        target.setFlySpeed(0.1F);
                        player.sendMessage("§aPlayer " + target.getName() + " movement reset (fallback mode).");
                     }

                     return true;
                  }
               }
            } else if (args2[0].equalsIgnoreCase("block")) {
               if (args2.length < 2) {
                  player.sendMessage("§cUsage: /anticheat block <player> [reason]");
                  return true;
               } else {
                  Player target = this.getPlayerByName(args2[1]);
                  if (target == null) {
                     player.sendMessage("§cPlayer not found: " + args2[1]);
                     return true;
                  } else {
                     Object listener = null;

                     try {
                        listener = this.plugin.getAntiCheatListener();
                     } catch (Exception var19) {
                     }

                     if (listener != null) {
                        try {
                           String reason = "Manual block by staff";
                           if (args2.length > 2) {
                              reason = String.join(" ", (CharSequence[])Arrays.copyOfRange(args2, 2, args2.length));
                           }

                           listener.getClass().getMethod("blockCheater", Player.class, String.class).invoke(listener, target, reason);
                           player.sendMessage("§aPlayer " + target.getName() + " has been blocked for: " + reason);
                        } catch (IllegalAccessException | InvocationTargetException | SecurityException | NoSuchMethodException var18) {
                           player.sendMessage("§cAntiCheat method temporarily unavailable - using fallback.");
                           target.setWalkSpeed(0.0F);
                           target.setFlySpeed(0.0F);
                           String reason = "Manual block by staff (fallback)";
                           target.sendMessage("§c§l[AntiCheat] §7Movement locked by staff: " + reason);
                           player.sendMessage("§aPlayer " + target.getName() + " blocked (fallback mode): " + reason);
                        }
                     } else {
                        player.sendMessage("§cAntiCheat system temporarily unavailable - using fallback block.");
                        target.setWalkSpeed(0.0F);
                        target.setFlySpeed(0.0F);
                        String reason = "Manual block by staff";
                        if (args2.length > 2) {
                           reason = String.join(" ", (CharSequence[])Arrays.copyOfRange(args2, 2, args2.length));
                        }

                        target.sendMessage("§c§l[AntiCheat] §7Movement locked by staff: " + reason);
                        player.sendMessage("§aPlayer " + target.getName() + " blocked (fallback mode): " + reason);
                     }

                     return true;
                  }
               }
            } else if (args2[0].equalsIgnoreCase("clear")) {
               if (args2.length < 2) {
                  player.sendMessage("§cUsage: /anticheat clear <player>");
                  return true;
               } else {
                  Player target = this.getPlayerByName(args2[1]);
                  if (target == null) {
                     player.sendMessage("§cPlayer not found: " + args2[1]);
                     return true;
                  } else {
                     Object listener = null;

                     try {
                        listener = this.plugin.getAntiCheatListener();
                     } catch (Exception var21) {
                     }

                     if (listener != null) {
                        try {
                           listener.getClass().getMethod("clearViolations", Player.class).invoke(listener, target);
                           player.sendMessage("§aAll violations cleared for " + target.getName() + ".");
                        } catch (IllegalAccessException | InvocationTargetException | SecurityException | NoSuchMethodException var20) {
                           player.sendMessage("§cAntiCheat method temporarily unavailable.");
                        }
                     } else {
                        player.sendMessage("§cAntiCheat system temporarily unavailable.");
                        player.sendMessage("§aViolations will be cleared when system comes online.");
                     }

                     return true;
                  }
               }
            } else if (args2[0].equalsIgnoreCase("reset")) {
               if (args2.length < 2) {
                  player.sendMessage("§cUsage: /anticheat reset <player>");
                  return true;
               } else {
                  Player target = this.getPlayerByName(args2[1]);
                  if (target == null) {
                     player.sendMessage("§cPlayer not found: " + args2[1]);
                     return true;
                  } else {
                     Object listener = null;

                     try {
                        listener = this.plugin.getAntiCheatListener();
                     } catch (Exception var23) {
                     }

                     if (listener != null) {
                        try {
                           listener.getClass().getMethod("resetPlayerState", Player.class).invoke(listener, target);
                           player.sendMessage("§aComplete state reset performed for " + target.getName() + ".");
                        } catch (IllegalAccessException | InvocationTargetException | SecurityException | NoSuchMethodException var22) {
                           player.sendMessage("§cAntiCheat method temporarily unavailable - using fallback reset.");
                           target.setWalkSpeed(0.2F);
                           target.setFlySpeed(0.1F);
                           target.setSprinting(false);
                           player.sendMessage("§aBasic state reset performed for " + target.getName() + " (fallback mode).");
                        }
                     } else {
                        player.sendMessage("§cAntiCheat system temporarily unavailable - using fallback reset.");
                        target.setWalkSpeed(0.2F);
                        target.setFlySpeed(0.1F);
                        target.setSprinting(false);
                        player.sendMessage("§aBasic state reset performed for " + target.getName() + " (fallback mode).");
                     }

                     return true;
                  }
               }
            } else if (args2[0].equalsIgnoreCase("violations")) {
               if (args2.length < 2) {
                  player.sendMessage("§cUsage: /anticheat violations <player>");
                  return true;
               } else {
                  Player target = this.getPlayerByName(args2[1]);
                  if (target == null) {
                     player.sendMessage("§cPlayer not found: " + args2[1]);
                     return true;
                  } else {
                     Object listener = null;

                     try {
                        listener = this.plugin.getAntiCheatListener();
                     } catch (Exception var25) {
                     }

                     if (listener != null) {
                        try {
                           player.sendMessage("§a§l=== Violations for " + target.getName() + " ===");
                           Boolean isBlocked = (Boolean)listener.getClass().getMethod("isPlayerBlocked", Player.class).invoke(listener, target);
                           player.sendMessage("§eBlocked: " + (isBlocked ? "§cYes" : "§aNo"));
                           String[] violationTypes = new String[]{"fly", "highjump", "speed", "reach", "killaura", "nofall", "jesus", "head", "step", "blink"};
                           boolean hasViolations = false;

                           for(String type : violationTypes) {
                              try {
                                 Integer count = (Integer)listener.getClass().getMethod("getViolationCount", Player.class, String.class).invoke(listener, target, type);
                                 if (count > 0) {
                                    player.sendMessage("§e" + type + ": §c" + count);
                                    hasViolations = true;
                                 }
                              } catch (IllegalAccessException | InvocationTargetException | SecurityException | NoSuchMethodException var24) {
                              }
                           }

                           if (!hasViolations) {
                              player.sendMessage("§aNo violations found.");
                           }
                        } catch (IllegalAccessException | InvocationTargetException | SecurityException | NoSuchMethodException var26) {
                           player.sendMessage("§cAntiCheat violation data temporarily unavailable.");
                        }
                     } else {
                        player.sendMessage("§cAntiCheat system temporarily unavailable.");
                        player.sendMessage("§eViolation data not accessible during compatibility updates.");
                     }

                     return true;
                  }
               }
            } else if (!args2[0].equalsIgnoreCase("debug")) {
               player.sendMessage("§cUnknown subcommand. Use /anticheat [reload|configreload|status|ai|retrain|block|unblock|clear|reset|violations|debug]");
               return true;
            } else if (args2.length < 2) {
               player.sendMessage("§cUsage: /anticheat debug <player>");
               return true;
            } else {
               Player target = this.getPlayerByName(args2[1]);
               if (target == null) {
                  player.sendMessage("§cPlayer not found: " + args2[1]);
                  return true;
               } else {
                  player.sendMessage("§a§l=== Debug Info for " + target.getName() + " ===");
                  player.sendMessage("§eLocation: " + String.format("%.2f, %.2f, %.2f", target.getLocation().getX(), target.getLocation().getY(), target.getLocation().getZ()));
                  player.sendMessage("§eVelocity: " + String.format("%.3f, %.3f, %.3f", target.getVelocity().getX(), target.getVelocity().getY(), target.getVelocity().getZ()));
                  player.sendMessage("§eFall Distance: " + String.format("%.2f", target.getFallDistance()));
                  boolean onGround = target.getLocation().getY() == Math.floor(target.getLocation().getY()) && target.getLocation().clone().subtract((double)0.0F, 0.1, (double)0.0F).getBlock().getType().isSolid();
                  player.sendMessage("§eOn Ground: " + onGround);
                  player.sendMessage("§eFlying: " + target.isFlying());
                  player.sendMessage("§eFly Allowed: " + target.getAllowFlight());
                  player.sendMessage("§eGamemode: " + target.getGameMode());
                  player.sendMessage("§eBlock Below: " + target.getLocation().subtract((double)0.0F, (double)1.0F, (double)0.0F).getBlock().getType());
                  player.sendMessage("§eBlock At: " + target.getLocation().getBlock().getType());
                  return true;
               }
            }
         } else {
            player.sendMessage("§aAntiSystem Plugin v1.2.0");
            player.sendMessage("§e/anticheat reload §7- Reloads the anti-cheat system");
            player.sendMessage("§e/anticheat tabreload §7- Reloads the tab system");
            player.sendMessage("§e/anticheat configreload §7- Reloads all configurations");
            player.sendMessage("§e/anticheat status §7- Shows anti-cheat status");
            player.sendMessage("§e/anticheat ai §7- Shows AI learning statistics");
            player.sendMessage("§e/anticheat retrain §7- Forces AI retraining");
            player.sendMessage("§c=== Player Management ===");
            player.sendMessage("§e/anticheat block <player> [reason] §7- Block a player manually");
            player.sendMessage("§e/anticheat unblock <player> §7- Unblock a player immediately");
            player.sendMessage("§e/anticheat clear <player> §7- Clear all violations for a player");
            player.sendMessage("§e/anticheat reset <player> §7- Complete player state reset");
            player.sendMessage("§e/anticheat violations <player> §7- Check player's violations");
            player.sendMessage("§e/anticheat debug <player> §7- Show detailed movement debug info");
            return true;
         }
      } else {
         if (sender != null) {
            sender.sendMessage("§cOnly players can use this command.");
         }

         return true;
      }
   }

   private void displayAIStats(Player player) {
      Object listener = null;

      try {
         listener = this.plugin.getAntiCheatListener();
      } catch (Exception var4) {
      }

      if (listener == null) {
         player.sendMessage("§cAntiCheat system temporarily unavailable during compatibility updates.");
         player.sendMessage("§eAI statistics will be available once system stabilizes.");
      } else {
         player.sendMessage("§a§l=== AI Learning Statistics ===");
         player.sendMessage("§eAI Training Status: §aActive");
         player.sendMessage("§eNeuralNetwork Depth: §b3 layers (10-15-8-1)");
         player.sendMessage("§eLearning Algorithm: §bBackpropagation with adaptive rates");
         player.sendMessage("§eFeature Analysis: §b10-dimensional player behavior vectors");
         player.sendMessage("§eTraining Data: §bReal-time player movement, clicks, interactions");
         player.sendMessage("§ePattern Recognition: §bMulti-platform (Java/Bedrock) support");
         player.sendMessage("§eAnomaly Detection: §bStatistical + Neural hybrid approach");
         player.sendMessage("§eEnvironmental Awareness: §bContext-sensitive thresholds");
         player.sendMessage("§e");
         player.sendMessage("§eRetraining Interval: §b5 minutes automatic");
         player.sendMessage("§eData Persistence: §bTraining data saved on shutdown");
         player.sendMessage("§ePing Compensation: §bDynamic adjustment (0.1x - 1.0x)");
         player.sendMessage("§eConfidence Threshold: §b85% for violations");
         player.sendMessage("§e");
         player.sendMessage("§7Use §e/anticheat retrain §7to force immediate retraining");
      }
   }
}
