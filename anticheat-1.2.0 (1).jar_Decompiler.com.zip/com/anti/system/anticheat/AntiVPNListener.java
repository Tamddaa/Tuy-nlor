package com.anti.system.anticheat;

import com.anti.system.utils.SpamFreeLogger;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerPreLoginEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.AsyncPlayerPreLoginEvent.Result;
import org.bukkit.plugin.java.JavaPlugin;

public class AntiVPNListener implements Listener {
   private final JavaPlugin plugin;
   private final SpamFreeLogger spamFreeLogger;
   private final Map<String, Boolean> ipCache = new ConcurrentHashMap();
   private final Map<String, Long> cacheTime = new ConcurrentHashMap();
   private boolean enabled = true;
   private boolean blockVPNs = true;
   private boolean blockProxies = true;
   private boolean logDetections = true;
   private String kickMessage = "§cVPN/Proxy connections are not allowed on this server!";
   private long cacheExpiry = 3600000L;
   private final String[] vpnAPIs = new String[]{"http://ip-api.com/json/%s?fields=proxy", "https://vpnapi.io/api/%s?key=free", "http://check.getipintel.net/check.php?ip=%s&contact=admin@yourserver.com&format=json"};

   public AntiVPNListener(JavaPlugin plugin) {
      this.plugin = plugin;
      this.spamFreeLogger = new SpamFreeLogger(plugin);
      this.loadConfig();
   }

   private void loadConfig() {
      this.enabled = this.plugin.getConfig().getBoolean("antivpn.enabled", true);
      this.blockVPNs = this.plugin.getConfig().getBoolean("antivpn.block-vpns", true);
      this.blockProxies = this.plugin.getConfig().getBoolean("antivpn.block-proxies", true);
      this.logDetections = this.plugin.getConfig().getBoolean("antivpn.log-detections", true);
      this.kickMessage = this.plugin.getConfig().getString("antivpn.kick-message", "§cVPN/Proxy connections are not allowed on this server!");
      this.cacheExpiry = this.plugin.getConfig().getLong("antivpn.cache-expiry", 3600000L);
   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void onPlayerPreLogin(AsyncPlayerPreLoginEvent event) {
      if (this.enabled) {
         String ip = event.getAddress().getHostAddress();
         String playerName = event.getName();
         UUID playerUUID = event.getUniqueId();
         if (!this.isPrivateIP(ip)) {
            if (this.ipCache.containsKey(ip)) {
               Long cached = (Long)this.cacheTime.get(ip);
               if (cached != null && System.currentTimeMillis() - cached < this.cacheExpiry) {
                  Boolean isVPN = (Boolean)this.ipCache.get(ip);
                  if (Boolean.TRUE.equals(isVPN)) {
                     event.disallow(Result.KICK_OTHER, this.kickMessage);
                     if (this.logDetections) {
                        this.spamFreeLogger.warning("ANTI_VPN", "Blocked " + playerName + " (" + ip + ") - Cached VPN/Proxy detection");
                     }
                  }

                  return;
               }

               this.ipCache.remove(ip);
               this.cacheTime.remove(ip);
            }

            CompletableFuture.runAsync(() -> {
               boolean isVPN = this.checkVPNStatus(ip);
               this.ipCache.put(ip, isVPN);
               this.cacheTime.put(ip, System.currentTimeMillis());
               if (isVPN) {
                  this.plugin.getServer().getScheduler().runTask(this.plugin, () -> {
                     Player player = this.plugin.getServer().getPlayer(playerUUID);
                     if (player != null && player.isOnline()) {
                        player.kickPlayer(this.kickMessage);
                        if (this.logDetections) {
                           this.spamFreeLogger.warning("ANTI_VPN", "Kicked " + playerName + " (" + ip + ") - VPN/Proxy detected");
                        }
                     }

                  });
               }

            });
         }
      }
   }

   @EventHandler
   public void onPlayerJoin(PlayerJoinEvent event) {
      if (this.enabled) {
         Player player = event.getPlayer();
         String ip = player.getAddress().getAddress().getHostAddress();
         if (!this.isPrivateIP(ip)) {
            if (!player.hasPermission("antivpn.bypass")) {
               CompletableFuture.runAsync(() -> {
                  boolean isVPN = this.checkVPNStatus(ip);
                  if (isVPN) {
                     this.plugin.getServer().getScheduler().runTask(this.plugin, () -> {
                        if (player.isOnline()) {
                           player.kickPlayer(this.kickMessage);
                           if (this.logDetections) {
                              this.spamFreeLogger.warning("ANTI_VPN", "Secondary check: Kicked " + player.getName() + " (" + ip + ") - VPN/Proxy detected");
                           }
                        }

                     });
                  }

               });
            }

         }
      }
   }

   private boolean checkVPNStatus(String ip) {
      if (!this.blockVPNs && !this.blockProxies) {
         return false;
      } else {
         for(String apiUrl : this.vpnAPIs) {
            try {
               String url = String.format(apiUrl, ip);
               String response = this.makeHTTPRequest(url);
               if (response != null && this.parseVPNResponse(response, apiUrl)) {
                  return true;
               }
            } catch (Exception var8) {
            }
         }

         return false;
      }
   }

   private String makeHTTPRequest(String urlString) {
      try {
         URL url = URI.create(urlString).toURL();
         HttpURLConnection conn = (HttpURLConnection)url.openConnection();
         conn.setRequestMethod("GET");
         conn.setConnectTimeout(5000);
         conn.setReadTimeout(5000);
         conn.setRequestProperty("User-Agent", "AntiVPN-Plugin/1.0");
         int responseCode = conn.getResponseCode();
         if (responseCode == 200) {
            BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));

            String var8;
            try {
               StringBuilder response = new StringBuilder();

               String line;
               while((line = reader.readLine()) != null) {
                  response.append(line);
               }

               var8 = response.toString();
            } catch (Throwable var10) {
               try {
                  reader.close();
               } catch (Throwable var9) {
                  var10.addSuppressed(var9);
               }

               throw var10;
            }

            reader.close();
            return var8;
         }
      } catch (IllegalArgumentException | IOException var11) {
      }

      return null;
   }

   private boolean parseVPNResponse(String response, String apiUrl) {
      if (response != null && !response.isEmpty()) {
         response = response.toLowerCase();
         boolean isVPN = false;
         boolean isProxy = false;
         if (apiUrl.contains("ip-api.com")) {
            isProxy = response.contains("\"proxy\":true") || response.contains("\"proxy\": true");
         } else if (apiUrl.contains("vpnapi.io")) {
            isVPN = response.contains("\"vpn\":true") || response.contains("\"vpn\": true");
            isProxy = response.contains("\"proxy\":true") || response.contains("\"proxy\": true");
         } else if (apiUrl.contains("getipintel.net")) {
            try {
               double score = Double.parseDouble(response.trim());
               isVPN = score > 0.95;
            } catch (NumberFormatException var7) {
               return false;
            }
         } else {
            isVPN = response.contains("vpn");
            isProxy = response.contains("proxy") || response.contains("\"risk\":\"high\"") || response.contains("\"threat\":true");
         }

         return this.blockVPNs && isVPN || this.blockProxies && isProxy;
      } else {
         return false;
      }
   }

   private boolean isPrivateIP(String ip) {
      if (ip == null) {
         return true;
      } else if (!ip.equals("127.0.0.1") && !ip.equals("::1") && !ip.equals("localhost")) {
         return ip.startsWith("192.168.") || ip.startsWith("10.") || ip.startsWith("172.") && this.isPrivate172(ip);
      } else {
         return true;
      }
   }

   private boolean isPrivate172(String ip) {
      String[] parts = ip.split("\\.");
      if (parts.length < 2) {
         return false;
      } else {
         try {
            int second = Integer.parseInt(parts[1]);
            return second >= 16 && second <= 31;
         } catch (NumberFormatException var4) {
            return false;
         }
      }
   }

   public void reloadConfig() {
      this.loadConfig();
      this.spamFreeLogger.info("ANTI_VPN", "Configuration reloaded");
   }

   public boolean checkIP(String ip) {
      return this.isPrivateIP(ip) ? false : this.checkVPNStatus(ip);
   }

   public void clearCache() {
      this.ipCache.clear();
      this.cacheTime.clear();
      this.spamFreeLogger.info("ANTI_VPN", "IP cache cleared");
   }

   public Map<String, Object> getCacheStats() {
      HashMap<String, Object> stats = new HashMap();
      stats.put("cached_ips", this.ipCache.size());
      stats.put("vpn_ips", this.ipCache.values().stream().mapToInt((b) -> b ? 1 : 0).sum());
      stats.put("clean_ips", this.ipCache.values().stream().mapToInt((b) -> b ? 0 : 1).sum());
      return stats;
   }
}
