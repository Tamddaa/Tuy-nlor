package com.anti.system.anticheat;

import com.anti.system.utils.VersionCompatibility;
import com.anti.system.utils.VersionUtils;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerToggleFlightEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;

public class FlightBlocker implements Listener {
   private final Map<UUID, Long> lastAlertTime = new HashMap();
   private final JavaPlugin plugin;
   private final AnomalyDetector detector = new AnomalyDetector();
   private final Map<UUID, FlightProfile> playerProfiles = new HashMap();
   private final Map<UUID, Long> flightWhitelist = new HashMap();
   private static final double MAX_Y_VELOCITY = 0.65;
   private static final int AIR_TIME_THRESHOLD = 120;
   private static final int FLIGHT_VIOLATIONS_LIMIT = 25;

   public FlightBlocker(JavaPlugin plugin) {
      this.plugin = plugin;
   }

   @EventHandler(
      priority = EventPriority.HIGH
   )
   public void onPlayerMove(PlayerMoveEvent event) {
      Player player = event.getPlayer();
      if (!player.hasPermission("antisystem.bypass.flight")) {
         if (player.getGameMode() != GameMode.CREATIVE || !player.hasPermission("antisystem.allow.creative.flight")) {
            if (player.getGameMode() != GameMode.SPECTATOR || !player.hasPermission("antisystem.allow.spectator")) {
               if (!VersionUtils.supportsFeature("elytra") || !VersionUtils.isGliding(player)) {
                  if (!VersionUtils.supportsFeature("swimming") || !VersionUtils.isSwimming(player)) {
                     if (!this.isFlightAllowed(player)) {
                        if (!player.getAllowFlight() || !player.hasPermission("antisystem.allow.server.flight")) {
                           Location from = event.getFrom();
                           Location to = event.getTo();
                           if (to != null) {
                              FlightProfile profile = (FlightProfile)this.playerProfiles.computeIfAbsent(player.getUniqueId(), (uuid) -> new FlightProfile());
                              this.updateFlightProfile(profile, from, to);
                              if (this.detectFlight(player, profile, from)) {
                                 this.handleFlightViolation(player, profile, event);
                              }

                           }
                        }
                     }
                  }
               }
            }
         }
      }
   }

   @EventHandler(
      priority = EventPriority.HIGH
   )
   public void onPlayerToggleFlight(PlayerToggleFlightEvent event) {
      Player player = event.getPlayer();
      if (!player.hasPermission("antisystem.bypass.flight")) {
         if (player.getGameMode() != GameMode.CREATIVE || !player.hasPermission("antisystem.allow.creative.flight")) {
            if (player.getGameMode() != GameMode.SPECTATOR || !player.hasPermission("antisystem.allow.spectator")) {
               if (!this.isFlightAllowed(player)) {
                  if (event.isFlying() && !player.getAllowFlight()) {
                     event.setCancelled(true);
                     FlightProfile profile = (FlightProfile)this.playerProfiles.computeIfAbsent(player.getUniqueId(), (uuid) -> new FlightProfile());
                     ++profile.flightToggleViolations;
                     if (profile.flightToggleViolations >= 3) {
                        this.handleFlightViolation(player, profile, (PlayerMoveEvent)null);
                     }
                  }

               }
            }
         }
      }
   }

   private void updateFlightProfile(FlightProfile profile, Location from, Location to) {
      profile.lastLocation = from;
      Vector movement = to.toVector().subtract(from.toVector());
      profile.horizontalSpeed = Math.sqrt(movement.getX() * movement.getX() + movement.getZ() * movement.getZ());
      profile.verticalSpeed = movement.getY();
      boolean onGround = this.isOnGround(to);
      profile.airTime = onGround ? 0 : ++profile.airTime;
      if (profile.lastVerticalSpeed != (double)0.0F) {
         profile.velocityChanges.add(profile.verticalSpeed - profile.lastVerticalSpeed);
         if (profile.velocityChanges.size() > 10) {
            profile.velocityChanges.remove(0);
         }
      }

      profile.lastVerticalSpeed = profile.verticalSpeed;
      if (profile.horizontalSpeed > profile.maxHorizontalSpeed) {
         profile.maxHorizontalSpeed = profile.horizontalSpeed;
      }

      if (Math.abs(profile.verticalSpeed) > Math.abs(profile.maxVerticalSpeed)) {
         profile.maxVerticalSpeed = profile.verticalSpeed;
      }

   }

   private boolean detectFlight(Player player, FlightProfile profile, Location from) {
      if (profile.lastLocation != null && !(from.distance(profile.lastLocation) > (double)10.0F)) {
         if (profile.airTime < 10) {
            return false;
         } else if (profile.airTime < 15 && Math.abs(profile.verticalSpeed - 0.42) < 0.05) {
            return false;
         } else {
            boolean violation = false;
            String reason = "";
            double confidence = (double)0.0F;
            if (profile.airTime > 120 && Math.abs(profile.verticalSpeed) < 0.01 && !this.hasLevitation(player)) {
               confidence = this.detector.getConfidence("flight_air_time", (double)profile.airTime);
               if (this.detector.isAnomalous("flight_air_time", (double)profile.airTime) && confidence > 0.95) {
                  violation = true;
                  reason = "Hovering";
               }
            }

            if (!violation && profile.verticalSpeed > 0.65 && profile.airTime > 10 && !this.hasJumpBoost(player)) {
               confidence = this.detector.getConfidence("flight_vertical_speed", profile.verticalSpeed);
               if (this.detector.isAnomalous("flight_vertical_speed", profile.verticalSpeed) && confidence > 0.95) {
                  violation = true;
                  reason = "Unnatural upward movement";
               }
            }

            if (!violation && profile.airTime > 20 && profile.verticalSpeed >= (double)0.0F && !this.hasLevitation(player)) {
               confidence = this.detector.getConfidence("flight_air_time", (double)profile.airTime);
               if (this.detector.isAnomalous("flight_air_time", (double)profile.airTime) && confidence > 0.95) {
                  violation = true;
                  reason = "No gravity";
               }
            }

            if (!violation && profile.velocityChanges.size() >= 5) {
               double totalChange = (double)0.0F;

               for(double change : profile.velocityChanges) {
                  totalChange += Math.abs(change);
               }

               if (totalChange > (double)2.0F && profile.airTime > 15) {
                  confidence = this.detector.getConfidence("flight_direction_change", totalChange);
                  if (this.detector.isAnomalous("flight_direction_change", totalChange) && confidence > 0.95) {
                     violation = true;
                     reason = "Rapid direction changes";
                  }
               }
            }

            if (!violation && profile.horizontalSpeed > 0.7 && profile.airTime > 20 && !this.hasSpeedBoost(player)) {
               confidence = this.detector.getConfidence("flight_horizontal_speed", profile.horizontalSpeed);
               if (this.detector.isAnomalous("flight_horizontal_speed", profile.horizontalSpeed) && confidence > 0.95) {
                  violation = true;
                  reason = "Excessive horizontal speed";
               }
            }

            this.detector.record("flight_horizontal_speed", profile.horizontalSpeed);
            this.detector.record("flight_vertical_speed", Math.abs(profile.verticalSpeed));
            this.detector.record("flight_air_time", (double)profile.airTime);
            if (profile.velocityChanges.size() >= 5) {
               double totalChange = (double)0.0F;

               for(double change : profile.velocityChanges) {
                  totalChange += Math.abs(change);
               }

               this.detector.record("flight_direction_change", totalChange);
            }

            if (violation) {
               ++profile.violations;
               profile.lastViolationReason = reason;
               PlayerBehaviorLogger.log(player, "Flight", reason + " (Airtime: " + profile.airTime + ", VSpeed: " + String.format("%.3f", profile.verticalSpeed) + ", Confidence: " + String.format("%.2f", confidence) + ")");
            } else if (profile.violations > 0) {
               profile.violations = Math.max(0, profile.violations - 1);
            }

            return violation && profile.violations >= 25;
         }
      } else {
         return false;
      }
   }

   private void handleFlightViolation(Player player, FlightProfile profile, PlayerMoveEvent event) {
      Location safe;
      Location last2;
      if (event != null && profile.lastLocation != null && !(last2 = profile.lastLocation.clone()).clone().subtract((double)0.0F, 0.1, (double)0.0F).getBlock().getType().isSolid() && (safe = this.findHighestSafeLocation(last2)) != null && safe.getBlockY() > 0) {
         event.setTo(safe);
      }

      if (player.isFlying()) {
         player.setFlying(false);
      }

      if (player.getAllowFlight() && player.getGameMode() != GameMode.CREATIVE) {
         player.setAllowFlight(false);
      }

      long lastAlert = (Long)this.lastAlertTime.getOrDefault(player.getUniqueId(), 0L);
      long now;
      if ((now = System.currentTimeMillis()) - lastAlert > 10000L) {
         this.lastAlertTime.put(player.getUniqueId(), now);
         String message = String.format("§c[AntiCheat] §7%s §cfailed Flight §7(%s) §c[VL: %d]", player.getName(), profile.lastViolationReason, profile.violations);
         Bukkit.getOnlinePlayers().stream().filter((p) -> p.hasPermission("antisystem.alerts") && !p.equals(player)).forEach((p) -> p.sendMessage(message));
         this.plugin.getLogger().warning(String.format("[AntiCheat] %s failed Flight (%s) [VL: %d]", player.getName(), profile.lastViolationReason, profile.violations));
      }

      if (profile.violations >= 50) {
         this.plugin.getServer().getScheduler().runTask(this.plugin, () -> Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "kick " + player.getName() + " Flight hacks detected"));
      }

      profile.violations = Math.max(0, profile.violations - 2);
   }

   private boolean isOnGround(Location location) {
      Block below = location.clone().subtract((double)0.0F, 0.1, (double)0.0F).getBlock();
      if (below.getType().isSolid()) {
         return true;
      } else {
         Material material = location.getBlock().getType();
         if (material != Material.WATER && material != Material.LADDER && material != Material.VINE && !material.name().contains("SCAFFOLDING")) {
            String blockName = below.getType().name();
            return blockName.contains("SLAB") || blockName.contains("STAIR") || blockName.contains("CARPET") || blockName.contains("SNOW");
         } else {
            return true;
         }
      }
   }

   private Location findHighestSafeLocation(Location base) {
      Location highest = base.getWorld().getHighestBlockAt(base).getLocation().add((double)0.5F, (double)1.0F, (double)0.5F);
      if (highest.getBlock().getType() == Material.AIR && highest.clone().add((double)0.0F, (double)1.0F, (double)0.0F).getBlock().getType() == Material.AIR) {
         return highest;
      } else {
         Location spawn = base.getWorld().getSpawnLocation().add((double)0.5F, (double)1.0F, (double)0.5F);
         return spawn.getBlock().getType() == Material.AIR ? spawn : base;
      }
   }

   private boolean hasLevitation(Player player) {
      PotionEffectType levitation = VersionCompatibility.getLevitationEffect();
      return levitation == null ? false : player.hasPotionEffect(levitation);
   }

   private boolean hasJumpBoost(Player player) {
      return player.hasPotionEffect(VersionCompatibility.getJumpBoostEffect());
   }

   private boolean hasSpeedBoost(Player player) {
      return player.hasPotionEffect(PotionEffectType.SPEED);
   }

   public void allowFlight(Player player, long durationMs) {
      this.flightWhitelist.put(player.getUniqueId(), System.currentTimeMillis() + durationMs);
   }

   public void disallowFlight(Player player) {
      this.flightWhitelist.remove(player.getUniqueId());
   }

   public boolean isFlightAllowed(Player player) {
      Long expiry = (Long)this.flightWhitelist.get(player.getUniqueId());
      if (expiry == null) {
         return false;
      } else if (System.currentTimeMillis() > expiry) {
         this.flightWhitelist.remove(player.getUniqueId());
         return false;
      } else {
         return true;
      }
   }

   @EventHandler
   public void onPlayerQuit(PlayerQuitEvent event) {
      Player player = event.getPlayer();
      this.playerProfiles.remove(player.getUniqueId());
      this.flightWhitelist.remove(player.getUniqueId());
   }

   private static class FlightProfile {
      Location lastLocation;
      double horizontalSpeed;
      double verticalSpeed;
      double lastVerticalSpeed;
      double maxHorizontalSpeed;
      double maxVerticalSpeed;
      int airTime;
      int violations;
      int flightToggleViolations;
      String lastViolationReason;
      List<Double> velocityChanges;

      private FlightProfile() {
         this.lastViolationReason = "";
         this.velocityChanges = new ArrayList();
      }
   }
}
