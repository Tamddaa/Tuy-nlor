package com.anti.system.anticheat;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class AnomalyDetector {
   private final Map<String, Stats> statsMap = new ConcurrentHashMap();
   private final Map<String, Long> lastUpdateTime = new ConcurrentHashMap();
   private static final int MIN_SAMPLES_FOR_DETECTION = 25;
   private static final double MIN_STD_THRESHOLD = 0.03;
   private static final double ANOMALY_MULTIPLIER = 2.2;
   private static final long STATS_DECAY_TIME = 600000L;

   public synchronized void record(String action, double value) {
      try {
         if (action == null || Double.isNaN(value) || Double.isInfinite(value)) {
            return;
         }

         long currentTime = System.currentTimeMillis();
         Long lastUpdate = (Long)this.lastUpdateTime.get(action);
         Stats stats;
         if (lastUpdate != null && currentTime - lastUpdate > 600000L && (stats = (Stats)this.statsMap.get(action)) != null && stats.count > 25) {
            stats.decay(0.1);
         }

         ((Stats)this.statsMap.computeIfAbsent(action, (k) -> new Stats())).add(value);
         this.lastUpdateTime.put(action, currentTime);
      } catch (Exception var8) {
      }

   }

   public synchronized boolean isAnomalous(String action, double value) {
      try {
         if (action != null && !Double.isNaN(value) && !Double.isInfinite(value)) {
            Stats stats = (Stats)this.statsMap.get(action);
            if (stats != null && stats.count >= 25) {
               double mean = stats.sum / (double)stats.count;
               double variance = stats.sumSq / (double)stats.count - mean * mean;
               double std = Math.sqrt(Math.max((double)0.0F, variance));
               double recentMean = stats.recentCount > 0 ? stats.recentSum / (double)stats.recentCount : mean;
               double recentVariance = stats.recentCount > 0 ? stats.recentSumSq / (double)stats.recentCount - recentMean * recentMean : variance;
               double recentStd = Math.sqrt(Math.max((double)0.0F, recentVariance));
               if (std < 0.03) {
                  return false;
               } else {
                  double deviation = Math.abs(value - mean);
                  double threshold = 2.2 * std;
                  double recentDeviation = Math.abs(value - recentMean);
                  double recentThreshold = 2.2 * Math.max(recentStd, 0.03);
                  boolean isExtreme = deviation > threshold;
                  boolean isRecentlyExtreme = recentDeviation > recentThreshold;
                  boolean hasRecentHistory = stats.count > 75;
                  boolean isConsistentAnomaly = deviation > 4.2 * std;
                  double confidence = this.getConfidence(action, value);
                  return isExtreme && isRecentlyExtreme && hasRecentHistory && isConsistentAnomaly && confidence > 0.95;
               }
            } else {
               return false;
            }
         } else {
            return false;
         }
      } catch (Exception var31) {
         return false;
      }
   }

   public double getConfidence(String action, double value) {
      Stats stats = (Stats)this.statsMap.get(action);
      if (stats != null && stats.count >= 25) {
         double mean = stats.sum / (double)stats.count;
         double std = Math.sqrt(stats.sumSq / (double)stats.count - mean * mean);
         if (std < 0.03) {
            return (double)0.0F;
         } else {
            double deviation = Math.abs(value - mean);
            double normalizedDeviation = deviation / (2.2 * std);
            return Math.min((double)1.0F, Math.max((double)0.0F, normalizedDeviation - (double)1.0F));
         }
      } else {
         return (double)0.0F;
      }
   }

   private static class Stats {
      double sum;
      double sumSq;
      int count;
      double recentSum;
      double recentSumSq;
      int recentCount;

      private Stats() {
         this.sum = (double)0.0F;
         this.sumSq = (double)0.0F;
         this.count = 0;
         this.recentSum = (double)0.0F;
         this.recentSumSq = (double)0.0F;
         this.recentCount = 0;
      }

      void add(double v) {
         this.sum += v;
         this.sumSq += v * v;
         ++this.count;
         this.recentSum += v;
         this.recentSumSq += v * v;
         ++this.recentCount;
         if (this.recentCount > 50) {
            double oldMean = this.recentSum / (double)this.recentCount;
            this.recentSum -= oldMean;
            this.recentSumSq -= oldMean * oldMean;
            --this.recentCount;
         }

      }

      void decay(double factor) {
         this.sum *= (double)1.0F - factor;
         this.sumSq *= (double)1.0F - factor;
         this.count = (int)((double)this.count * ((double)1.0F - factor));
         this.recentSum *= (double)1.0F - factor;
         this.recentSumSq *= (double)1.0F - factor;
         this.recentCount = (int)((double)this.recentCount * ((double)1.0F - factor));
      }
   }
}
