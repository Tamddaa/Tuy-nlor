package com.anti.system.anticheat;

import com.anti.system.utils.VersionCompatibility;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class AntiCheatGUINew implements Listener {
   private final AntiCheatPlugin plugin;
   private final CheckManager checkManager;
   private final Map<Player, String> playerCurrentPage = new HashMap();

   public AntiCheatGUINew(AntiCheatPlugin plugin, CheckManager checkManager) {
      this.plugin = plugin;
      this.checkManager = checkManager;
   }

   public void openMainGUI(Player player) {
      this.playerCurrentPage.put(player, "main");
      Inventory gui = Bukkit.createInventory((InventoryHolder)null, 54, "§4§lAntiCheat Control Hub");
      gui.setItem(4, this.createItem(Material.DIAMOND, "§6§lAntiSystem AntiCheat", Arrays.asList("§7System: §aOnline & Active", "§7Version: §f1.2.0 Professional", "§7Protection Level: §cMaximum", "§7Active Checks: §f" + this.getActiveChecksCount(), "§7Online Players: §f" + Bukkit.getOnlinePlayers().size(), "", "§8§l» §dSuperior to GrimAC & Vulcan §8§l«")));
      gui.setItem(10, this.createItem(Material.IRON_SWORD, "§c§lCombat Detection", Arrays.asList("§7Manage all combat-related checks", "§8• §fReach Detection", "§8• §fKillAura Detection", "§8• §fCriticals Detection", "§8• §fHitbox Detection", "§8• §fAnti-Velocity Detection", "", "§a§l▶ Click to open Combat page")));
      gui.setItem(12, this.createItem(Material.FEATHER, "§b§lMovement Detection", Arrays.asList("§7Manage all movement-related checks", "§8• §fFly Detection", "§8• §fSpeed Detection", "§8• §fJesus Detection", "§8• §fNoFall Detection", "§8• §fPhase Detection", "", "§a§l▶ Click to open Movement page")));
      gui.setItem(14, this.createItem(Material.REDSTONE, "§e§lPvP Exploits", Arrays.asList("§7Manage advanced PvP exploit detection", "§8• §fCrystal Aura Detection", "§8• §fAnchor Aura Detection", "§8• §fBed Aura Detection", "§8• §fAuto Totem Detection", "§8• §fTrigger Bot Detection", "", "§a§l▶ Click to open PvP page")));
      gui.setItem(16, this.createItem(Material.CHEST, "§d§lWorld Interaction", Arrays.asList("§7Manage world interaction checks", "§8• §fFast Break Detection", "§8• §fFast Place Detection", "§8• §fScaffold Detection", "§8• §fNuker Detection", "§8• §fAir Place Detection", "", "§a§l▶ Click to open World page")));
      gui.setItem(19, this.createItem(Material.COMMAND, "§6§lSystem Settings", Arrays.asList("§7Global anti-cheat configuration", "§8• §fThreshold Management", "§8• §fPlatform Settings", "§8• §fBypass Management", "§8• §fNotification Settings", "", "§a§l▶ Click to open Settings page")));
      gui.setItem(21, this.createItem(Material.BOOK, "§3§lPlayer Reports", Arrays.asList("§7View and manage player violations", "§8• §fViolation History", "§8• §fActive Flags", "§8• §fPlayer Statistics", "§8• §fBan Management", "", "§a§l▶ Click to open Reports page")));
      gui.setItem(23, this.createItem(Material.WATCH, "§5§lReal-Time Monitor", Arrays.asList("§7Live monitoring and statistics", "§8• §fActive Detections", "§8• §fPerformance Metrics", "§8• §fConsole Output", "§8• §fAI Learning Status", "", "§a§l▶ Click to open Monitor page")));
      gui.setItem(25, this.createItem(Material.EMERALD, "§2§lAI & Machine Learning", Arrays.asList("§7Advanced AI detection systems", "§8• §fAI Training Status", "§8• §fAnomaly Detection", "§8• §fPattern Analysis", "§8• §fAdaptive Thresholds", "", "§a§l▶ Click to open AI page")));
      gui.setItem(45, this.createItem(Material.INK_SACK, "§c§lEmergency Stop", Arrays.asList("§7Disable all anti-cheat checks", "§c§lWARNING: This will stop all protection!", "", "§c§l▶ Click to disable AntiCheat")));
      gui.setItem(49, this.createItem(Material.COMPASS, "§f§lNavigation Help", Arrays.asList("§7Use this GUI to manage all aspects", "§7of the AntiCheat system.", "", "§8• §fEach page contains specific controls", "§8• §fChanges are applied instantly", "§8• §fUse §7/anticheat gui §8to reopen", "", "§a§lCurrent Page: §fMain Hub")));
      gui.setItem(53, this.createItem(Material.INK_SACK, "§a§lReload Config", Arrays.asList("§7Reload anti-cheat configuration", "§8• §fRefresh all settings", "§8• §fApply new thresholds", "", "§a§l▶ Click to reload config")));
      player.openInventory(gui);
   }

   public void openCombatPage(Player player) {
      this.playerCurrentPage.put(player, "combat");
      Inventory gui = Bukkit.createInventory((InventoryHolder)null, 54, "§c§lCombat Detection Controls");
      gui.setItem(0, this.createItem(Material.ARROW, "§f§l← Back to Main Hub", Arrays.asList("§7Return to main menu")));
      gui.setItem(10, this.createToggleItem(Material.IRON_SWORD, "§c§lReach Detection", this.checkManager.isEnabled("reach"), Arrays.asList("§7Prevents players from hitting beyond normal reach", "§8• §fVanilla limit: 3.0 blocks", "§8• §fPing compensation included", "§7Current: " + (this.checkManager.isEnabled("reach") ? "§aEnabled" : "§cDisabled"), "", "§e§l▶ Click to toggle")));
      gui.setItem(11, this.createToggleItem(Material.DIAMOND_SWORD, "§c§lKillAura Detection", this.checkManager.isEnabled("killaura"), Arrays.asList("§7Detects automated combat assistance", "§8• §fMulti-target detection", "§8• §fAngle-based analysis", "§7Current: " + (this.checkManager.isEnabled("killaura") ? "§aEnabled" : "§cDisabled"), "", "§e§l▶ Click to toggle")));
      gui.setItem(12, this.createToggleItem(Material.GOLD_SWORD, "§c§lCriticals Detection", this.checkManager.isEnabled("criticals"), Arrays.asList("§7Prevents fake critical hits", "§8• §fRequires proper fall/jump", "§8• §fStrict validation", "§7Current: " + (this.checkManager.isEnabled("criticals") ? "§aEnabled" : "§cDisabled"), "", "§e§l▶ Click to toggle")));
      gui.setItem(13, this.createToggleItem(Material.WOOD_DOOR, "§c§lAnti-Velocity Detection", this.checkManager.isEnabled("antivelocity"), Arrays.asList("§7Detects knockback resistance cheats", "§8• §fMonitors velocity changes", "§8• §fValidates knockback physics", "§7Current: " + (this.checkManager.isEnabled("antivelocity") ? "§aEnabled" : "§cDisabled"), "", "§e§l▶ Click to toggle")));
      gui.setItem(14, this.createToggleItem(Material.BOW, "§c§lAimbot Detection", this.checkManager.isEnabled("aimbot"), Arrays.asList("§7Detects automated aiming assistance", "§8• §fRotation analysis", "§8• §fUnnatural movement patterns", "§7Current: " + (this.checkManager.isEnabled("aimbot") ? "§aEnabled" : "§cDisabled"), "", "§e§l▶ Click to toggle")));
      gui.setItem(15, this.createToggleItem(Material.BOW, "§c§lTrigger Bot Detection", this.checkManager.isEnabled("triggerbot"), Arrays.asList("§7Detects automated clicking/attacking", "§8• §fTiming analysis", "§8• §fRapid click detection", "§7Current: " + (this.checkManager.isEnabled("triggerbot") ? "§aEnabled" : "§cDisabled"), "", "§e§l▶ Click to toggle")));
      gui.setItem(16, this.createToggleItem(Material.FISHING_ROD, "§c§lHitbox Detection", this.checkManager.isEnabled("hitbox"), Arrays.asList("§7Prevents hitbox expansion cheats", "§8• §fValidates hit registration", "§8• §fStrict hitbox bounds", "§7Current: " + (this.checkManager.isEnabled("hitbox") ? "§aEnabled" : "§cDisabled"), "", "§e§l▶ Click to toggle")));
      player.openInventory(gui);
   }

   public void openMovementPage(Player player) {
      this.playerCurrentPage.put(player, "movement");
      Inventory gui = Bukkit.createInventory((InventoryHolder)null, 54, "§b§lMovement Detection Controls");
      gui.setItem(0, this.createItem(Material.ARROW, "§f§l← Back to Main Hub", Arrays.asList("§7Return to main menu")));
      gui.setItem(10, this.createToggleItem(Material.FEATHER, "§b§lFly Detection", this.checkManager.isEnabled("fly"), Arrays.asList("§7Prevents unauthorized flight", "§8• §fCreative mode exempt", "§8• §fElytra validation included", "§7Current: " + (this.checkManager.isEnabled("fly") ? "§aEnabled" : "§cDisabled"), "", "§e§l▶ Click to toggle")));
      gui.setItem(11, this.createToggleItem(Material.SUGAR, "§b§lSpeed Detection", this.checkManager.isEnabled("speed"), Arrays.asList("§7Prevents movement speed cheats", "§8• §fPing compensation", "§8• §fPotions effects considered", "§7Current: " + (this.checkManager.isEnabled("speed") ? "§aEnabled" : "§cDisabled"), "", "§e§l▶ Click to toggle")));
      gui.setItem(12, this.createToggleItem(Material.WATER_BUCKET, "§b§lJesus Detection", this.checkManager.isEnabled("jesus"), Arrays.asList("§7Prevents water/lava walking", "§8• §fLiquid movement validation", "§8• §fBoat/swimming exempt", "§7Current: " + (this.checkManager.isEnabled("jesus") ? "§aEnabled" : "§cDisabled"), "", "§e§l▶ Click to toggle")));
      gui.setItem(13, this.createToggleItem(Material.FEATHER, "§b§lNoFall Detection", this.checkManager.isEnabled("nofall"), Arrays.asList("§7Prevents fall damage bypass", "§8• §fFall distance tracking", "§8• §fDamage validation", "§7Current: " + (this.checkManager.isEnabled("nofall") ? "§aEnabled" : "§cDisabled"), "", "§e§l▶ Click to toggle")));
      gui.setItem(14, this.createToggleItem(Material.ENDER_PEARL, "§b§lPhase Detection", this.checkManager.isEnabled("phase"), Arrays.asList("§7Prevents wall/block phasing", "§8• §fSolid block validation", "§8• §fMovement tracking", "§7Current: " + (this.checkManager.isEnabled("phase") ? "§aEnabled" : "§cDisabled"), "", "§e§l▶ Click to toggle")));
      gui.setItem(15, this.createToggleItem(Material.SLIME_BLOCK, "§b§lStep Detection", this.checkManager.isEnabled("step"), Arrays.asList("§7Prevents block step cheats", "§8• §fVertical movement analysis", "§8• §fStair validation", "§7Current: " + (this.checkManager.isEnabled("step") ? "§aEnabled" : "§cDisabled"), "", "§e§l▶ Click to toggle")));
      player.openInventory(gui);
   }

   public void openPvPPage(Player player) {
      this.playerCurrentPage.put(player, "pvp");
      Inventory gui = Bukkit.createInventory((InventoryHolder)null, 54, "§e§lPvP Exploit Detection");
      gui.setItem(0, this.createItem(Material.ARROW, "§f§l← Back to Main Hub", Arrays.asList("§7Return to main menu")));
      gui.setItem(10, this.createToggleItem(Material.FIREWORK, "§e§lCrystal Aura", this.checkManager.isEnabled("crystalaura"), Arrays.asList("§7Detects automated crystal placement/breaking", "§8• §fRange validation", "§8• §fTiming analysis", "§7Current: " + (this.checkManager.isEnabled("crystalaura") ? "§aEnabled" : "§cDisabled"), "", "§e§l▶ Click to toggle")));
      gui.setItem(11, this.createToggleItem(Material.GLOWSTONE, "§e§lAnchor Aura", this.checkManager.isEnabled("anchoraura"), Arrays.asList("§7Detects automated anchor usage", "§8• §fNether dimension only", "§8• §fCharge sequence validation", "§7Current: " + (this.checkManager.isEnabled("anchoraura") ? "§aEnabled" : "§cDisabled"), "", "§e§l▶ Click to toggle")));
      gui.setItem(12, this.createToggleItem(Material.BED, "§e§lBed Aura", this.checkManager.isEnabled("bedaura"), Arrays.asList("§7Detects automated bed usage in Nether/End", "§8• §fExplosion dimension check", "§8• §fPlacement pattern analysis", "§7Current: " + (this.checkManager.isEnabled("bedaura") ? "§aEnabled" : "§cDisabled"), "", "§e§l▶ Click to toggle")));
      gui.setItem(13, this.createToggleItem(Material.GOLDEN_APPLE, "§e§lAuto Totem", this.checkManager.isEnabled("autototem"), Arrays.asList("§7Detects automated totem swapping", "§8• §fInventory movement tracking", "§8• §fSwap timing analysis", "§7Current: " + (this.checkManager.isEnabled("autototem") ? "§aEnabled" : "§cDisabled"), "", "§e§l▶ Click to toggle")));
      player.openInventory(gui);
   }

   @EventHandler
   public void onInventoryClick(InventoryClickEvent event) {
      if (event.getWhoClicked() instanceof Player) {
         Player player = (Player)event.getWhoClicked();
         String title = event.getView().getTitle();
         if (title.contains("AntiCheat") || title.contains("Combat") || title.contains("Movement") || title.contains("PvP")) {
            event.setCancelled(true);
            if (event.getCurrentItem() != null) {
               ItemStack item = event.getCurrentItem();
               if (item.hasItemMeta() && item.getItemMeta().hasDisplayName()) {
                  String itemName = item.getItemMeta().getDisplayName();
                  String currentPage = (String)this.playerCurrentPage.getOrDefault(player, "main");
                  if (itemName.contains("← Back to Main Hub")) {
                     this.openMainGUI(player);
                  } else {
                     if (currentPage.equals("main")) {
                        if (itemName.contains("Combat Detection")) {
                           this.openCombatPage(player);
                        } else if (itemName.contains("Movement Detection")) {
                           this.openMovementPage(player);
                        } else if (itemName.contains("PvP Exploits")) {
                           this.openPvPPage(player);
                        } else if (itemName.contains("Reload Config")) {
                           this.plugin.reloadConfig();
                           player.sendMessage("§a§l[AntiCheat] §7Configuration reloaded!");
                        } else if (itemName.contains("Emergency Stop")) {
                           for(String check2 : new String[]{"reach", "killaura", "fly", "speed", "criticals"}) {
                              this.checkManager.setEnabled(check2, false);
                           }

                           player.sendMessage("§c§l[AntiCheat] §7Emergency stop activated! All checks disabled.");
                           this.openMainGUI(player);
                        }
                     } else {
                        this.handleToggleAction(player, itemName, currentPage);
                     }

                  }
               }
            }
         }
      }
   }

   private void handleToggleAction(Player player, String itemName, String page) {
      String checkType = null;
      if (itemName.contains("Reach Detection")) {
         checkType = "reach";
      } else if (itemName.contains("KillAura Detection")) {
         checkType = "killaura";
      } else if (itemName.contains("Criticals Detection")) {
         checkType = "criticals";
      } else if (itemName.contains("Anti-Velocity Detection")) {
         checkType = "antivelocity";
      } else if (itemName.contains("Aimbot Detection")) {
         checkType = "aimbot";
      } else if (itemName.contains("Trigger Bot Detection")) {
         checkType = "triggerbot";
      } else if (itemName.contains("Hitbox Detection")) {
         checkType = "hitbox";
      } else if (itemName.contains("Fly Detection")) {
         checkType = "fly";
      } else if (itemName.contains("Speed Detection")) {
         checkType = "speed";
      } else if (itemName.contains("Jesus Detection")) {
         checkType = "jesus";
      } else if (itemName.contains("NoFall Detection")) {
         checkType = "nofall";
      } else if (itemName.contains("Phase Detection")) {
         checkType = "phase";
      } else if (itemName.contains("Step Detection")) {
         checkType = "step";
      } else if (itemName.contains("Crystal Aura")) {
         checkType = "crystalaura";
      } else if (itemName.contains("Anchor Aura")) {
         checkType = "anchoraura";
      } else if (itemName.contains("Bed Aura")) {
         checkType = "bedaura";
      } else if (itemName.contains("Auto Totem")) {
         checkType = "autototem";
      }

      if (checkType != null) {
         boolean newState = !this.checkManager.isEnabled(checkType);
         this.checkManager.setEnabled(checkType, newState);
         player.sendMessage(String.format("§a§l[AntiCheat] §7%s §f%s", checkType.substring(0, 1).toUpperCase() + checkType.substring(1), newState ? "§aenabled" : "§cdisabled"));
         switch (page) {
            case "combat":
               this.openCombatPage(player);
               break;
            case "movement":
               this.openMovementPage(player);
               break;
            case "pvp":
               this.openPvPPage(player);
         }
      }

   }

   private ItemStack createItem(Material material, String name, List<String> lore) {
      ItemStack item = new ItemStack(material);
      ItemMeta meta = item.getItemMeta();
      meta.setDisplayName(name);
      meta.setLore(lore);
      item.setItemMeta(meta);
      return item;
   }

   private ItemStack createToggleItem(Material material, String name, boolean enabled, List<String> lore) {
      ItemStack item = new ItemStack(material);
      ItemMeta meta = item.getItemMeta();
      meta.setDisplayName(name);
      meta.setLore(lore);
      if (enabled) {
         item.addUnsafeEnchantment(VersionCompatibility.getUnbreakingEnchantment(), 1);
         meta.addItemFlags(new ItemFlag[]{ItemFlag.HIDE_ENCHANTS});
      }

      item.setItemMeta(meta);
      return item;
   }

   private int getActiveChecksCount() {
      int count = 0;

      for(String check2 : new String[]{"reach", "killaura", "fly", "speed", "criticals", "triggerbot", "crystalaura"}) {
         if (this.checkManager.isEnabled(check2)) {
            ++count;
         }
      }

      return count;
   }
}
