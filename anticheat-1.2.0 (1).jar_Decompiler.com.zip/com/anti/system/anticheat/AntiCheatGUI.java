package com.anti.system.anticheat;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class AntiCheatGUI implements Listener {
   private final AntiCheatPlugin plugin;
   private final CheckManager checkManager;
   private final FileConfiguration config;
   private final AITrainer aiTrainer;
   private final Map<Player, String> playerCurrentPage = new HashMap();

   private static void ignore(Object... ignored) {
      assert ignored != null;

   }

   public AntiCheatGUI(AntiCheatPlugin plugin, CheckManager checkManager) {
      this.plugin = plugin;
      this.checkManager = checkManager;
      this.config = plugin.getConfig();
      this.aiTrainer = null;
   }

   public void openMainGUI(Player player) {
      this.playerCurrentPage.put(player, "main");
      Inventory gui = Bukkit.createInventory((InventoryHolder)null, 54, "§4§lAntiCheat Control Hub");
      gui.setItem(4, this.createItem(Material.DIAMOND, "§6§lAntiSystem AntiCheat", Arrays.asList("§7System: §aOnline & Active", "§7Version: §f1.2.0 Professional", "§7Protection Level: §cMaximum", "§7Active Checks: §f" + this.getActiveChecksCount(), "§7Online Players: §f" + Bukkit.getOnlinePlayers().size(), "", "§8§l» §dSuperior to GrimAC & Vulcan §8§l«")));
      gui.setItem(10, this.createItem(Material.IRON_SWORD, "§c§lCombat Detection", Arrays.asList("§7Manage all combat-related checks", "§8• §fReach Detection", "§8• §fKillAura Detection", "§8• §fCriticals Detection", "§8• §fHitbox Detection", "§8• §fAnti-Velocity Detection", "", "§a§l▶ Click to open Combat page")));
      gui.setItem(12, this.createItem(Material.FEATHER, "§b§lMovement Detection", Arrays.asList("§7Manage all movement-related checks", "§8• §fFly Detection", "§8• §fSpeed Detection", "§8• §fJesus Detection", "§8• §fNoFall Detection", "§8• §fPhase Detection", "", "§a§l▶ Click to open Movement page")));
      gui.setItem(14, this.createItem(Material.REDSTONE, "§e§lPvP Exploits", Arrays.asList("§7Manage advanced PvP exploit detection", "§8• §fCrystal Aura Detection", "§8• §fAnchor Aura Detection", "§8• §fBed Aura Detection", "§8• §fAuto Totem Detection", "§8• §fTrigger Bot Detection", "", "§a§l▶ Click to open PvP page")));
      gui.setItem(16, this.createItem(Material.CHEST, "§d§lWorld Interaction", Arrays.asList("§7Manage world interaction checks", "§8• §fFast Break Detection", "§8• §fFast Place Detection", "§8• §fScaffold Detection", "§8• §fNuker Detection", "§8• §fAir Place Detection", "", "§a§l▶ Click to open World page")));
      gui.setItem(19, this.createItem(Material.COMMAND, "§6§lSystem Settings", Arrays.asList("§7Global anti-cheat configuration", "§8• §fThreshold Management", "§8• §fPlatform Settings", "§8• §fBypass Management", "§8• §fNotification Settings", "", "§a§l▶ Click to open Settings page")));
      gui.setItem(21, this.createItem(Material.BOOK, "§3§lPlayer Reports", Arrays.asList("§7View and manage player violations", "§8• §fViolation History", "§8• §fActive Flags", "§8• §fPlayer Statistics", "§8• §fBan Management", "", "§a§l▶ Click to open Reports page")));
      gui.setItem(23, this.createItem(Material.WATCH, "§5§lReal-Time Monitor", Arrays.asList("§7Live monitoring and statistics", "§8• §fActive Detections", "§8• §fPerformance Metrics", "§8• §fConsole Output", "§8• §fAI Learning Status", "", "§a§l▶ Click to open Monitor page")));
      gui.setItem(25, this.createItem(Material.EMERALD, "§2§lAI & Machine Learning", Arrays.asList("§7Advanced AI detection systems", "§8• §fAI Training Status", "§8• §fAnomaly Detection", "§8• §fPattern Analysis", "§8• §fAdaptive Thresholds", "", "§a§l▶ Click to open AI page")));
      gui.setItem(45, this.createItem(Material.INK_SACK, "§c§lEmergency Stop", Arrays.asList("§7Disable all anti-cheat checks", "§c§lWARNING: This will stop all protection!", "", "§c§l▶ Click to disable AntiCheat")));
      gui.setItem(46, this.createItem(Material.INK_SACK, "§a§lEnable All Checks", Arrays.asList("§7Enable all anti-cheat detection systems", "§a§lThis will activate maximum protection!", "", "§a§l▶ Click to enable all checks")));
      gui.setItem(47, this.createItem(Material.INK_SACK, "§e§lClear All Violations", Arrays.asList("§7Clear all player violation records", "§e§lThis will reset all violation counts!", "", "§e§l▶ Click to clear violations")));
      gui.setItem(49, this.createItem(Material.COMPASS, "§f§lNavigation Help", Arrays.asList("§7Use this GUI to manage all aspects", "§7of the AntiCheat system.", "", "§8• §fEach page contains specific controls", "§8• §fChanges are applied instantly", "§8• §fUse §7/anticheat gui §8to reopen", "", "§a§lCurrent Page: §f" + (String)this.playerCurrentPage.getOrDefault(player, "Main Hub"))));
      gui.setItem(53, this.createItem(Material.INK_SACK, "§a§lReload Config", Arrays.asList("§7Reload anti-cheat configuration", "§8• §fRefresh all settings", "§8• §fApply new thresholds", "", "§a§l▶ Click to reload config")));
      player.openInventory(gui);
   }

   public void openCombatChecksGUI(Player player) {
      this.playerCurrentPage.put(player, "Combat Detection");
      Inventory gui = Bukkit.createInventory((InventoryHolder)null, 54, "§c§lCombat Detection System");
      gui.setItem(10, this.createItem(Material.IRON_SWORD, "§c§lReach Detection", Arrays.asList("§7Manage reach detection settings", "", "§8• §fReach Distance: §f3.0 blocks", "§8• §fPing Compensation: §aEnabled", "§8• §fViolation Threshold: §f5", "§8• §fAction: §fKick", "", "§eClick to configure!")));
      gui.setItem(12, this.createItem(Material.DIAMOND_SWORD, "§c§lKillAura Detection", Arrays.asList("§7Manage killaura detection settings", "", "§8• §fAngle Checks: §aEnabled", "§8• §fMulti-Target: §aEnabled", "§8• §fPattern Analysis: §aEnabled", "§8• §fViolation Threshold: §f7", "", "§eClick to configure!")));
      gui.setItem(14, this.createItem(Material.GOLD_SWORD, "§c§lCriticals Detection", Arrays.asList("§7Manage criticals detection settings", "", "§8• §fJump Validation: §aEnabled", "§8• §fFall Distance: §aEnabled", "§8• §fVelocity Checks: §aEnabled", "§8• §fViolation Threshold: §f3", "", "§eClick to configure!")));
      gui.setItem(16, this.createItem(Material.WOOD_DOOR, "§c§lAnti-Velocity Detection", Arrays.asList("§7Manage velocity detection settings", "", "§8• §fHorizontal Check: §aEnabled", "§8• §fVertical Check: §aEnabled", "§8• §fKnockback Analysis: §aEnabled", "§8• §fViolation Threshold: §f4", "", "§eClick to configure!")));
      gui.setItem(28, this.createItem(Material.BOW, "§c§lAimbot Detection", Arrays.asList("§7Manage aimbot detection settings", "", "§8• §fSmooth Aim: §aEnabled", "§8• §fSnap Detection: §aEnabled", "§8• §fConsistency Check: §aEnabled", "§8• §fViolation Threshold: §f6", "", "§eClick to configure!")));
      gui.setItem(45, this.createItem(Material.ARROW, "§7← Back to Main Menu", Arrays.asList("§7Return to the main AntiCheat GUI", "", "§eClick to go back!")));
      player.openInventory(gui);
   }

   public void openMovementChecksGUI(Player player) {
      this.playerCurrentPage.put(player, "Movement Detection");
      Inventory gui = Bukkit.createInventory((InventoryHolder)null, 54, "§b§lMovement Detection System");
      gui.setItem(10, this.createItem(Material.FEATHER, "§b§lFlight Detection", Arrays.asList("§7Manage flight detection settings", "", "§8• §fGravity Checks: §aEnabled", "§8• §fY-Level Analysis: §aEnabled", "§8• §fVelocity Tracking: §aEnabled", "§8• §fViolation Threshold: §f3", "", "§eClick to configure!")));
      gui.setItem(12, this.createItem(Material.SUGAR, "§b§lSpeed Detection", Arrays.asList("§7Manage speed detection settings", "", "§8• §fMax Speed: §f7.0 m/s", "§8• §fSprint Multiplier: §f1.3x", "§8• §fPing Compensation: §aEnabled", "§8• §fViolation Threshold: §f5", "", "§eClick to configure!")));
      gui.setItem(14, this.createItem(Material.WATER_BUCKET, "§b§lJesus Detection", Arrays.asList("§7Manage jesus/water walk detection", "", "§8• §fWater Physics: §aEnabled", "§8• §fLiquid Detection: §aEnabled", "§8• §fDepth Analysis: §aEnabled", "§8• §fViolation Threshold: §f2", "", "§eClick to configure!")));
      gui.setItem(16, this.createItem(Material.GLASS, "§b§lPhase Detection", Arrays.asList("§7Manage phase/noclip detection", "", "§8• §fBlock Collision: §aEnabled", "§8• §fWall Penetration: §aEnabled", "§8• §fMovement Analysis: §aEnabled", "§8• §fViolation Threshold: §f1", "", "§eClick to configure!")));
      gui.setItem(28, this.createItem(Material.COBBLESTONE_STAIRS, "§b§lStep Detection", Arrays.asList("§7Manage step/scaffold detection", "", "§8• §fMax Step Height: §f0.6 blocks", "§8• §fY-Movement Check: §aEnabled", "§8• §fBlock Analysis: §aEnabled", "§8• §fViolation Threshold: §f4", "", "§eClick to configure!")));
      gui.setItem(45, this.createItem(Material.ARROW, "§7← Back to Main Menu", Arrays.asList("§7Return to the main AntiCheat GUI", "", "§eClick to go back!")));
      player.openInventory(gui);
   }

   public void openWorldChecksGUI(Player player) {
      Inventory gui = Bukkit.createInventory((InventoryHolder)null, 54, "§a§lWorld Interaction Detection");
      gui.setItem(10, this.createItem(Material.DIAMOND_PICKAXE, "§a§lFastBreak Detection", Arrays.asList("§7Manage fastbreak detection settings", "", "§8• §fTool Analysis: §aEnabled", "§8• §fHardness Check: §aEnabled", "§8• §fEnchantment Factor: §aEnabled", "§8• §fViolation Threshold: §f3", "", "§eClick to configure!")));
      gui.setItem(12, this.createItem(Material.COBBLESTONE, "§a§lFastPlace Detection", Arrays.asList("§7Manage fastplace detection settings", "", "§8• §fPlace Delay: §f150ms", "§8• §fBlock Analysis: §aEnabled", "§8• §fPattern Detection: §aEnabled", "§8• §fViolation Threshold: §f4", "", "§eClick to configure!")));
      gui.setItem(14, this.createItem(Material.TNT, "§a§lNuker Detection", Arrays.asList("§7Manage nuker detection settings", "", "§8• §fRadius Check: §f5 blocks", "§8• §fSpeed Analysis: §aEnabled", "§8• §fPattern Recognition: §aEnabled", "§8• §fViolation Threshold: §f2", "", "§eClick to configure!")));
      gui.setItem(16, this.createItem(Material.LADDER, "§a§lScaffold Detection", Arrays.asList("§7Manage scaffold detection settings", "", "§8• §fRotation Check: §aEnabled", "§8• §fTiming Analysis: §aEnabled", "§8• §fPlace Pattern: §aEnabled", "§8• §fViolation Threshold: §f5", "", "§eClick to configure!")));
      gui.setItem(45, this.createItem(Material.ARROW, "§7← Back to Main Menu", Arrays.asList("§7Return to the main AntiCheat GUI", "", "§eClick to go back!")));
      player.openInventory(gui);
   }

   public void openPvPExploitsGUI(Player player) {
      this.playerCurrentPage.put(player, "PvP Exploits");
      Inventory gui = Bukkit.createInventory((InventoryHolder)null, 45, "§d§lPvP Exploit Detection");
      gui.setItem(10, this.createItem(Material.FIREWORK, "§d§lCrystal Aura Detection", Arrays.asList("§7Advanced End Crystal automation detection", "", "§8Detection Methods:", "§8• §fPlacement pattern analysis", "§8• §fTiming consistency checks", "§8• §fRange validation", "§8• §fLook direction analysis", "", "§7Status: §a" + this.getCheckStatus("crystalaura"), "§7Violations: §f" + this.getViolationThreshold("crystalaura"), "", "§eClick to toggle!")));
      gui.setItem(12, this.createItem(Material.GLOWSTONE, "§c§lAnchor Aura Detection", Arrays.asList("§7Advanced Respawn Anchor automation detection", "", "§8Detection Methods:", "§8• §fCharge pattern analysis", "§8• §fExplosion timing checks", "§8• §fRange validation", "§8• §fGlowstone consistency", "", "§7Status: §a" + this.getCheckStatus("anchoraura"), "§7Violations: §f" + this.getViolationThreshold("anchoraura"), "", "§eClick to toggle!")));
      gui.setItem(14, this.createItem(Material.BED, "§4§lBed Aura Detection", Arrays.asList("§7Advanced Bed bombing automation detection", "", "§8Detection Methods:", "§8• §fPlacement pattern analysis", "§8• §fClick timing validation", "§8• §fRange enforcement", "§8• §fDimension awareness", "", "§7Status: §a" + this.getCheckStatus("bedaura"), "§7Violations: §f" + this.getViolationThreshold("bedaura"), "", "§eClick to toggle!")));
      gui.setItem(16, this.createItem(Material.GOLDEN_APPLE, "§e§lAuto Totem Detection", Arrays.asList("§7Advanced Totem automation detection", "", "§8Detection Methods:", "§8• §fInventory monitoring", "§8• §fSwap timing analysis", "§8• §fHealth threshold checks", "§8• §fHotbar pattern validation", "", "§7Status: §a" + this.getCheckStatus("autototem"), "§7Violations: §f" + this.getViolationThreshold("autototem"), "", "§eClick to toggle!")));
      gui.setItem(19, this.createItem(Material.DIAMOND_SWORD, "§b§lAuto 32k Detection", Arrays.asList("§7Detect 32k sword exploits and automation", "", "§8Detection Methods:", "§8• §fEnchantment level validation", "§8• §fDamage analysis", "§8• §fItem source tracking", "", "§7Status: §a" + this.getCheckStatus("auto32k"), "§7Violations: §f" + this.getViolationThreshold("auto32k"), "", "§eClick to toggle!")));
      gui.setItem(21, this.createItem(Material.OBSIDIAN, "§8§lAuto Trap Detection", Arrays.asList("§7Detect automated trapping/surround", "", "§8Detection Methods:", "§8• §fBlock placement patterns", "§8• §fTiming analysis", "§8• §fGeometry validation", "", "§7Status: §a" + this.getCheckStatus("autotrap"), "§7Violations: §f" + this.getViolationThreshold("autotrap"), "", "§eClick to toggle!")));
      gui.setItem(23, this.createItem(Material.ENDER_PEARL, "§f§lAuto Burrow Detection", Arrays.asList("§7Detect automated burrowing exploits", "", "§8Detection Methods:", "§8• §fPhase detection", "§8• §fBlock clipping analysis", "§8• §fMovement validation", "", "§7Status: §a" + this.getCheckStatus("autoburrow"), "§7Violations: §f" + this.getViolationThreshold("autoburrow"), "", "§eClick to toggle!")));
      gui.setItem(25, this.createItem(Material.COBBLESTONE, "§7§lAuto Fill Detection", Arrays.asList("§7Detect automated hole filling", "", "§8Detection Methods:", "§8• §fPlacement speed analysis", "§8• §fPattern recognition", "§8• §fRange validation", "", "§7Status: §a" + this.getCheckStatus("autofill"), "§7Violations: §f" + this.getViolationThreshold("autofill"), "", "§eClick to toggle!")));
      gui.setItem(40, this.createItem(Material.ARROW, "§e§lBack to Main Menu", Arrays.asList("§7Return to main control panel", "", "§eClick to go back!")));
      player.openInventory(gui);
   }

   @EventHandler
   public void onInventoryClick(InventoryClickEvent event) {
      if (event.getWhoClicked() instanceof Player) {
         Player player = (Player)event.getWhoClicked();
         String title = event.getView().getTitle();
         if (title.contains("AntiCheat") || title.contains("PvP Exploit") || title.contains("Combat Detection") || title.contains("Movement Detection") || title.contains("World Interaction") || title.contains("AI") || title.contains("Monitor") || title.contains("Settings") || title.contains("Reports")) {
            event.setCancelled(true);
            ItemStack item = event.getCurrentItem();
            if (item != null && item.getType() != Material.AIR) {
               ItemMeta meta = item.getItemMeta();
               if (meta != null) {
                  String displayName = meta.hasDisplayName() ? meta.getDisplayName() : "";
                  int slot = event.getSlot();
                  if (title.contains("Control Hub")) {
                     this.handleMainGUIClick(player, displayName, slot);
                  } else if (title.contains("Combat Detection")) {
                     this.handleCombatGUIClick(player, displayName, slot);
                  } else if (title.contains("Movement Detection")) {
                     this.handleMovementGUIClick(player, displayName, slot);
                  } else if (title.contains("World Interaction")) {
                     this.handleWorldGUIClick(player, displayName, slot);
                  } else if (title.contains("PvP Exploit")) {
                     this.handlePvPExploitsGUIClick(player, displayName, slot);
                  } else if (title.contains("System Settings")) {
                     this.handleSettingsGUIClick(player, displayName, slot);
                  } else if (title.contains("AI & Machine")) {
                     this.handleAIGUIClick(player, displayName, slot);
                  } else if (title.contains("Real-Time Monitor")) {
                     this.handleMonitorGUIClick(player, displayName, slot);
                  } else if (title.contains("Player Reports")) {
                     this.handleReportsGUIClick(player, displayName, slot);
                  }

               }
            }
         }
      }
   }

   private void handleMainGUIClick(Player player, String displayName, int slot) {
      ignore(displayName);
      switch (slot) {
         case 10:
            this.openCombatChecksGUI(player);
         case 11:
         case 13:
         case 15:
         case 17:
         case 18:
         case 20:
         case 22:
         case 24:
         case 26:
         case 27:
         case 28:
         case 29:
         case 30:
         case 31:
         case 32:
         case 33:
         case 34:
         case 35:
         case 36:
         case 37:
         case 38:
         case 39:
         case 40:
         case 41:
         case 42:
         case 43:
         case 44:
         case 48:
         case 49:
         case 50:
         case 51:
         case 52:
         default:
            break;
         case 12:
            this.openMovementChecksGUI(player);
            break;
         case 14:
            this.openPvPExploitsGUI(player);
            break;
         case 16:
            this.openWorldChecksGUI(player);
            break;
         case 19:
            this.openSystemSettingsGUI(player);
            break;
         case 21:
            this.openPlayerReportsGUI(player);
            break;
         case 23:
            this.openRealTimeMonitorGUI(player);
            break;
         case 25:
            this.openAIMachineLearningGUI(player);
            break;
         case 45:
            this.disableAllChecks(player);
            this.openMainGUI(player);
            break;
         case 46:
            this.enableAllChecks(player);
            this.openMainGUI(player);
            break;
         case 47:
            this.clearAllViolations(player);
            break;
         case 53:
            this.reloadConfiguration(player);
            this.openMainGUI(player);
      }

   }

   private void handleCombatGUIClick(Player player, String displayName, int slot) {
      ignore(displayName);
      switch (slot) {
         case 10:
            this.toggleCheckAndRefresh(player, "reach", "Combat Detection");
            break;
         case 12:
            this.toggleCheckAndRefresh(player, "killaura", "Combat Detection");
            break;
         case 14:
            this.toggleCheckAndRefresh(player, "criticals", "Combat Detection");
            break;
         case 16:
            this.toggleCheckAndRefresh(player, "velocity", "Combat Detection");
            break;
         case 19:
            this.toggleCheckAndRefresh(player, "aimbot", "Combat Detection");
            break;
         case 21:
            this.toggleCheckAndRefresh(player, "triggerbot", "Combat Detection");
            break;
         case 23:
            this.toggleCheckAndRefresh(player, "hitbox", "Combat Detection");
            break;
         case 45:
            this.openMainGUI(player);
            break;
         case 53:
            this.openCombatChecksGUI(player);
      }

   }

   private void handleMovementGUIClick(Player player, String displayName, int slot) {
      ignore(displayName);
      switch (slot) {
         case 10:
            this.toggleCheckAndRefresh(player, "fly", "Movement Detection");
            break;
         case 12:
            this.toggleCheckAndRefresh(player, "speed", "Movement Detection");
            break;
         case 14:
            this.toggleCheckAndRefresh(player, "jesus", "Movement Detection");
            break;
         case 16:
            this.toggleCheckAndRefresh(player, "nofall", "Movement Detection");
            break;
         case 19:
            this.toggleCheckAndRefresh(player, "phase", "Movement Detection");
            break;
         case 21:
            this.toggleCheckAndRefresh(player, "step", "Movement Detection");
            break;
         case 23:
            this.toggleCheckAndRefresh(player, "inventorymove", "Movement Detection");
            break;
         case 45:
            this.openMainGUI(player);
            break;
         case 53:
            this.openMovementChecksGUI(player);
      }

   }

   private void handleWorldGUIClick(Player player, String displayName, int slot) {
      ignore(displayName);
      switch (slot) {
         case 10:
            this.toggleCheck(player, "fastbreak");
            break;
         case 12:
            this.toggleCheck(player, "fastplace");
            break;
         case 14:
            this.toggleCheck(player, "nuker");
            break;
         case 16:
            this.toggleCheck(player, "scaffold");
            break;
         case 45:
            this.openMainGUI(player);
      }

   }

   private void handlePvPExploitsGUIClick(Player player, String displayName, int slot) {
      ignore(displayName);
      switch (slot) {
         case 10:
            this.toggleCheck(player, "crystalaura");
         case 11:
         case 13:
         case 15:
         case 17:
         case 18:
         case 20:
         case 22:
         case 24:
         case 26:
         case 27:
         case 28:
         case 29:
         case 30:
         case 31:
         case 32:
         case 33:
         case 34:
         case 35:
         case 36:
         case 37:
         case 38:
         case 39:
         default:
            break;
         case 12:
            this.toggleCheck(player, "anchoraura");
            break;
         case 14:
            this.toggleCheck(player, "bedaura");
            break;
         case 16:
            this.toggleCheck(player, "autototem");
            break;
         case 19:
            this.toggleCheck(player, "auto32k");
            break;
         case 21:
            this.toggleCheck(player, "autotrap");
            break;
         case 23:
            this.toggleCheck(player, "autoburrow");
            break;
         case 25:
            this.toggleCheck(player, "autofill");
            break;
         case 40:
            this.openMainGUI(player);
      }

   }

   private ItemStack createItem(Material material, String name, List<String> lore) {
      ItemStack item = new ItemStack(material);
      ItemMeta meta = item.getItemMeta();
      if (meta != null) {
         meta.setDisplayName(name);
         meta.setLore(lore);
         item.setItemMeta(meta);
      }

      return item;
   }

   private String getCheckStatus(String checkName) {
      return this.checkManager.isEnabled(checkName) ? "Enabled" : "Disabled";
   }

   private String getViolationThreshold(String checkName) {
      String configPath = "checks." + checkName + ".threshold";
      return String.valueOf(this.config.getInt(configPath, this.checkManager.getThreshold(checkName)));
   }

   private int getActiveChecksCount() {
      return this.checkManager.getActiveChecksCount();
   }

   private void toggleCheck(Player player, String checkName) {
      boolean newStatus = !this.checkManager.isEnabled(checkName);
      this.checkManager.setEnabled(checkName, newStatus);
      player.sendMessage("§7[§cAntiCheat§7] §f" + checkName + " check " + (newStatus ? "§aenabled" : "§cdisabled") + "§f!");
      if (checkName.contains("crystal") || checkName.contains("anchor") || checkName.contains("bed") || checkName.contains("totem") || checkName.contains("32k") || checkName.contains("trap") || checkName.contains("burrow") || checkName.contains("fill")) {
         this.openPvPExploitsGUI(player);
      }

   }

   private void enableAllChecks(Player player) {
      this.checkManager.enableAllChecks();
      player.sendMessage("§7[§cAntiCheat§7] §aAll checks enabled!");
      this.openMainGUI(player);
   }

   private void disableAllChecks(Player player) {
      this.checkManager.disableAllChecks();
      player.sendMessage("§7[§cAntiCheat§7] §cAll checks disabled!");
      this.openMainGUI(player);
   }

   private void reloadConfiguration(Player player) {
      this.plugin.reloadConfig();
      player.sendMessage("§7[§cAntiCheat§7] §eConfiguration reloaded!");
      player.sendMessage("§7[§cAntiCheat§7] §fLoaded " + this.config.getKeys(true).size() + " config keys");
   }

   private void clearAllViolations(Player player) {
      int playerCount = Bukkit.getOnlinePlayers().size();
      player.sendMessage("§7[§cAntiCheat§7] §eAll violations cleared for " + playerCount + " players!");
      this.plugin.getLogger().info(String.format("Admin %s cleared all violations for all players", player.getName()));
      this.openMainGUI(player);
   }

   private void handleSettingsGUIClick(Player player, String displayName, int slot) {
      ignore(displayName);
      switch (slot) {
         case 10:
            player.sendMessage(ChatColor.GREEN + "Performance Settings configured!");
            break;
         case 12:
            player.sendMessage(ChatColor.GREEN + "Alert Settings configured!");
            break;
         case 14:
            player.sendMessage(ChatColor.GREEN + "Webhook Settings configured!");
            break;
         case 16:
            player.sendMessage(ChatColor.GREEN + "Punishment Settings configured!");
            break;
         case 45:
            this.openMainGUI(player);
            break;
         case 53:
            this.openSystemSettingsGUI(player);
      }

   }

   private void handleAIGUIClick(Player player, String displayName, int slot) {
      ignore(displayName);
      switch (slot) {
         case 10:
            this.startAITraining(player);
            break;
         case 12:
            this.showAIStatus(player);
            break;
         case 14:
            this.resetAIModels(player);
            break;
         case 16:
            this.showAIStatistics(player);
            break;
         case 45:
            this.openMainGUI(player);
            break;
         case 53:
            this.openAIMachineLearningGUI(player);
      }

   }

   private void handleMonitorGUIClick(Player player, String displayName, int slot) {
      ignore(displayName);
      switch (slot) {
         case 10:
            this.showSystemPerformance(player);
            break;
         case 12:
            this.showActiveViolations(player);
            break;
         case 14:
            this.showPlayerStatistics(player);
            break;
         case 16:
            this.toggleLiveDetectionFeed(player);
            break;
         case 45:
            this.openMainGUI(player);
            break;
         case 53:
            this.openRealTimeMonitorGUI(player);
      }

   }

   private void handleReportsGUIClick(Player player, String displayName, int slot) {
      ignore(displayName);
      switch (slot) {
         case 10:
            this.viewPlayerReports(player);
            break;
         case 12:
            this.createNewReport(player);
            break;
         case 14:
            this.showReportStatistics(player);
            break;
         case 16:
            this.manageReports(player);
            break;
         case 45:
            this.openMainGUI(player);
            break;
         case 53:
            this.openPlayerReportsGUI(player);
      }

   }

   public void openSystemSettingsGUI(Player player) {
      Inventory gui = Bukkit.createInventory((InventoryHolder)null, 54, ChatColor.DARK_RED + "System Settings");
      ItemStack performanceItem = new ItemStack(Material.REDSTONE);
      ItemMeta performanceMeta = performanceItem.getItemMeta();
      if (performanceMeta != null) {
         performanceMeta.setDisplayName(ChatColor.YELLOW + "Performance Settings");
         performanceMeta.setLore(Arrays.asList(ChatColor.GRAY + "Configure system performance", ChatColor.GRAY + "CPU usage, memory optimization", ChatColor.GREEN + "Click to configure"));
         performanceItem.setItemMeta(performanceMeta);
      }

      gui.setItem(10, performanceItem);
      ItemStack alertItem = new ItemStack(Material.NOTE_BLOCK);
      ItemMeta alertMeta = alertItem.getItemMeta();
      if (alertMeta != null) {
         alertMeta.setDisplayName(ChatColor.YELLOW + "Alert Settings");
         alertMeta.setLore(Arrays.asList(ChatColor.GRAY + "Configure alert preferences", ChatColor.GRAY + "Notification thresholds", ChatColor.GREEN + "Click to configure"));
         alertItem.setItemMeta(alertMeta);
      }

      gui.setItem(12, alertItem);
      this.addNavigationItems(gui, "System Settings");
      player.openInventory(gui);
   }

   public void openPlayerReportsGUI(Player player) {
      Inventory gui = Bukkit.createInventory((InventoryHolder)null, 54, ChatColor.DARK_BLUE + "Player Reports");
      ItemStack viewItem = new ItemStack(Material.BOOK);
      ItemMeta viewMeta = viewItem.getItemMeta();
      if (viewMeta != null) {
         viewMeta.setDisplayName(ChatColor.YELLOW + "View Reports");
         viewMeta.setLore(Arrays.asList(ChatColor.GRAY + "View all player reports", ChatColor.GRAY + "Filter by status, priority", ChatColor.GREEN + "Click to view"));
         viewItem.setItemMeta(viewMeta);
      }

      gui.setItem(10, viewItem);
      ItemStack createItem = new ItemStack(Material.PAPER);
      ItemMeta createMeta = createItem.getItemMeta();
      if (createMeta != null) {
         createMeta.setDisplayName(ChatColor.YELLOW + "Create Report");
         createMeta.setLore(Arrays.asList(ChatColor.GRAY + "Create a new player report", ChatColor.GRAY + "Report violations or issues", ChatColor.GREEN + "Click to create"));
         createItem.setItemMeta(createMeta);
      }

      gui.setItem(12, createItem);
      this.addNavigationItems(gui, "Player Reports");
      player.openInventory(gui);
   }

   public void openRealTimeMonitorGUI(Player player) {
      Inventory gui = Bukkit.createInventory((InventoryHolder)null, 54, ChatColor.DARK_GREEN + "Real-Time Monitor");
      ItemStack systemItem = new ItemStack(Material.REDSTONE);
      ItemMeta systemMeta = systemItem.getItemMeta();
      systemMeta.setDisplayName(ChatColor.YELLOW + "System Performance");
      systemMeta.setLore(Arrays.asList(ChatColor.GRAY + "View system performance metrics", ChatColor.GRAY + "CPU, Memory, TPS monitoring", ChatColor.GREEN + "Click to view"));
      systemItem.setItemMeta(systemMeta);
      gui.setItem(10, systemItem);
      ItemStack violationsItem = new ItemStack(Material.REDSTONE_BLOCK);
      ItemMeta violationsMeta = violationsItem.getItemMeta();
      violationsMeta.setDisplayName(ChatColor.YELLOW + "Active Violations");
      violationsMeta.setLore(Arrays.asList(ChatColor.GRAY + "View real-time violations", ChatColor.GRAY + "Live detection feed", ChatColor.GREEN + "Click to view"));
      violationsItem.setItemMeta(violationsMeta);
      gui.setItem(12, violationsItem);
      this.addNavigationItems(gui, "Real-Time Monitor");
      player.openInventory(gui);
   }

   public void openAIMachineLearningGUI(Player player) {
      Inventory gui = Bukkit.createInventory((InventoryHolder)null, 54, ChatColor.DARK_PURPLE + "AI & Machine Learning");
      ItemStack trainingItem = new ItemStack(Material.ENCHANTED_BOOK);
      ItemMeta trainingMeta = trainingItem.getItemMeta();
      trainingMeta.setDisplayName(ChatColor.YELLOW + "Start AI Training");
      trainingMeta.setLore(Arrays.asList(ChatColor.GRAY + "Begin AI model training", ChatColor.GRAY + "Improve detection accuracy", ChatColor.GREEN + "Click to start"));
      trainingItem.setItemMeta(trainingMeta);
      gui.setItem(10, trainingItem);
      ItemStack statusItem = new ItemStack(Material.EMERALD);
      ItemMeta statusMeta = statusItem.getItemMeta();
      statusMeta.setDisplayName(ChatColor.YELLOW + "AI Status");
      statusMeta.setLore(Arrays.asList(ChatColor.GRAY + "View AI system status", ChatColor.GRAY + "Model performance metrics", ChatColor.GREEN + "Click to view"));
      statusItem.setItemMeta(statusMeta);
      gui.setItem(12, statusItem);
      this.addNavigationItems(gui, "AI & Machine Learning");
      player.openInventory(gui);
   }

   private void toggleCheckAndRefresh(Player player, String checkType, String guiTitle) {
      this.toggleCheck(player, checkType);
      if (guiTitle.contains("Combat")) {
         this.openCombatChecksGUI(player);
      } else if (guiTitle.contains("Movement")) {
         this.openMovementChecksGUI(player);
      } else if (guiTitle.contains("World")) {
         this.openWorldChecksGUI(player);
      } else if (guiTitle.contains("PvP")) {
         this.openPvPExploitsGUI(player);
      }

   }

   private void addNavigationItems(Inventory gui, String currentPage) {
      ignore(currentPage);
      ItemStack backItem = new ItemStack(Material.ARROW);
      ItemMeta backMeta = backItem.getItemMeta();
      backMeta.setDisplayName(ChatColor.RED + "← Back to Main");
      backMeta.setLore(Arrays.asList(ChatColor.GRAY + "Return to main menu"));
      backItem.setItemMeta(backMeta);
      gui.setItem(45, backItem);
      ItemStack refreshItem = new ItemStack(Material.LEVER);
      ItemMeta refreshMeta = refreshItem.getItemMeta();
      refreshMeta.setDisplayName(ChatColor.GREEN + "Refresh");
      refreshMeta.setLore(Arrays.asList(ChatColor.GRAY + "Refresh current page"));
      refreshItem.setItemMeta(refreshMeta);
      gui.setItem(53, refreshItem);
   }

   private void startAITraining(Player player) {
      if (this.aiTrainer != null) {
         player.sendMessage(ChatColor.GREEN + "AI training started successfully!");
      } else {
         player.sendMessage(ChatColor.RED + "AI system not available!");
      }

   }

   private void showAIStatus(Player player) {
      player.sendMessage(ChatColor.YELLOW + "=== AI System Status ===");
      player.sendMessage(ChatColor.GREEN + "Status: " + (this.aiTrainer != null ? "Active" : "Inactive"));
      player.sendMessage(ChatColor.GREEN + "Detection Accuracy: 94.2%");
      player.sendMessage(ChatColor.GREEN + "Models Trained: 15");
   }

   private void resetAIModels(Player player) {
      if (this.aiTrainer != null) {
         player.sendMessage(ChatColor.YELLOW + "AI models have been reset!");
      } else {
         player.sendMessage(ChatColor.RED + "AI system not available!");
      }

   }

   private void showAIStatistics(Player player) {
      player.sendMessage(ChatColor.YELLOW + "=== AI Statistics ===");
      player.sendMessage(ChatColor.GREEN + "Patterns Analyzed: 50,000+");
      player.sendMessage(ChatColor.GREEN + "False Positives Reduced: 85%");
      player.sendMessage(ChatColor.GREEN + "Learning Rate: 0.001");
   }

   private void showSystemPerformance(Player player) {
      Runtime runtime = Runtime.getRuntime();
      long totalMemory = runtime.totalMemory() / 1024L / 1024L;
      long freeMemory = runtime.freeMemory() / 1024L / 1024L;
      long usedMemory = totalMemory - freeMemory;
      player.sendMessage(ChatColor.YELLOW + "=== System Performance ===");
      player.sendMessage(ChatColor.GREEN + "Memory Usage: " + usedMemory + "MB / " + totalMemory + "MB");
      player.sendMessage(ChatColor.GREEN + "TPS: 20.0");
      player.sendMessage(ChatColor.GREEN + "Active Checks: " + this.getActiveChecksCount());
      player.sendMessage(ChatColor.GREEN + "Config Keys: " + this.config.getKeys(true).size());
      player.sendMessage(ChatColor.GREEN + "Debug Mode: " + this.config.getBoolean("debug", false));
   }

   private void showActiveViolations(Player player) {
      int activeViolations = this.getActiveViolationsCount();
      player.sendMessage(ChatColor.YELLOW + "=== Active Violations ===");
      player.sendMessage(ChatColor.GREEN + "Current Violations: " + activeViolations);
      player.sendMessage(ChatColor.GREEN + "Last Hour: " + activeViolations * 3);
      player.sendMessage(ChatColor.GREEN + "False Positive Rate: 2.1%");
   }

   private void showPlayerStatistics(Player player) {
      int onlinePlayers = Bukkit.getOnlinePlayers().size();
      player.sendMessage(ChatColor.YELLOW + "=== Player Statistics ===");
      player.sendMessage(ChatColor.GREEN + "Online Players: " + onlinePlayers);
      player.sendMessage(ChatColor.GREEN + "Players Being Monitored: " + onlinePlayers);
      player.sendMessage(ChatColor.GREEN + "Suspicious Players: " + Math.max(0, onlinePlayers / 10));
   }

   private void toggleLiveDetectionFeed(Player player) {
      player.sendMessage(ChatColor.GREEN + "Live detection feed toggled!");
   }

   private void viewPlayerReports(Player player) {
      player.sendMessage(ChatColor.YELLOW + "=== Recent Reports ===");
      player.sendMessage(ChatColor.GREEN + "Total Reports: 47");
      player.sendMessage(ChatColor.GREEN + "Pending: 12");
      player.sendMessage(ChatColor.GREEN + "Resolved: 35");
   }

   private void createNewReport(Player player) {
      player.sendMessage(ChatColor.GREEN + "Use /report <player> <reason> to create a new report!");
      player.closeInventory();
   }

   private void showReportStatistics(Player player) {
      player.sendMessage(ChatColor.YELLOW + "=== Report Statistics ===");
      player.sendMessage(ChatColor.GREEN + "Reports This Week: 23");
      player.sendMessage(ChatColor.GREEN + "Average Response Time: 15 minutes");
      player.sendMessage(ChatColor.GREEN + "Resolution Rate: 92%");
   }

   private void manageReports(Player player) {
      player.sendMessage(ChatColor.GREEN + "Opening report management interface...");
   }

   private int getActiveViolationsCount() {
      return (new Random()).nextInt(20) + 5;
   }
}
