package com.anti.system.anticheat;

import com.anti.system.utils.VersionUtils;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;

public class AdaptiveMLDecisionEngine {
   private final JavaPlugin plugin;
   private final IntelligentAutoConfig autoConfig;
   private final Map<String, Double> performanceMetrics;
   private final Map<String, Integer> violationHistory;
   private final Map<String, Double> settingsEffectiveness;
   private final Queue<PerformanceSnapshot> performanceHistory;
   private static final int ANALYSIS_INTERVAL = 300;
   private static final int PERFORMANCE_HISTORY_SIZE = 24;
   private static final double LEARNING_RATE = 0.05;
   private static final double FALSE_POSITIVE_PENALTY = (double)-2.0F;
   private static final double TRUE_POSITIVE_REWARD = (double)1.0F;
   private final boolean isLearning = true;
   private long lastOptimization = 0L;

   public AdaptiveMLDecisionEngine(JavaPlugin plugin, IntelligentAutoConfig autoConfig) {
      this.plugin = plugin;
      this.autoConfig = autoConfig;
      this.performanceMetrics = new ConcurrentHashMap();
      this.violationHistory = new ConcurrentHashMap();
      this.settingsEffectiveness = new ConcurrentHashMap();
      this.performanceHistory = new LinkedList();
      this.initializeMetrics();
      this.startAdaptiveLearning();
      if (autoConfig != null) {
         plugin.getLogger().info("[AdaptiveML] Adaptive ML Decision Engine initialized with auto-config");
      } else {
         plugin.getLogger().info("[AdaptiveML] Adaptive ML Decision Engine initialized without auto-config");
      }

   }

   private void initializeMetrics() {
      this.performanceMetrics.put("avg_tps", (double)20.0F);
      this.performanceMetrics.put("avg_ping", (double)50.0F);
      this.performanceMetrics.put("player_count", (double)0.0F);
      this.performanceMetrics.put("violation_rate", (double)0.0F);
      this.performanceMetrics.put("false_positive_rate", (double)0.0F);
      this.settingsEffectiveness.put("speed_threshold", (double)1.0F);
      this.settingsEffectiveness.put("fly_threshold", (double)1.0F);
      this.settingsEffectiveness.put("reach_threshold", (double)1.0F);
      this.settingsEffectiveness.put("ml_confidence", (double)1.0F);
   }

   private void startAdaptiveLearning() {
      (new BukkitRunnable() {
         public void run() {
            AdaptiveMLDecisionEngine.this.collectPerformanceData();
            AdaptiveMLDecisionEngine.this.analyzeEffectiveness();
            if (System.currentTimeMillis() - AdaptiveMLDecisionEngine.this.lastOptimization > 3600000L) {
               AdaptiveMLDecisionEngine.this.optimizeSettings();
               AdaptiveMLDecisionEngine.this.lastOptimization = System.currentTimeMillis();
            }

         }
      }).runTaskTimerAsynchronously(this.plugin, 6000L, 6000L);
      this.plugin.getLogger().info("[AdaptiveML] ✅ Started continuous learning system");
   }

   private void collectPerformanceData() {
      double[] tps = VersionUtils.getTPS();
      double avgTPS = (tps[0] + tps[1] + tps[2]) / (double)3.0F;
      double avgPing = Bukkit.getOnlinePlayers().stream().mapToInt(VersionUtils::getPing).filter((ping) -> ping > 0).average().orElse((double)50.0F);
      int playerCount = Bukkit.getOnlinePlayers().size();
      int totalViolations = this.violationHistory.values().stream().mapToInt(Integer::intValue).sum();
      double violationRate = (double)totalViolations / (double)5.0F;
      this.performanceMetrics.put("avg_tps", avgTPS);
      this.performanceMetrics.put("avg_ping", avgPing);
      this.performanceMetrics.put("player_count", (double)playerCount);
      this.performanceMetrics.put("violation_rate", violationRate);
      PerformanceSnapshot snapshot = new PerformanceSnapshot(System.currentTimeMillis(), avgTPS, avgPing, playerCount, violationRate);
      this.performanceHistory.offer(snapshot);
      if (this.performanceHistory.size() > 24) {
         this.performanceHistory.poll();
      }

      this.violationHistory.clear();
   }

   private void analyzeEffectiveness() {
      if (this.performanceHistory.size() >= 3) {
         ArrayList<PerformanceSnapshot> recent = new ArrayList(this.performanceHistory);
         Collections.reverse(recent);
         boolean tpsImproving = this.analyzeTrend(recent, PerformanceSnapshot::getTps);
         boolean violationsStable = this.analyzeTrend(recent, PerformanceSnapshot::getViolationRate, 0.1);
         double overallEffectiveness = this.calculateOverallEffectiveness(recent);
         if (tpsImproving && violationsStable) {
            this.adjustEffectivenessScores(0.020000000000000004);
         } else if (!tpsImproving && !violationsStable) {
            this.adjustEffectivenessScores(-0.03);
         }

         this.performanceMetrics.put("overall_effectiveness", overallEffectiveness);
      }
   }

   private void optimizeSettings() {
      this.plugin.getLogger().info("§d[AdaptiveML] Starting intelligent settings optimization...");
      Map<String, Object> newSettings = this.generateOptimizedSettings();
      if (this.shouldApplyOptimizations(newSettings)) {
         this.applyOptimizations(newSettings);
         this.plugin.getLogger().info("§a[AdaptiveML] ✅ Settings optimized based on ML analysis");
      } else {
         this.plugin.getLogger().info("§e[AdaptiveML] Current settings appear optimal - no changes needed");
      }

   }

   private Map<String, Object> generateOptimizedSettings() {
      HashMap<String, Object> optimizations = new HashMap();
      double avgTPS = (Double)this.performanceMetrics.get("avg_tps");
      double avgPing = (Double)this.performanceMetrics.get("avg_ping");
      double violationRate = (Double)this.performanceMetrics.get("violation_rate");
      double falsePositiveRate = (Double)this.performanceMetrics.get("false_positive_rate");
      if (avgTPS < (double)16.0F) {
         optimizations.put("speed_multiplier", 1.3);
         optimizations.put("violation_threshold_multiplier", (double)1.5F);
         optimizations.put("ml_confidence_increase", 0.02);
      } else if (avgTPS > 19.8) {
         optimizations.put("speed_multiplier", 0.95);
         optimizations.put("violation_threshold_multiplier", 0.9);
         optimizations.put("ml_confidence_decrease", 0.01);
      }

      if (avgPing > (double)200.0F) {
         optimizations.put("ping_compensation_increase", 1.2);
         optimizations.put("timeout_increase", 1.4);
         this.plugin.getLogger().info("§e[AdaptiveML] High ping environment detected - adjusting compensation");
      }

      if (violationRate > (double)10.0F && falsePositiveRate > 0.1) {
         optimizations.put("threshold_relaxation", 1.2);
         optimizations.put("ml_confidence_increase", 0.03);
         this.plugin.getLogger().warning("§e[AdaptiveML] High violation rate detected - reducing sensitivity");
      } else if (violationRate < (double)0.5F && falsePositiveRate < 0.01) {
         optimizations.put("threshold_tightening", 0.95);
         this.plugin.getLogger().info("§a[AdaptiveML] Low violation rate - optimizing sensitivity");
      }

      if (VersionUtils.isLegacy()) {
         optimizations.put("legacy_mode_enhancement", true);
         this.plugin.getLogger().info("§e[AdaptiveML] Applying legacy version optimizations");
      } else if (VersionUtils.is121Plus()) {
         optimizations.put("modern_features_optimization", true);
         this.plugin.getLogger().info("§a[AdaptiveML] Applying modern version optimizations");
      }

      return optimizations;
   }

   private boolean shouldApplyOptimizations(Map<String, Object> optimizations) {
      if (optimizations.isEmpty()) {
         return false;
      } else if (System.currentTimeMillis() - this.lastOptimization < 1800000L) {
         return false;
      } else {
         double impactScore = this.calculateOptimizationImpact(optimizations);
         return impactScore > 0.1;
      }
   }

   private void applyOptimizations(Map<String, Object> optimizations) {
      try {
         for(Map.Entry<String, Object> entry : optimizations.entrySet()) {
            this.applySpecificOptimization((String)entry.getKey(), entry.getValue());
         }

         this.plugin.getLogger().info(String.format("§a[AdaptiveML] Applied %d ML-based optimizations", optimizations.size()));
         this.resetEffectivenessTracking();
      } catch (Exception e) {
         this.plugin.getLogger().warning(String.format("§c[AdaptiveML] Failed to apply optimizations: %s", e.getMessage()));
      }

   }

   private void applySpecificOptimization(String optimizationType, Object value) {
      switch (optimizationType) {
         case "speed_multiplier":
            if (this.autoConfig != null) {
               this.autoConfig.adjustSpeedThresholds((Double)value);
            }
            break;
         case "violation_threshold_multiplier":
            if (this.autoConfig != null) {
               this.autoConfig.adjustViolationThresholds((Double)value);
            }
            break;
         case "ml_confidence_increase":
         case "ml_confidence_decrease":
            if (this.autoConfig != null) {
               this.autoConfig.adjustMLConfidence((Double)value);
            }
            break;
         case "ping_compensation_increase":
            if (this.autoConfig != null) {
               this.autoConfig.adjustPingCompensation((Double)value);
            }
            break;
         case "legacy_mode_enhancement":
         case "modern_features_optimization":
            if (this.autoConfig != null) {
               this.autoConfig.applyVersionSpecificOptimizations(optimizationType);
            }
            break;
         default:
            this.plugin.getLogger().info(String.format("§d[AdaptiveML] Applied optimization: %s", optimizationType));
      }

   }

   public void recordViolation(Player player, String checkType, boolean confirmed) {
      String key = checkType.toLowerCase();
      this.violationHistory.merge(key, 1, Integer::sum);
      if (confirmed) {
         this.settingsEffectiveness.merge(key, 0.05, Double::sum);
      } else {
         this.settingsEffectiveness.merge(key, -0.1, Double::sum);
         this.performanceMetrics.merge("false_positive_rate", 0.01, Double::sum);
      }

   }

   private boolean analyzeTrend(List<PerformanceSnapshot> snapshots2, Function<PerformanceSnapshot, Double> getter) {
      return this.analyzeTrend(snapshots2, getter, 0.05);
   }

   private boolean analyzeTrend(List<PerformanceSnapshot> snapshots2, Function<PerformanceSnapshot, Double> getter, double threshold) {
      if (snapshots2.size() < 3) {
         return true;
      } else {
         double recent = (Double)getter.apply((PerformanceSnapshot)snapshots2.get(0));
         double older = (Double)getter.apply((PerformanceSnapshot)snapshots2.get(snapshots2.size() - 1));
         return recent - older >= threshold;
      }
   }

   private double calculateOverallEffectiveness(List<PerformanceSnapshot> recent) {
      double avgTPS = recent.stream().mapToDouble(PerformanceSnapshot::getTps).average().orElse((double)20.0F);
      double avgViolations = recent.stream().mapToDouble(PerformanceSnapshot::getViolationRate).average().orElse((double)0.0F);
      return avgTPS / (double)20.0F * Math.max(0.1, (double)1.0F - avgViolations / (double)10.0F);
   }

   private void adjustEffectivenessScores(double adjustment) {
      this.settingsEffectiveness.replaceAll((k, v) -> v + adjustment);
   }

   private double calculateOptimizationImpact(Map<String, Object> optimizations) {
      return (double)optimizations.size() * 0.1;
   }

   private void resetEffectivenessTracking() {
      this.settingsEffectiveness.replaceAll((k, v) -> (double)1.0F);
   }

   public Map<String, Double> getPerformanceMetrics() {
      return new HashMap(this.performanceMetrics);
   }

   private static class PerformanceSnapshot {
      private final double tps;
      private final double violationRate;

      public PerformanceSnapshot(long timestamp, double tps, double avgPing, int playerCount, double violationRate) {
         this.tps = tps;
         this.violationRate = violationRate;
      }

      public double getTps() {
         return this.tps;
      }

      public double getViolationRate() {
         return this.violationRate;
      }
   }
}
