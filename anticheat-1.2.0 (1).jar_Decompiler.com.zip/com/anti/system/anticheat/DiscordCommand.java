package com.anti.system.anticheat;

import java.util.Arrays;
import java.util.List;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

public class DiscordCommand implements CommandExecutor, TabCompleter {
   private final AntiCheatPlugin plugin;
   private final DiscordWebhookManager discordManager;

   public DiscordCommand(AntiCheatPlugin plugin) {
      this.plugin = plugin;
      this.discordManager = plugin.getDiscordManager();
   }

   public boolean onCommand(CommandSender sender, Command command, String label, String[] args2) {
      if (!sender.hasPermission("antisystem.discord")) {
         sender.sendMessage("§cNo permission!");
         return true;
      } else if (args2.length == 0) {
         this.sendHelp(sender);
         return true;
      } else {
         switch (args2[0].toLowerCase()) {
            case "status":
               this.handleStatus(sender);
               break;
            case "test":
               this.handleTest(sender, args2);
               break;
            case "reload":
               this.handleReload(sender);
               break;
            case "toggle":
               this.handleToggle(sender);
               break;
            default:
               this.sendHelp(sender);
         }

         return true;
      }
   }

   private void sendHelp(CommandSender sender) {
      sender.sendMessage("§6=== Discord Integration Commands ===");
      sender.sendMessage("§e/discord status §7- Check Discord integration status");
      sender.sendMessage("§e/discord test [message] §7- Send test message to Discord");
      sender.sendMessage("§e/discord reload §7- Reload Discord configuration");
      sender.sendMessage("§e/discord toggle §7- Toggle Discord notifications");
   }

   private void handleStatus(CommandSender sender) {
      if (this.discordManager.isEnabled()) {
         sender.sendMessage("§7Discord Status: §aENABLED");
         sender.sendMessage("§7Webhook URL: §e" + this.getPartialWebhookUrl());
      } else {
         sender.sendMessage("§7Discord Status: §cDISABLED");
         sender.sendMessage("§7Configure webhook URL in config.yml to enable");
      }

   }

   private void handleTest(CommandSender sender, String[] args2) {
      if (!this.discordManager.isEnabled()) {
         sender.sendMessage("§cDiscord is not enabled!");
      } else {
         String message = "Test message from " + sender.getName();
         if (args2.length > 1) {
            message = String.join(" ", (CharSequence[])Arrays.copyOfRange(args2, 1, args2.length));
         }

         this.discordManager.sendServerAlert("TEST", message, DiscordWebhookManager.AlertLevel.INFO);
         sender.sendMessage("§aTest message sent to Discord!");
         if (sender instanceof Player) {
            Player player = (Player)sender;
            this.discordManager.sendViolationAlert(player, "TEST_CHECK", "This is a test violation for Discord integration", 99);
            sender.sendMessage("§aTest violation alert also sent!");
         }

      }
   }

   private void handleReload(CommandSender sender) {
      try {
         this.plugin.reloadConfig();
         this.discordManager.reload();
         sender.sendMessage("§aDiscord configuration reloaded!");
         if (this.discordManager.isEnabled()) {
            sender.sendMessage("§7Discord is now: §aENABLED");
         } else {
            sender.sendMessage("§7Discord is now: §cDISABLED");
         }
      } catch (Exception e) {
         sender.sendMessage("§cFailed to reload Discord configuration: " + e.getMessage());
      }

   }

   private void handleToggle(CommandSender sender) {
      boolean currentState = this.plugin.getConfig().getBoolean("discord.enabled", false);
      this.plugin.getConfig().set("discord.enabled", !currentState ? 1 : 0);
      this.plugin.saveConfig();
      this.discordManager.reload();
      if (!currentState) {
         sender.sendMessage("§aDiscord notifications ENABLED");
         this.discordManager.sendServerAlert("DISCORD_ENABLED", "Discord notifications have been enabled by " + sender.getName(), DiscordWebhookManager.AlertLevel.SUCCESS);
      } else {
         sender.sendMessage("§cDiscord notifications DISABLED");
      }

   }

   private String getPartialWebhookUrl() {
      String webhookUrl = this.plugin.getConfig().getString("discord.webhook_url", "");
      if (webhookUrl.isEmpty()) {
         return "Not configured";
      } else {
         return webhookUrl.length() > 20 ? "..." + webhookUrl.substring(webhookUrl.length() - 20) : webhookUrl;
      }
   }

   public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args2) {
      return args2.length == 1 ? Arrays.asList("status", "test", "reload", "toggle") : null;
   }
}
