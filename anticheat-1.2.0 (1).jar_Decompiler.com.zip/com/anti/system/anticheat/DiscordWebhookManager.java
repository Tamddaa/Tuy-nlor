package com.anti.system.anticheat;

import com.anti.system.libs.json.JSONArray;
import com.anti.system.libs.json.JSONObject;
import com.anti.system.libs.okhttp3.MediaType;
import com.anti.system.libs.okhttp3.OkHttpClient;
import com.anti.system.libs.okhttp3.Request;
import com.anti.system.libs.okhttp3.RequestBody;
import com.anti.system.libs.okhttp3.Response;
import com.anti.system.utils.VersionCompatibility;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.time.Instant;
import java.util.concurrent.CompletableFuture;
import java.util.logging.Level;
import org.bukkit.Bukkit;
import org.bukkit.Server;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

public class DiscordWebhookManager {
   private final JavaPlugin plugin;
   private final OkHttpClient client;
   private String webhookUrl;
   private boolean enabled;
   private boolean debugMode;
   private String serverName;
   private String serverIcon;
   private String botName;
   private String botAvatar;

   public DiscordWebhookManager(JavaPlugin plugin) {
      this.plugin = plugin;
      this.client = new OkHttpClient();
      this.loadConfiguration();
   }

   private void loadConfiguration() {
      this.enabled = this.plugin.getConfig().getBoolean("discord.enabled", false);
      this.webhookUrl = this.plugin.getConfig().getString("discord.webhook_url", "");
      this.debugMode = this.plugin.getConfig().getBoolean("discord.debug", false);
      this.serverName = this.plugin.getConfig().getString("discord.server_name", "AntiCheat Server");
      this.serverIcon = this.plugin.getConfig().getString("discord.server_icon", "https://cdn.discordapp.com/attachments/123456789/shield.png");
      this.botName = this.plugin.getConfig().getString("discord.bot_name", "AntiCheat Security");
      this.botAvatar = this.plugin.getConfig().getString("discord.bot_avatar", "https://cdn.discordapp.com/attachments/123456789/bot.png");
      if (this.enabled && (this.webhookUrl == null || this.webhookUrl.isEmpty())) {
         this.plugin.getLogger().warning("Discord webhook is enabled but no URL is configured!");
         this.enabled = false;
      }

   }

   public void sendViolationAlert(Player player, String checkType, String reason, int violationLevel) {
      if (this.enabled) {
         CompletableFuture.runAsync(() -> {
            try {
               JSONObject embed = (new JSONObject()).put("title", "\ud83d\udea8 **CHEAT DETECTION ALERT**").put("description", "Suspicious activity detected on the server").put("color", this.getColorForViolation(violationLevel)).put("timestamp", Instant.now().toString()).put("footer", (new JSONObject()).put("text", this.serverName + " • AntiCheat System").put("icon_url", this.serverIcon)).put("thumbnail", (new JSONObject()).put("url", "https://crafatar.com/avatars/" + player.getUniqueId() + "?overlay")).put("fields", (new JSONArray()).put((new JSONObject()).put("name", "\ud83d\udc64 Player").put("value", "```" + player.getName() + "```").put("inline", true)).put((new JSONObject()).put("name", "\ud83d\udd0d Check Type").put("value", "```" + checkType + "```").put("inline", true)).put((new JSONObject()).put("name", "⚠️ Violation Level").put("value", "```" + violationLevel + "```").put("inline", true)).put((new JSONObject()).put("name", "\ud83d\udcdd Reason").put("value", "```" + reason + "```").put("inline", false)).put((new JSONObject()).put("name", "\ud83c\udf0d Location").put("value", "```World: " + player.getWorld().getName() + "\nX: " + (int)player.getLocation().getX() + ", Y: " + (int)player.getLocation().getY() + ", Z: " + (int)player.getLocation().getZ() + "```").put("inline", false)).put((new JSONObject()).put("name", "\ud83c\udfae Game Info").put("value", "```Health: " + (int)player.getHealth() + "/20\nGamemode: " + player.getGameMode().name() + "\nPing: " + VersionCompatibility.getPing(player) + "ms```").put("inline", false)));
               this.sendWebhook(embed);
            } catch (RuntimeException | IOException e) {
               this.plugin.getLogger().log(Level.WARNING, "Failed to send Discord violation alert", e);
            }

         });
      }
   }

   public void sendStaffAction(String staffName, String action, String targetPlayer, String reason) {
      if (this.enabled) {
         CompletableFuture.runAsync(() -> {
            try {
               JSONObject embed = (new JSONObject()).put("title", "\ud83d\udc6e **STAFF ACTION PERFORMED**").put("description", "A staff member has taken moderation action").put("color", 65280).put("timestamp", Instant.now().toString()).put("footer", (new JSONObject()).put("text", this.serverName + " • Staff Management").put("icon_url", this.serverIcon)).put("fields", (new JSONArray()).put((new JSONObject()).put("name", "\ud83d\udc64 Staff Member").put("value", "```" + staffName + "```").put("inline", true)).put((new JSONObject()).put("name", "⚡ Action").put("value", "```" + action + "```").put("inline", true)).put((new JSONObject()).put("name", "\ud83c\udfaf Target").put("value", "```" + targetPlayer + "```").put("inline", true)).put((new JSONObject()).put("name", "\ud83d\udcdd Reason").put("value", "```" + reason + "```").put("inline", false)));
               this.sendWebhook(embed);
            } catch (RuntimeException | IOException e) {
               this.plugin.getLogger().log(Level.WARNING, "Failed to send Discord staff action", e);
            }

         });
      }
   }

   public void sendPlayerEvent(Player player, String eventType) {
      if (this.enabled) {
         if (this.debugMode || this.isVIPPlayer(player)) {
            CompletableFuture.runAsync(() -> {
               try {
                  boolean isJoin = eventType.equals("JOIN");
                  JSONObject embed = (new JSONObject()).put("title", isJoin ? "✅ **PLAYER JOINED**" : "❌ **PLAYER LEFT**").put("description", player.getName() + " has " + (isJoin ? "joined" : "left") + " the server").put("color", isJoin ? '\uff00' : 16711680).put("timestamp", Instant.now().toString()).put("footer", (new JSONObject()).put("text", this.serverName + " • Player Events").put("icon_url", this.serverIcon)).put("thumbnail", (new JSONObject()).put("url", "https://crafatar.com/avatars/" + player.getUniqueId() + "?overlay")).put("fields", (new JSONArray()).put((new JSONObject()).put("name", "\ud83d\udc64 Player").put("value", "```" + player.getName() + "```").put("inline", true)).put((new JSONObject()).put("name", "\ud83d\udc65 Online Players").put("value", "```" + Bukkit.getOnlinePlayers().size() + "/" + Bukkit.getMaxPlayers() + "```").put("inline", true)));
                  this.sendWebhook(embed);
               } catch (RuntimeException | IOException e) {
                  this.plugin.getLogger().log(Level.WARNING, "Failed to send Discord player event", e);
               }

            });
         }
      }
   }

   public void sendServerAlert(String alertType, String message, AlertLevel level) {
      if (this.enabled) {
         CompletableFuture.runAsync(() -> {
            try {
               JSONObject embed = (new JSONObject()).put("title", this.getAlertIcon(level) + " **SERVER ALERT**").put("description", message).put("color", this.getColorForAlert(level)).put("timestamp", Instant.now().toString()).put("footer", (new JSONObject()).put("text", this.serverName + " • System Alerts").put("icon_url", this.serverIcon)).put("fields", (new JSONArray()).put((new JSONObject()).put("name", "\ud83c\udff7️ Alert Type").put("value", "```" + alertType + "```").put("inline", true)).put((new JSONObject()).put("name", "\ud83d\udcca Server Status").put("value", "```Players: " + Bukkit.getOnlinePlayers().size() + "/" + Bukkit.getMaxPlayers() + "\nTPS: " + String.format("%.2f", this.getCurrentTPS()) + "```").put("inline", true)));
               this.sendWebhook(embed);
            } catch (RuntimeException | IOException e) {
               this.plugin.getLogger().log(Level.WARNING, "Failed to send Discord server alert", e);
            }

         });
      }
   }

   public void sendHelpRequest(Player player, String message) {
      if (this.enabled) {
         CompletableFuture.runAsync(() -> {
            try {
               JSONObject embed = (new JSONObject()).put("title", "\ud83c\udd98 **HELP REQUEST**").put("description", "A player needs assistance").put("color", 16776960).put("timestamp", Instant.now().toString()).put("footer", (new JSONObject()).put("text", this.serverName + " • Help System").put("icon_url", this.serverIcon)).put("thumbnail", (new JSONObject()).put("url", "https://crafatar.com/avatars/" + player.getUniqueId() + "?overlay")).put("fields", (new JSONArray()).put((new JSONObject()).put("name", "\ud83d\udc64 Player").put("value", "```" + player.getName() + "```").put("inline", true)).put((new JSONObject()).put("name", "\ud83c\udf0d Location").put("value", "```" + player.getWorld().getName() + " (" + (int)player.getLocation().getX() + ", " + (int)player.getLocation().getY() + ", " + (int)player.getLocation().getZ() + ")```").put("inline", true)).put((new JSONObject()).put("name", "\ud83d\udcac Message").put("value", "```" + message + "```").put("inline", false)));
               this.sendWebhook(embed);
            } catch (RuntimeException | IOException e) {
               this.plugin.getLogger().log(Level.WARNING, "Failed to send Discord help request", e);
            }

         });
      }
   }

   private void sendWebhook(JSONObject embed) throws IOException {
      JSONObject payload = (new JSONObject()).put("username", this.botName).put("avatar_url", this.botAvatar).put("embeds", (new JSONArray()).put(embed));
      RequestBody body = RequestBody.create(MediaType.get("application/json; charset=utf-8"), payload.toString());
      Request request = (new Request.Builder()).url(this.webhookUrl).post(body).build();
      Response response = this.client.newCall(request).execute();

      try {
         if (!response.isSuccessful()) {
            this.plugin.getLogger().log(Level.WARNING, "Discord webhook failed with code: {0}", String.valueOf(response.code()));
         } else if (this.debugMode) {
            this.plugin.getLogger().info("Discord webhook sent successfully");
         }
      } catch (Throwable var9) {
         if (response != null) {
            try {
               response.close();
            } catch (Throwable var8) {
               var9.addSuppressed(var8);
            }
         }

         throw var9;
      }

      if (response != null) {
         response.close();
      }

   }

   private int getColorForViolation(int violationLevel) {
      if (violationLevel >= 50) {
         return 16711680;
      } else if (violationLevel >= 30) {
         return 16747520;
      } else {
         return violationLevel >= 15 ? 16776960 : '뿿';
      }
   }

   private int getColorForAlert(AlertLevel level) {
      switch (level.ordinal()) {
         case 0:
            return 16711680;
         case 1:
            return 16747520;
         case 2:
            return 49151;
         case 3:
            return 65280;
         default:
            return 8421504;
      }
   }

   private String getAlertIcon(AlertLevel level) {
      switch (level.ordinal()) {
         case 0:
            return "\ud83d\udd34";
         case 1:
            return "\ud83d\udfe0";
         case 2:
            return "\ud83d\udd35";
         case 3:
            return "\ud83d\udfe2";
         default:
            return "⚪";
      }
   }

   private boolean isVIPPlayer(Player player) {
      return player.hasPermission("antisystem.vip") || player.hasPermission("antisystem.staff") || player.isOp();
   }

   private double getCurrentTPS() {
      try {
         Server server = Bukkit.getServer();
         Method getTPS = server.getClass().getMethod("getTPS");
         double[] tpsArray = (double[])getTPS.invoke(server);
         return tpsArray[0];
      } catch (IllegalAccessException | InvocationTargetException | ClassCastException | NoSuchMethodException var5) {
         try {
            Server server = Bukkit.getServer();
            Method getTicksPerSecond = server.getClass().getMethod("getTicksPerSecond");
            return (Double)getTicksPerSecond.invoke(server);
         } catch (IllegalAccessException | InvocationTargetException | ClassCastException | NoSuchMethodException var4) {
            return (double)20.0F;
         }
      }
   }

   public void reload() {
      this.loadConfiguration();
      this.plugin.getLogger().info("Discord configuration reloaded");
   }

   public boolean isEnabled() {
      return this.enabled;
   }

   public static enum AlertLevel {
      CRITICAL,
      WARNING,
      INFO,
      SUCCESS;

      // $FF: synthetic method
      private static AlertLevel[] $values() {
         return new AlertLevel[]{CRITICAL, WARNING, INFO, SUCCESS};
      }
   }
}
