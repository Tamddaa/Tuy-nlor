package com.anti.system.anticheat;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

public class DiscordEventListener implements Listener {
   private final DiscordWebhookManager discordManager;

   public DiscordEventListener(DiscordWebhookManager discordManager) {
      this.discordManager = discordManager;
   }

   @EventHandler(
      priority = EventPriority.MONITOR
   )
   public void onPlayerJoin(PlayerJoinEvent event) {
      Player player = event.getPlayer();
      this.discordManager.sendPlayerEvent(player, "JOIN");
   }

   @EventHandler(
      priority = EventPriority.MONITOR
   )
   public void onPlayerQuit(PlayerQuitEvent event) {
      Player player = event.getPlayer();
      this.discordManager.sendPlayerEvent(player, "LEAVE");
   }
}
