package com.anti.system.anticheat;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.logging.Level;
import org.bukkit.plugin.java.JavaPlugin;

public class DatabaseManager {
   private final JavaPlugin plugin;
   private Connection connection;
   private final String dbPath;

   public DatabaseManager(JavaPlugin plugin) {
      this.plugin = plugin;
      this.dbPath = plugin.getDataFolder().getAbsolutePath() + File.separator + "anticheat.db";
      this.initializeDatabase();
   }

   private void initializeDatabase() {
      try {
         Class.forName("org.sqlite.JDBC");
         this.connection = DriverManager.getConnection("jdbc:sqlite:" + this.dbPath);
         this.createTables();
         this.plugin.getLogger().info("AntiCheat database initialized successfully.");
      } catch (SQLException | ClassNotFoundException e) {
         this.plugin.getLogger().log(Level.SEVERE, "Failed to initialize database", e);
      }

   }

   private void createTables() throws SQLException {
      String createViolationsTable = "CREATE TABLE IF NOT EXISTS violations (id INTEGER PRIMARY KEY AUTOINCREMENT,player_uuid TEXT NOT NULL,player_name TEXT NOT NULL,violation_type TEXT NOT NULL,reason TEXT,timestamp DATETIME DEFAULT CURRENT_TIMESTAMP)";
      String createStaffActionsTable = "CREATE TABLE IF NOT EXISTS staff_actions (id INTEGER PRIMARY KEY AUTOINCREMENT,staff_uuid TEXT NOT NULL,player_uuid TEXT NOT NULL,action TEXT NOT NULL,reason TEXT,timestamp DATETIME DEFAULT CURRENT_TIMESTAMP)";
      String createPlayerNotesTable = "CREATE TABLE IF NOT EXISTS player_notes (id INTEGER PRIMARY KEY AUTOINCREMENT,player_uuid TEXT NOT NULL,staff_uuid TEXT NOT NULL,note TEXT NOT NULL,timestamp DATETIME DEFAULT CURRENT_TIMESTAMP)";
      String createHelpRequestsTable = "CREATE TABLE IF NOT EXISTS help_requests (id INTEGER PRIMARY KEY AUTOINCREMENT,player_uuid TEXT NOT NULL,player_name TEXT NOT NULL,request TEXT NOT NULL,status TEXT DEFAULT 'PENDING',staff_uuid TEXT,timestamp DATETIME DEFAULT CURRENT_TIMESTAMP)";
      Statement stmt = this.connection.createStatement();

      try {
         stmt.execute(createViolationsTable);
         stmt.execute(createStaffActionsTable);
         stmt.execute(createPlayerNotesTable);
         stmt.execute(createHelpRequestsTable);
      } catch (Throwable var9) {
         if (stmt != null) {
            try {
               stmt.close();
            } catch (Throwable var8) {
               var9.addSuppressed(var8);
            }
         }

         throw var9;
      }

      if (stmt != null) {
         stmt.close();
      }

   }

   public void logViolation(UUID playerUuid, String playerName, String violationType, String reason) {
      String sql = "INSERT INTO violations (player_uuid, player_name, violation_type, reason) VALUES (?, ?, ?, ?)";

      try {
         PreparedStatement stmt = this.connection.prepareStatement(sql);

         try {
            stmt.setString(1, playerUuid.toString());
            stmt.setString(2, playerName);
            stmt.setString(3, violationType);
            stmt.setString(4, reason);
            stmt.executeUpdate();
         } catch (Throwable var10) {
            if (stmt != null) {
               try {
                  stmt.close();
               } catch (Throwable var9) {
                  var10.addSuppressed(var9);
               }
            }

            throw var10;
         }

         if (stmt != null) {
            stmt.close();
         }
      } catch (SQLException e) {
         this.plugin.getLogger().log(Level.WARNING, "Failed to log violation", e);
      }

   }

   public List<Map<String, Object>> getPlayerViolations(UUID playerUuid) {
      ArrayList<Map<String, Object>> violations = new ArrayList();
      String sql = "SELECT * FROM violations WHERE player_uuid = ? ORDER BY timestamp DESC LIMIT 50";

      try {
         PreparedStatement stmt = this.connection.prepareStatement(sql);

         try {
            stmt.setString(1, playerUuid.toString());
            ResultSet rs = stmt.executeQuery();

            while(rs.next()) {
               HashMap<String, Object> violation = new HashMap();
               violation.put("id", rs.getInt("id"));
               violation.put("violation_type", rs.getString("violation_type"));
               violation.put("reason", rs.getString("reason"));
               violation.put("timestamp", rs.getString("timestamp"));
               violations.add(violation);
            }
         } catch (Throwable var8) {
            if (stmt != null) {
               try {
                  stmt.close();
               } catch (Throwable var7) {
                  var8.addSuppressed(var7);
               }
            }

            throw var8;
         }

         if (stmt != null) {
            stmt.close();
         }
      } catch (SQLException e) {
         this.plugin.getLogger().log(Level.WARNING, "Failed to get player violations", e);
      }

      return violations;
   }

   public void logStaffAction(UUID staffUuid, UUID playerUuid, String action, String reason, Long duration) {
      String sql = "INSERT INTO violations (player_uuid, player_name, violation_type, reason) VALUES (?, ?, ?, ?)";

      try {
         PreparedStatement stmt = this.connection.prepareStatement(sql);

         try {
            stmt.setString(1, playerUuid.toString());
            stmt.setString(2, "Unknown");
            stmt.setString(3, "STAFF_ACTION_" + action);
            stmt.setString(4, reason + (duration != null ? " (" + duration + " minutes)" : ""));
            stmt.executeUpdate();
         } catch (Throwable var11) {
            if (stmt != null) {
               try {
                  stmt.close();
               } catch (Throwable var10) {
                  var11.addSuppressed(var10);
               }
            }

            throw var11;
         }

         if (stmt != null) {
            stmt.close();
         }
      } catch (SQLException e) {
         this.plugin.getLogger().log(Level.WARNING, "Failed to log staff action", e);
      }

   }

   public Connection getConnection() {
      return this.connection;
   }

   public int getTotalReports() {
      String sql = "SELECT COUNT(*) FROM help_requests";

      try {
         PreparedStatement stmt = this.connection.prepareStatement(sql);

         int n;
         label50: {
            int var5;
            try {
               ResultSet rs = stmt.executeQuery();
               if (!rs.next()) {
                  n = 0;
                  break label50;
               }

               n = rs.getInt(1);
               var5 = n;
            } catch (Throwable var7) {
               if (stmt != null) {
                  try {
                     stmt.close();
                  } catch (Throwable var6) {
                     var7.addSuppressed(var6);
                  }
               }

               throw var7;
            }

            if (stmt != null) {
               stmt.close();
            }

            return var5;
         }

         if (stmt != null) {
            stmt.close();
         }

         return n;
      } catch (SQLException e) {
         this.plugin.getLogger().log(Level.WARNING, "Failed to get total reports", e);
         return 0;
      }
   }

   public List<String> getPendingReports() {
      ArrayList<String> reports = new ArrayList();
      String sql = "SELECT player_name, request FROM help_requests WHERE status = 'PENDING' ORDER BY timestamp DESC LIMIT 10";

      try {
         PreparedStatement stmt = this.connection.prepareStatement(sql);

         try {
            ResultSet rs = stmt.executeQuery();

            while(rs.next()) {
               reports.add(rs.getString("player_name") + ": " + rs.getString("request"));
            }
         } catch (Throwable var7) {
            if (stmt != null) {
               try {
                  stmt.close();
               } catch (Throwable var6) {
                  var7.addSuppressed(var6);
               }
            }

            throw var7;
         }

         if (stmt != null) {
            stmt.close();
         }
      } catch (SQLException e) {
         this.plugin.getLogger().log(Level.WARNING, "Failed to get pending reports", e);
      }

      return reports;
   }

   public void addPlayerNote(UUID playerUuid, UUID staffUuid, String note) {
      String sql = "INSERT INTO player_notes (player_uuid, staff_uuid, note) VALUES (?, ?, ?)";

      try {
         PreparedStatement stmt = this.connection.prepareStatement(sql);

         try {
            stmt.setString(1, playerUuid.toString());
            stmt.setString(2, staffUuid.toString());
            stmt.setString(3, note);
            stmt.executeUpdate();
         } catch (Throwable var9) {
            if (stmt != null) {
               try {
                  stmt.close();
               } catch (Throwable var8) {
                  var9.addSuppressed(var8);
               }
            }

            throw var9;
         }

         if (stmt != null) {
            stmt.close();
         }
      } catch (SQLException e) {
         this.plugin.getLogger().log(Level.WARNING, "Failed to add player note", e);
      }

   }

   public List<String> getPendingHelpRequests() {
      ArrayList<String> requests = new ArrayList();
      String sql = "SELECT id, player_name, request, timestamp FROM help_requests WHERE status = 'PENDING' ORDER BY timestamp ASC";

      try {
         PreparedStatement stmt = this.connection.prepareStatement(sql);

         try {
            ResultSet rs = stmt.executeQuery();

            while(rs.next()) {
               requests.add("#" + rs.getInt("id") + " " + rs.getString("player_name") + ": " + rs.getString("request") + " (" + rs.getString("timestamp") + ")");
            }
         } catch (Throwable var7) {
            if (stmt != null) {
               try {
                  stmt.close();
               } catch (Throwable var6) {
                  var7.addSuppressed(var6);
               }
            }

            throw var7;
         }

         if (stmt != null) {
            stmt.close();
         }
      } catch (SQLException e) {
         this.plugin.getLogger().log(Level.WARNING, "Failed to get pending help requests", e);
      }

      return requests;
   }

   public void closeConnection() {
      try {
         if (this.connection != null && !this.connection.isClosed()) {
            this.connection.close();
         }
      } catch (SQLException e) {
         this.plugin.getLogger().log(Level.WARNING, "Failed to close database connection", e);
      }

   }
}
