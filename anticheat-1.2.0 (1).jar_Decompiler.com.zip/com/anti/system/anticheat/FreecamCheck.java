package com.anti.system.anticheat;

import com.anti.system.utils.BypassUtils;
import java.util.HashMap;
import java.util.Map;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerGameModeChangeEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.plugin.java.JavaPlugin;

public class FreecamCheck implements Check, Listener {
   private final JavaPlugin plugin = (JavaPlugin)Bukkit.getPluginManager().getPlugin("AntiCheat");
   private final Map<Player, FreecamProfile> playerProfiles = new HashMap();
   private boolean enabled = true;
   private long violationResetTime = 30000L;
   private double minFreecamDistance = (double)64.0F;

   public FreecamCheck() {
      this.loadConfig();
   }

   private void loadConfig() {
      if (this.plugin != null) {
         FileConfiguration config = this.plugin.getConfig();
         this.enabled = false;
         this.violationResetTime = Math.max(this.violationResetTime, config.getLong("anticheat.freecam.violation_reset_time", 30L) * 1000L);
         this.minFreecamDistance = Math.max((double)64.0F, config.getDouble("anticheat.freecam.min_detection_distance", (double)64.0F));
      }

   }

   public String getName() {
      return "FreecamDetection";
   }

   public void handle(Player player, Object... context) {
      try {
         if (!this.enabled) {
            return;
         }

         if (context.length < 2 || !(context[0] instanceof Location) || !(context[1] instanceof Location)) {
            return;
         }

         Location from = (Location)context[0];
         Location to = (Location)context[1];
         if (from == null || to == null || from.getWorld() == null || to.getWorld() == null) {
            return;
         }

         this.checkFreecamMovement(player, from, to);
      } catch (Exception var5) {
      }

   }

   @EventHandler
   public void onPlayerMove(PlayerMoveEvent event) {
      if (this.enabled) {
         Player player = event.getPlayer();
         if (!BypassUtils.hasAntiCheatBypass(player)) {
            if (player.getGameMode() != GameMode.SPECTATOR || !player.hasPermission("antisystem.staff")) {
               if (player.getGameMode() != GameMode.SPECTATOR) {
                  Location from = event.getFrom();
                  Location to = event.getTo();
                  if (to != null) {
                     this.checkFreecamMovement(player, from, to);
                  }
               }
            }
         }
      }
   }

   @EventHandler
   public void onGameModeChange(PlayerGameModeChangeEvent event) {
      Player player = event.getPlayer();
      if (event.getNewGameMode() == GameMode.SPECTATOR && player.hasPermission("antisystem.staff")) {
         this.playerProfiles.remove(player);
      }

   }

   private void checkFreecamMovement(Player player, Location from, Location to) {
      if (this.enabled && !player.hasPermission("antisystem.bypass.freecam")) {
         FreecamProfile profile = (FreecamProfile)this.playerProfiles.computeIfAbsent(player, (k) -> new FreecamProfile());
         if (this.isPhaseMovement(from, to)) {
            profile.addViolation();
            PlayerBehaviorLogger.log(player, "freecam_detection", String.format("Phase movement detected: from=%.2f,%.2f,%.2f to=%.2f,%.2f,%.2f violations=%d", from.getX(), from.getY(), from.getZ(), to.getX(), to.getY(), to.getZ(), profile.getViolations()));
            this.handleViolation(profile);
         }

         if (this.isImpossibleVerticalMovement(from, to)) {
            profile.addViolation();
            PlayerBehaviorLogger.log(player, "freecam_y_movement", String.format("Impossible Y movement: from=%.2f to=%.2f violations=%d", from.getY(), to.getY(), profile.getViolations()));
            this.handleViolation(profile);
         }

         profile.updateLastPosition(to);
      }
   }

   private boolean isPhaseMovement(Location from, Location to) {
      if (!from.getWorld().equals(to.getWorld())) {
         return false;
      } else {
         double distance = from.distance(to);
         if (distance < this.minFreecamDistance) {
            return false;
         } else {
            int steps = (int)Math.ceil(distance * (double)2.0F);

            for(int i = 1; i < steps; ++i) {
               double ratio = (double)i / (double)steps;
               Location checkLoc = from.clone().add((to.getX() - from.getX()) * ratio, (to.getY() - from.getY()) * ratio, (to.getZ() - from.getZ()) * ratio);
               Block block = checkLoc.getBlock();
               Block blockAbove = checkLoc.clone().add((double)0.0F, (double)1.0F, (double)0.0F).getBlock();
               if (this.isSolidBlock(block) && this.isSolidBlock(blockAbove)) {
                  return true;
               }
            }

            return false;
         }
      }
   }

   private boolean isImpossibleVerticalMovement(Location from, Location to) {
      double yDiff = to.getY() - from.getY();
      if (yDiff > (double)3.0F) {
         for(int y = 1; (double)y <= Math.ceil(yDiff); ++y) {
            Block block = from.clone().add((double)0.0F, (double)y, (double)0.0F).getBlock();
            if (this.isSolidBlock(block)) {
               return true;
            }
         }
      }

      if (yDiff < (double)-3.0F) {
         for(int y = -1; (double)y >= Math.floor(yDiff); --y) {
            Block block = from.clone().add((double)0.0F, (double)y, (double)0.0F).getBlock();
            if (this.isSolidBlock(block)) {
               return true;
            }
         }
      }

      return false;
   }

   private boolean isSolidBlock(Block block) {
      Material type = block.getType();
      return type.isSolid() && type != Material.AIR && type != Material.WATER && type != Material.LAVA && !type.name().contains("SIGN") && !type.name().contains("BANNER") && !type.name().contains("CARPET") && type != Material.SNOW;
   }

   private void handleViolation(FreecamProfile profile) {
      if (System.currentTimeMillis() - profile.getLastViolation() > this.violationResetTime) {
         profile.resetViolations();
      }

      if (profile.getViolations() > 5) {
         profile.resetViolations();
      }

   }

   private static class FreecamProfile {
      private int violations;
      private long lastViolation;

      private FreecamProfile() {
         this.violations = 0;
         this.lastViolation = 0L;
      }

      public void addViolation() {
         ++this.violations;
         this.lastViolation = System.currentTimeMillis();
      }

      public int getViolations() {
         return this.violations;
      }

      public long getLastViolation() {
         return this.lastViolation;
      }

      public void resetViolations() {
         this.violations = 0;
      }

      public void updateLastPosition(Location location) {
      }
   }
}
