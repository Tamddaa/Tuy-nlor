package com.anti.system.anticheat;

import com.anti.system.anticheat.advanced.AdvancedAntiCheatSystem;
import com.anti.system.anticheat.advanced.EnhancedMLEngine;
import com.anti.system.gui.AdminDashboard;
import com.anti.system.staff.BanCommand;
import com.anti.system.staff.BtpCommand;
import com.anti.system.staff.FreezeCommand;
import com.anti.system.staff.HelpOpCommand;
import com.anti.system.staff.HelpOpManager;
import com.anti.system.staff.InvseeCommand;
import com.anti.system.staff.KickCommand;
import com.anti.system.staff.LocateCommand;
import com.anti.system.staff.MacroCommand;
import com.anti.system.staff.MacroManager;
import com.anti.system.staff.MuteCommand;
import com.anti.system.staff.NoteCommand;
import com.anti.system.staff.NoteManager;
import com.anti.system.staff.PunishmentManager;
import com.anti.system.staff.QuickModCommand;
import com.anti.system.staff.ReasonCommand;
import com.anti.system.staff.ReasonManager;
import com.anti.system.staff.SmartTeleportCommand;
import com.anti.system.staff.StaffChatListener;
import com.anti.system.staff.StaffCommand;
import com.anti.system.staff.StaffGUIListener;
import com.anti.system.staff.StaffManager;
import com.anti.system.staff.StaffModeCommand;
import com.anti.system.staff.StpCommand;
import com.anti.system.staff.UnbanCommand;
import com.anti.system.staff.UnmuteCommand;
import com.anti.system.staff.VanishCommand;
import com.anti.system.staff.VanishManager;
import com.anti.system.staff.WarnCommand;
import com.anti.system.staff.WhoisCommand;
import com.anti.system.utils.AutoConfigurationSystem;
import com.anti.system.utils.DiscordIntegration;
import com.anti.system.utils.PlaceholderIntegration;
import com.anti.system.utils.SpamFreeLogger;
import com.anti.system.utils.VersionCompatibility;
import com.anti.system.utils.VersionUtils;
import org.bukkit.Bukkit;
import org.bukkit.command.PluginCommand;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

public class AntiCheatPlugin extends JavaPlugin {
   private SpamFreeLogger spamFreeLogger;
   private EnhancedMLEngine mlEngine;
   private AdvancedMLEngine advancedMLEngine;
   private DiscordWebhookManager discordManager;
   private DiscordIntegration discordIntegration;
   private AntiCheatListener antiCheatListener;
   private AntiVPNListener antiVPNListener;
   private DatabaseManager databaseManager;
   private AdvancedAntiCheatSystem advancedAntiCheat;
   private FlightBlocker flightBlocker;
   private CheckManager checkManager;
   private AntiCheatGUI antiCheatGUI;
   private PvPExploitDetection pvpExploitDetection;
   private IntelligentAutoConfig autoConfig;
   private AdaptiveMLDecisionEngine adaptiveML;
   private StaffManager staffManager;
   private PunishmentManager punishmentManager;
   private VanishManager vanishManager;
   private HelpOpManager helpOpManager;
   private NoteManager noteManager;
   private MacroManager macroManager;
   private ReasonManager reasonManager;
   private AdminDashboard adminDashboard;
   private PlaceholderIntegration placeholderIntegration;

   public void onEnable() {
      this.spamFreeLogger = new SpamFreeLogger(this);
      this.spamFreeLogger.info("STARTUP", "Enhanced AntiCheat Plugin v2.0 initializing...");
      this.spamFreeLogger.info("DISCORD_V2", "Initializing advanced Discord integration system...");
      this.discordIntegration = new DiscordIntegration(this);
      this.spamFreeLogger.info("ML_V2", "Initializing Advanced ML Detection Engine v2.0...");
      this.advancedMLEngine = new AdvancedMLEngine(this);
      if (VersionCompatibility.isPaper()) {
         this.spamFreeLogger.info("PAPER_OPTIMIZATION", "Paper server detected! Enabling Paper-specific optimizations...");
         this.enablePaperOptimizations();
      }

      this.spamFreeLogger.info("CONFIG", "Loading configuration files...");
      this.saveDefaultConfig();
      this.saveResource("bedrockac.yml", false);
      this.saveResource("staff.yml", false);
      this.saveResource("reasons.yml", false);
      this.spamFreeLogger.info("CONFIG", "Configuration files loaded successfully!");
      this.spamFreeLogger.info("ADAPTIVE_ML", "Initializing adaptive ML decision engine...");
      this.adaptiveML = new AdaptiveMLDecisionEngine(this, (IntelligentAutoConfig)null);
      this.spamFreeLogger.info("ADAPTIVE_ML", "Continuous learning system activated!");
      this.mlEngine = new EnhancedMLEngine(this);
      this.spamFreeLogger.info("ML_ENGINE", "Legacy ML engine initialized for compatibility");
      if (this.discordIntegration.isEnabled()) {
         this.discordIntegration.sendAlert((new DiscordIntegration.DiscordAlert(DiscordIntegration.AlertType.SYSTEM, DiscordIntegration.AlertLevel.MEDIUM, "AntiCheat v2.0 Initialized", "Advanced AntiCheat system has been successfully initialized with 100x improvements including:\n• Advanced ML Detection Engine with Neural Networks\n• Intelligent Auto-Configuration System\n• Enhanced Discord Integration\n• Real-time Performance Monitoring\n• Cross-version compatibility (1.8-1.21.8)", (Player)null, "Server: " + VersionUtils.getMinecraftVersion())).addField("Server Analysis", "Auto-configured based on server environment").addField("Optimization Profile", "Applied optimal settings").addField("ML Features", this.advancedMLEngine.isAdvancedFeaturesEnabled() ? "Advanced" : "Basic"));
      }

      this.discordManager = new DiscordWebhookManager(this);
      this.spamFreeLogger.info("DISCORD", "Legacy Discord webhook manager initialized for compatibility");
      if (this.discordManager.isEnabled()) {
         this.discordManager.sendServerAlert("SERVER_START", "AntiCheat system initialized with auto-optimized settings for " + VersionUtils.getMinecraftVersion() + "!", DiscordWebhookManager.AlertLevel.SUCCESS);
      }

      this.databaseManager = new DatabaseManager(this);
      this.checkManager = new CheckManager(this);
      this.checkManager.loadConfiguration();
      this.antiCheatListener = new AntiCheatListener(this);
      this.antiVPNListener = new AntiVPNListener(this);
      this.advancedAntiCheat = new AdvancedAntiCheatSystem(this);
      this.flightBlocker = new FlightBlocker(this);
      this.antiCheatGUI = new AntiCheatGUI(this, this.checkManager);
      this.pvpExploitDetection = new PvPExploitDetection(this, this.checkManager);
      this.staffManager = new StaffManager();
      this.punishmentManager = new PunishmentManager(this.databaseManager, this.discordManager);
      this.vanishManager = new VanishManager(this, this.staffManager);
      this.helpOpManager = new HelpOpManager(this, this.databaseManager, this.discordManager);
      this.noteManager = new NoteManager(this, this.databaseManager);
      this.macroManager = new MacroManager();
      this.reasonManager = new ReasonManager(this);
      Bukkit.getPluginManager().registerEvents(this.antiCheatListener, this);
      Bukkit.getPluginManager().registerEvents(this.antiVPNListener, this);
      Bukkit.getPluginManager().registerEvents(this.advancedAntiCheat, this);
      Bukkit.getPluginManager().registerEvents(this.flightBlocker, this);
      Bukkit.getPluginManager().registerEvents(new StaffChatListener(this.punishmentManager), this);
      Bukkit.getPluginManager().registerEvents(this.staffManager, this);
      Bukkit.getPluginManager().registerEvents(this.vanishManager, this);
      Bukkit.getPluginManager().registerEvents(new StaffGUIListener(this.staffManager), this);
      if (this.discordManager.isEnabled()) {
         Bukkit.getPluginManager().registerEvents(new DiscordEventListener(this.discordManager), this);
         this.spamFreeLogger.info("DISCORD", "Discord event listener registered");
      }

      Bukkit.getPluginManager().registerEvents(this.antiCheatGUI, this);
      Bukkit.getPluginManager().registerEvents(this.pvpExploitDetection, this);
      Bukkit.getPluginManager().registerEvents(new FallDamageProtection(), this);
      Bukkit.getPluginManager().registerEvents(new FreecamCheck(), this);
      Bukkit.getPluginManager().registerEvents(new BedrockAC(), this);
      PluginCommand anticheatCmd = this.getCommand("anticheat");
      if (anticheatCmd != null) {
         anticheatCmd.setExecutor(new AntiCheatCommand(this));
      }

      PluginCommand antivpnCmd = this.getCommand("antivpn");
      if (antivpnCmd != null) {
         antivpnCmd.setExecutor(new AntiVPNCommand(this.antiVPNListener));
      }

      PluginCommand antisystemreloadCmd = this.getCommand("antisystemreload");
      if (antisystemreloadCmd != null) {
         antisystemreloadCmd.setExecutor(new AntiSystemReloadCommand(this));
      }

      PluginCommand bedrockdebugCmd = this.getCommand("bedrockdebug");
      if (bedrockdebugCmd != null) {
         bedrockdebugCmd.setExecutor(new BedrockDebugCommand(this));
      }

      PluginCommand discordCmd = this.getCommand("discord");
      if (discordCmd != null) {
         discordCmd.setExecutor(new DiscordCommand(this));
      }

      PluginCommand staffCmd = this.getCommand("staff");
      if (staffCmd != null) {
         staffCmd.setExecutor(new StaffCommand(this.databaseManager, this.staffManager));
      }

      PluginCommand staffmodeCmd = this.getCommand("staffmode");
      if (staffmodeCmd != null) {
         staffmodeCmd.setExecutor(new StaffModeCommand(this.staffManager));
      }

      PluginCommand vanishCmd = this.getCommand("vanish");
      if (vanishCmd != null) {
         vanishCmd.setExecutor(new VanishCommand(this.staffManager));
      }

      PluginCommand freezeCmd = this.getCommand("freeze");
      if (freezeCmd != null) {
         freezeCmd.setExecutor(new FreezeCommand(this.staffManager));
      }

      PluginCommand banCmd = this.getCommand("ban");
      if (banCmd != null) {
         banCmd.setExecutor(new BanCommand(this.punishmentManager));
      }

      PluginCommand kickCmd = this.getCommand("kick");
      if (kickCmd != null) {
         kickCmd.setExecutor(new KickCommand());
      }

      PluginCommand muteCmd = this.getCommand("mute");
      if (muteCmd != null) {
         muteCmd.setExecutor(new MuteCommand(this.punishmentManager));
      }

      PluginCommand unbanCmd = this.getCommand("unban");
      if (unbanCmd != null) {
         unbanCmd.setExecutor(new UnbanCommand(this.punishmentManager));
      }

      PluginCommand unmuteCmd = this.getCommand("unmute");
      if (unmuteCmd != null) {
         unmuteCmd.setExecutor(new UnmuteCommand(this.punishmentManager));
      }

      PluginCommand warnCmd = this.getCommand("warn");
      if (warnCmd != null) {
         warnCmd.setExecutor(new WarnCommand(this.punishmentManager));
      }

      PluginCommand helpopCmd = this.getCommand("helpop");
      if (helpopCmd != null) {
         helpopCmd.setExecutor(new HelpOpCommand(this.helpOpManager));
      }

      PluginCommand noteCmd = this.getCommand("note");
      if (noteCmd != null) {
         noteCmd.setExecutor(new NoteCommand(this.noteManager));
      }

      PluginCommand macroCmd = this.getCommand("macro");
      if (macroCmd != null) {
         macroCmd.setExecutor(new MacroCommand(this.macroManager));
      }

      PluginCommand reasonCmd = this.getCommand("reason");
      if (reasonCmd != null) {
         reasonCmd.setExecutor(new ReasonCommand(this.reasonManager));
      }

      PluginCommand invseeCmd = this.getCommand("invsee");
      if (invseeCmd != null) {
         invseeCmd.setExecutor(new InvseeCommand());
      }

      PluginCommand locateCmd = this.getCommand("locate");
      if (locateCmd != null) {
         locateCmd.setExecutor(new LocateCommand());
      }

      PluginCommand stpCmd = this.getCommand("stp");
      if (stpCmd != null) {
         stpCmd.setExecutor(new StpCommand(this.staffManager));
      }

      PluginCommand btpCmd = this.getCommand("btp");
      if (btpCmd != null) {
         btpCmd.setExecutor(new BtpCommand(this.staffManager));
      }

      PluginCommand whoisCmd = this.getCommand("whois");
      if (whoisCmd != null) {
         whoisCmd.setExecutor(new WhoisCommand(this.staffManager, this.noteManager));
      }

      PluginCommand quickmodCmd = this.getCommand("quickmod");
      if (quickmodCmd != null) {
         quickmodCmd.setExecutor(new QuickModCommand());
      }

      PluginCommand smartteleportCmd = this.getCommand("smartteleport");
      if (smartteleportCmd != null) {
         smartteleportCmd.setExecutor(new SmartTeleportCommand(this.staffManager));
      }

      PluginCommand aistatsCmd = this.getCommand("aistats");
      if (aistatsCmd != null) {
         aistatsCmd.setExecutor((sender, cmd, label, args2) -> {
            if (!sender.hasPermission("antisystem.aistats")) {
               sender.sendMessage("No permission.");
               return true;
            } else {
               AntiCheatListener l = this.getAntiCheatListener();
               if (l == null) {
                  sender.sendMessage("Listener not ready.");
                  return true;
               } else {
                  sender.sendMessage("AI learning active - dynamic anomaly adaptation enabled.");
                  return true;
               }
            }
         });
      }

      this.spamFreeLogger.info("DASHBOARD", "Initializing Advanced Admin Dashboard...");
      this.adminDashboard = new AdminDashboard(this, this.advancedMLEngine, (AutoConfigurationSystem)null, this.discordIntegration);
      PluginCommand dashboardCmd = this.getCommand("dashboard");
      if (dashboardCmd != null) {
         dashboardCmd.setExecutor((sender, cmd, label, args2) -> {
            if (sender == null) {
               return true;
            } else if (!(sender instanceof Player)) {
               sender.sendMessage("§cThis command can only be used by players!");
               return true;
            } else if (!sender.hasPermission("anticheat.admin")) {
               sender.sendMessage("§cYou don't have permission to access the dashboard!");
               return true;
            } else {
               synchronized(this) {
                  AdminDashboard dashboard = this.adminDashboard;
                  if (dashboard != null) {
                     dashboard.openDashboard((Player)sender);
                  } else {
                     sender.sendMessage("§cAdmin dashboard is not available!");
                  }

                  return true;
               }
            }
         });
      }

      this.spamFreeLogger.info("PLACEHOLDERAPI", "Initializing PlaceholderAPI integration...");
      this.placeholderIntegration = new PlaceholderIntegration(this);
      if (this.placeholderIntegration.register()) {
         this.spamFreeLogger.info("PLACEHOLDERAPI", "PlaceholderAPI integration registered successfully!");
      } else {
         this.spamFreeLogger.warning("PLACEHOLDERAPI", "Failed to register PlaceholderAPI integration!");
      }

      this.spamFreeLogger.info("STARTUP", "AntiCheat Plugin v1.2.0 enabled successfully!");
      this.spamFreeLogger.info("SYSTEMS", "Active: AntiCheat, Anti-VPN, Staff Management, PvP Exploits, Enhanced ML");
      this.spamFreeLogger.info("FEATURES", "Advanced ML, GUI Interface, Interactive Help, Crystal/Anchor/Bed Aura Detection");
      this.spamFreeLogger.info("COMMANDS", "Staff commands: ban, kick, mute, warn, freeze, vanish, staff, invsee, locate, quickmod");
      this.spamFreeLogger.info("DETECTION", "Anti-cheat detection: Movement, Combat, World Interaction, Packets, PvP Exploits");
      this.spamFreeLogger.info("USAGE", "Use '/anticheat help' for interactive help or '/anticheat gui' for GUI interface");
      Bukkit.getScheduler().runTaskTimerAsynchronously(this, () -> {
         if (this.antiCheatListener != null) {
            this.antiCheatListener.performAIRetraining();
         }

      }, 6000L, 6000L);
   }

   public void onDisable() {
      if (this.antiCheatListener != null) {
         this.antiCheatListener.shutdownAI();
      }

      if (this.mlEngine != null) {
         this.mlEngine.shutdown();
      }

      if (this.databaseManager != null) {
         this.databaseManager.closeConnection();
      }

      if (this.discordManager != null && this.discordManager.isEnabled()) {
         this.discordManager.sendServerAlert("SERVER_STOP", "AntiCheat system is shutting down. Server protection temporarily disabled.", DiscordWebhookManager.AlertLevel.WARNING);
      }

      if (this.spamFreeLogger != null) {
         this.spamFreeLogger.info("SHUTDOWN", "Enhanced AntiCheat Plugin disabled successfully");
      }

   }

   public AntiCheatListener getAntiCheatListener() {
      return this.antiCheatListener;
   }

   public DiscordWebhookManager getDiscordManager() {
      return this.discordManager;
   }

   public EnhancedMLEngine getMLEngine() {
      return this.mlEngine;
   }

   public SpamFreeLogger getSpamFreeLogger() {
      return this.spamFreeLogger;
   }

   public IntelligentAutoConfig getAutoConfig() {
      return this.autoConfig;
   }

   public AdaptiveMLDecisionEngine getAdaptiveML() {
      return this.adaptiveML;
   }

   public DatabaseManager getDatabaseManager() {
      return this.databaseManager;
   }

   public AdvancedAntiCheatSystem getAdvancedAntiCheat() {
      return this.advancedAntiCheat;
   }

   public FlightBlocker getFlightBlocker() {
      return this.flightBlocker;
   }

   public CheckManager getCheckManager() {
      return this.checkManager;
   }

   private void enablePaperOptimizations() {
      try {
         if (VersionCompatibility.isVersionOrHigher(1, 13)) {
            this.spamFreeLogger.info("PAPER_OPTIMIZATION", "Async chunk loading optimizations enabled");
         }

         if (VersionCompatibility.isVersionOrHigher(1, 16)) {
            this.spamFreeLogger.info("PAPER_OPTIMIZATION", "Timings v2 optimization enabled");
         }

         if (VersionCompatibility.isVersionOrHigher(1, 19)) {
            this.spamFreeLogger.info("PAPER_OPTIMIZATION", "Enhanced packet processing enabled");
         }

         if (VersionCompatibility.supportsAdventure()) {
            this.spamFreeLogger.info("PAPER_OPTIMIZATION", "Adventure API text components enabled");
         }

         if (VersionCompatibility.supportsHex()) {
            this.spamFreeLogger.info("PAPER_OPTIMIZATION", "Hex color support enabled");
         }

         this.spamFreeLogger.info("PAPER_OPTIMIZATION", "All Paper optimizations successfully enabled!");
      } catch (Exception e) {
         this.spamFreeLogger.warning("PAPER_OPTIMIZATION", "Failed to enable some Paper optimizations: " + e.getMessage());
      }

   }
}
