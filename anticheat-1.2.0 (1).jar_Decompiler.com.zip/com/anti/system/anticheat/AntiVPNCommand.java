package com.anti.system.anticheat;

import java.util.Map;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.plugin.java.JavaPlugin;

public class AntiVPNCommand implements CommandExecutor {
   private final AntiVPNListener antiVPN;

   public AntiVPNCommand(AntiVPNListener antiVPN) {
      this.antiVPN = antiVPN;
   }

   public boolean onCommand(CommandSender sender, Command command, String label, String[] args2) {
      if (!sender.hasPermission("antivpn.admin")) {
         sender.sendMessage("§cYou don't have permission to use this command!");
         return true;
      } else if (args2.length == 0) {
         this.sendHelp(sender);
         return true;
      } else {
         switch (args2[0].toLowerCase()) {
            case "reload":
               this.antiVPN.reloadConfig();
               sender.sendMessage("§aAnti-VPN configuration reloaded!");
               break;
            case "check":
               if (args2.length < 2) {
                  sender.sendMessage("§cUsage: /antivpn check <ip>");
                  return true;
               }

               this.checkIP(sender, args2[1]);
               break;
            case "stats":
               this.showStats(sender);
               break;
            case "clear":
               this.antiVPN.clearCache();
               sender.sendMessage("§aAnti-VPN cache cleared!");
               break;
            default:
               this.sendHelp(sender);
         }

         return true;
      }
   }

   private void sendHelp(CommandSender sender) {
      sender.sendMessage("§6=== Anti-VPN Commands ===");
      sender.sendMessage("§e/antivpn reload - Reload configuration");
      sender.sendMessage("§e/antivpn check <ip> - Check if IP is VPN/Proxy");
      sender.sendMessage("§e/antivpn stats - Show cache statistics");
      sender.sendMessage("§e/antivpn clear - Clear IP cache");
   }

   private void checkIP(CommandSender sender, String ip) {
      sender.sendMessage("§eChecking IP: " + ip + "...");
      Bukkit.getScheduler().runTaskAsynchronously(JavaPlugin.getProvidingPlugin(this.getClass()), () -> {
         boolean isVPN = this.antiVPN.checkIP(ip);
         Bukkit.getScheduler().runTask(JavaPlugin.getProvidingPlugin(this.getClass()), () -> {
            if (isVPN) {
               sender.sendMessage("§cIP " + ip + " is detected as VPN/Proxy!");
            } else {
               sender.sendMessage("§aIP " + ip + " appears to be clean.");
            }

         });
      });
   }

   private void showStats(CommandSender sender) {
      Map<String, Object> stats = this.antiVPN.getCacheStats();
      sender.sendMessage("§6=== Anti-VPN Statistics ===");
      sender.sendMessage("§bCached IPs: " + stats.get("cached_ips"));
      sender.sendMessage("§cVPN/Proxy IPs: " + stats.get("vpn_ips"));
      sender.sendMessage("§aClean IPs: " + stats.get("clean_ips"));
   }
}
