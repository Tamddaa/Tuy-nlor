package com.anti.system.anticheat;

import com.anti.system.utils.VersionCompatibility;
import java.util.HashMap;
import java.util.Map;
import org.bukkit.entity.Player;

public class PacketCheck implements Check {
   private final AnomalyDetector detector = new AnomalyDetector();
   private final Map<Player, PacketProfile> playerProfiles = new HashMap();
   private static final int MAX_REASONABLE_PPS = 500;
   private static final int SUSPICIOUS_PPS_THRESHOLD = 1000;
   private static final double PACKET_BURST_TOLERANCE = (double)2.0F;

   public String getName() {
      return "ExtremelyIntelligentPacket";
   }

   public void handle(Player player, Object... context) {
      try {
         if (context.length < 1 || !(context[0] instanceof Integer) || player == null) {
            return;
         }

         int packetsPerSecond = (Integer)context[0];
         if (packetsPerSecond < 0 || packetsPerSecond > 10000) {
            return;
         }

         long currentTime = System.currentTimeMillis();
         PacketProfile profile = (PacketProfile)this.playerProfiles.computeIfAbsent(player, (k) -> new PacketProfile());
         profile.recordPackets(packetsPerSecond, currentTime);
         if (this.isExtremelyIntelligentPacketAnomaly(player, packetsPerSecond, profile)) {
            double confidence = this.detector.getConfidence("packets_" + this.getNetworkContext(player), (double)packetsPerSecond);
            PlayerBehaviorLogger.log(player, "intelligent_packet_anomaly", String.format("pps=%d baseline=%d confidence=%.2f context=%s", packetsPerSecond, profile.getBaseline(), confidence, this.getNetworkContext(player)));
         }

         this.detector.record("packets_" + this.getNetworkContext(player), (double)packetsPerSecond);
      } catch (Exception var9) {
      }

   }

   private boolean isExtremelyIntelligentPacketAnomaly(Player player, int pps, PacketProfile profile) {
      if (pps < 500) {
         return false;
      } else if (pps < 1000) {
         return false;
      } else {
         int baseline = profile.getBaseline();
         if ((double)pps <= (double)baseline * (double)2.0F) {
            return false;
         } else if (!profile.hasNetworkIssues() && !profile.isLikelyLagging()) {
            if (this.isBedrock(player) && (double)pps <= (double)1500.0F) {
               return false;
            } else {
               String context = this.getNetworkContext(player);
               if (!this.detector.isAnomalous("packets_" + context, (double)pps)) {
                  return false;
               } else {
                  double confidence = this.detector.getConfidence("packets_" + context, (double)pps);
                  if (confidence < 0.95) {
                     return false;
                  } else {
                     return profile.hasIrregularTiming() ? true : profile.isConsistentlyHigh(pps);
                  }
               }
            }
         } else {
            return false;
         }
      }
   }

   private String getNetworkContext(Player player) {
      StringBuilder context = new StringBuilder();
      context.append(this.isBedrock(player) ? "bedrock" : "java");

      try {
         int ping = VersionCompatibility.getPing(player);
         if (ping > 300) {
            context.append("_extreme_ping");
         } else if (ping > 200) {
            context.append("_high_ping");
         } else if (ping > 100) {
            context.append("_medium_ping");
         } else {
            context.append("_low_ping");
         }
      } catch (Exception var4) {
         context.append("_unknown_ping");
      }

      if (player.isSprinting()) {
         context.append("_active");
      } else if (player.isSneaking()) {
         context.append("_sneaking");
      } else {
         context.append("_normal");
      }

      return context.toString();
   }

   private boolean isBedrock(Player player) {
      return player.getName().startsWith(".") || player.hasPermission("floodgate.legacy") || player.getName().length() > 16;
   }

   private static class PacketProfile {
      private final int[] recentPackets;
      private final long[] packetTimestamps;
      private int packetIndex;
      private long lastNetworkIssue;
      private int baseline;

      private PacketProfile() {
         this.recentPackets = new int[30];
         this.packetTimestamps = new long[30];
         this.packetIndex = 0;
         this.lastNetworkIssue = 0L;
         this.baseline = 50;
      }

      void recordPackets(int pps, long time) {
         if (this.packetIndex > 0) {
            int prevPps = this.recentPackets[(this.packetIndex - 1 + this.recentPackets.length) % this.recentPackets.length];
            if (prevPps < 10 && pps > 200) {
               this.lastNetworkIssue = time;
            }
         }

         this.recentPackets[this.packetIndex] = pps;
         this.packetTimestamps[this.packetIndex] = time;
         this.packetIndex = (this.packetIndex + 1) % this.recentPackets.length;
         this.updateBaseline();
      }

      private void updateBaseline() {
         int sum = 0;
         int count = 0;

         for(int pps : this.recentPackets) {
            if (pps > 0 && pps < 500) {
               sum += pps;
               ++count;
            }
         }

         if (count > 10) {
            this.baseline = sum / count + 20;
         }

      }

      boolean hasNetworkIssues() {
         long currentTime = System.currentTimeMillis();
         return currentTime - this.lastNetworkIssue < 5000L;
      }

      boolean isLikelyLagging() {
         int lowCount = 0;
         int highCount = 0;

         for(int pps : this.recentPackets) {
            if (pps > 0) {
               if (pps < 20) {
                  ++lowCount;
               } else if (pps > 200) {
                  ++highCount;
               }
            }
         }

         return lowCount > 3 && highCount > 2;
      }

      boolean isConsistentlyHigh(int currentPps) {
         int highCount = 0;
         int total = 0;

         for(int pps : this.recentPackets) {
            if (pps > 0) {
               ++total;
               if (!((double)pps <= (double)800.0F)) {
                  ++highCount;
               }
            }
         }

         if (total < 5) {
            return false;
         } else {
            return (double)highCount / (double)total > 0.6;
         }
      }

      int getBaseline() {
         return this.baseline;
      }

      boolean hasIrregularTiming() {
         int irregularPatterns = 0;
         int validTimestamps = 0;

         for(int i = 1; i < this.packetTimestamps.length; ++i) {
            int prevIndex = (i - 1 + this.packetTimestamps.length) % this.packetTimestamps.length;
            if (this.packetTimestamps[i] != 0L && this.packetTimestamps[prevIndex] != 0L) {
               long timeDiff = this.packetTimestamps[i] - this.packetTimestamps[prevIndex];
               ++validTimestamps;
               if (timeDiff > 0L && timeDiff < 5L) {
                  ++irregularPatterns;
               } else if (timeDiff == 0L && this.recentPackets[i] > 100) {
                  irregularPatterns += 2;
               }
            }
         }

         return validTimestamps > 5 && (double)irregularPatterns / (double)validTimestamps > 0.4;
      }
   }
}
