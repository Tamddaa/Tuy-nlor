package com.anti.system.anticheat;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public class InventoryCheck implements Check {
   private final AnomalyDetector detector = new AnomalyDetector();
   private final Map<Player, InventoryProfile> playerProfiles = new HashMap();
   private static final int MAX_STACK_SIZE_MULTIPLIER = 2;
   private static final int CREATIVE_MAX_STACKS = 1000;
   private static final double DUPE_CONFIDENCE_THRESHOLD = 0.9;

   public String getName() {
      return "ExtremelyIntelligentInventory";
   }

   public void handle(Player player, Object... context) {
      try {
         if (context.length < 1 || player == null) {
            return;
         }

         long currentTime = System.currentTimeMillis();
         InventoryProfile profile = (InventoryProfile)this.playerProfiles.computeIfAbsent(player, (k) -> new InventoryProfile());
         InventoryAnalysis analysis = this.analyzeInventory(player, profile, currentTime);
         if (analysis == null) {
            return;
         }

         this.detector.record("inventory_" + this.getInventoryContext(player), (double)analysis.suspiciousScore);
         if (this.isExtremelyIntelligentInventoryAnomaly(player, analysis, profile)) {
            double confidence = this.detector.getConfidence("inventory_" + this.getInventoryContext(player), (double)analysis.suspiciousScore);
            PlayerBehaviorLogger.log(player, "intelligent_inventory_anomaly", String.format("score=%d illegal_items=%d context=%s confidence=%.2f details=%s", analysis.suspiciousScore, analysis.illegalItemCount, this.getInventoryContext(player), confidence, analysis.details));
         }

         profile.updateInventorySnapshot(player, currentTime);
      } catch (Exception var9) {
      }

   }

   private boolean isExtremelyIntelligentInventoryAnomaly(Player player, InventoryAnalysis analysis, InventoryProfile profile) {
      if (player.getGameMode().toString().equals("CREATIVE")) {
         return analysis.illegalItemCount > 1000;
      } else if (analysis.illegalItemCount == 0 && analysis.suspiciousScore < 50) {
         return false;
      } else if (!analysis.hasDuplicationPattern) {
         return false;
      } else if (!player.isOp() && !player.hasPermission("antisystem.bypass") && !player.hasPermission("*")) {
         if (profile.isLikelyLegitimateInventoryGrowth(analysis)) {
            return false;
         } else if (this.isBedrock(player) && analysis.suspiciousScore < 75) {
            return false;
         } else {
            String context = this.getInventoryContext(player);
            if (!this.detector.isAnomalous("inventory_" + context, (double)analysis.suspiciousScore)) {
               return false;
            } else {
               double confidence = this.detector.getConfidence("inventory_" + context, (double)analysis.suspiciousScore);
               return !(confidence < 0.9);
            }
         }
      } else {
         return false;
      }
   }

   private InventoryAnalysis analyzeInventory(Player player, InventoryProfile profile, long currentTime) {
      InventoryAnalysis analysis = new InventoryAnalysis();
      ItemStack[] contents = player.getInventory().getContents();
      HashMap<Material, Integer> itemCounts = new HashMap();
      HashSet<String> suspiciousItems = new HashSet();

      for(ItemStack item : contents) {
         if (item != null && item.getType() != Material.AIR) {
            Material material = item.getType();
            int amount = item.getAmount();
            itemCounts.merge(material, amount, Integer::sum);
            int maxStack = material.getMaxStackSize();
            if (amount > maxStack * 2) {
               ++analysis.illegalItemCount;
               analysis.suspiciousScore += 25;
               suspiciousItems.add(material.name() + ":" + amount);
            }

            if (this.hasImpossibleEnchantments(item)) {
               ++analysis.illegalItemCount;
               analysis.suspiciousScore += 30;
               suspiciousItems.add(material.name() + ":impossible_ench");
            }

            if (this.isCreativeOnlyItem(material) && !player.getGameMode().toString().equals("CREATIVE")) {
               ++analysis.illegalItemCount;
               analysis.suspiciousScore += 20;
               suspiciousItems.add(material.name() + ":creative_only");
            }
         }
      }

      analysis.hasDuplicationPattern = this.detectDuplicationPattern(itemCounts, profile);
      if (analysis.hasDuplicationPattern) {
         analysis.suspiciousScore += 40;
      }

      if (profile.hasRapidInventoryGrowth(itemCounts, currentTime)) {
         analysis.suspiciousScore += 15;
         suspiciousItems.add("rapid_growth");
      }

      analysis.details = String.join(",", suspiciousItems);
      return analysis;
   }

   private boolean detectDuplicationPattern(Map<Material, Integer> itemCounts, InventoryProfile profile) {
      for(Map.Entry<Material, Integer> entry : itemCounts.entrySet()) {
         Material material = (Material)entry.getKey();
         int count = (Integer)entry.getValue();
         if (!this.isCommonItem(material)) {
            if (this.isPowerOfTwo(count) && count >= 64) {
               return true;
            }

            if (count > 64 && profile.hasIdenticalQuantityPattern(material, count)) {
               return true;
            }

            if (this.isRareItem(material) && count > this.getExpectedMaxQuantity(material)) {
               return true;
            }
         }
      }

      return false;
   }

   private boolean hasImpossibleEnchantments(ItemStack item) {
      if (item.getEnchantments().isEmpty()) {
         return false;
      } else {
         for(Map.Entry<Enchantment, Integer> entry : item.getEnchantments().entrySet()) {
            Enchantment ench = (Enchantment)entry.getKey();
            int level = (Integer)entry.getValue();
            if (level > ench.getMaxLevel() + 1) {
               return true;
            }

            if (!ench.canEnchantItem(item)) {
               return true;
            }
         }

         return false;
      }
   }

   private boolean isCommonItem(Material material) {
      String name = material.name();
      return name.contains("COBBLESTONE") || name.contains("DIRT") || name.contains("STONE") || name.contains("SAND") || name.contains("WOOD") || name.equals("WHEAT") || name.equals("COAL") || name.equals("BREAD");
   }

   private boolean isRareItem(Material material) {
      String name = material.name();
      return name.contains("DIAMOND") || name.contains("NETHERITE") || name.contains("EMERALD") || name.equals("BEACON") || name.equals("DRAGON_EGG") || name.contains("SHULKER");
   }

   private boolean isCreativeOnlyItem(Material material) {
      String name = material.name();
      return name.equals("BEDROCK") || name.equals("BARRIER") || name.equals("COMMAND_BLOCK") || name.equals("STRUCTURE_BLOCK") || name.equals("JIGSAW") || name.contains("SPAWN_EGG");
   }

   private boolean isPowerOfTwo(int n) {
      return n > 0 && (n & n - 1) == 0;
   }

   private int getExpectedMaxQuantity(Material material) {
      if (material.name().contains("DIAMOND")) {
         return 128;
      } else if (material.name().contains("NETHERITE")) {
         return 32;
      } else {
         return material.name().contains("EMERALD") ? 64 : 256;
      }
   }

   private String getInventoryContext(Player player) {
      StringBuilder context = new StringBuilder();
      context.append(this.isBedrock(player) ? "bedrock" : "java");
      context.append("_").append(player.getGameMode().toString().toLowerCase());
      if (player.isOp()) {
         context.append("_op");
      } else if (player.hasPermission("antisystem.bypass")) {
         context.append("_bypass");
      } else {
         context.append("_player");
      }

      return context.toString();
   }

   private boolean isBedrock(Player player) {
      return player.getName().startsWith(".") || player.hasPermission("floodgate.legacy") || player.getName().length() > 16;
   }

   private static class InventoryProfile {
      private Map<Material, Integer> lastItemCounts;
      private long lastUpdateTime;
      private final Map<Integer, Integer> identicalQuantities;

      private InventoryProfile() {
         this.lastItemCounts = new HashMap();
         this.lastUpdateTime = 0L;
         this.identicalQuantities = new HashMap();
      }

      void updateInventorySnapshot(Player player, long currentTime) {
         HashMap<Material, Integer> currentCounts = new HashMap();

         for(ItemStack item : player.getInventory().getContents()) {
            if (item != null && item.getType() != Material.AIR) {
               currentCounts.merge(item.getType(), item.getAmount(), Integer::sum);
            }
         }

         for(int quantity : currentCounts.values()) {
            if (quantity > 64) {
               this.identicalQuantities.merge(quantity, 1, Integer::sum);
            }
         }

         this.lastItemCounts = currentCounts;
         this.lastUpdateTime = currentTime;
      }

      boolean hasRapidInventoryGrowth(Map<Material, Integer> currentCounts, long currentTime) {
         if (this.lastUpdateTime != 0L && currentTime - this.lastUpdateTime <= 30000L) {
            int totalGrowth = 0;

            for(Map.Entry<Material, Integer> entry : currentCounts.entrySet()) {
               Material material = (Material)entry.getKey();
               int currentCount = (Integer)entry.getValue();
               int lastCount;
               if (currentCount > (lastCount = (Integer)this.lastItemCounts.getOrDefault(material, 0))) {
                  totalGrowth += currentCount - lastCount;
               }
            }

            return totalGrowth > 640;
         } else {
            return false;
         }
      }

      boolean hasIdenticalQuantityPattern(Material material, int count) {
         return (Integer)this.identicalQuantities.getOrDefault(count, 0) >= 3;
      }

      boolean isLikelyLegitimateInventoryGrowth(InventoryAnalysis analysis) {
         return analysis.suspiciousScore < 30;
      }
   }

   private static class InventoryAnalysis {
      int suspiciousScore;
      int illegalItemCount;
      boolean hasDuplicationPattern;
      String details;

      private InventoryAnalysis() {
         this.suspiciousScore = 0;
         this.illegalItemCount = 0;
         this.hasDuplicationPattern = false;
         this.details = "";
      }
   }
}
