package com.anti.system.anticheat;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

public class AntiCheatHelpCommand implements CommandExecutor, TabCompleter {
   private final AntiCheatGUI gui;
   private final CheckManager checkManager;

   public AntiCheatHelpCommand(AntiCheatPlugin plugin, AntiCheatGUI gui, CheckManager checkManager) {
      this.gui = gui;
      this.checkManager = checkManager;
   }

   public boolean onCommand(CommandSender sender, Command command, String label, String[] args2) {
      if (args2.length == 0) {
         this.showMainHelp(sender);
         return true;
      } else {
         String subCommand;
         switch (subCommand = args2[0].toLowerCase()) {
            case "gui":
            case "menu":
               if (sender instanceof Player && sender.hasPermission("antisystem.gui")) {
                  this.gui.openMainGUI((Player)sender);
               } else {
                  sender.sendMessage("§cOnly players can use the GUI!");
               }
               break;
            case "checks":
               this.showChecksHelp(sender);
               break;
            case "combat":
               this.showCombatHelp(sender);
               break;
            case "movement":
               this.showMovementHelp(sender);
               break;
            case "pvp":
               this.showPvPHelp(sender);
               break;
            case "config":
               this.showConfigHelp(sender);
               break;
            case "violations":
               this.showViolationsHelp(sender);
               break;
            case "staff":
               this.showStaffHelp(sender);
               break;
            case "api":
               this.showAPIHelp(sender);
               break;
            case "performance":
               this.showPerformanceHelp(sender);
               break;
            default:
               sender.sendMessage("§cUnknown help topic: " + subCommand);
               sender.sendMessage("§eUse §f/anticheat help §efor available topics.");
         }

         return true;
      }
   }

   private void showMainHelp(CommandSender sender) {
      sender.sendMessage("");
      sender.sendMessage("§6§l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬");
      sender.sendMessage("                §c§lAntiCheat §f§lHelp System");
      sender.sendMessage("           §7Superior to GrimAC & Vulcan");
      sender.sendMessage("§6§l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬");
      sender.sendMessage("");
      sender.sendMessage("§e§l\ud83c\udfae GUI Interface §7- §f/anticheat help gui");
      sender.sendMessage("§7  Open the interactive control panel");
      sender.sendMessage("§c§l⚔ Combat Checks §7- §f/anticheat help combat");
      sender.sendMessage("§7  Reach, KillAura, Criticals, etc.");
      sender.sendMessage("§b§l\ud83c\udfc3 Movement Checks §7- §f/anticheat help movement");
      sender.sendMessage("§7  Flight, Speed, Jesus, Phase, etc.");
      sender.sendMessage("§d§l\ud83d\udc8e PvP Exploits §7- §f/anticheat help pvp");
      sender.sendMessage("§7  Crystal Aura, Anchor Aura, Bed Aura, etc.");
      sender.sendMessage("§a§l\ud83d\udccb Check Management §7- §f/anticheat help checks");
      sender.sendMessage("§7  Enable/disable specific checks");
      sender.sendMessage("§f§l⚙ Configuration §7- §f/anticheat help config");
      sender.sendMessage("§7  Thresholds, punishments, settings");
      sender.sendMessage("§6§l\ud83d\udcca Violations §7- §f/anticheat help violations");
      sender.sendMessage("§7  View and manage player violations");
      sender.sendMessage("§9§l\ud83d\udc6e Staff Tools §7- §f/anticheat help staff");
      sender.sendMessage("§7  Advanced moderation features");
      sender.sendMessage("§5§l\ud83d\udd27 API & Development §7- §f/anticheat help api");
      sender.sendMessage("§7  Developer integration guide");
      sender.sendMessage("§7§l\ud83d\udcc8 Performance §7- §f/anticheat help performance");
      sender.sendMessage("§7  Optimization and monitoring");
      sender.sendMessage("");
      if (sender instanceof Player && sender.hasPermission("antisystem.gui")) {
         sender.sendMessage("§7Quick Actions:");
         sender.sendMessage("§a§l[OPEN GUI] §7- §f/anticheat gui");
         sender.sendMessage("§e§l[RELOAD] §7- §f/anticheat reload");
      }

      sender.sendMessage("");
      sender.sendMessage("§6§l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬");
   }

   private void showCombatHelp(CommandSender sender) {
      this.sendHeader(sender, "Combat Detection System");
      sender.sendMessage("§c§lReach Detection:");
      sender.sendMessage("§7• Detects extended reach beyond vanilla 3.0 blocks");
      sender.sendMessage("§7• Advanced ping compensation");
      sender.sendMessage("§7• Weapon-specific validation");
      sender.sendMessage("§7Command: §f/anticheat toggle reach");
      sender.sendMessage("");
      sender.sendMessage("§c§lKillAura Detection:");
      sender.sendMessage("§7• Multi-target attack analysis");
      sender.sendMessage("§7• Angle and timing validation");
      sender.sendMessage("§7• Line of sight checking");
      sender.sendMessage("§7Command: §f/anticheat toggle killaura");
      sender.sendMessage("");
      sender.sendMessage("§c§lCriticals Detection:");
      sender.sendMessage("§7• Jump state validation");
      sender.sendMessage("§7• Velocity analysis");
      sender.sendMessage("§7• Damage modifier checking");
      sender.sendMessage("§7Command: §f/anticheat toggle criticals");
      sender.sendMessage("");
      sender.sendMessage("§c§lHitbox Extender Detection:");
      sender.sendMessage("§7• Precise hitbox boundary validation");
      sender.sendMessage("§7• Sub-block precision checking");
      sender.sendMessage("§7• Instant punishment for violations");
      sender.sendMessage("§7Command: §f/anticheat toggle hitbox");
      this.sendFooter(sender);
   }

   private void showMovementHelp(CommandSender sender) {
      this.sendHeader(sender, "Movement Detection System");
      sender.sendMessage("§b§lFlight Detection:");
      sender.sendMessage("§7• Physics-based analysis");
      sender.sendMessage("§7• Elytra context awareness");
      sender.sendMessage("§7• Creative mode exclusion");
      sender.sendMessage("§7Command: §f/anticheat toggle fly");
      sender.sendMessage("");
      sender.sendMessage("§b§lSpeed Detection:");
      sender.sendMessage("§7• Ground and air speed limits");
      sender.sendMessage("§7• Potion effect compensation");
      sender.sendMessage("§7• Environment factor analysis");
      sender.sendMessage("§7Command: §f/anticheat toggle speed");
      sender.sendMessage("");
      sender.sendMessage("§b§lJesus Detection:");
      sender.sendMessage("§7• Water walking prevention");
      sender.sendMessage("§7• Frost Walker exclusion");
      sender.sendMessage("§7• Boat context awareness");
      sender.sendMessage("§7Command: §f/anticheat toggle jesus");
      this.sendFooter(sender);
   }

   private void showPvPHelp(CommandSender sender) {
      this.sendHeader(sender, "PvP Exploit Detection");
      sender.sendMessage("§d§lCrystal Aura Detection:");
      sender.sendMessage("§7• End crystal automation detection");
      sender.sendMessage("§7• Placement pattern analysis");
      sender.sendMessage("§7• Timing and range validation");
      sender.sendMessage("§7• Look direction verification");
      sender.sendMessage("§7Command: §f/anticheat toggle crystalaura");
      sender.sendMessage("");
      sender.sendMessage("§c§lAnchor Aura Detection:");
      sender.sendMessage("§7• Respawn anchor automation");
      sender.sendMessage("§7• Charge pattern monitoring");
      sender.sendMessage("§7• Explosion timing analysis");
      sender.sendMessage("§7Command: §f/anticheat toggle anchoraura");
      sender.sendMessage("");
      sender.sendMessage("§4§lBed Aura Detection:");
      sender.sendMessage("§7• Bed bombing automation");
      sender.sendMessage("§7• Nether/End dimension specific");
      sender.sendMessage("§7• Rapid placement detection");
      sender.sendMessage("§7Command: §f/anticheat toggle bedaura");
      sender.sendMessage("");
      sender.sendMessage("§e§lAuto Totem Detection:");
      sender.sendMessage("§7• Totem swap automation");
      sender.sendMessage("§7• Health threshold monitoring");
      sender.sendMessage("§7• Inventory pattern analysis");
      sender.sendMessage("§7Command: §f/anticheat toggle autototem");
      this.sendFooter(sender);
   }

   private void showChecksHelp(CommandSender sender) {
      this.sendHeader(sender, "Check Management");
      sender.sendMessage("§a§lAvailable Commands:");
      sender.sendMessage("§7• §f/anticheat toggle <check> §7- Enable/disable a specific check");
      sender.sendMessage("§7• §f/anticheat enable <check> §7- Enable a specific check");
      sender.sendMessage("§7• §f/anticheat disable <check> §7- Disable a specific check");
      sender.sendMessage("§7• §f/anticheat enableall §7- Enable all checks");
      sender.sendMessage("§7• §f/anticheat disableall §7- Disable all checks");
      sender.sendMessage("§7• §f/anticheat status §7- Show check status");
      sender.sendMessage("");
      sender.sendMessage("§e§lActive Checks:");

      for(String checkName : this.checkManager.getCheckNames()) {
         boolean enabled = this.checkManager.isEnabled(checkName);
         String status = enabled ? "§aEnabled" : "§cDisabled";
         int threshold = this.checkManager.getThreshold(checkName);
         sender.sendMessage("§7• §f" + checkName + " §7- " + status + " §7(Threshold: §f" + threshold + "§7)");
      }

      this.sendFooter(sender);
   }

   private void showConfigHelp(CommandSender sender) {
      this.sendHeader(sender, "Configuration Guide");
      sender.sendMessage("§f§lConfiguration Files:");
      sender.sendMessage("§7• §econfig.yml §7- Advanced ML detection & core settings");
      sender.sendMessage("§7• §ebedrockac.yml §7- Cross-platform ML detection");
      sender.sendMessage("§7• §estaff.yml §7- Staff tools & ML analytics");
      sender.sendMessage("§7• §ereasons.yml §7- AI-powered violation categories");
      sender.sendMessage("§7• §eplugin.yml §7- Plugin metadata");
      sender.sendMessage("");
      sender.sendMessage("§e§lCommands:");
      sender.sendMessage("§7• §f/anticheat reload §7- Reload all configuration files");
      sender.sendMessage("§7• §f/anticheat threshold <check> <value> §7- Set violation threshold");
      sender.sendMessage("§7• §f/anticheat export §7- Export current configuration");
      sender.sendMessage("§7• §f/anticheat import §7- Import configuration");
      this.sendFooter(sender);
   }

   private void showViolationsHelp(CommandSender sender) {
      this.sendHeader(sender, "Violation Management");
      sender.sendMessage("§7• §f/anticheat violations <player> §7- View player violations");
      sender.sendMessage("§7• §f/anticheat clear <player> §7- Clear player violations");
      sender.sendMessage("§7• §f/anticheat clearall §7- Clear all violations");
      sender.sendMessage("§7• §f/anticheat top §7- Show top violators");
      sender.sendMessage("§7• §f/anticheat logs §7- View recent detections");
      this.sendFooter(sender);
   }

   private void showStaffHelp(CommandSender sender) {
      this.sendHeader(sender, "Staff Tools");
      sender.sendMessage("§7• §f/staff §7- Open staff management GUI");
      sender.sendMessage("§7• §f/staffmode §7- Toggle staff mode");
      sender.sendMessage("§7• §f/vanish §7- Toggle vanish mode");
      sender.sendMessage("§7• §f/freeze <player> §7- Freeze a player");
      sender.sendMessage("§7• §f/probe <player> §7- Start behavior probe");
      this.sendFooter(sender);
   }

   private void showAPIHelp(CommandSender sender) {
      this.sendHeader(sender, "API & Development");
      sender.sendMessage("§5§lDeveloper Integration:");
      sender.sendMessage("§7• Event-based violation handling");
      sender.sendMessage("§7• Custom check registration");
      sender.sendMessage("§7• Configuration API");
      sender.sendMessage("§7• Database integration");
      sender.sendMessage("");
      sender.sendMessage("§e§lExample Usage:");
      sender.sendMessage("§7AntiCheatAPI.registerCheck(new CustomCheck());");
      sender.sendMessage("§7AntiCheatAPI.getViolations(player);");
      this.sendFooter(sender);
   }

   private void showPerformanceHelp(CommandSender sender) {
      this.sendHeader(sender, "Performance & Optimization");
      sender.sendMessage("§7• §f/anticheat performance §7- Show performance metrics");
      sender.sendMessage("§7• §f/anticheat memory §7- Show memory usage");
      sender.sendMessage("§7• §f/anticheat benchmark §7- Run performance benchmark");
      sender.sendMessage("§7• §f/anticheat optimize §7- Optimize configuration");
      this.sendFooter(sender);
   }

   private void sendHeader(CommandSender sender, String title) {
      sender.sendMessage("");
      sender.sendMessage("§6§l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬");
      sender.sendMessage("                §c§l" + title);
      sender.sendMessage("§6§l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬");
      sender.sendMessage("");
   }

   private void sendFooter(CommandSender sender) {
      sender.sendMessage("");
      sender.sendMessage("§e§l[← Back to Main Help] §7- §f/anticheat help");
      sender.sendMessage("§6§l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬");
   }

   public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args2) {
      ArrayList<String> completions = new ArrayList();
      if (args2.length == 1) {
         List<String> topics = Arrays.asList("gui", "menu", "checks", "combat", "movement", "pvp", "config", "violations", "staff", "api", "performance");
         String input = args2[0].toLowerCase();

         for(String topic : topics) {
            if (topic.startsWith(input)) {
               completions.add(topic);
            }
         }
      }

      return completions;
   }
}
