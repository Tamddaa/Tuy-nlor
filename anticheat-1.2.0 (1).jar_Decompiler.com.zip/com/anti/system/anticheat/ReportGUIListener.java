package com.anti.system.anticheat;

import com.anti.system.utils.VersionCompatibility;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class ReportGUIListener implements Listener {
   private final ReportSystem reportSystem;
   private final Map<UUID, String> playerReportContext = new HashMap();

   public ReportGUIListener(ReportSystem reportSystem) {
      this.reportSystem = reportSystem;
   }

   @EventHandler
   public void onInventoryClick(InventoryClickEvent event) {
      if (event.getWhoClicked() instanceof Player) {
         Player player = (Player)event.getWhoClicked();
         String title = event.getView().getTitle();
         if (title.contains("Report")) {
            event.setCancelled(true);
            ItemStack item = event.getCurrentItem();
            if (item != null && item.getType() != Material.AIR) {
               if (title.equals("§c§lReport Player")) {
                  this.handleReportPlayerGUI(player, item, event.getSlot());
               } else if (title.equals("§c§lSelect Report Category")) {
                  this.handleCategorySelectGUI(player, item);
               } else if (title.equals("§c§lSelect Priority")) {
                  this.handlePrioritySelectGUI(player, item);
               } else if (title.equals("§4§lReport Management")) {
                  this.handleStaffReportGUI(player, item, event.getSlot());
               } else if (title.contains("Report #") && title.contains("Details")) {
                  this.handleReportDetailGUI(player, item, title);
               } else if (title.equals("§6§lReport Statistics")) {
                  this.handleReportStatisticsGUI(player, item);
               }

            }
         }
      }
   }

   private void handleReportPlayerGUI(Player player, ItemStack item, int slot) {
      if (slot >= 45) {
         if (item.getType() == Material.BARRIER) {
            player.closeInventory();
         }

      } else {
         ItemMeta meta;
         if (item.getType() == VersionCompatibility.getPlayerHeadMaterial() && (meta = item.getItemMeta()) != null && meta.getDisplayName() != null) {
            String targetName = meta.getDisplayName().replace("§f", "");
            Player target = (Player)Bukkit.getOnlinePlayers().stream().filter((p) -> p.getName().equalsIgnoreCase(targetName)).findFirst().orElse((Object)null);
            if (target != null && target.isOnline()) {
               this.reportSystem.openCategoryGUI(player, targetName);
            } else {
               player.sendMessage("§cPlayer is no longer online!");
               player.closeInventory();
            }
         }

      }
   }

   private void handleCategorySelectGUI(Player player, ItemStack item) {
      if (item.getType() == Material.BARRIER) {
         player.closeInventory();
      } else if (item.getType() == Material.ARROW) {
         this.reportSystem.openReportGUI(player);
      } else {
         ItemMeta meta = item.getItemMeta();
         if (meta != null && meta.getDisplayName() != null) {
            String category = meta.getDisplayName().replace("§f", "");
            String loreLine;
            if (meta.getLore() != null && meta.getLore().size() > 1 && (loreLine = (String)meta.getLore().get(1)).contains("Reporting: §c")) {
               String reportedPlayer = loreLine.replace("§7Reporting: §c", "");
               this.playerReportContext.put(player.getUniqueId(), reportedPlayer + "|" + category);
               this.openPriorityGUI(player, reportedPlayer, category);
            }
         }

      }
   }

   private void handlePrioritySelectGUI(Player player, ItemStack item) {
      if (item.getType() == Material.BARRIER) {
         player.closeInventory();
      } else if (item.getType() == Material.ARROW) {
         String context = (String)this.playerReportContext.get(player.getUniqueId());
         String[] parts;
         if (context != null && (parts = context.split("\\|")).length >= 2) {
            this.reportSystem.openCategoryGUI(player, parts[0]);
         }

      } else {
         ItemMeta meta = item.getItemMeta();
         if (meta != null && meta.getDisplayName() != null) {
            String priorityName = meta.getDisplayName().replace("§7", "").replace("§e", "").replace("§6", "").replace("§c", "").replace("§l", "");
            ReportSystem.ReportPriority priority = null;
            switch (priorityName) {
               case "Low Priority":
                  priority = ReportSystem.ReportPriority.LOW;
                  break;
               case "Normal Priority":
                  priority = ReportSystem.ReportPriority.MEDIUM;
                  break;
               case "High Priority":
                  priority = ReportSystem.ReportPriority.HIGH;
                  break;
               case "Urgent Priority":
                  priority = ReportSystem.ReportPriority.URGENT;
            }

            String[] parts;
            String context;
            if (priority != null && (context = (String)this.playerReportContext.get(player.getUniqueId())) != null && (parts = context.split("\\|")).length >= 2) {
               String reportedPlayer = parts[0];
               String category = parts[1];
               String reason = "Report submitted via GUI";
               boolean success = this.reportSystem.submitReport(player, reportedPlayer, category, reason, priority);
               if (success) {
                  player.closeInventory();
               }

               this.playerReportContext.remove(player.getUniqueId());
            }
         }

      }
   }

   private void handleStaffReportGUI(Player player, ItemStack item, int slot) {
      if (!player.hasPermission("antisystem.staff.reports")) {
         player.closeInventory();
      } else {
         Inventory inv = player.getOpenInventory().getTopInventory();
         int size = inv.getSize();
         if (slot >= size - 9) {
            switch (item.getType()) {
               case EMERALD:
                  this.reportSystem.openStaffReportsGUI(player);
                  break;
               case BOOK:
                  this.showReportStatistics(player);
                  break;
               case BARRIER:
                  player.closeInventory();
            }

         } else {
            String displayName;
            ItemMeta meta;
            if (item.getType() == Material.PAPER && (meta = item.getItemMeta()) != null && meta.getDisplayName() != null && (displayName = meta.getDisplayName()).contains("Report #")) {
               String reportIdStr = displayName.replace("§c§lReport #", "");

               try {
                  int reportId = Integer.parseInt(reportIdStr);
                  this.openReportDetailGUI(player, reportId);
               } catch (NumberFormatException var10) {
                  player.sendMessage("§cError parsing report ID!");
               }
            }

         }
      }
   }

   private void openPriorityGUI(Player player, String reportedPlayer, String category) {
      Inventory gui = Bukkit.createInventory((InventoryHolder)null, 27, "§c§lSelect Priority");
      ItemStack low = new ItemStack(VersionCompatibility.getLimeDyeMaterial());
      ItemMeta lowMeta = low.getItemMeta();
      lowMeta.setDisplayName("§7Low Priority");
      lowMeta.setLore(Arrays.asList("§7For minor issues", "§7Will be handled when staff is available", "§7Reporting: §c" + reportedPlayer, "§7Category: §e" + category));
      low.setItemMeta(lowMeta);
      gui.setItem(10, low);
      ItemStack normal = new ItemStack(VersionCompatibility.getYellowDyeMaterial());
      ItemMeta normalMeta = normal.getItemMeta();
      normalMeta.setDisplayName("§eNormal Priority");
      normalMeta.setLore(Arrays.asList("§7For standard issues", "§7Will be handled in normal queue", "§7Reporting: §c" + reportedPlayer, "§7Category: §e" + category));
      normal.setItemMeta(normalMeta);
      gui.setItem(12, normal);
      ItemStack high = new ItemStack(VersionCompatibility.getOrangeDyeMaterial());
      ItemMeta highMeta = high.getItemMeta();
      highMeta.setDisplayName("§6High Priority");
      highMeta.setLore(Arrays.asList("§7For serious issues", "§7Will be prioritized by staff", "§7Reporting: §c" + reportedPlayer, "§7Category: §e" + category));
      high.setItemMeta(highMeta);
      gui.setItem(14, high);
      ItemStack urgent = new ItemStack(VersionCompatibility.getRedDyeMaterial());
      ItemMeta urgentMeta = urgent.getItemMeta();
      urgentMeta.setDisplayName("§c§lUrgent Priority");
      urgentMeta.setLore(Arrays.asList("§7For critical issues requiring immediate attention", "§7Staff will be notified immediately", "§7Reporting: §c" + reportedPlayer, "§7Category: §e" + category));
      urgent.setItemMeta(urgentMeta);
      gui.setItem(16, urgent);
      ItemStack back = new ItemStack(Material.ARROW);
      ItemMeta backMeta = back.getItemMeta();
      backMeta.setDisplayName("§7« Back to Categories");
      back.setItemMeta(backMeta);
      gui.setItem(18, back);
      ItemStack close = new ItemStack(Material.BARRIER);
      ItemMeta closeMeta = close.getItemMeta();
      closeMeta.setDisplayName("§c§lClose");
      close.setItemMeta(closeMeta);
      gui.setItem(26, close);
      player.openInventory(gui);
   }

   private void openReportDetailGUI(Player player, int reportId) {
      this.reportSystem.openReportDetailGUI(player, reportId);
   }

   private void showReportStatistics(Player player) {
      this.reportSystem.showReportStatisticsGUI(player);
   }

   private void handleReportDetailGUI(Player player, ItemStack item, String title) {
      if (!player.hasPermission("antisystem.staff.reports")) {
         player.closeInventory();
      } else {
         String reportIdStr = title.replace("§c§lReport #", "").replace(" Details", "");

         int reportId;
         try {
            reportId = Integer.parseInt(reportIdStr);
         } catch (NumberFormatException var11) {
            player.sendMessage("§cError parsing report ID!");
            return;
         }

         ItemMeta meta = item.getItemMeta();
         if (meta != null && meta.getDisplayName() != null) {
            String displayName = meta.getDisplayName();
            if (displayName.contains("Teleport to Player")) {
               String targetLine;
               if (meta.getLore() != null && meta.getLore().size() >= 2 && (targetLine = (String)meta.getLore().get(1)).contains("Target: §c")) {
                  String targetName = targetLine.replace("§7Target: §c", "");
                  Player target = (Player)Bukkit.getOnlinePlayers().stream().filter((p) -> p.getName().equalsIgnoreCase(targetName)).findFirst().orElse((Object)null);
                  if (target != null && target.isOnline()) {
                     player.teleport(target.getLocation());
                     player.sendMessage("§aTeleported to " + targetName);
                     player.closeInventory();
                  } else {
                     player.sendMessage("§cPlayer " + targetName + " is not online!");
                  }
               }
            } else if (displayName.contains("Punish Player")) {
               String targetLine;
               if (meta.getLore() != null && meta.getLore().size() >= 2 && (targetLine = (String)meta.getLore().get(1)).contains("Target: §c")) {
                  String targetName = targetLine.replace("§7Target: §c", "");
                  player.closeInventory();
                  player.performCommand("quickmod " + targetName);
               }
            } else if (displayName.contains("Resolve Report")) {
               boolean success = this.reportSystem.resolveReport(reportId, player, "Resolved by " + player.getName());
               if (success) {
                  player.sendMessage("§aReport #" + reportId + " has been resolved!");
                  player.closeInventory();
                  this.reportSystem.openStaffReportsGUI(player);
               } else {
                  player.sendMessage("§cFailed to resolve report!");
               }
            } else if (displayName.contains("Dismiss Report")) {
               boolean success = this.reportSystem.dismissReport(reportId, player, "Dismissed by " + player.getName());
               if (success) {
                  player.sendMessage("§aReport #" + reportId + " has been dismissed!");
                  player.closeInventory();
                  this.reportSystem.openStaffReportsGUI(player);
               } else {
                  player.sendMessage("§cFailed to dismiss report!");
               }
            } else if (displayName.contains("Assign to Me")) {
               boolean success = this.reportSystem.assignReport(reportId, player);
               if (success) {
                  player.sendMessage("§aReport #" + reportId + " has been assigned to you!");
                  this.reportSystem.openReportDetailGUI(player, reportId);
               } else {
                  player.sendMessage("§cFailed to assign report!");
               }
            } else if (displayName.contains("Back to Reports")) {
               this.reportSystem.openStaffReportsGUI(player);
            } else if (displayName.contains("Close")) {
               player.closeInventory();
            }

         }
      }
   }

   private void handleReportStatisticsGUI(Player player, ItemStack item) {
      if (!player.hasPermission("antisystem.staff.reports")) {
         player.closeInventory();
      } else {
         ItemMeta meta = item.getItemMeta();
         if (meta != null && meta.getDisplayName() != null) {
            String displayName = meta.getDisplayName();
            if (displayName.contains("Close")) {
               player.closeInventory();
            }

         }
      }
   }
}
