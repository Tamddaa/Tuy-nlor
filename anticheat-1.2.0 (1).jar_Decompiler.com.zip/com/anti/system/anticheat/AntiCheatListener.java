package com.anti.system.anticheat;

import com.anti.system.utils.VersionCompatibility;
import java.io.IOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.entity.EntityDamageEvent.DamageCause;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;

public class AntiCheatListener implements Listener {
   private final Map<Player, Boolean> blockedCheaters = new HashMap();
   private final Map<Player, Long> blockTime = new HashMap();
   private final Map<Player, Boolean> bedrockCache = new HashMap();
   private final JavaPlugin plugin;
   private final Map<Player, Map<String, Integer>> violations = new HashMap();
   private final Map<Player, Map<String, Long>> lastViolationTime = new HashMap();
   private final Map<Player, Long> playerJoinTime = new HashMap();
   private final Map<Player, Long> lastAttackTime = new HashMap();
   private final Map<Player, Location> lastAttackLocation = new HashMap();
   private final Map<Player, Double> lastAttackDistance = new HashMap();
   private final Map<Player, String> lastWeaponUsed = new HashMap();
   private final Map<Player, Long> lastMaceHitTime = new HashMap();
   private final Map<Player, Integer> maceRapidHitCount = new HashMap();
   private final Map<Player, Double> lastYPosition = new HashMap();
   private final Map<Player, Location> lastGroundLocation = new HashMap();
   private final Map<Player, Long> lastOnGroundTime = new HashMap();
   private final Map<Player, Long> onWaterStartTime = new HashMap();
   private final Map<Player, Float> lastYaw = new HashMap();
   private final Map<Player, Float> lastPitch = new HashMap();
   private final Map<Player, Long> lastRotationTime = new HashMap();
   private final Map<Player, Long> lastInteractionTime = new HashMap();
   private final Map<Player, Integer> freecamViolations = new HashMap();
   private final Map<Player, Integer> fastBreakViolations = new HashMap();
   private final Map<Player, Long> lastBlockBreakTime = new HashMap();
   private final Map<Player, Integer> inventoryMoveViolations = new HashMap();
   private final Map<Player, Long> lastChatTime = new HashMap();
   private final Map<Player, Integer> chatSpamCount = new HashMap();
   private final Map<Player, Long> lastPacketTime = new HashMap();
   private final Map<Player, Integer> packetCount = new HashMap();
   private final Map<Player, Long> lastInteractPacketTime = new HashMap();
   private final Map<Player, Long> lastScaffoldPlaceTime = new HashMap();
   private final Map<Player, Integer> scaffoldSequenceCount = new HashMap();
   private final Map<Player, Double> lastScaffoldY = new HashMap();
   private final Map<Player, Long> lastAttackPacketTime = new HashMap();
   private final Map<Player, Integer> triggerRapidHits = new HashMap();
   private final Map<Player, Long> lastMaceSwapTime = new HashMap();
   private final Map<Player, Long> lastShieldRaiseTime = new HashMap();
   private final Map<Player, Long> lastShieldStunTime = new HashMap();
   private final Map<Player, Long> lastCrystalPlaceTime = new HashMap();
   private final Map<Player, Long> lastCrystalIgniteTime = new HashMap();
   private final Map<Player, Integer> crystalSequenceCount = new HashMap();
   private final Map<Player, Long> lastAnchorPlaceTime = new HashMap();
   private final Map<Player, Long> lastAnchorChargeTime = new HashMap();
   private final Map<Player, Integer> anchorSequenceCount = new HashMap();
   private final Map<Player, Double> lastPlayerSpeed = new HashMap();
   private final Map<Player, Double> lastYVelocity = new HashMap();
   private final Map<Player, Long> lastLandingTime = new HashMap();
   private final Map<Player, Long> lastEdgeJumpTime = new HashMap();
   private final Map<Player, Double> actualFallDistance = new HashMap();
   private final Map<Player, Double> maxHeightReached = new HashMap();
   private final Map<Player, Long> lastDamageTime = new HashMap();
   private final Map<String, Long> lastNotificationTime = new HashMap();
   private String webhookUrl = "";
   private String webhookMessage = "[AntiSystem] %type% detected for %player%: %reason%";
   private boolean javaChecks = true;
   private boolean bedrockChecks = true;
   private Map<String, Integer> javaThresholds = new HashMap();
   private Map<String, Integer> bedrockThresholds = new HashMap();

   public AntiCheatListener(JavaPlugin plugin) {
      this.plugin = plugin;

      try {
         plugin.saveDefaultConfig();
         FileConfiguration config = plugin.getConfig();
         this.webhookUrl = config.getString("anticheat.discord_webhook_url", "");
         this.webhookMessage = config.getString("anticheat.webhook_message", "[AntiSystem] %type% detected for %player%: %reason%");
         this.javaChecks = config.getBoolean("anticheat.java_checks", true);
         this.bedrockChecks = config.getBoolean("anticheat.bedrock_checks", true);
         ConfigurationSection javaSection = config.getConfigurationSection("anticheat.java_thresholds");
         if (javaSection != null) {
            for(String key : javaSection.getKeys(false)) {
               this.javaThresholds.put(key, javaSection.getInt(key));
            }
         }

         ConfigurationSection bedrockSection = config.getConfigurationSection("anticheat.bedrock_thresholds");
         if (bedrockSection != null) {
            for(String key : bedrockSection.getKeys(false)) {
               this.bedrockThresholds.put(key, bedrockSection.getInt(key));
            }
         }

         this.setDefaultThresholds();
      } catch (Exception e) {
         String errorMsg = "Error loading config: " + e.getMessage();
         this.plugin.getLogger().warning(errorMsg);
      }

   }

   private boolean isBlocked(Player player) {
      return (Boolean)this.blockedCheaters.getOrDefault(player, false);
   }

   public void blockCheater(Player player, String reason) {
      this.blockedCheaters.put(player, true);
      this.blockTime.put(player, System.currentTimeMillis());
      player.setWalkSpeed(0.0F);
      player.setFlySpeed(0.0F);
      player.setSprinting(false);
      player.setVelocity(new Vector(0, 0, 0));
      player.sendMessage("§c§l[AntiCheat] §7Movement locked due to: " + reason + " §8(Auto-release in 30s)");
      player.sendMessage("§7Staff can use §e/anticheat unblock " + player.getName() + " §7to release you immediately.");
      Bukkit.getScheduler().runTaskLater(this.plugin, () -> this.unblockCheater(player), 600L);
   }

   private void unblockCheater(Player player) {
      if (this.blockedCheaters.remove(player) != null) {
         this.blockTime.remove(player);
         player.setWalkSpeed(0.2F);
         player.setFlySpeed(0.1F);
         player.sendMessage("§a§l[AntiCheat] §7Movement lock lifted. Please play fairly.");
      }

   }

   public void staffUnblockPlayer(Player player) {
      this.unblockCheater(player);
      player.sendMessage("§a§l[AntiCheat] §7Movement lock manually lifted by staff.");
   }

   public void clearViolations(Player player) {
      this.violations.remove(player);
      this.lastViolationTime.remove(player);
      player.sendMessage("§a§l[AntiCheat] §7All violations cleared.");
   }

   public void resetViolationType(Player player, String violationType) {
      Map<String, Integer> vmap = (Map)this.violations.get(player);
      Map<String, Long> timemap = (Map)this.lastViolationTime.get(player);
      if (vmap != null) {
         vmap.remove(violationType);
         if (vmap.isEmpty()) {
            this.violations.remove(player);
         }
      }

      if (timemap != null) {
         timemap.remove(violationType);
         if (timemap.isEmpty()) {
            this.lastViolationTime.remove(player);
         }
      }

      player.sendMessage("§a§l[AntiCheat] §7" + violationType + " violations cleared.");
   }

   public void resetPlayerState(Player player) {
      this.clearViolations(player);
      this.unblockCheater(player);
      this.bedrockCache.remove(player);
      this.lastYPosition.remove(player);
      this.lastGroundLocation.remove(player);
      this.lastOnGroundTime.remove(player);
      this.onWaterStartTime.remove(player);
      this.lastYaw.remove(player);
      this.lastPitch.remove(player);
      this.lastRotationTime.remove(player);
      this.lastInteractionTime.remove(player);
      this.freecamViolations.remove(player);
      this.fastBreakViolations.remove(player);
      this.lastBlockBreakTime.remove(player);
      this.inventoryMoveViolations.remove(player);
      this.lastChatTime.remove(player);
      this.chatSpamCount.remove(player);
      this.lastPacketTime.remove(player);
      this.packetCount.remove(player);
      this.lastInteractPacketTime.remove(player);
      this.lastAttackTime.remove(player);
      this.lastAttackLocation.remove(player);
      this.lastAttackDistance.remove(player);
      this.lastWeaponUsed.remove(player);
      this.lastMaceHitTime.remove(player);
      this.maceRapidHitCount.remove(player);
      this.lastPlayerSpeed.remove(player);
      this.lastYVelocity.remove(player);
      this.lastLandingTime.remove(player);
      this.lastEdgeJumpTime.remove(player);
      this.actualFallDistance.remove(player);
      this.maxHeightReached.remove(player);
      this.lastDamageTime.remove(player);
      this.lastScaffoldPlaceTime.remove(player);
      this.scaffoldSequenceCount.remove(player);
      this.lastScaffoldY.remove(player);
      this.lastAttackPacketTime.remove(player);
      this.triggerRapidHits.remove(player);
      this.lastMaceSwapTime.remove(player);
      this.lastShieldRaiseTime.remove(player);
      this.lastShieldStunTime.remove(player);
      this.lastCrystalPlaceTime.remove(player);
      this.lastCrystalIgniteTime.remove(player);
      this.crystalSequenceCount.remove(player);
      this.lastAnchorPlaceTime.remove(player);
      this.lastAnchorChargeTime.remove(player);
      this.anchorSequenceCount.remove(player);
      player.setWalkSpeed(0.2F);
      player.setFlySpeed(0.1F);
      if (player.hasMetadata("mobDamageTime")) {
         player.removeMetadata("mobDamageTime", this.plugin);
      }

      if (player.hasMetadata("knockbackEffect")) {
         player.removeMetadata("knockbackEffect", this.plugin);
      }

      player.sendMessage("§a§l[AntiCheat] §7Complete player state reset - all restrictions lifted.");
   }

   public boolean isPlayerBlocked(Player player) {
      return this.isBlocked(player);
   }

   @EventHandler
   public void onFoodLevelChange(FoodLevelChangeEvent event) {
      if (event.getEntity() instanceof Player) {
         Player player = (Player)event.getEntity();
         int newLevel = event.getFoodLevel();
         int oldLevel = player.getFoodLevel();
         long now = System.currentTimeMillis();
         if (!player.getGameMode().toString().equalsIgnoreCase("CREATIVE") && oldLevel == 20 && newLevel == 20) {
            long join = (Long)this.playerJoinTime.getOrDefault(player, now);
            if (now - join > 120000L) {
               this.addViolation(player, "antihunger", 2, "AntiCheat: Hunger not decreasing (anti hunger cheat)");
            }
         }

      }
   }

   @EventHandler
   public void onPlayerJoin(PlayerJoinEvent event) {
      Player player = event.getPlayer();
      this.playerJoinTime.put(player, System.currentTimeMillis());
      this.bedrockCache.remove(player);
   }

   @EventHandler
   public void onPlayerQuit(PlayerQuitEvent event) {
      Player player = event.getPlayer();
      this.blockedCheaters.remove(player);
      this.blockTime.remove(player);
      this.bedrockCache.remove(player);
      this.violations.remove(player);
      this.lastViolationTime.remove(player);
      this.playerJoinTime.remove(player);
      this.lastYPosition.remove(player);
   }

   private boolean isExemptFromMovementChecks(Player player) {
      if (player.hasPermission("antisystem.bypass.movement")) {
         return true;
      } else if (player.getGameMode() == GameMode.CREATIVE && player.hasPermission("antisystem.allow.creative.flight")) {
         return true;
      } else if ((player.getAllowFlight() || player.isFlying()) && player.hasPermission("antisystem.allow.flight")) {
         return true;
      } else {
         Long joinTime = (Long)this.playerJoinTime.get(player);
         if (joinTime != null && System.currentTimeMillis() - joinTime < 5000L) {
            return true;
         } else {
            try {
               int ping = VersionCompatibility.getPing(player);
               if (ping > 300) {
                  return true;
               }
            } catch (Exception var6) {
            }

            if (player.getVehicle() != null) {
               return true;
            } else {
               try {
                  return player.hasPotionEffect(VersionCompatibility.getLevitationEffect()) || player.hasPotionEffect(VersionCompatibility.getSlowFallingEffect()) || player.hasPotionEffect(VersionCompatibility.getJumpBoostEffect());
               } catch (Exception var7) {
                  try {
                     return player.hasPotionEffect(VersionCompatibility.getJumpBoostEffect());
                  } catch (Exception var5) {
                     return false;
                  }
               }
            }
         }
      }
   }

   private void setDefaultThresholds() {
      this.setJavaThresholds();
      this.setBedrockThresholds();
      this.randomizeThresholds();
   }

   private void setJavaThresholds() {
      this.javaThresholds.put("fly", 15);
      this.javaThresholds.put("speed", 35);
      this.javaThresholds.put("jesus", 15);
      this.javaThresholds.put("step", 18);
      this.javaThresholds.put("highjump", 12);
      this.javaThresholds.put("spider", 20);
      this.javaThresholds.put("glide", 18);
      this.javaThresholds.put("blink", 25);
      this.javaThresholds.put("nofall", 20);
      this.javaThresholds.put("timer", 25);
      this.javaThresholds.put("noslow", 30);
      this.javaThresholds.put("reach", 5);
      this.javaThresholds.put("killaura", 8);
      this.javaThresholds.put("criticals", 8);
      this.javaThresholds.put("antivelocity", 10);
      this.javaThresholds.put("aimbot", 6);
      this.javaThresholds.put("triggerbot", 8);
      this.javaThresholds.put("hitbox", 3);
      this.javaThresholds.put("shieldstun", 10);
      this.javaThresholds.put("autoclick", 15);
      this.javaThresholds.put("fastbreak", 12);
      this.javaThresholds.put("fastplace", 12);
      this.javaThresholds.put("nuker", 8);
      this.javaThresholds.put("scaffold", 10);
      this.javaThresholds.put("freecam", 12);
      this.javaThresholds.put("badpackets", 10);
      this.javaThresholds.put("inventorymove", 8);
      this.javaThresholds.put("derp", 15);
      this.javaThresholds.put("omnisprint", 10);
      this.javaThresholds.put("noswing", 9);
      this.javaThresholds.put("head", 12);
      this.javaThresholds.put("chatspam", 18);
      this.javaThresholds.put("commandspam", 15);
      this.javaThresholds.put("crystalaura", 5);
      this.javaThresholds.put("autoanchor", 6);
      this.javaThresholds.put("airplace", 2);
      this.javaThresholds.put("antihunger", 2);
      this.javaThresholds.put("mace_reach", 2);
      this.javaThresholds.put("mace_speed", 4);
      this.javaThresholds.put("mace_damage", 2);
   }

   private void setBedrockThresholds() {
      this.bedrockThresholds.put("fly", 15);
      this.bedrockThresholds.put("speed", 25);
      this.bedrockThresholds.put("jesus", 12);
      this.bedrockThresholds.put("step", 15);
      this.bedrockThresholds.put("highjump", 20);
      this.bedrockThresholds.put("spider", 30);
      this.bedrockThresholds.put("glide", 25);
      this.bedrockThresholds.put("blink", 35);
      this.bedrockThresholds.put("nofall", 30);
      this.bedrockThresholds.put("timer", 35);
      this.bedrockThresholds.put("noslow", 40);
      this.bedrockThresholds.put("reach", 8);
      this.bedrockThresholds.put("killaura", 12);
      this.bedrockThresholds.put("criticals", 10);
      this.bedrockThresholds.put("antivelocity", 15);
      this.bedrockThresholds.put("aimbot", 10);
      this.bedrockThresholds.put("triggerbot", 12);
      this.bedrockThresholds.put("hitbox", 6);
      this.bedrockThresholds.put("shieldstun", 12);
      this.bedrockThresholds.put("autoclick", 18);
      this.bedrockThresholds.put("fastbreak", 15);
      this.bedrockThresholds.put("fastplace", 15);
      this.bedrockThresholds.put("nuker", 12);
      this.bedrockThresholds.put("scaffold", 15);
      this.bedrockThresholds.put("freecam", 15);
      this.bedrockThresholds.put("badpackets", 12);
      this.bedrockThresholds.put("inventorymove", 10);
      this.bedrockThresholds.put("derp", 18);
      this.bedrockThresholds.put("omnisprint", 12);
      this.bedrockThresholds.put("noswing", 11);
      this.bedrockThresholds.put("head", 15);
      this.bedrockThresholds.put("chatspam", 22);
      this.bedrockThresholds.put("commandspam", 18);
      this.bedrockThresholds.put("crystalaura", 7);
      this.bedrockThresholds.put("autoanchor", 8);
      this.bedrockThresholds.put("airplace", 3);
      this.bedrockThresholds.put("antihunger", 3);
      this.bedrockThresholds.put("mace_reach", 3);
      this.bedrockThresholds.put("mace_speed", 6);
      this.bedrockThresholds.put("mace_damage", 3);
   }

   private void randomizeThresholds() {
      Random random = new Random();

      for(Map.Entry<String, Integer> entry : this.javaThresholds.entrySet()) {
         int baseThreshold = (Integer)entry.getValue();
         if (baseThreshold >= 4) {
            int randomized = baseThreshold + random.nextInt(3) - 1;
            randomized = Math.max(1, randomized);
            entry.setValue(randomized);
         }
      }

      for(Map.Entry<String, Integer> entry : this.bedrockThresholds.entrySet()) {
         int baseThreshold = (Integer)entry.getValue();
         if (baseThreshold >= 5) {
            int randomized = baseThreshold + random.nextInt(3) - 1;
            randomized = Math.max(2, randomized);
            entry.setValue(randomized);
         }
      }

   }

   public void reloadConfig(JavaPlugin plugin) {
      try {
         plugin.reloadConfig();
         FileConfiguration config = plugin.getConfig();
         this.webhookUrl = config.getString("anticheat.discord_webhook_url", "");
         this.webhookMessage = config.getString("anticheat.webhook_message", "[AntiSystem] %type% detected for %player%: %reason%");
         this.javaChecks = config.getBoolean("anticheat.java_checks", true);
         this.bedrockChecks = config.getBoolean("anticheat.bedrock_checks", true);
      } catch (Exception e) {
         String errorMsg = "Error reloading config: " + e.getMessage();
         this.plugin.getLogger().warning(errorMsg);
      }

   }

   public Map<Player, Map<String, Integer>> getViolations() {
      return new HashMap(this.violations);
   }

   public Map<Player, Map<String, Long>> getLastViolationTime() {
      return new HashMap(this.lastViolationTime);
   }

   public Map<Player, Long> getPlayerJoinTime() {
      return new HashMap(this.playerJoinTime);
   }

   public boolean isBedrock(Player player) {
      Boolean cached = (Boolean)this.bedrockCache.get(player);
      if (cached != null) {
         return cached;
      } else {
         try {
            boolean hasFloodgate = Bukkit.getPluginManager().getPlugin("floodgate") != null;
            boolean hasGeyser = Bukkit.getPluginManager().getPlugin("Geyser-Spigot") != null || Bukkit.getPluginManager().getPlugin("Geyser-Bukkit") != null || Bukkit.getPluginManager().getPlugin("geyser") != null;
            if (!hasFloodgate && !hasGeyser) {
               this.bedrockCache.put(player, false);
               return false;
            } else {
               String uuid = player.getUniqueId().toString();
               if (uuid.startsWith("00000000-0000-0000-0009")) {
                  this.bedrockCache.put(player, true);
                  return true;
               } else {
                  boolean hasFloodgateMeta = player.hasMetadata("floodgate-player");
                  if (hasFloodgateMeta) {
                     this.bedrockCache.put(player, true);
                     return true;
                  } else {
                     boolean hasForced = player.hasMetadata("antisystem.bedrock.forced");
                     if (hasForced) {
                        this.bedrockCache.put(player, true);
                        return true;
                     } else {
                        this.bedrockCache.put(player, false);
                        return false;
                     }
                  }
               }
            }
         } catch (Exception e) {
            String errorMsg = "Error detecting player edition for " + player.getName() + ": " + e.getMessage();
            this.plugin.getLogger().warning(errorMsg);
            this.bedrockCache.put(player, false);
            return false;
         }
      }
   }

   public void setPlayerEdition(Player player, boolean isBedrock) {
      this.bedrockCache.remove(player);
      if (isBedrock) {
         player.setMetadata("antisystem.bedrock.forced", new FixedMetadataValue(this.plugin, true));
      } else {
         player.removeMetadata("antisystem.bedrock.forced", this.plugin);
      }

   }

   public String getEditionDebugInfo(Player player) {
      StringBuilder info = new StringBuilder();
      info.append("§7Player: §f").append(player.getName()).append("\n");
      info.append("§7Final Detection: §f").append(this.isBedrock(player) ? "§aBedrock" : "§eJava").append("\n");
      info.append("§7UUID: §f").append(player.getUniqueId().toString()).append("\n");
      String uuid = player.getUniqueId().toString();
      info.append("§7UUID Check: §f").append(uuid.startsWith("00000000-0000-0000-0009") ? "§aBedrock" : "§cJava").append("\n");
      info.append("§7Floodgate Meta: §f").append(player.hasMetadata("floodgate-player") ? "§aYes" : "§cNo").append("\n");
      info.append("§7Forced Setting: §f").append(player.hasMetadata("antisystem.bedrock.forced") ? "§aYes" : "§cNo").append("\n");
      return info.toString();
   }

   private void notifyDetection(Player player, String type, String reason) {
      String key = player.getUniqueId() + ":" + type + ":detection";
      long currentTime = System.currentTimeMillis();
      Long lastNotification = (Long)this.lastNotificationTime.get(key);
      if (lastNotification == null || currentTime - lastNotification >= 3000L) {
         this.lastNotificationTime.put(key, currentTime);
         String msg = this.webhookMessage.replace("%player%", player.getName()).replace("%type%", type).replace("%reason%", reason);
         this.plugin.getLogger().warning(msg);
         player.getServer().getOnlinePlayers().stream().filter((op) -> (op.isOp() || op.hasPermission("anticheat.alerts")) && !op.equals(player)).forEach((op) -> op.sendMessage("§c[AntiCheat] " + player.getName() + " flagged for " + type));
         if (this.webhookUrl != null && !this.webhookUrl.isEmpty()) {
            this.sendDiscordWebhook(this.webhookUrl, msg);
         }

      }
   }

   private void sendDiscordWebhook(String url, String content) {
      try {
         URL webhook = URI.create(url).toURL();
         HttpURLConnection connection = (HttpURLConnection)webhook.openConnection();
         connection.setRequestMethod("POST");
         connection.setRequestProperty("Content-Type", "application/json");
         connection.setDoOutput(true);
         String json = "{\"content\":\"" + content.replace("\"", "\\\"") + "\"}";
         OutputStream os = connection.getOutputStream();

         try {
            os.write(json.getBytes());
         } catch (Throwable var10) {
            if (os != null) {
               try {
                  os.close();
               } catch (Throwable var9) {
                  var10.addSuppressed(var9);
               }
            }

            throw var10;
         }

         if (os != null) {
            os.close();
         }

         connection.getInputStream().close();
      } catch (IOException var11) {
      }

   }

   public int getViolationCount(Player player, String type) {
      Map<String, Integer> vmap = (Map)this.violations.get(player);
      return vmap == null ? 0 : (Integer)vmap.getOrDefault(type, 0);
   }

   private void addViolation(Player player, String type, int threshold, String kickMsg) {
      try {
         long currentTime = System.currentTimeMillis();
         if (this.isBlocked(player)) {
            return;
         }

         Long lastBlockTime = (Long)this.blockTime.get(player);
         if (lastBlockTime != null && currentTime - lastBlockTime < 15000L) {
            return;
         }

         Map<String, Integer> vmap = (Map)this.violations.computeIfAbsent(player, (k) -> new HashMap());
         Map<String, Long> timemap = (Map)this.lastViolationTime.computeIfAbsent(player, (k) -> new HashMap());
         int v = (Integer)vmap.getOrDefault(type, 0) + 1;
         vmap.put(type, v);
         timemap.put(type, currentTime);
         if (v >= threshold) {
            this.notifyDetection(player, type, "FLAGGED: " + player.getName() + " (" + type + ") " + v + "/" + threshold + " - " + kickMsg);
            if (v >= threshold * 2) {
               this.blockCheater(player, type + " violations");
            }

            vmap.put(type, Math.max(0, v / 2));
         }
      } catch (Exception e) {
         String errorMsg = "Error in addViolation for " + player.getName() + ": " + e.getMessage();
         this.plugin.getLogger().severe(errorMsg);
      }

   }

   @EventHandler
   public void onEntityDamage(EntityDamageEvent event) {
      if (event.getEntity() instanceof Player) {
         Player player = (Player)event.getEntity();
         if (event.getCause() == DamageCause.FALL && player.hasMetadata("expectedFallDamage")) {
            player.removeMetadata("expectedFallDamage", this.plugin);
            player.removeMetadata("fallHeight", this.plugin);
         }

         if (event.getCause() == DamageCause.ENTITY_ATTACK || event.getCause() == DamageCause.PROJECTILE || event.getCause() == DamageCause.ENTITY_EXPLOSION || event.getCause() == DamageCause.BLOCK_EXPLOSION || event.getCause() == DamageCause.MAGIC) {
            long compensationTime = System.currentTimeMillis() + 2000L;
            player.setMetadata("mobDamageTime", new FixedMetadataValue(this.plugin, compensationTime));
            player.setMetadata("knockbackEffect", new FixedMetadataValue(this.plugin, compensationTime));
         }
      }

   }

   @EventHandler
   public void onPlayerMove(PlayerMoveEvent event) {
      Player player = event.getPlayer();
      if (!player.isOp() && !player.hasPermission("anticheat.bypass")) {
         if (this.isBlocked(player)) {
            Long blockStartTime = (Long)this.blockTime.get(player);
            if (blockStartTime != null && System.currentTimeMillis() - blockStartTime > 300000L) {
               this.unblockCheater(player);
               player.sendMessage("§a§l[AntiCheat] §7Emergency auto-release after 5 minutes.");
            } else {
               Location from = event.getFrom();
               event.setTo(from);
               player.setVelocity(new Vector(0, 0, 0));
            }
         } else if (!player.hasPermission("antisystem.bypass.movement")) {
            boolean bedrock = this.isBedrock(player);
            if ((!bedrock || this.bedrockChecks) && (bedrock || this.javaChecks)) {
               if (bedrock) {
                  this.handleBedrockMove(event, player);
               } else {
                  this.handleJavaMove(event, player);
               }

            }
         }
      }
   }

   private void handleJavaMove(PlayerMoveEvent event, Player player) {
      try {
         boolean exemptFromMovement = this.isExemptFromMovementChecks(player);
         if (exemptFromMovement) {
            return;
         }

         Location currentLoc = event.getTo();
         Location fromLoc = event.getFrom();
         if (currentLoc == null || fromLoc == null) {
            return;
         }

         double dx = currentLoc.getX() - fromLoc.getX();
         double dy = currentLoc.getY() - fromLoc.getY();
         double dz = currentLoc.getZ() - fromLoc.getZ();
         double horizontalDistance = Math.sqrt(dx * dx + dz * dz);
         double baseSpeedLimit = 0.6;
         if (player.isSprinting()) {
            baseSpeedLimit = (double)1.0F;
         }

         if (player.hasPotionEffect(PotionEffectType.SPEED)) {
            baseSpeedLimit += 0.4;
         }

         if (horizontalDistance > baseSpeedLimit + 0.2) {
            this.addViolation(player, "speed", (Integer)this.javaThresholds.getOrDefault("speed", 35), "AntiCheat: Speed hack detected (Java) - Distance: " + String.format("%.2f", horizontalDistance));
         }

         if (Math.abs(dy) > (double)2.0F && !exemptFromMovement) {
            this.addViolation(player, "fly", (Integer)this.javaThresholds.getOrDefault("fly", 15), "AntiCheat: Fly detected (Java) - Y difference: " + dy);
         }
      } catch (Exception e) {
         if (this.plugin.getConfig().getBoolean("anticheat.debug", false)) {
            String errorMsg = "Error in handleJavaMove: " + e.getMessage();
            this.plugin.getLogger().warning(errorMsg);
         }
      }

   }

   private void handleBedrockMove(PlayerMoveEvent event, Player player) {
      try {
         boolean exemptFromMovement = this.isExemptFromMovementChecks(player);
         if (exemptFromMovement) {
            return;
         }

         Location currentLoc = event.getTo();
         Location fromLoc = event.getFrom();
         if (currentLoc == null || fromLoc == null) {
            return;
         }

         double dx = currentLoc.getX() - fromLoc.getX();
         double dy = currentLoc.getY() - fromLoc.getY();
         double dz = currentLoc.getZ() - fromLoc.getZ();
         double horizontalDistance = Math.sqrt(dx * dx + dz * dz);
         double baseSpeedLimit = 0.8;
         if (player.isSprinting()) {
            baseSpeedLimit = 1.2;
         }

         if (horizontalDistance > baseSpeedLimit + 0.3) {
            this.addViolation(player, "speed", (Integer)this.bedrockThresholds.getOrDefault("speed", 25), "AntiCheat: Speed hack detected (Bedrock) - Distance: " + String.format("%.2f", horizontalDistance));
         }

         if (Math.abs(dy) > (double)3.0F) {
            this.addViolation(player, "fly", (Integer)this.bedrockThresholds.getOrDefault("fly", 15), "AntiCheat: Fly detected (Bedrock) - Y difference: " + dy);
         }
      } catch (Exception e) {
         if (this.plugin.getConfig().getBoolean("anticheat.debug", false)) {
            String errorMsg = "Error in handleBedrockMove: " + e.getMessage();
            this.plugin.getLogger().warning(errorMsg);
         }
      }

   }

   @EventHandler
   public void onTriggerBotDetection(PlayerInteractEvent event) {
      Player player = event.getPlayer();
      if (!player.isOp() && !player.hasPermission("anticheat.bypass")) {
         if (this.isBlocked(player)) {
            event.setCancelled(true);
         } else {
            long now = System.currentTimeMillis();
            long last = (Long)this.lastAttackPacketTime.getOrDefault(player, 0L);
            if (now - last < 50L) {
               int count = (Integer)this.triggerRapidHits.getOrDefault(player, 0) + 1;
               this.triggerRapidHits.put(player, count);
               if (count > 5) {
                  this.addViolation(player, "triggerbot", 2, "AntiCheat: TriggerBot rapid attack detected");
                  event.setCancelled(true);
                  this.blockCheater(player, "TriggerBot rapid attack detected");
               }
            } else {
               this.triggerRapidHits.put(player, 0);
            }

            this.lastAttackPacketTime.put(player, now);
         }
      }
   }

   @EventHandler
   public void onFastBreakDetection(BlockBreakEvent event) {
      Player player = event.getPlayer();
      if (!player.isOp() && !player.hasPermission("anticheat.bypass") && !player.hasPermission("anticheat.bypass.fastbreak")) {
         if (player.getGameMode() != GameMode.CREATIVE) {
            if (this.isBlocked(player)) {
               event.setCancelled(true);
            } else {
               Material blockType = event.getBlock().getType();
               if (!this.isInstantBreakBlock(blockType)) {
                  long now = System.currentTimeMillis();
                  long last = (Long)this.lastBlockBreakTime.getOrDefault(player, 0L);
                  int minBreakTime = 100;
                  if (now - last < (long)minBreakTime) {
                     int count = (Integer)this.fastBreakViolations.getOrDefault(player, 0) + 1;
                     this.fastBreakViolations.put(player, count);
                     if (count > 5) {
                        this.addViolation(player, "fastbreak", 2, "AntiCheat: Fast break detected on " + blockType.name());
                        event.setCancelled(true);
                     }
                  } else {
                     this.fastBreakViolations.put(player, 0);
                  }

                  this.lastBlockBreakTime.put(player, now);
               }
            }
         }
      }
   }

   private boolean isInstantBreakBlock(Material material) {
      String name = material.name().toLowerCase();
      return name.contains("grass") || name.contains("flower") || name.contains("crop") || name.contains("torch") || name.contains("redstone") || name.equals("snow") || material == Material.TNT || material == Material.SLIME_BLOCK;
   }

   public void performAIRetraining() {
      if (this.plugin != null) {
         this.plugin.getLogger().info("AI retraining cycle completed");
      }

   }

   public void shutdownAI() {
      if (this.plugin != null) {
         this.plugin.getLogger().info("AI systems shut down successfully");
      }

   }
}
