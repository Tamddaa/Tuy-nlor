package com.anti.system.anticheat;

import com.anti.system.utils.VersionCompatibility;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDamageEvent.DamageCause;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;

public class FallDamageProtection implements Listener {
   @EventHandler(
      priority = EventPriority.MONITOR,
      ignoreCancelled = true
   )
   public void onEntityDamage(EntityDamageEvent event) {
      if (event.getEntity() instanceof Player) {
         Player player = (Player)event.getEntity();
         if (event.getCause() == DamageCause.FALL) {
            ItemStack[] armorContents = (ItemStack[])player.getInventory().getArmorContents().clone();
            ItemStack offHandItem = this.getOffHandItem(player);
            Bukkit.getScheduler().runTaskLater(JavaPlugin.getProvidingPlugin(this.getClass()), () -> {
               if (player.isOnline() && !player.isDead()) {
                  ItemStack[] currentArmor = player.getInventory().getArmorContents();
                  boolean armorWasCleared = true;

                  for(ItemStack item : currentArmor) {
                     if (item != null && item.getType() != Material.AIR) {
                        armorWasCleared = false;
                        break;
                     }
                  }

                  if (armorWasCleared && armorContents != null) {
                     boolean hadArmor = false;

                     for(ItemStack item : armorContents) {
                        if (item != null && item.getType() != Material.AIR) {
                           hadArmor = true;
                           break;
                        }
                     }

                     if (hadArmor) {
                        player.getInventory().setArmorContents(armorContents);
                        player.sendMessage("§a[Protection] Your armor was restored after fall damage!");
                        System.out.println("[FallDamageProtection] Restored armor for " + player.getName() + " after fall damage");
                     }
                  }

                  ItemStack currentOffHand;
                  if (((currentOffHand = this.getOffHandItem(player)) == null || currentOffHand.getType() == Material.AIR) && offHandItem != null && offHandItem.getType() != Material.AIR) {
                     this.setOffHandItem(player, offHandItem);
                  }

                  try {
                     player.updateInventory();
                  } catch (Exception var12) {
                  }
               }

            }, 2L);
         }
      }
   }

   private ItemStack getOffHandItem(Player player) {
      if (!VersionCompatibility.hasOffHandSupport()) {
         return null;
      } else {
         try {
            Object inventory = player.getInventory();
            Method method = inventory.getClass().getMethod("getItemInOffHand");
            ItemStack item = (ItemStack)method.invoke(inventory);
            return item != null ? item.clone() : null;
         } catch (IllegalAccessException | InvocationTargetException | ClassCastException | NoSuchMethodException var5) {
            return null;
         }
      }
   }

   private void setOffHandItem(Player player, ItemStack item) {
      if (VersionCompatibility.hasOffHandSupport()) {
         try {
            Object inventory = player.getInventory();
            Method method = inventory.getClass().getMethod("setItemInOffHand", ItemStack.class);
            method.invoke(inventory, item);
         } catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException var5) {
         }

      }
   }
}
