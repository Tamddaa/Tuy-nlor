package com.anti.system.anticheat;

import com.anti.system.utils.BypassUtils;
import com.anti.system.utils.VersionCompatibility;
import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.lang.reflect.InvocationTargetException;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.metadata.MetadataValue;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public class BedrockAC implements Listener {
   private final Map<Player, Map<String, Integer>> violations = new HashMap();
   private String webhookUrl = "";
   private String webhookMessage = "[AntiSystem] %type% detected for %player%: %reason%";
   private int headThreshold = 25;
   private final Map<Player, Boolean> isBedrockPlayer = new HashMap();
   private double maxSpeedJava = (double)1.0F;
   private double maxSpeedBedrock = (double)1.5F;
   private float maxYawJava = 320.0F;
   private float maxYawBedrock = 360.0F;
   private float maxPitchJava = 160.0F;
   private float maxPitchBedrock = 180.0F;

   public BedrockAC() {
      try {
         File configFile = new File(JavaPlugin.getProvidingPlugin(this.getClass()).getDataFolder(), "bedrockac.yml");
         if (!configFile.exists()) {
            JavaPlugin.getProvidingPlugin(this.getClass()).saveResource("bedrockac.yml", false);
         }

         YamlConfiguration config = YamlConfiguration.loadConfiguration(configFile);
         this.webhookUrl = config.getString("discord_webhook_url", "");
         this.webhookMessage = config.getString("webhook_message", "[AntiSystem] %type% detected for %player%: %reason%");
         this.headThreshold = config.getInt("head_threshold", 25);
         this.maxSpeedJava = config.getDouble("java.max_speed", (double)1.0F);
         this.maxSpeedBedrock = config.getDouble("bedrock.max_speed", (double)1.5F);
         this.maxYawJava = (float)config.getDouble("java.max_yaw", (double)320.0F);
         this.maxYawBedrock = (float)config.getDouble("bedrock.max_yaw", (double)360.0F);
         this.maxPitchJava = (float)config.getDouble("java.max_pitch", (double)160.0F);
         this.maxPitchBedrock = (float)config.getDouble("bedrock.max_pitch", (double)180.0F);
      } catch (Exception var3) {
      }

   }

   private void notifyDetection(Player player, String type, String reason) {
      String msg = this.webhookMessage.replace("%player%", player.getName()).replace("%type%", type).replace("%reason%", reason);
      Bukkit.getLogger().warning(msg);
      player.getServer().getOnlinePlayers().stream().filter((op) -> op.isOp()).forEach((op) -> op.sendMessage(msg));
      if (this.webhookUrl != null && !this.webhookUrl.isEmpty()) {
         this.sendDiscordWebhook(this.webhookUrl, msg);
      }

   }

   private void sendDiscordWebhook(String url, String content) {
      try {
         URL webhook = URI.create(url).toURL();
         HttpURLConnection connection = (HttpURLConnection)webhook.openConnection();
         connection.setRequestMethod("POST");
         connection.setRequestProperty("Content-Type", "application/json");
         connection.setDoOutput(true);
         String json = "{\"content\":\"" + content.replace("\"", "\\\"") + "\"}";
         OutputStream os = connection.getOutputStream();

         try {
            os.write(json.getBytes());
         } catch (Throwable var10) {
            if (os != null) {
               try {
                  os.close();
               } catch (Throwable var9) {
                  var10.addSuppressed(var9);
               }
            }

            throw var10;
         }

         if (os != null) {
            os.close();
         }

         connection.getInputStream().close();
      } catch (IOException var11) {
      }

   }

   private void addViolation(Player player, String type, int threshold, String kickMsg) {
      Map<String, Integer> vmap = (Map)this.violations.computeIfAbsent(player, (k) -> new HashMap());
      int v = (Integer)vmap.getOrDefault(type, 0) + 1;
      vmap.put(type, v);
      if (v >= threshold) {
         this.notifyDetection(player, type, kickMsg);
         player.kickPlayer(kickMsg);
         vmap.put(type, 0);
      }

   }

   @EventHandler
   public void onPlayerMove(PlayerMoveEvent event) {
      Player player = event.getPlayer();
      if (!BypassUtils.hasAntiCheatBypass(player)) {
         if (!player.getAllowFlight() && player.getVelocity().getY() > 1.2 && event.getFrom().getY() < event.getTo().getY()) {
            this.addViolation(player, "fly", 2, "AntiCheat: Fly detected");
         }

         double dx = event.getTo().getX() - event.getFrom().getX();
         double dz = event.getTo().getZ() - event.getFrom().getZ();
         double horizontalSpeed = Math.sqrt(dx * dx + dz * dz);
         boolean isBedrock = (Boolean)this.isBedrockPlayer.getOrDefault(player, false);
         double maxSpeed = isBedrock ? this.maxSpeedBedrock : this.maxSpeedJava;
         double speedMultiplier = (double)1.0F;
         if (player.isSprinting()) {
            speedMultiplier *= 1.3;
         }

         if (player.hasPotionEffect(PotionEffectType.SPEED)) {
            PotionEffect speedEffect = null;

            for(PotionEffect effect : player.getActivePotionEffects()) {
               if (effect.getType().equals(PotionEffectType.SPEED)) {
                  speedEffect = effect;
                  break;
               }
            }

            if (speedEffect != null) {
               int amplifier = speedEffect.getAmplifier();
               speedMultiplier *= (double)1.0F + (double)(amplifier + 1) * 0.35;
            }
         }

         if (player.hasPotionEffect(VersionCompatibility.getJumpBoostEffect())) {
            PotionEffect jumpEffect = null;

            for(PotionEffect effect : player.getActivePotionEffects()) {
               if (effect.getType().equals(VersionCompatibility.getJumpBoostEffect())) {
                  jumpEffect = effect;
                  break;
               }
            }

            if (jumpEffect != null) {
               int amplifier = jumpEffect.getAmplifier();
               speedMultiplier *= (double)1.0F + (double)(amplifier + 1) * 0.15;
            }
         }

         if (event.getTo().getY() > event.getFrom().getY()) {
            speedMultiplier *= (double)1.25F;
         }

         double adjustedMaxSpeed;
         if (horizontalSpeed > (adjustedMaxSpeed = maxSpeed * speedMultiplier) && !player.hasPermission("anticheat.bypass.speed")) {
            this.addViolation(player, "speed", 8, "AntiCheat: Speed detected (" + String.format("%.2f", horizontalSpeed) + " > " + String.format("%.2f", adjustedMaxSpeed) + ")");
         }

         float fromYaw = event.getFrom().getYaw();
         float toYaw = event.getTo().getYaw();
         float fromPitch = event.getFrom().getPitch();
         float toPitch = event.getTo().getPitch();
         float yawDiff = Math.abs(toYaw - fromYaw);
         float pitchDiff = Math.abs(toPitch - fromPitch);
         if (yawDiff > 180.0F) {
            yawDiff = 360.0F - yawDiff;
         }

         float maxYaw = isBedrock ? this.maxYawBedrock : this.maxYawJava;
         float maxPitch = isBedrock ? this.maxPitchBedrock : this.maxPitchJava;
         if ((yawDiff > maxYaw || pitchDiff > maxPitch) && !player.hasPermission("anticheat.bypass.head")) {
            this.addViolation(player, "head", this.headThreshold, "AntiCheat: Extreme head movement detected (Yaw: " + String.format("%.1f", yawDiff) + ", Pitch: " + String.format("%.1f", pitchDiff) + ")");
         }

         Block toBlock = player.getWorld().getBlockAt(event.getTo());
         Block headBlock = toBlock.getRelative(BlockFace.UP);
         boolean insideSolidBlock = !this.isBlockPassable(toBlock) && !this.isBlockPassable(headBlock);
         boolean legitMovement = player.isFlying() || player.getAllowFlight() || player.getGameMode() == GameMode.CREATIVE || player.getGameMode() == GameMode.SPECTATOR;
         if (insideSolidBlock && !legitMovement && !player.isOp() && !player.hasPermission("anticheat.bypass.noclip")) {
            this.addViolation(player, "noclip", 8, "AntiCheat: Noclip detected");
         }

      }
   }

   @EventHandler
   public void onEntityDamage(EntityDamageByEntityEvent event) {
      if (event.getDamager() instanceof Player && event.getEntity() instanceof Player) {
         Player attacker = (Player)event.getDamager();
         Player victim = (Player)event.getEntity();
         if (BypassUtils.hasAntiCheatBypass(attacker)) {
            return;
         }

         if (!attacker.getLocation().getWorld().equals(victim.getLocation().getWorld())) {
            return;
         }

         double reach = attacker.getLocation().distance(victim.getLocation());
         if (reach > (double)4.5F) {
            event.setCancelled(true);
            this.addViolation(attacker, "reach", 2, "AntiCheat: Reach detected");
         }

         long now = System.currentTimeMillis();
         Long lastAttack = null;
         if (attacker.hasMetadata("lastAttackTime")) {
            lastAttack = ((MetadataValue)attacker.getMetadata("lastAttackTime").get(0)).asLong();
         }

         if (lastAttack != null && now - lastAttack < 200L) {
            event.setCancelled(true);
            this.addViolation(attacker, "killaura", 2, "AntiCheat: Kill aura/auto-attack detected");
         }

         attacker.setMetadata("lastAttackTime", new FixedMetadataValue(JavaPlugin.getProvidingPlugin(this.getClass()), now));
         boolean isBedrock = attacker.hasPermission("floodgate.legacy") || attacker.getName().startsWith(".") || attacker.getName().length() > 16;
         if (isBedrock && (attacker.getVelocity().getY() > -0.08 || (double)attacker.getFallDistance() < 0.1)) {
            event.setDamage(event.getDamage() / (double)1.5F);
         }
      }

   }

   @EventHandler
   public void onPlayerInteract(PlayerInteractEvent event) {
      Player player = event.getPlayer();
      if (!BypassUtils.hasAntiCheatBypass(player)) {
         ItemStack item = event.getItem();
         if (item != null && item.getType() == Material.BEDROCK && !player.hasPermission("anticheat.bypass.bedrock")) {
            event.setCancelled(true);
            player.getInventory().remove(item);
            this.addViolation(player, "illegalitem", 1, "AntiCheat: Illegal item (bedrock)");
         }

         if (item != null && (item.getType() == Material.BARRIER || item.getType().name().contains("COMMAND_BLOCK") || item.getType().name().contains("STRUCTURE_BLOCK")) && !player.isOp()) {
            event.setCancelled(true);
            player.getInventory().remove(item);
            this.addViolation(player, "illegalitem", 1, "AntiCheat: Illegal item (" + item.getType() + ")");
         }

      }
   }

   @EventHandler
   public void onCommand(PlayerCommandPreprocessEvent event) {
      Player player = event.getPlayer();
      if (!BypassUtils.hasAntiCheatBypass(player)) {
         String msg = event.getMessage().toLowerCase();
         if (msg.contains("/op") || msg.contains("/deop") || msg.contains("/give") || msg.contains("/minecraft:give") || msg.contains("/reload") || msg.contains("/stop")) {
            event.setCancelled(true);
            this.addViolation(event.getPlayer(), "command", 1, "AntiCheat: Command exploit");
         }

         if (msg.contains("/plugman") || msg.contains("/packet") || msg.contains("/bukkit:reload")) {
            event.setCancelled(true);
            this.addViolation(event.getPlayer(), "command", 1, "AntiCheat: Plugin/packet exploit");
         }

      }
   }

   @EventHandler
   public void onJoin(PlayerJoinEvent event) {
      Player player = event.getPlayer();
      this.violations.put(player, new HashMap());
      boolean isBedrock = this.detectBedrockPlayer(player);
      this.isBedrockPlayer.put(player, isBedrock);
      if (isBedrock) {
         String joinMsg = "[AntiSystem] Bedrock player joined: " + player.getName() + " (Enhanced compatibility enabled)";
         Bukkit.getLogger().info(joinMsg);
         player.getServer().getOnlinePlayers().stream().filter((op) -> op.isOp()).forEach((op) -> op.sendMessage(joinMsg));
         if (this.webhookUrl != null && !this.webhookUrl.isEmpty()) {
            String msg = this.webhookMessage.replace("%player%", player.getName()).replace("%type%", "bedrock_join").replace("%reason%", "Bedrock player joined with enhanced compatibility");
            this.sendDiscordWebhook(this.webhookUrl, msg);
         }

         player.sendMessage("§a[AntiSystem] Bedrock compatibility mode enabled");
      }

   }

   private boolean detectBedrockPlayer(Player player) {
      String playerName = player.getName();
      String uuid = player.getUniqueId().toString();
      boolean isBedrock = false;
      if (player.hasPermission("floodgate.legacy") || playerName.startsWith(".") || playerName.length() > 16) {
         isBedrock = true;
      }

      if (uuid.startsWith("00000000-")) {
         isBedrock = true;
      }

      if (playerName.contains("*") || playerName.matches(".*[^a-zA-Z0-9_].*")) {
         isBedrock = true;
      }

      try {
         Class.forName("org.geysermc.geyser.api.GeyserApi");
      } catch (ClassNotFoundException var6) {
      }

      return isBedrock;
   }

   private boolean isBlockPassable(Block block) {
      try {
         return (Boolean)block.getClass().getMethod("isPassable").invoke(block);
      } catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException var4) {
         Material type = block.getType();
         return type == Material.AIR || type.name().contains("WATER") || type.name().contains("LAVA") || type.name().contains("GRASS") || type.name().contains("FLOWER") || type.name().contains("SAPLING") || type.name().contains("SIGN") || type.name().contains("TORCH") || type.name().contains("REDSTONE") || type.name().contains("RAIL") || type == Material.SNOW;
      }
   }
}
