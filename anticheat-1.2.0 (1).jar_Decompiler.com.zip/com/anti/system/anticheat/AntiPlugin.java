package com.anti.system.anticheat;

import com.anti.system.utils.BypassUtils;
import java.lang.reflect.InvocationTargetException;
import java.util.List;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerCommandSendEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.plugin.java.JavaPlugin;

public class AntiPlugin implements Listener, CommandExecutor {
   private final JavaPlugin plugin;
   private boolean blockCommands = true;
   private boolean blockTab = true;
   private boolean detectMeteor = true;
   private List<String> blockedCommands;
   private List<String> blockedKeywords;

   public AntiPlugin(JavaPlugin plugin) {
      this.plugin = plugin;
      this.loadConfig();
   }

   private void loadConfig() {
      this.plugin.saveDefaultConfig();
      FileConfiguration config = this.plugin.getConfig();
      this.blockCommands = config.getBoolean("block_commands", true);
      this.blockTab = config.getBoolean("block_tab_complete", true);
      this.detectMeteor = config.getBoolean("detect_meteor", true);
      this.blockedCommands = config.getStringList("blocked_commands");
      this.blockedKeywords = config.getStringList("blocked_keywords");
   }

   @EventHandler
   public void onCommand(PlayerCommandPreprocessEvent event) {
      if (this.blockCommands) {
         Player player = event.getPlayer();
         if (!BypassUtils.hasAntiSystemBypass(player)) {
            String msg = event.getMessage().toLowerCase();
            String cmd = msg.split(" ", 2)[0].replaceFirst("/", "");

            for(String blocked : this.blockedCommands) {
               if (cmd.equalsIgnoreCase(blocked)) {
                  event.setCancelled(true);
                  event.getPlayer().sendMessage("[AntiSystem] Plugin list blocked.");
                  return;
               }
            }

            for(String keyword : this.blockedKeywords) {
               if (msg.contains(keyword)) {
                  event.setCancelled(true);
                  event.getPlayer().sendMessage("[AntiSystem] Plugin list blocked.");
                  return;
               }
            }

         }
      }
   }

   @EventHandler
   public void onTabComplete(PlayerCommandSendEvent event) {
      if (this.blockTab) {
         Player player = event.getPlayer();
         if (!BypassUtils.hasAntiSystemBypass(player)) {
            event.getCommands().removeIf((cmd) -> this.blockedCommands.stream().anyMatch((b) -> cmd.equalsIgnoreCase(b)) || this.blockedKeywords.stream().anyMatch((k) -> cmd.toLowerCase().contains(k)));
         }
      }
   }

   @EventHandler
   public void onJoin(PlayerJoinEvent event) {
      if (this.detectMeteor) {
         Player player = event.getPlayer();
         String brand = this.getClientBrandSafely(player);
         if (brand != null && brand.toLowerCase().contains("meteor")) {
            Bukkit.getLogger().warning(String.format("[AntiSystem] Player '%s' attempted to join with Meteor Client!", player.getName()));
            player.kickPlayer("[AntiSystem] Meteor Client is not allowed.");
         }

      }
   }

   private String getClientBrandSafely(Player player) {
      try {
         return (String)player.getClass().getMethod("getClientBrandName").invoke(player);
      } catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException var3) {
         return null;
      }
   }

   public boolean onCommand(CommandSender sender, Command command, String label, String[] args2) {
      if (label.equalsIgnoreCase("antipluginreload")) {
         this.loadConfig();
         sender.sendMessage("[AntiSystem] AntiPlugin config reloaded!");
         return true;
      } else {
         return false;
      }
   }
}
