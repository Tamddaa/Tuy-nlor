package com.anti.system.anticheat.advanced;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;

public class AdvancedAntiCheatSystem implements Listener {
   private final JavaPlugin plugin;
   private final MLAntiCheatEngine mlEngine;
   private final Map<UUID, ViolationHistory> violationHistories = new ConcurrentHashMap();
   private final Map<UUID, Long> lastViolationTime = new ConcurrentHashMap();
   private final Map<String, Long> logCache = new ConcurrentHashMap();
   private final AdvancedConfigManager config;
   private final KillAuraDetector killAuraDetector = new KillAuraDetector();
   private final AutoClickerDetector autoClickerDetector = new AutoClickerDetector();
   private final ReachDetector reachDetector = new ReachDetector();
   private final VelocityDetector velocityDetector = new VelocityDetector();
   private final PacketAnalyzer packetAnalyzer = new PacketAnalyzer();

   public AdvancedAntiCheatSystem(JavaPlugin plugin) {
      this.plugin = plugin;
      this.mlEngine = new MLAntiCheatEngine(plugin);
      this.config = new AdvancedConfigManager(plugin);
      this.startAnalysisTask();
   }

   @EventHandler(
      priority = EventPriority.LOWEST
   )
   public void onPlayerMove(PlayerMoveEvent event) {
      Player player = event.getPlayer();
      if (!player.hasPermission("anticheat.bypass.movement")) {
         Location from = event.getFrom();
         Location to = event.getTo();
         if (to != null) {
            this.packetAnalyzer.analyzePacket(player, "PLAYER_MOVE");
            MLAntiCheatEngine.CheatDetectionResult result = this.mlEngine.processMovement(player, from, to, to.getYaw() - from.getYaw(), to.getPitch() - from.getPitch(), !player.isFlying() && to.getY() <= from.getY() + 0.1);
            if (result.isViolation()) {
               this.handleViolation(player, "MOVEMENT", result.violations, result.suspicionLevel);
            }

            if (this.velocityDetector.checkVelocity(player, event)) {
               this.handleViolation(player, "VELOCITY", Arrays.asList("VELOCITY_MODIFICATION"), 0.6);
            }

         }
      }
   }

   @EventHandler(
      priority = EventPriority.LOWEST
   )
   public void onEntityDamage(EntityDamageByEntityEvent event) {
      if (event.getDamager() instanceof Player) {
         Player attacker = (Player)event.getDamager();
         if (!attacker.hasPermission("anticheat.bypass.combat")) {
            this.packetAnalyzer.analyzePacket(attacker, "ENTITY_DAMAGE");
            if (this.killAuraDetector.detectKillAura(attacker, event)) {
               this.handleViolation(attacker, "KILLAURA", Arrays.asList("KILLAURA_DETECTED"), 0.8);
            }

            double reach;
            if (event.getEntity() instanceof Player && (reach = this.reachDetector.calculateReach(attacker, (Player)event.getEntity())) > this.getMaxReach(attacker)) {
               this.handleViolation(attacker, "REACH", Arrays.asList("REACH_" + String.format("%.2f", reach)), 0.7);
            }

            this.mlEngine.processClick(attacker, MLAntiCheatEngine.ClickType.LEFT_CLICK);
         }
      }
   }

   @EventHandler(
      priority = EventPriority.LOWEST
   )
   public void onBlockBreak(BlockBreakEvent event) {
      Player player = event.getPlayer();
      if (!player.hasPermission("anticheat.bypass.mining")) {
         if (this.autoClickerDetector.detectAutoClicker(player, "BLOCK_BREAK")) {
            this.handleViolation(player, "AUTOCLICKER", Arrays.asList("MINING_AUTOCLICKER"), 0.6);
         }

         this.mlEngine.processClick(player, MLAntiCheatEngine.ClickType.BLOCK_BREAK);
      }
   }

   @EventHandler
   public void onPlayerJoin(PlayerJoinEvent event) {
      Player player = event.getPlayer();
      UUID uuid = player.getUniqueId();
      this.violationHistories.put(uuid, this.loadViolationHistory(uuid));
      this.detectPlatform(player);
      this.startPlayerMonitoring(player);
   }

   @EventHandler
   public void onPlayerQuit(PlayerQuitEvent event) {
      UUID uuid = event.getPlayer().getUniqueId();
      this.mlEngine.removePlayer(event.getPlayer());
      this.lastViolationTime.remove(uuid);
      this.saveViolationHistory(uuid);
   }

   private void handleViolation(Player player, String checkType, List<String> details, double severity) {
      UUID uuid = player.getUniqueId();
      ViolationHistory history = (ViolationHistory)this.violationHistories.get(uuid);
      if (history != null) {
         int ping = this.getPlayerPing(player);
         double pingMultiplier = this.calculatePingMultiplier(ping);
         severity *= pingMultiplier;
         long now = System.currentTimeMillis();
         if (!this.lastViolationTime.containsKey(uuid) || now - (Long)this.lastViolationTime.get(uuid) >= 5000L) {
            this.lastViolationTime.put(uuid, now);
            history.addViolation(checkType, severity);
            String violationMessage = String.format("[AdvancedAC] %s violated %s (Severity: %.2f, Trust: %.1f, Ping: %dms) - %s", player.getName(), checkType, severity, history.getTrustScore(), ping, String.join(", ", details));

            for(Player staff : Bukkit.getOnlinePlayers()) {
               if (staff.hasPermission("anticheat.staff") || staff.isOp()) {
                  staff.sendMessage("§c" + violationMessage);
               }
            }

            int violations = history.getViolationCount(checkType);
            int maxViolations = this.config.getMaxViolations(checkType);
            if (violations >= maxViolations) {
               this.executePunishment(player, checkType, violations);
            }

            this.notifyStaff(player, checkType, details, severity, violations);
         }
      }
   }

   private double calculatePingMultiplier(int ping) {
      if (ping > 500) {
         return 0.2;
      } else if (ping > 300) {
         return 0.4;
      } else if (ping > 200) {
         return 0.6;
      } else if (ping > 100) {
         return 0.8;
      } else {
         return ping > 50 ? 0.9 : (double)1.0F;
      }
   }

   private int getPlayerPing(Player player) {
      try {
         Object handle = player.getClass().getMethod("getHandle").invoke(player);
         Object playerConnection = handle.getClass().getField("playerConnection").get(handle);
         return (Integer)playerConnection.getClass().getField("ping").get(playerConnection);
      } catch (NoSuchFieldException | IllegalAccessException | InvocationTargetException | SecurityException | NoSuchMethodException var4) {
         return 50;
      }
   }

   private void executePunishment(Player player, String checkType, int violationCount) {
      String command = this.config.getPunishmentCommand(checkType, violationCount);
      command = command.replace("%player%", player.getName());
      this.plugin.getServer().dispatchCommand(this.plugin.getServer().getConsoleSender(), command);
   }

   private void notifyStaff(Player player, String checkType, List<String> details, double severity, int violations) {
      int ping = this.getPlayerPing(player);
      String pingColor = ping > 200 ? "§c" : (ping > 100 ? "§e" : "§a");
      String message = String.format("§c[AC] §f%s §cvio %s §7(x%d, %.1f%%, %s%dms§7) §8- %s", player.getName(), checkType, violations, severity * (double)100.0F, pingColor, ping, String.join(", ", details));
      this.plugin.getServer().getOnlinePlayers().stream().filter((p) -> p.hasPermission("anticheat.notify")).forEach((p) -> p.sendMessage(message));
   }

   private double getMaxReach(Player player) {
      MLAntiCheatEngine.PlayerProfile profile = this.mlEngine.getPlayerProfile(player);
      int ping = this.getPlayerPing(player);
      double baseReach = profile != null && profile.platform == MLAntiCheatEngine.Platform.BEDROCK ? (double)6.0F : (double)4.5F;
      double pingBonus = (double)0.0F;
      if (ping > 200) {
         pingBonus = (double)1.5F;
      } else if (ping > 100) {
         pingBonus = (double)1.0F;
      } else if (ping > 50) {
         pingBonus = (double)0.5F;
      }

      return baseReach + pingBonus;
   }

   private void detectPlatform(Player player) {
      String name = player.getName();
      MLAntiCheatEngine.PlayerProfile profile;
      if ((name.startsWith(".") || name.length() > 16) && (profile = this.mlEngine.getPlayerProfile(player)) != null) {
         profile.platform = MLAntiCheatEngine.Platform.BEDROCK;
      }

   }

   private void startPlayerMonitoring(final Player player) {
      (new BukkitRunnable() {
         public void run() {
            if (!player.isOnline()) {
               this.cancel();
            } else {
               AdvancedAntiCheatSystem.this.performPeriodicChecks(player);
            }
         }
      }).runTaskTimer(this.plugin, 100L, 600L);
   }

   private void performPeriodicChecks(Player player) {
      MLAntiCheatEngine.PlayerProfile profile = this.mlEngine.getPlayerProfile(player);
      if (profile != null) {
         if (profile.trustScore < 0.05 && profile.movementStats.max > (double)15.0F) {
            String cacheKey = "low_trust_log_" + player.getUniqueId();
            long lastLog = (Long)this.logCache.getOrDefault(cacheKey, 0L);
            long now = System.currentTimeMillis();
            if (now - lastLog > 300000L) {
               this.logCache.put(cacheKey, now);
               this.plugin.getLogger().info(String.format("[AdvancedAC] LOW_TRUST: %s (Trust: %.2f, MaxSpeed: %.1f)", player.getName(), profile.trustScore, profile.movementStats.max));
            }
         }

         if (profile.movementStats.max > (double)200.0F) {
            this.plugin.getLogger().info(String.format("[AdvancedAC] IMPOSSIBLE_STATS: %s (Max speed: %.2f)", player.getName(), profile.movementStats.max));
         }

      }
   }

   private void startAnalysisTask() {
      (new BukkitRunnable() {
         public void run() {
            AdvancedAntiCheatSystem.this.performGlobalAnalysis();
         }
      }).runTaskTimerAsynchronously(this.plugin, 100L, 100L);
   }

   private void performGlobalAnalysis() {
      long now = System.currentTimeMillis();
      HashMap<String, Integer> recentViolations = new HashMap();
      double totalSeverity = (double)0.0F;
      int violationCount = 0;

      for(ViolationHistory history : this.violationHistories.values()) {
         for(ViolationHistory.ViolationRecord record : history.recentViolations) {
            if (now - record.timestamp < 60000L) {
               recentViolations.merge(record.type, 1, Integer::sum);
               totalSeverity += record.severity;
               ++violationCount;
            }
         }
      }

      if (!recentViolations.isEmpty() && violationCount > 0) {
         double avgSeverity = totalSeverity / (double)violationCount;
         if (violationCount >= 5) {
            this.plugin.getLogger().info(String.format("[AdvancedAC] Global violations in last minute: %s (Count: %d, Avg Severity: %.2f)", recentViolations, violationCount, avgSeverity));
         }
      }

   }

   private void saveViolationHistory(UUID uuid) {
      ViolationHistory history = (ViolationHistory)this.violationHistories.get(uuid);
      if (history != null) {
         try {
            File dataDir = new File(this.plugin.getDataFolder(), "violations");
            if (!dataDir.exists()) {
               dataDir.mkdirs();
            }

            File playerFile = new File(dataDir, uuid + ".json");
            StringBuilder json = new StringBuilder();
            json.append("{\n");
            json.append("  \"uuid\": \"").append(uuid).append("\",\n");
            json.append("  \"trustScore\": ").append(history.getTrustScore()).append(",\n");
            json.append("  \"lastUpdated\": ").append(System.currentTimeMillis()).append(",\n");
            json.append("  \"violationCounts\": {\n");
            boolean first = true;

            for(Map.Entry<String, Integer> entry : history.violationCounts.entrySet()) {
               if (!first) {
                  json.append(",\n");
               }

               json.append("    \"").append((String)entry.getKey()).append("\": ").append(entry.getValue());
               first = false;
            }

            json.append("\n  },\n");
            json.append("  \"recentViolations\": [\n");
            first = true;
            long cutoff = System.currentTimeMillis() - 600000L;

            for(ViolationHistory.ViolationRecord record : history.recentViolations) {
               if (record.timestamp > cutoff) {
                  if (!first) {
                     json.append(",\n");
                  }

                  json.append("    {\n");
                  json.append("      \"type\": \"").append(record.type).append("\",\n");
                  json.append("      \"severity\": ").append(record.severity).append(",\n");
                  json.append("      \"timestamp\": ").append(record.timestamp).append("\n");
                  json.append("    }");
                  first = false;
               }
            }

            json.append("\n  ]\n");
            json.append("}");
            FileWriter writer = new FileWriter(playerFile);

            try {
               writer.write(json.toString());
            } catch (Throwable var13) {
               try {
                  writer.close();
               } catch (Throwable var12) {
                  var13.addSuppressed(var12);
               }

               throw var13;
            }

            writer.close();
            this.plugin.getLogger().fine(String.format("Saved violation history for player: %s (Trust: %.1f, Total violations: %d)", uuid, history.getTrustScore(), history.violationCounts.values().stream().mapToInt(Integer::intValue).sum()));
         } catch (IOException e) {
            this.plugin.getLogger().warning(String.format("Failed to save violation history for player %s: %s", uuid, e.getMessage()));
         }

      }
   }

   private ViolationHistory loadViolationHistory(UUID uuid) {
      ViolationHistory history = new ViolationHistory();

      try {
         File dataDir = new File(this.plugin.getDataFolder(), "violations");
         File playerFile = new File(dataDir, uuid + ".json");
         if (!playerFile.exists()) {
            this.plugin.getLogger().fine(String.format("No existing violation history for player: %s", uuid));
            return history;
         }

         StringBuilder content = new StringBuilder();
         BufferedReader reader = new BufferedReader(new FileReader(playerFile));

         String line;
         try {
            while((line = reader.readLine()) != null) {
               content.append(line);
            }
         } catch (Throwable var21) {
            try {
               reader.close();
            } catch (Throwable var18) {
               var21.addSuppressed(var18);
            }

            throw var21;
         }

         reader.close();
         String jsonStr = content.toString();
         if (jsonStr.contains("\"trustScore\":")) {
            int start = jsonStr.indexOf("\"trustScore\":") + 13;
            int end = jsonStr.indexOf(",", start);
            if (end == -1) {
               end = jsonStr.indexOf("}", start);
            }

            try {
               double trustScore = Double.parseDouble(jsonStr.substring(start, end).trim());
               history.trustScore = trustScore;
            } catch (NumberFormatException var20) {
               this.plugin.getLogger().warning(String.format("Invalid trust score in history file for %s", uuid));
            }
         }

         if (jsonStr.contains("\"violationCounts\":")) {
            int start = jsonStr.indexOf("\"violationCounts\":") + 18;
            int end = jsonStr.indexOf("}", start) + 1;
            String countsStr = jsonStr.substring(start, end);
            String[] parts = countsStr.split(",");

            for(String part : parts) {
               if (part.contains("\":")) {
                  String[] keyValue = part.split("\":");
                  if (keyValue.length == 2) {
                     String key = keyValue[0].replaceAll("[{\"\\s]", "");

                     try {
                        int count = Integer.parseInt(keyValue[1].replaceAll("[}\\s]", ""));
                        if (!key.isEmpty()) {
                           history.violationCounts.put(key, count);
                        }
                     } catch (NumberFormatException var19) {
                     }
                  }
               }
            }
         }

         this.plugin.getLogger().fine(String.format("Loaded violation history for player: %s (Trust: %.1f, Types: %d)", uuid, history.getTrustScore(), history.violationCounts.size()));
      } catch (IOException e) {
         this.plugin.getLogger().warning(String.format("Failed to load violation history for player %s: %s", uuid, e.getMessage()));
      }

      return history;
   }

   public MLAntiCheatEngine getMLEngine() {
      return this.mlEngine;
   }

   public ViolationHistory getViolationHistory(Player player) {
      return (ViolationHistory)this.violationHistories.get(player.getUniqueId());
   }

   public Map<UUID, ViolationHistory> getAllViolationHistories() {
      return new HashMap(this.violationHistories);
   }

   public static class KillAuraDetector {
      private final Map<UUID, List<AttackInfo>> attackHistory = new ConcurrentHashMap();

      public boolean detectKillAura(Player attacker, EntityDamageByEntityEvent event) {
         UUID uuid = attacker.getUniqueId();
         List<AttackInfo> attacks = (List)this.attackHistory.computeIfAbsent(uuid, (k) -> new ArrayList());
         AttackInfo attack = new AttackInfo(System.currentTimeMillis(), attacker.getLocation(), event.getEntity().getLocation(), attacker.getLocation().getYaw(), attacker.getLocation().getPitch());
         attacks.add(attack);
         attacks.removeIf((a) -> System.currentTimeMillis() - a.timestamp > 5000L);
         if (attacks.size() < 3) {
            return false;
         } else {
            long uniqueTargets = attacks.stream().map((a) -> a.targetLocation).distinct().count();
            if (uniqueTargets >= 3L && attacks.size() >= 5) {
               double totalYawChange = (double)0.0F;
               double totalPitchChange = (double)0.0F;

               for(int i = 1; i < attacks.size(); ++i) {
                  totalYawChange += (double)Math.abs(((AttackInfo)attacks.get(i)).yaw - ((AttackInfo)attacks.get(i - 1)).yaw);
                  totalPitchChange += (double)Math.abs(((AttackInfo)attacks.get(i)).pitch - ((AttackInfo)attacks.get(i - 1)).pitch);
               }

               if (!(totalYawChange > (double)540.0F) && !(totalPitchChange > (double)270.0F)) {
                  ArrayList<Long> intervals = new ArrayList();

                  for(int i = 1; i < attacks.size(); ++i) {
                     intervals.add(((AttackInfo)attacks.get(i)).timestamp - ((AttackInfo)attacks.get(i - 1)).timestamp);
                  }

                  double avgInterval = intervals.stream().mapToLong(Long::longValue).average().orElse((double)0.0F);
                  double variance = intervals.stream().mapToDouble((interval) -> Math.pow((double)interval - avgInterval, (double)2.0F)).average().orElse((double)0.0F);
                  return variance < (double)100.0F;
               } else {
                  return true;
               }
            } else {
               return false;
            }
         }
      }

      private static class AttackInfo {
         final long timestamp;
         final Location targetLocation;
         final float yaw;
         final float pitch;

         AttackInfo(long timestamp, Location attackerLocation, Location targetLocation, float yaw, float pitch) {
            this.timestamp = timestamp;
            this.targetLocation = targetLocation;
            this.yaw = yaw;
            this.pitch = pitch;
         }
      }
   }

   public static class AutoClickerDetector {
      private final Map<UUID, List<Long>> clickTimestamps = new ConcurrentHashMap();

      public boolean detectAutoClicker(Player player, String action) {
         UUID uuid = player.getUniqueId();
         List<Long> timestamps = (List)this.clickTimestamps.computeIfAbsent(uuid, (k) -> new ArrayList());
         long now = System.currentTimeMillis();
         timestamps.add(now);
         timestamps.removeIf((time) -> now - time > 10000L);
         if (timestamps.size() < 10) {
            return false;
         } else {
            double cps = (double)timestamps.size() / (double)10.0F;
            if (cps > (double)25.0F) {
               return true;
            } else {
               ArrayList<Long> intervals = new ArrayList();

               for(int i = 1; i < timestamps.size(); ++i) {
                  intervals.add((Long)timestamps.get(i) - (Long)timestamps.get(i - 1));
               }

               double avgInterval = intervals.stream().mapToLong(Long::longValue).average().orElse((double)0.0F);
               long perfectIntervals = intervals.stream().mapToLong((interval) -> Math.abs((double)interval - avgInterval) < (double)5.0F ? 1L : 0L).sum();
               double consistency = (double)perfectIntervals / (double)intervals.size();
               return consistency > 0.7 && cps > (double)15.0F;
            }
         }
      }
   }

   public static class ReachDetector {
      public double calculateReach(Player attacker, Player victim) {
         Location attackerLoc = attacker.getLocation();
         Location victimLoc = victim.getLocation();
         double deltaX = Math.abs(attackerLoc.getX() - victimLoc.getX()) - 0.6;
         double deltaY = Math.abs(attackerLoc.getY() - victimLoc.getY()) - 1.8;
         double deltaZ = Math.abs(attackerLoc.getZ() - victimLoc.getZ()) - 0.6;
         return Math.sqrt(Math.max((double)0.0F, deltaX * deltaX) + Math.max((double)0.0F, deltaY * deltaY) + Math.max((double)0.0F, deltaZ * deltaZ));
      }
   }

   public static class VelocityDetector {
      private final Map<UUID, VelocityData> velocityMap = new ConcurrentHashMap();

      public boolean checkVelocity(Player player, PlayerMoveEvent event) {
         UUID uuid = player.getUniqueId();
         VelocityData data = (VelocityData)this.velocityMap.get(uuid);
         if (data == null) {
            return false;
         } else {
            long timeSinceVelocity = System.currentTimeMillis() - data.timestamp;
            if (timeSinceVelocity > 2000L) {
               this.velocityMap.remove(uuid);
               return false;
            } else {
               Location from = event.getFrom();
               Location to = event.getTo();
               if (to == null) {
                  return false;
               } else {
                  double timeSeconds = (double)timeSinceVelocity / (double)1000.0F;
                  double expectedX = data.velocityX * timeSeconds;
                  double expectedZ = data.velocityZ * timeSeconds;
                  double expectedY = data.velocityY * timeSeconds - 4.905 * timeSeconds * timeSeconds;
                  double actualX = to.getX() - data.originalX;
                  double actualZ = to.getZ() - data.originalZ;
                  double actualY = to.getY() - from.getY();
                  double xRatio = Math.abs(actualX) / Math.max(Math.abs(expectedX), 0.1);
                  double zRatio = Math.abs(actualZ) / Math.max(Math.abs(expectedZ), 0.1);
                  double yRatio = Math.abs(actualY) / Math.max(Math.abs(expectedY), 0.1);
                  return (xRatio < 0.3 || zRatio < 0.3 || yRatio < 0.3) && (Math.abs(expectedX) > (double)0.5F || Math.abs(expectedZ) > (double)0.5F || Math.abs(expectedY) > (double)0.5F);
               }
            }
         }
      }

      public void addVelocity(Player player, double x, double y, double z) {
         this.velocityMap.put(player.getUniqueId(), new VelocityData(System.currentTimeMillis(), player.getLocation().getX(), player.getLocation().getZ(), x, y, z));
      }

      private static class VelocityData {
         final long timestamp;
         final double originalX;
         final double originalZ;
         final double velocityX;
         final double velocityY;
         final double velocityZ;

         VelocityData(long timestamp, double originalX, double originalZ, double velocityX, double velocityY, double velocityZ) {
            this.timestamp = timestamp;
            this.originalX = originalX;
            this.originalZ = originalZ;
            this.velocityX = velocityX;
            this.velocityY = velocityY;
            this.velocityZ = velocityZ;
         }
      }
   }

   public static class PacketAnalyzer {
      private final Map<UUID, PacketStats> packetStats = new ConcurrentHashMap();

      public void analyzePacket(Player player, String packetType) {
         UUID uuid = player.getUniqueId();
         PacketStats stats = (PacketStats)this.packetStats.computeIfAbsent(uuid, (k) -> new PacketStats());
         stats.recordPacket(packetType);
         double rate = stats.getPacketRate(packetType);
         if (rate > (double)50.0F) {
         }

      }

      private static class PacketStats {
         private final Map<String, List<Long>> packetTimestamps;

         private PacketStats() {
            this.packetTimestamps = new HashMap();
         }

         void recordPacket(String type) {
            List<Long> timestamps = (List)this.packetTimestamps.computeIfAbsent(type, (k) -> new ArrayList());
            long now = System.currentTimeMillis();
            timestamps.add(now);
            timestamps.removeIf((time) -> now - time > 5000L);
         }

         double getPacketRate(String type) {
            List<Long> timestamps = (List)this.packetTimestamps.get(type);
            return timestamps == null ? (double)0.0F : (double)timestamps.size() / (double)5.0F;
         }
      }
   }

   public static class AdvancedConfigManager {
      private final JavaPlugin plugin;

      public AdvancedConfigManager(JavaPlugin plugin) {
         this.plugin = plugin;
      }

      public int getMaxViolations(String checkType) {
         return this.plugin.getConfig().getInt("checks." + checkType + ".max_violations", 5);
      }

      public boolean isCheckEnabled(String checkType) {
         return this.plugin.getConfig().getBoolean("checks." + checkType + ".enabled", true);
      }

      public String getPunishmentCommand(String checkType, int violationCount) {
         return this.plugin.getConfig().getString("punishments." + checkType + "." + violationCount, "kick %player% [AntiCheat] Suspicious activity detected");
      }
   }

   public static class ViolationHistory {
      private final Map<String, Integer> violationCounts = new HashMap();
      private final List<ViolationRecord> recentViolations = new ArrayList();
      private double trustScore = (double)100.0F;

      public void addViolation(String type, double severity) {
         this.violationCounts.merge(type, 1, Integer::sum);
         this.recentViolations.add(new ViolationRecord(type, severity, System.currentTimeMillis()));
         this.recentViolations.removeIf((v) -> System.currentTimeMillis() - v.timestamp > 600000L);
         this.trustScore = Math.max((double)0.0F, this.trustScore - severity * 0.1);
      }

      public int getViolationCount(String type) {
         return (Integer)this.violationCounts.getOrDefault(type, 0);
      }

      public double getTrustScore() {
         return this.trustScore;
      }

      private static class ViolationRecord {
         final String type;
         final double severity;
         final long timestamp;

         ViolationRecord(String type, double severity, long timestamp) {
            this.type = type;
            this.severity = severity;
            this.timestamp = timestamp;
         }
      }
   }
}
