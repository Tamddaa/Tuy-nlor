package com.anti.system.anticheat.advanced;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ThreadLocalRandom;

public class OptimizedNeuralNetwork {
   private final int[] layerSizes;
   private final double[][][] weights;
   private final double[][] biases;
   private final double[][] activations;
   private final double[][] errors;
   private final ActivationFunction[] activationFunctions;
   private double learningRate = 0.001;
   private final double weightDecay = 1.0E-4;
   private final double[][][] momentumWeights;
   private final double[][] momentumBiases;
   private final double[][][] adamM;
   private final double[][][] adamV;
   private final double[][] adamMBias;
   private final double[][] adamVBias;
   private int timeStep = 0;
   private final double[][] batchMeans;
   private final double[][] batchVariances;
   private final double[][] batchGamma;
   private final double[][] batchBeta;

   public OptimizedNeuralNetwork(int[] layerSizes) {
      this.layerSizes = (int[])(([I)layerSizes).clone();
      this.weights = new double[layerSizes.length - 1][][];
      this.biases = new double[layerSizes.length - 1][];
      this.activations = new double[layerSizes.length][];
      this.errors = new double[layerSizes.length][];
      this.momentumWeights = new double[layerSizes.length - 1][][];
      this.momentumBiases = new double[layerSizes.length - 1][];
      this.adamM = new double[layerSizes.length - 1][][];
      this.adamV = new double[layerSizes.length - 1][][];
      this.adamMBias = new double[layerSizes.length - 1][];
      this.adamVBias = new double[layerSizes.length - 1][];
      this.batchMeans = new double[layerSizes.length - 1][];
      this.batchVariances = new double[layerSizes.length - 1][];
      this.batchGamma = new double[layerSizes.length - 1][];
      this.batchBeta = new double[layerSizes.length - 1][];
      this.activationFunctions = new ActivationFunction[layerSizes.length - 1];

      for(int i = 0; i < this.activationFunctions.length - 1; ++i) {
         this.activationFunctions[i] = OptimizedNeuralNetwork.ActivationFunction.LEAKY_RELU;
      }

      this.activationFunctions[this.activationFunctions.length - 1] = OptimizedNeuralNetwork.ActivationFunction.SIGMOID;
      this.initializeNetwork();
   }

   private void initializeNetwork() {
      ThreadLocalRandom random = ThreadLocalRandom.current();

      for(int layer = 0; layer < this.layerSizes.length - 1; ++layer) {
         int inputSize = this.layerSizes[layer];
         int outputSize = this.layerSizes[layer + 1];
         double scale = Math.sqrt((double)2.0F / (double)(inputSize + outputSize));
         this.weights[layer] = new double[inputSize][outputSize];
         this.momentumWeights[layer] = new double[inputSize][outputSize];
         this.adamM[layer] = new double[inputSize][outputSize];
         this.adamV[layer] = new double[inputSize][outputSize];

         for(int i = 0; i < inputSize; ++i) {
            for(int j = 0; j < outputSize; ++j) {
               this.weights[layer][i][j] = random.nextGaussian() * scale;
            }
         }

         this.biases[layer] = new double[outputSize];
         this.momentumBiases[layer] = new double[outputSize];
         this.adamMBias[layer] = new double[outputSize];
         this.adamVBias[layer] = new double[outputSize];
         this.batchMeans[layer] = new double[outputSize];
         this.batchVariances[layer] = new double[outputSize];
         this.batchGamma[layer] = new double[outputSize];
         this.batchBeta[layer] = new double[outputSize];
         Arrays.fill(this.batchGamma[layer], (double)1.0F);
         Arrays.fill(this.batchVariances[layer], (double)1.0F);
      }

      for(int i = 0; i < this.layerSizes.length; ++i) {
         this.activations[i] = new double[this.layerSizes[i]];
         this.errors[i] = new double[this.layerSizes[i]];
      }

   }

   public double[] forwardPropagation(double[] inputs) {
      if (inputs.length != this.layerSizes[0]) {
         throw new IllegalArgumentException("Input size mismatch");
      } else {
         System.arraycopy(inputs, 0, this.activations[0], 0, inputs.length);

         for(int layer = 0; layer < this.weights.length; ++layer) {
            this.forwardLayer(layer);
         }

         return (double[])this.activations[this.activations.length - 1].clone();
      }
   }

   private void forwardLayer(int layer) {
      int inputSize = this.layerSizes[layer];
      int outputSize = this.layerSizes[layer + 1];

      for(int j = 0; j < outputSize; ++j) {
         double sum = this.biases[layer][j];

         int i;
         for(i = 0; i < inputSize - 3; i += 4) {
            sum += this.activations[layer][i] * this.weights[layer][i][j] + this.activations[layer][i + 1] * this.weights[layer][i + 1][j] + this.activations[layer][i + 2] * this.weights[layer][i + 2][j] + this.activations[layer][i + 3] * this.weights[layer][i + 3][j];
         }

         while(i < inputSize) {
            sum += this.activations[layer][i] * this.weights[layer][i][j];
            ++i;
         }

         sum = this.batchNormalize(sum, layer, j);
         this.activations[layer + 1][j] = this.applyActivation(sum, this.activationFunctions[layer]);
      }

   }

   private double batchNormalize(double value, int layer, int neuron) {
      double mean = this.batchMeans[layer][neuron];
      double variance = this.batchVariances[layer][neuron];
      double gamma = this.batchGamma[layer][neuron];
      double beta = this.batchBeta[layer][neuron];
      return gamma * (value - mean) / Math.sqrt(variance + 1.0E-8) + beta;
   }

   private double applyActivation(double x, ActivationFunction function) {
      switch (function.ordinal()) {
         case 0:
            return (double)1.0F / ((double)1.0F + Math.exp(-Math.max((double)-500.0F, Math.min((double)500.0F, x))));
         case 1:
            return Math.tanh(x);
         case 2:
            return Math.max((double)0.0F, x);
         case 3:
            return x > (double)0.0F ? x : 0.01 * x;
         case 4:
            return x * ((double)1.0F / ((double)1.0F + Math.exp(-x)));
         case 5:
            return x > (double)0.0F ? x : Math.exp(x) - (double)1.0F;
         case 6:
            return (double)0.5F * x * ((double)1.0F + Math.tanh(Math.sqrt(0.6366197723675814) * (x + 0.044715 * Math.pow(x, (double)3.0F))));
         default:
            return x;
      }
   }

   private double activationDerivative(double x, ActivationFunction function) {
      switch (function.ordinal()) {
         case 0:
            double sigmoid = this.applyActivation(x, function);
            return sigmoid * ((double)1.0F - sigmoid);
         case 1:
            double tanh = Math.tanh(x);
            return (double)1.0F - tanh * tanh;
         case 2:
            return x > (double)0.0F ? (double)1.0F : (double)0.0F;
         case 3:
            return x > (double)0.0F ? (double)1.0F : 0.01;
         case 4:
            double swish = this.applyActivation(x, function);
            return swish + (double)1.0F / ((double)1.0F + Math.exp(-x)) * ((double)1.0F - swish);
         case 5:
            return x > (double)0.0F ? (double)1.0F : Math.exp(x);
         case 6:
            return (double)0.5F * ((double)1.0F + Math.tanh(Math.sqrt(0.6366197723675814) * (x + 0.044715 * Math.pow(x, (double)3.0F)))) + (double)0.5F * x * ((double)1.0F - Math.pow(Math.tanh(Math.sqrt(0.6366197723675814) * (x + 0.044715 * Math.pow(x, (double)3.0F))), (double)2.0F)) * Math.sqrt(0.6366197723675814) * ((double)1.0F + 0.134145 * Math.pow(x, (double)2.0F));
         default:
            return (double)1.0F;
      }
   }

   public void backpropagation(double[] expectedOutputs) {
      ++this.timeStep;
      int outputLayer = this.layerSizes.length - 1;

      for(int i = 0; i < this.layerSizes[outputLayer]; ++i) {
         double output = this.activations[outputLayer][i];
         double error = expectedOutputs[i] - output;
         this.errors[outputLayer][i] = error * this.activationDerivative(output, this.activationFunctions[this.activationFunctions.length - 1]);
      }

      for(int layer = this.weights.length - 1; layer >= 0; --layer) {
         this.backpropagateLayer(layer);
      }

      this.updateWeightsAdam();
   }

   private void backpropagateLayer(int layer) {
      if (layer > 0) {
         for(int i = 0; i < this.layerSizes[layer]; ++i) {
            double error = (double)0.0F;

            for(int j = 0; j < this.layerSizes[layer + 1]; ++j) {
               error += this.errors[layer + 1][j] * this.weights[layer][i][j];
            }

            this.errors[layer][i] = error * this.activationDerivative(this.activations[layer][i], this.activationFunctions[layer - 1]);
         }
      }

   }

   private void updateWeightsAdam() {
      double beta1 = 0.9;
      double beta2 = 0.999;
      double epsilon = 1.0E-8;
      double beta1Corrected = (double)1.0F - Math.pow(beta1, (double)this.timeStep);
      double beta2Corrected = (double)1.0F - Math.pow(beta2, (double)this.timeStep);

      for(int layer = 0; layer < this.weights.length; ++layer) {
         double mCorrected;
         double vCorrected;
         double[] dArray;
         int n;
         for(int i = 0; i < this.weights[layer].length; ++i) {
            for(int j = 0; j < this.weights[layer][i].length; dArray[n] += this.learningRate * mCorrected / (Math.sqrt(vCorrected) + epsilon)) {
               double var10000 = this.activations[layer][i] * this.errors[layer + 1][j];
               Objects.requireNonNull(this);
               double gradient = var10000 + 1.0E-4 * this.weights[layer][i][j];
               this.adamM[layer][i][j] = beta1 * this.adamM[layer][i][j] + ((double)1.0F - beta1) * gradient;
               this.adamV[layer][i][j] = beta2 * this.adamV[layer][i][j] + ((double)1.0F - beta2) * gradient * gradient;
               mCorrected = this.adamM[layer][i][j] / beta1Corrected;
               vCorrected = this.adamV[layer][i][j] / beta2Corrected;
               dArray = this.weights[layer][i];
               n = j++;
            }
         }

         double mCorrected;
         double vCorrected;
         double[] dArray;
         for(int j = 0; j < this.biases[layer].length; dArray[n] += this.learningRate * mCorrected / (Math.sqrt(vCorrected) + epsilon)) {
            double gradient = this.errors[layer + 1][j];
            this.adamMBias[layer][j] = beta1 * this.adamMBias[layer][j] + ((double)1.0F - beta1) * gradient;
            this.adamVBias[layer][j] = beta2 * this.adamVBias[layer][j] + ((double)1.0F - beta2) * gradient * gradient;
            mCorrected = this.adamMBias[layer][j] / beta1Corrected;
            vCorrected = this.adamVBias[layer][j] / beta2Corrected;
            dArray = this.biases[layer];
            n = j++;
         }
      }

   }

   public double calculateMSE(double[] expected, double[] actual) {
      double sum = (double)0.0F;

      for(int i = 0; i < expected.length; ++i) {
         double diff = expected[i] - actual[i];
         sum += diff * diff;
      }

      return sum / (double)expected.length;
   }

   public void setLearningRate(double rate) {
      this.learningRate = Math.max(1.0E-4, Math.min(0.1, rate));
   }

   public void adjustLearningRate(double factor) {
      this.learningRate *= factor;
      this.learningRate = Math.max(1.0E-4, Math.min(0.1, this.learningRate));
   }

   public Map<String, Double> getPerformanceMetrics() {
      HashMap<String, Double> metrics = new HashMap();
      metrics.put("learning_rate", this.learningRate);
      metrics.put("time_step", (double)this.timeStep);
      metrics.put("total_parameters", (double)this.getTotalParameters());
      return metrics;
   }

   private int getTotalParameters() {
      int total = 0;

      for(int layer = 0; layer < this.weights.length; ++layer) {
         total += this.weights[layer].length * this.weights[layer][0].length;
         total += this.biases[layer].length;
      }

      return total;
   }

   public double[] predict(double[] inputs) {
      return this.forwardPropagation(inputs);
   }

   public static enum ActivationFunction {
      SIGMOID,
      TANH,
      RELU,
      LEAKY_RELU,
      SWISH,
      ELU,
      GELU;

      // $FF: synthetic method
      private static ActivationFunction[] $values() {
         return new ActivationFunction[]{SIGMOID, TANH, RELU, LEAKY_RELU, SWISH, ELU, GELU};
      }
   }
}
