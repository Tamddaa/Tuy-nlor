package com.anti.system.anticheat.advanced;

import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.Objects;
import java.util.Queue;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;

public class EnhancedMLEngine {
   private final JavaPlugin plugin;
   private final SpamFreeLogger logger;
   private final OptimizedNeuralNetwork movementNetwork;
   private final OptimizedNeuralNetwork combatNetwork;
   private final OptimizedNeuralNetwork behaviorNetwork;
   private final Map<UUID, PlayerMLProfile> playerProfiles = new ConcurrentHashMap();
   private final Map<UUID, CheatProbabilities> cheatProbabilities = new ConcurrentHashMap();
   private final AtomicInteger detectionsPerSecond = new AtomicInteger(0);
   private final AtomicInteger falsePositives = new AtomicInteger(0);
   private final AtomicInteger truePositives = new AtomicInteger(0);
   private double detectionThreshold = 0.85;
   private final boolean adaptiveLearning = true;
   private final boolean realTimeTraining = true;

   public EnhancedMLEngine(JavaPlugin plugin) {
      this.plugin = plugin;
      this.logger = new SpamFreeLogger(plugin);
      this.movementNetwork = new OptimizedNeuralNetwork(new int[]{15, 32, 16, 8, 1});
      this.combatNetwork = new OptimizedNeuralNetwork(new int[]{12, 24, 12, 6, 1});
      this.behaviorNetwork = new OptimizedNeuralNetwork(new int[]{20, 40, 20, 10, 1});
      this.logger.info("ML_ENGINE", "Enhanced ML Engine initialized with optimized networks");
      this.startPerformanceMonitoring();
   }

   private boolean isPlayerInWater(Player player) {
      try {
         Location loc = player.getLocation();
         Object block = loc.getBlock();
         Object material = block.getClass().getMethod("getType").invoke(block);
         String materialName = material.toString();
         return materialName.contains("WATER") || materialName.contains("STATIONARY_WATER");
      } catch (IllegalAccessException | InvocationTargetException | SecurityException | NoSuchMethodException var6) {
         return false;
      }
   }

   public void analyzeMovement(Player player, Location from, Location to, float yawChange, float pitchChange) {
      UUID uuid = player.getUniqueId();
      PlayerMLProfile profile = this.getOrCreateProfile(uuid, player.getName());
      MovementSample sample = new MovementSample(from, to, yawChange, pitchChange, !player.isFlying() && to.getY() <= from.getY() + 0.1, this.isPlayerInWater(player), 0);
      profile.addMovementSample(sample);
      if (profile.movementHistory.size() >= 10) {
         double[] features = sample.toFeatureVector();
         double[] prediction = this.movementNetwork.predict(features);
         profile.movementScore = prediction[0];
         CheatProbabilities probs = (CheatProbabilities)this.cheatProbabilities.computeIfAbsent(uuid, (k) -> new CheatProbabilities());
         probs.movement = prediction[0];
         probs.updateOverall();
         if (prediction[0] > this.detectionThreshold) {
            this.handleCheatDetection(player, "Movement", prediction[0], "Suspicious movement patterns detected");
         }

         this.detectionsPerSecond.incrementAndGet();
      }

   }

   public void analyzeCombat(Player player, double reach, boolean hit, double reactionTime, int combo) {
      UUID uuid = player.getUniqueId();
      PlayerMLProfile profile = this.getOrCreateProfile(uuid, player.getName());
      CombatSample sample = new CombatSample(reach, hit, reactionTime, combo, (double)0.0F);
      profile.addCombatSample(sample);
      if (profile.combatHistory.size() >= 5) {
         double[] features = sample.toFeatureVector();
         double[] prediction = this.combatNetwork.predict(features);
         profile.combatScore = prediction[0];
         CheatProbabilities probs = (CheatProbabilities)this.cheatProbabilities.computeIfAbsent(uuid, (k) -> new CheatProbabilities());
         probs.combat = prediction[0];
         probs.updateOverall();
         if (prediction[0] > this.detectionThreshold) {
            this.handleCheatDetection(player, "Combat", prediction[0], String.format("Reach: %.2f, Hit: %s, Reaction: %.2fms", reach, hit, reactionTime));
         }
      }

   }

   public void analyzeBehavior(Player player, long sessionTime, int blocksBroken, int blocksPlaced) {
      UUID uuid = player.getUniqueId();
      PlayerMLProfile profile = this.getOrCreateProfile(uuid, player.getName());
      BehaviorSample sample = new BehaviorSample((double)sessionTime, blocksBroken, blocksPlaced, false, player.isSneaking());
      profile.addBehaviorSample(sample);
      if (profile.behaviorHistory.size() >= 10) {
         double[] features = sample.toFeatureVector();
         double[] prediction = this.behaviorNetwork.predict(features);
         profile.behaviorScore = prediction[0];
         CheatProbabilities probs = (CheatProbabilities)this.cheatProbabilities.computeIfAbsent(uuid, (k) -> new CheatProbabilities());
         probs.behavior = prediction[0];
         probs.updateOverall();
         if (prediction[0] > this.detectionThreshold) {
            this.handleCheatDetection(player, "Behavior", prediction[0], "Anomalous behavior patterns detected");
         }
      }

   }

   private PlayerMLProfile getOrCreateProfile(UUID uuid, String name) {
      return (PlayerMLProfile)this.playerProfiles.computeIfAbsent(uuid, (k) -> new PlayerMLProfile(uuid, name));
   }

   private void handleCheatDetection(Player player, String type, double confidence, String details) {
      this.logger.logCheatDetection(player.getName(), type, details, confidence * (double)100.0F);
      this.truePositives.incrementAndGet();
      if (confidence > 0.95) {
         this.logger.severe("HIGH_CONFIDENCE_CHEAT", String.format("%s - %s: %.1f%% confidence", player.getName(), type, confidence * (double)100.0F));
      } else if (confidence > 0.85) {
         this.logger.warning("MEDIUM_CONFIDENCE_CHEAT", String.format("%s - %s: %.1f%% confidence", player.getName(), type, confidence * (double)100.0F));
      }

   }

   public void provideFeedback(UUID uuid, String cheatType, boolean wasCorrect) {
      PlayerMLProfile profile = (PlayerMLProfile)this.playerProfiles.get(uuid);
      if (profile != null) {
         if (wasCorrect) {
            ++profile.correctPredictions;
            this.truePositives.incrementAndGet();
         } else {
            ++profile.incorrectPredictions;
            this.falsePositives.incrementAndGet();
         }

         double accuracy = profile.getAccuracy();
         if (accuracy < 0.8) {
            profile.learningRate *= 1.1;
         } else if (accuracy > 0.95) {
            profile.learningRate *= 0.9;
         }

         this.logger.info("ML_FEEDBACK", String.format("Player %s accuracy: %.2f%%", profile.name, accuracy * (double)100.0F));
      }

   }

   public Map<String, Object> getPlayerAnalysis(UUID uuid) {
      PlayerMLProfile profile = (PlayerMLProfile)this.playerProfiles.get(uuid);
      CheatProbabilities probs = (CheatProbabilities)this.cheatProbabilities.get(uuid);
      HashMap<String, Object> analysis = new HashMap();
      if (profile != null && probs != null) {
         analysis.put("movement_score", profile.movementScore);
         analysis.put("combat_score", profile.combatScore);
         analysis.put("behavior_score", profile.behaviorScore);
         analysis.put("overall_risk", probs.overall);
         analysis.put("accuracy", profile.getAccuracy());
         analysis.put("platform", profile.platform.name());
         analysis.put("is_new_player", profile.isNewPlayer);
         analysis.put("risk_level", probs.isHighRisk() ? "HIGH" : (probs.isMediumRisk() ? "MEDIUM" : "LOW"));
      }

      return analysis;
   }

   private void startPerformanceMonitoring() {
      (new BukkitRunnable() {
         public void run() {
            EnhancedMLEngine.this.detectionsPerSecond.getAndSet(0);
            EnhancedMLEngine.this.cleanupOldData();
            double accuracy = EnhancedMLEngine.this.calculateOverallAccuracy();
            EnhancedMLEngine.this.adjustThresholds(accuracy);
         }
      }).runTaskTimer(this.plugin, 20L, 20L);
   }

   private double calculateOverallAccuracy() {
      int total = this.truePositives.get() + this.falsePositives.get();
      return total > 0 ? (double)this.truePositives.get() / (double)total : (double)0.0F;
   }

   private void adjustThresholds(double accuracy) {
      if (accuracy < 0.8) {
         this.detectionThreshold = Math.min(0.95, this.detectionThreshold + 0.01);
      } else if (accuracy > 0.95) {
         this.detectionThreshold = Math.max((double)0.75F, this.detectionThreshold - 0.01);
      }

   }

   private void cleanupOldData() {
      this.playerProfiles.entrySet().removeIf((entry) -> {
         Player player = this.plugin.getServer().getPlayer((UUID)entry.getKey());
         return player == null && ((PlayerMLProfile)entry.getValue()).behaviorHistory.isEmpty();
      });
      this.logger.cleanup();
   }

   public Map<String, Object> getEngineStats() {
      HashMap<String, Object> stats = new HashMap();
      stats.put("active_profiles", this.playerProfiles.size());
      stats.put("total_detections", this.truePositives.get() + this.falsePositives.get());
      stats.put("accuracy", this.calculateOverallAccuracy());
      stats.put("detection_threshold", this.detectionThreshold);
      Objects.requireNonNull(this);
      stats.put("adaptive_learning", true);
      Objects.requireNonNull(this);
      stats.put("real_time_training", true);
      stats.putAll(this.logger.getLoggingStats());
      return stats;
   }

   public void shutdown() {
      this.logger.info("ML_ENGINE", "Enhanced ML Engine shutting down...");
      this.playerProfiles.clear();
      this.cheatProbabilities.clear();
   }

   public static class PlayerMLProfile {
      public final UUID uuid;
      public final String name;
      public final Queue<MovementSample> movementHistory = new LinkedList();
      public final Queue<CombatSample> combatHistory = new LinkedList();
      public final Queue<BehaviorSample> behaviorHistory = new LinkedList();
      public double movementScore = (double)0.5F;
      public double combatScore = (double)0.5F;
      public double behaviorScore = (double)0.5F;
      public double overallRisk = (double)0.0F;
      public int correctPredictions = 0;
      public int incorrectPredictions = 0;
      public double learningRate = 0.001;
      public Platform platform;
      public boolean isNewPlayer;

      public PlayerMLProfile(UUID uuid, String name) {
         this.platform = EnhancedMLEngine.Platform.UNKNOWN;
         this.isNewPlayer = true;
         this.uuid = uuid;
         this.name = name;
      }

      public void addMovementSample(MovementSample sample) {
         this.movementHistory.offer(sample);
         if (this.movementHistory.size() > 100) {
            this.movementHistory.poll();
         }

      }

      public void addCombatSample(CombatSample sample) {
         this.combatHistory.offer(sample);
         if (this.combatHistory.size() > 50) {
            this.combatHistory.poll();
         }

      }

      public void addBehaviorSample(BehaviorSample sample) {
         this.behaviorHistory.offer(sample);
         if (this.behaviorHistory.size() > 75) {
            this.behaviorHistory.poll();
         }

      }

      public double getAccuracy() {
         int total = this.correctPredictions + this.incorrectPredictions;
         return total > 0 ? (double)this.correctPredictions / (double)total : (double)0.0F;
      }
   }

   public static class MovementSample {
      public final long timestamp = System.currentTimeMillis();
      public final double speed;
      public final double acceleration;
      public final double jerk;
      public final float yawChange;
      public final float pitchChange;
      public final boolean onGround;
      public final boolean inWater;
      public final boolean inAir;
      public final double friction;
      public final double jumpHeight;
      public final int airTime;
      public final int groundTime;
      public final double consistencyScore;

      public MovementSample(Location from, Location to, float yawChange, float pitchChange, boolean onGround, boolean inWater, int airTime) {
         this.yawChange = yawChange;
         this.pitchChange = pitchChange;
         this.onGround = onGround;
         this.inWater = inWater;
         this.inAir = !onGround && !inWater;
         this.airTime = airTime;
         this.groundTime = onGround ? 1 : 0;
         double distance = from.distance(to);
         this.speed = distance * (double)20.0F;
         this.acceleration = (double)0.0F;
         this.jerk = (double)0.0F;
         this.friction = inWater ? 0.8 : (onGround ? 0.91 : 0.98);
         this.jumpHeight = to.getY() - from.getY();
         this.consistencyScore = this.calculateConsistency();
      }

      private double calculateConsistency() {
         double yawConsistency = Math.abs(this.yawChange) < 180.0F ? (double)1.0F : (double)0.0F;
         double speedConsistency = this.speed < (double)20.0F ? (double)1.0F : (double)0.0F;
         return (yawConsistency + speedConsistency) / (double)2.0F;
      }

      public double[] toFeatureVector() {
         return new double[]{this.speed, this.acceleration, this.jerk, (double)Math.abs(this.yawChange), (double)Math.abs(this.pitchChange), this.onGround ? (double)1.0F : (double)0.0F, this.inWater ? (double)1.0F : (double)0.0F, this.inAir ? (double)1.0F : (double)0.0F, this.friction, this.jumpHeight, (double)this.airTime / (double)20.0F, (double)this.groundTime, this.consistencyScore, Math.sin(Math.toRadians((double)this.yawChange)), Math.cos(Math.toRadians((double)this.pitchChange))};
      }
   }

   public static class CheatProbabilities {
      public double movement = (double)0.0F;
      public double combat = (double)0.0F;
      public double behavior = (double)0.0F;
      public double overall = (double)0.0F;
      public long lastUpdate = System.currentTimeMillis();

      public void updateOverall() {
         this.overall = this.movement * 0.4 + this.combat * 0.4 + this.behavior * 0.2;
         this.lastUpdate = System.currentTimeMillis();
      }

      public boolean isHighRisk() {
         return this.overall > 0.85;
      }

      public boolean isMediumRisk() {
         return this.overall > 0.65 && this.overall <= 0.85;
      }
   }

   public static class CombatSample {
      public final long timestamp = System.currentTimeMillis();
      public final double reach;
      public final double aimAccuracy;
      public final double clickRate;
      public final boolean isHit;
      public final boolean isCritical;
      public final boolean isBlocked;
      public final double reactionTime;
      public final double aimConsistency;
      public final int comboLength;
      public final double damageDealt;
      public final double kbTaken;

      public CombatSample(double reach, boolean isHit, double reactionTime, int comboLength, double damageDealt) {
         this.reach = reach;
         this.isHit = isHit;
         this.reactionTime = reactionTime;
         this.comboLength = comboLength;
         this.damageDealt = damageDealt;
         this.aimAccuracy = isHit ? (double)1.0F : (double)0.0F;
         this.clickRate = (double)0.0F;
         this.isCritical = false;
         this.isBlocked = false;
         this.aimConsistency = this.calculateAimConsistency();
         this.kbTaken = (double)0.0F;
      }

      private double calculateAimConsistency() {
         return this.reach > (double)0.0F && this.reach < (double)6.0F ? (double)1.0F : (double)0.0F;
      }

      public double[] toFeatureVector() {
         return new double[]{this.reach, this.aimAccuracy, this.clickRate, this.isHit ? (double)1.0F : (double)0.0F, this.isCritical ? (double)1.0F : (double)0.0F, this.isBlocked ? (double)1.0F : (double)0.0F, this.reactionTime, this.aimConsistency, (double)this.comboLength / (double)10.0F, this.damageDealt / (double)20.0F, this.kbTaken, Math.log(this.reactionTime + (double)1.0F)};
      }
   }

   public static class BehaviorSample {
      public final long timestamp = System.currentTimeMillis();
      public final double sessionTime;
      public final double activityLevel;
      public final int blocksBroken;
      public final int blocksPlaced;
      public final double chatActivity;
      public final double commandUsage;
      public final boolean isAfk;
      public final boolean isSneaking;
      public final boolean isRunning;
      public final double inventoryActivity;
      public final double toolSwitching;
      public final int deathCount;
      public final int killCount;
      public final double economicActivity;

      public BehaviorSample(double sessionTime, int blocksBroken, int blocksPlaced, boolean isAfk, boolean isSneaking) {
         this.sessionTime = sessionTime;
         this.blocksBroken = blocksBroken;
         this.blocksPlaced = blocksPlaced;
         this.isAfk = isAfk;
         this.isSneaking = isSneaking;
         this.isRunning = false;
         this.activityLevel = this.calculateActivityLevel();
         this.chatActivity = (double)0.0F;
         this.commandUsage = (double)0.0F;
         this.inventoryActivity = (double)0.0F;
         this.toolSwitching = (double)0.0F;
         this.deathCount = 0;
         this.killCount = 0;
         this.economicActivity = (double)0.0F;
      }

      private double calculateActivityLevel() {
         double blockActivity = (double)(this.blocksBroken + this.blocksPlaced) / Math.max(this.sessionTime / (double)1000.0F, (double)1.0F);
         return Math.min((double)1.0F, blockActivity / (double)10.0F);
      }

      public double[] toFeatureVector() {
         return new double[]{Math.log(this.sessionTime + (double)1.0F), this.activityLevel, (double)this.blocksBroken / (double)1000.0F, (double)this.blocksPlaced / (double)1000.0F, this.chatActivity, this.commandUsage, this.isAfk ? (double)1.0F : (double)0.0F, this.isSneaking ? (double)1.0F : (double)0.0F, this.isRunning ? (double)1.0F : (double)0.0F, this.inventoryActivity, this.toolSwitching, (double)this.deathCount / (double)10.0F, (double)this.killCount / (double)10.0F, this.economicActivity, Math.sin((double)(this.timestamp % 86400000L) / (double)8.64E7F * (double)2.0F * Math.PI), Math.cos((double)(this.timestamp % 86400000L) / (double)8.64E7F * (double)2.0F * Math.PI), this.sessionTime / (double)3600000.0F, (double)(this.blocksBroken + this.blocksPlaced) / Math.max(this.sessionTime / (double)1000.0F, (double)1.0F), this.isAfk ? (double)0.0F : (double)1.0F};
      }
   }

   public static enum Platform {
      JAVA,
      BEDROCK,
      UNKNOWN;

      // $FF: synthetic method
      private static Platform[] $values() {
         return new Platform[]{JAVA, BEDROCK, UNKNOWN};
      }
   }
}
