package com.anti.system.anticheat.advanced;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;
import java.util.logging.Level;
import org.bukkit.plugin.java.JavaPlugin;

public class SpamFreeLogger {
   private static final long DEFAULT_COOLDOWN_MS = 5000L;
   private static final long SPAM_THRESHOLD_MS = 1000L;
   private static final int MAX_DUPLICATE_COUNT = 10;
   private final JavaPlugin plugin;
   private final Map<String, MessageTracker> messageTrackers = new ConcurrentHashMap();
   private final Map<String, AtomicLong> categoryCounters = new ConcurrentHashMap();
   private final Map<Level, Long> levelCooldowns;

   public SpamFreeLogger(JavaPlugin plugin) {
      this.plugin = plugin;
      this.levelCooldowns = new ConcurrentHashMap();
      this.levelCooldowns.put(Level.INFO, 2000L);
      this.levelCooldowns.put(Level.WARNING, 3000L);
      this.levelCooldowns.put(Level.SEVERE, 1000L);
   }

   public void log(Level level, String category, String message) {
      String key = level.getName() + ":" + category;
      long cooldown = (Long)this.levelCooldowns.getOrDefault(level, 5000L);
      MessageTracker tracker = (MessageTracker)this.messageTrackers.computeIfAbsent(key, (k) -> new MessageTracker(cooldown));
      if (tracker.shouldLog(message)) {
         String finalMessage = message;
         if (tracker.getDuplicateCount() > 1) {
            finalMessage = String.format("%s (+%d similar)", message, tracker.getDuplicateCount());
         }

         this.plugin.getLogger().log(level, String.format("[%s] %s", category, finalMessage));
         ((AtomicLong)this.categoryCounters.computeIfAbsent(category, (k) -> new AtomicLong(0L))).incrementAndGet();
      }

   }

   public void info(String category, String message) {
      this.log(Level.INFO, category, message);
   }

   public void warning(String category, String message) {
      this.log(Level.WARNING, category, message);
   }

   public void severe(String category, String message) {
      this.log(Level.SEVERE, category, message);
   }

   public void logCheatDetection(String playerName, String cheatType, String details, double confidence) {
      if (confidence > (double)95.0F) {
         this.severe("CHEAT_DETECTION", String.format("%s detected %s (%.1f%% confidence): %s", playerName, cheatType, confidence, details));
      } else if (confidence > (double)75.0F) {
         this.warning("CHEAT_SUSPICION", String.format("%s suspected %s (%.1f%% confidence): %s", playerName, cheatType, confidence, details));
      }

   }

   public void logMLProgress(String stage, double progress, String details) {
   }

   public void logPerformance(String metric, double value, String unit) {
   }

   public void emergency(String message) {
      this.plugin.getLogger().severe(String.format("[EMERGENCY] %s", message));
   }

   public Map<String, Long> getLoggingStats() {
      ConcurrentHashMap<String, Long> stats = new ConcurrentHashMap();
      this.categoryCounters.forEach((category, count) -> stats.put(category, count.get()));
      return stats;
   }

   public void cleanup() {
      long cutoffTime = System.currentTimeMillis() - 50000L;
      this.messageTrackers.entrySet().removeIf((entry) -> ((MessageTracker)entry.getValue()).lastLogTime < cutoffTime);
   }

   private static class MessageTracker {
      private long lastLogTime = 0L;
      private int duplicateCount = 0;
      private String lastMessage = "";
      private final long cooldownMs;

      public MessageTracker(long cooldownMs) {
         this.cooldownMs = cooldownMs;
      }

      public boolean shouldLog(String message) {
         long currentTime = System.currentTimeMillis();
         if (message.equals(this.lastMessage)) {
            ++this.duplicateCount;
            if (this.duplicateCount > 10 && currentTime - this.lastLogTime < 1000L) {
               return false;
            }
         } else {
            this.duplicateCount = 0;
            this.lastMessage = message;
         }

         if (currentTime - this.lastLogTime < this.cooldownMs) {
            return false;
         } else {
            this.lastLogTime = currentTime;
            return true;
         }
      }

      public int getDuplicateCount() {
         return this.duplicateCount;
      }
   }
}
