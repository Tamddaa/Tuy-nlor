package com.anti.system.anticheat.advanced;

import com.anti.system.utils.VersionCompatibility;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public class MLAntiCheatEngine {
   private final Map<UUID, PlayerProfile> playerProfiles = new ConcurrentHashMap();
   private final Map<UUID, MovementPredictor> movementPredictors = new ConcurrentHashMap();
   private final Map<UUID, BehaviorAnalyzer> behaviorAnalyzers = new ConcurrentHashMap();
   private final AdvancedHeuristicEngine heuristicEngine = new AdvancedHeuristicEngine();
   private final NeuralCheatDetector neuralDetector = new NeuralCheatDetector();

   public MLAntiCheatEngine(JavaPlugin plugin) {
   }

   public CheatDetectionResult processMovement(Player player, Location from, Location to, float yawDelta, float pitchDelta, boolean onGround) {
      UUID uuid = player.getUniqueId();
      PlayerProfile profile = (PlayerProfile)this.playerProfiles.computeIfAbsent(uuid, PlayerProfile::new);
      MovementPredictor predictor = (MovementPredictor)this.movementPredictors.computeIfAbsent(uuid, (k) -> new MovementPredictor());
      MovementSample sample = new MovementSample(from, to, yawDelta, pitchDelta, onGround);
      profile.addMovementSample(sample);
      CheatDetectionResult heuristicResult = this.heuristicEngine.analyzeMovement(profile, sample);
      double mlProbability = this.neuralDetector.predictCheatProbability(profile, sample);
      boolean physicsViolation = !predictor.predictMovement(player, to);
      double finalSuspicion = (heuristicResult.suspicionLevel + mlProbability) / (double)2.0F;
      if (physicsViolation) {
         finalSuspicion += 0.3;
      }

      int ping = this.getPlayerPing(player);
      double pingAdjustment = this.getPingAdjustment(ping);
      finalSuspicion *= pingAdjustment;
      ArrayList<String> allViolations = new ArrayList(heuristicResult.violations);
      if (physicsViolation) {
         allViolations.add("PHYSICS_VIOLATION");
      }

      if (mlProbability > 0.8) {
         allViolations.add("ML_DETECTION");
      }

      profile.trustScore = Math.max((double)0.0F, profile.trustScore - finalSuspicion * (double)1.0F);
      return new CheatDetectionResult(allViolations, finalSuspicion);
   }

   private double getPingAdjustment(int ping) {
      if (ping > 500) {
         return 0.1;
      } else if (ping > 300) {
         return 0.3;
      } else if (ping > 200) {
         return (double)0.5F;
      } else if (ping > 100) {
         return 0.7;
      } else {
         return ping > 50 ? 0.85 : (double)1.0F;
      }
   }

   private int getPlayerPing(Player player) {
      try {
         Object handle = player.getClass().getMethod("getHandle").invoke(player);
         Object playerConnection = handle.getClass().getField("playerConnection").get(handle);
         return (Integer)playerConnection.getClass().getField("ping").get(playerConnection);
      } catch (NoSuchFieldException | IllegalAccessException | InvocationTargetException | SecurityException | NoSuchMethodException var4) {
         return 50;
      }
   }

   private static PotionEffect getPlayerPotionEffect(Player player, PotionEffectType effectType) {
      try {
         for(PotionEffect effect : player.getActivePotionEffects()) {
            if (effect.getType().equals(effectType)) {
               return effect;
            }
         }

         return null;
      } catch (Exception var4) {
         return null;
      }
   }

   public void processClick(Player player, ClickType clickType) {
      UUID uuid = player.getUniqueId();
      PlayerProfile profile = (PlayerProfile)this.playerProfiles.computeIfAbsent(uuid, PlayerProfile::new);
      BehaviorAnalyzer analyzer = (BehaviorAnalyzer)this.behaviorAnalyzers.computeIfAbsent(uuid, (k) -> new BehaviorAnalyzer());
      long lastClickTime = profile.clickHistory.isEmpty() ? 0L : ((ClickSample)profile.clickHistory.get(profile.clickHistory.size() - 1)).timestamp;
      ClickSample sample = new ClickSample(clickType, lastClickTime);
      profile.addClickSample(sample);
      double humanlikeScore = analyzer.analyzeBehavior(player, clickType.name());
      if (humanlikeScore < 0.3) {
         profile.trustScore -= (double)5.0F;
      }

   }

   public void removePlayer(Player player) {
      UUID uuid = player.getUniqueId();
      this.playerProfiles.remove(uuid);
      this.movementPredictors.remove(uuid);
      this.behaviorAnalyzers.remove(uuid);
   }

   public PlayerProfile getPlayerProfile(Player player) {
      return (PlayerProfile)this.playerProfiles.get(player.getUniqueId());
   }

   public PlayerProfile getPlayerProfile(UUID uuid) {
      return (PlayerProfile)this.playerProfiles.get(uuid);
   }

   public void clearData() {
      this.playerProfiles.clear();
      this.movementPredictors.clear();
      this.behaviorAnalyzers.clear();
   }

   public Map<UUID, PlayerProfile> getAllProfiles() {
      return new HashMap(this.playerProfiles);
   }

   public static class AdvancedHeuristicEngine {
      public CheatDetectionResult analyzeMovement(PlayerProfile profile, MovementSample sample) {
         ArrayList<String> violations = new ArrayList();
         double suspicionLevel = (double)0.0F;
         double environmentalModifier = (double)1.0F;
         if (sample.nearBlocks || sample.underBlocks || sample.inWater || sample.inCobweb) {
            environmentalModifier = 0.1;
         }

         double maxSpeed = this.getMaxSpeed(profile.platform) * (sample.nearBlocks ? (double)2.0F : (double)1.0F);
         if (sample.speed > maxSpeed) {
            violations.add("SPEED_" + String.format("%.2f", sample.speed));
            suspicionLevel += 0.3 * environmentalModifier;
         }

         if (this.detectImpossibleMovement(profile, sample)) {
            violations.add("IMPOSSIBLE_MOVEMENT");
            suspicionLevel += (double)0.5F * environmentalModifier;
         }

         if (this.detectAimbotMovement(profile, sample)) {
            violations.add("AIMBOT_MOVEMENT");
            suspicionLevel += 0.4 * environmentalModifier;
         }

         if (this.detectAdvancedFly(profile, sample)) {
            violations.add("ADVANCED_FLY");
            suspicionLevel += 0.6 * environmentalModifier;
         }

         return new CheatDetectionResult(violations, suspicionLevel);
      }

      private double getMaxSpeed(Platform platform) {
         switch (platform.ordinal()) {
            case 0:
               return (double)2.5F;
            case 1:
               return (double)3.0F;
            default:
               return 2.8;
         }
      }

      private boolean detectImpossibleMovement(PlayerProfile profile, MovementSample sample) {
         if (profile != null && sample.from != null && sample.to != null) {
            if (!Objects.equals(sample.from.getWorld(), sample.to.getWorld())) {
               return false;
            } else {
               double distance = sample.from.distance(sample.to);
               if (distance > (double)25.0F) {
                  return true;
               } else {
                  double dx = Math.abs(sample.to.getX() - sample.from.getX());
                  double dz = Math.abs(sample.to.getZ() - sample.from.getZ());
                  if (dx > (double)0.0F && dz > (double)0.0F && Math.abs(dx - dz) < 0.001) {
                     return sample.speed > (double)2.0F;
                  } else {
                     return false;
                  }
               }
            }
         } else {
            return false;
         }
      }

      private boolean detectAimbotMovement(PlayerProfile profile, MovementSample sample) {
         if (Math.abs(sample.yawDelta) > 90.0F && Math.abs(sample.pitchDelta) > 45.0F) {
            return true;
         } else if (profile.movementHistory.size() < 3) {
            return false;
         } else {
            List<MovementSample> recent = profile.movementHistory.subList(Math.max(0, profile.movementHistory.size() - 3), profile.movementHistory.size());
            double yawVariance = this.calculateVariance(recent.stream().mapToDouble((s) -> (double)s.yawDelta).toArray());
            double pitchVariance = this.calculateVariance(recent.stream().mapToDouble((s) -> (double)s.pitchDelta).toArray());
            return yawVariance < 0.1 && pitchVariance < 0.1 && sample.speed > (double)0.0F;
         }
      }

      private boolean detectAdvancedFly(PlayerProfile profile, MovementSample sample) {
         if (sample.onGround) {
            return false;
         } else {
            long airTime = profile.movementHistory.stream().filter((s) -> !s.onGround).count();
            double verticalMovement = Math.abs(sample.to.getY() - sample.from.getY());
            return airTime > 10L && sample.speed > 0.3 && verticalMovement < 0.1;
         }
      }

      private double calculateVariance(double[] values2) {
         if (values2.length < 2) {
            return (double)0.0F;
         } else {
            double mean = Arrays.stream(values2).average().orElse((double)0.0F);
            return Arrays.stream(values2).map((v) -> Math.pow(v - mean, (double)2.0F)).average().orElse((double)0.0F);
         }
      }
   }

   public static class NeuralCheatDetector {
      private final double[][] weights = this.initializeWeights();

      public double predictCheatProbability(PlayerProfile profile, MovementSample sample) {
         double[] inputs = this.extractFeatures(profile, sample);
         double[] hiddenLayer = new double[10];

         for(int i = 0; i < hiddenLayer.length; ++i) {
            hiddenLayer[i] = this.sigmoid(this.dotProduct(inputs, this.weights[i]));
         }

         double output = this.sigmoid(this.dotProduct(hiddenLayer, this.weights[this.weights.length - 1]));
         return output;
      }

      private double[] extractFeatures(PlayerProfile profile, MovementSample sample) {
         return new double[]{sample.speed, (double)Math.abs(sample.yawDelta), (double)Math.abs(sample.pitchDelta), sample.onGround ? (double)1.0F : (double)0.0F, profile.trustScore / (double)100.0F, profile.movementStats.stdDev, profile.clickStats.mean, sample.acceleration, profile.platform == MLAntiCheatEngine.Platform.BEDROCK ? (double)1.0F : (double)0.0F, (double)(System.currentTimeMillis() - profile.joinTime) / (double)60000.0F};
      }

      private double[][] initializeWeights() {
         double[][] w = new double[11][];

         for(int i = 0; i < 10; ++i) {
            w[i] = new double[10];

            for(int j = 0; j < 10; ++j) {
               w[i][j] = (Math.random() - (double)0.5F) * 0.1;
            }
         }

         w[10] = new double[10];

         for(int var4 = 0; var4 < 10; ++var4) {
            w[10][var4] = (Math.random() - (double)0.5F) * 0.1;
         }

         return w;
      }

      private double sigmoid(double x) {
         return (double)1.0F / ((double)1.0F + Math.exp(-x));
      }

      private double dotProduct(double[] a, double[] b) {
         double sum = (double)0.0F;

         for(int i = 0; i < Math.min(a.length, b.length); ++i) {
            sum += a[i] * b[i];
         }

         return sum;
      }
   }

   public static class PlayerProfile {
      public final UUID uuid;
      public final List<MovementSample> movementHistory = new ArrayList();
      public final List<ClickSample> clickHistory = new ArrayList();
      public final Map<String, Double> behaviorMetrics = new HashMap();
      public double trustScore = (double)100.0F;
      public long joinTime = System.currentTimeMillis();
      public Platform platform;
      public final Statistics movementStats;
      public final Statistics clickStats;
      public final Statistics aimStats;

      public PlayerProfile(UUID uuid) {
         this.platform = MLAntiCheatEngine.Platform.UNKNOWN;
         this.movementStats = new Statistics();
         this.clickStats = new Statistics();
         this.aimStats = new Statistics();
         this.uuid = uuid;
      }

      public void addMovementSample(MovementSample sample) {
         this.movementHistory.add(sample);
         if (this.movementHistory.size() > 1000) {
            this.movementHistory.remove(0);
         }

         this.movementStats.update(sample.speed);
      }

      public void addClickSample(ClickSample sample) {
         this.clickHistory.add(sample);
         if (this.clickHistory.size() > 500) {
            this.clickHistory.remove(0);
         }

         this.clickStats.update((double)sample.timeDelta);
      }
   }

   public static class MovementPredictor {
      private Location lastLocation;
      private Location predictedLocation;
      private double lastSpeed = (double)0.0F;
      private long lastUpdate = 0L;

      public boolean predictMovement(Player player, Location newLocation) {
         if (this.lastLocation == null) {
            this.lastLocation = newLocation.clone();
            this.lastUpdate = System.currentTimeMillis();
            return true;
         } else if (!Objects.equals(this.lastLocation.getWorld(), newLocation.getWorld())) {
            this.lastLocation = newLocation.clone();
            this.lastUpdate = System.currentTimeMillis();
            this.predictedLocation = null;
            this.lastSpeed = (double)0.0F;
            return true;
         } else {
            long timeDelta = System.currentTimeMillis() - this.lastUpdate;
            if (timeDelta < 50L) {
               return true;
            } else {
               double expectedSpeed = this.calculateExpectedSpeed(player, this.lastLocation, timeDelta);
               double actualSpeed = this.lastLocation.distance(newLocation) / ((double)timeDelta / (double)1000.0F);
               this.predictedLocation = this.calculatePredictedLocation(this.lastLocation, this.lastSpeed, timeDelta);
               boolean isValidMovement = true;
               if (this.predictedLocation != null && Objects.equals(this.predictedLocation.getWorld(), newLocation.getWorld())) {
                  double predictionError = this.predictedLocation.distance(newLocation);
                  if (predictionError > (double)2.0F) {
                     isValidMovement = false;
                  }
               }

               this.lastLocation = newLocation.clone();
               this.lastSpeed = actualSpeed;
               this.lastUpdate = System.currentTimeMillis();
               double speedRatio = actualSpeed / Math.max(expectedSpeed, 0.1);
               boolean speedValid = speedRatio <= (double)1.5F;
               return speedValid && isValidMovement;
            }
         }
      }

      private double calculateExpectedSpeed(Player player, Location from, long timeDelta) {
         if (from != null && timeDelta < 0L) {
         }

         double baseSpeed = player.isSprinting() ? 0.28 : 0.21;
         if (player.isSneaking()) {
            baseSpeed *= 0.3;
         }

         baseSpeed *= (double)20.0F;
         if (player.hasPotionEffect(PotionEffectType.SPEED)) {
            PotionEffect effect = MLAntiCheatEngine.getPlayerPotionEffect(player, PotionEffectType.SPEED);
            if (effect != null) {
               int amplifier = effect.getAmplifier();
               baseSpeed *= (double)1.0F + (double)(amplifier + 1) * 0.2;
            }
         }

         if (player.hasPotionEffect(VersionCompatibility.getSlownessEffect())) {
            PotionEffect effect = MLAntiCheatEngine.getPlayerPotionEffect(player, VersionCompatibility.getSlownessEffect());
            if (effect != null) {
               int amplifier = effect.getAmplifier();
               baseSpeed *= Math.max(0.15, (double)1.0F - (double)(amplifier + 1) * 0.15);
            }
         }

         return baseSpeed;
      }

      private Location calculatePredictedLocation(Location from, double speed, long timeDelta) {
         if (from == null) {
            return null;
         } else {
            Location predicted = from.clone();
            double velocityDecay = 0.95;
            double timeSeconds = (double)timeDelta / (double)1000.0F;
            double adjustedSpeed = speed * Math.pow(velocityDecay, timeSeconds);
            if (adjustedSpeed > 0.01) {
               predicted.add((double)0.0F, (double)0.0F, adjustedSpeed * timeSeconds);
            }

            return predicted;
         }
      }

      public Location getPredictedLocation() {
         return this.predictedLocation != null ? this.predictedLocation.clone() : null;
      }

      public double getLastSpeed() {
         return this.lastSpeed;
      }
   }

   public static class MovementSample {
      public final long timestamp = System.currentTimeMillis();
      public final Location from;
      public final Location to;
      public final double speed;
      public final double acceleration;
      public final float yawDelta;
      public final float pitchDelta;
      public final boolean onGround;
      public final boolean inWater;
      public final boolean inLava;
      public final boolean inCobweb;
      public final boolean nearBlocks;
      public final boolean underBlocks;

      public MovementSample(Location from, Location to, float yawDelta, float pitchDelta, boolean onGround) {
         this.from = from;
         this.to = to;
         this.yawDelta = yawDelta;
         this.pitchDelta = pitchDelta;
         this.onGround = onGround;
         double distance = (double)0.0F;
         if (from != null && to != null && Objects.equals(from.getWorld(), to.getWorld())) {
            distance = from.distance(to);
         }

         this.speed = distance * (double)20.0F;
         this.inWater = to != null && to.getBlock().isLiquid();
         this.inLava = to != null && to.getBlock().getType().name().contains("LAVA");
         this.inCobweb = to != null && to.getBlock().getType().name().contains("COBWEB");
         this.nearBlocks = this.hasNearbyBlocks(to, 2);
         this.underBlocks = this.hasBlocksAbove(to, 3);
         this.acceleration = (double)0.0F;
      }

      private boolean hasNearbyBlocks(Location loc, int radius) {
         if (loc == null) {
            return false;
         } else {
            for(int x = -radius; x <= radius; ++x) {
               for(int z = -radius; z <= radius; ++z) {
                  if (loc.clone().add((double)x, (double)0.0F, (double)z).getBlock().getType().isSolid()) {
                     return true;
                  }
               }
            }

            return false;
         }
      }

      private boolean hasBlocksAbove(Location loc, int height) {
         if (loc == null) {
            return false;
         } else {
            for(int y = 1; y <= height; ++y) {
               if (loc.clone().add((double)0.0F, (double)y, (double)0.0F).getBlock().getType().isSolid()) {
                  return true;
               }
            }

            return false;
         }
      }
   }

   public static class CheatDetectionResult {
      public final List<String> violations;
      public final double suspicionLevel;
      public final long timestamp;

      public CheatDetectionResult(List<String> violations, double suspicionLevel) {
         this.violations = violations;
         this.suspicionLevel = suspicionLevel;
         this.timestamp = System.currentTimeMillis();
      }

      public boolean isViolation() {
         return this.suspicionLevel > 0.95 && !this.violations.isEmpty();
      }
   }

   public static class BehaviorAnalyzer {
      private final Map<String, Double> patterns = new HashMap();
      private final List<Long> actionTimestamps = new ArrayList();

      public double analyzeBehavior(Player player, String action) {
         long now = System.currentTimeMillis();
         this.actionTimestamps.add(now);
         this.actionTimestamps.removeIf((time) -> now - time > 10000L);
         double frequency = (double)this.actionTimestamps.size() / (double)10.0F;
         double patternScore = this.detectPatterns(this.actionTimestamps);
         double humanlikeScore = this.calculateHumanlikeScore(frequency, patternScore);
         this.patterns.put(action, humanlikeScore);
         return humanlikeScore;
      }

      private double detectPatterns(List<Long> timestamps) {
         if (timestamps.size() < 3) {
            return (double)1.0F;
         } else {
            ArrayList<Long> intervals = new ArrayList();

            for(int i = 1; i < timestamps.size(); ++i) {
               intervals.add((Long)timestamps.get(i) - (Long)timestamps.get(i - 1));
            }

            double avgInterval = intervals.stream().mapToLong(Long::longValue).average().orElse((double)0.0F);
            double variance = intervals.stream().mapToDouble(Long::doubleValue).map((interval) -> Math.pow(interval - avgInterval, (double)2.0F)).average().orElse((double)0.0F);
            double varianceScore = Math.min((double)1.0F, variance / (double)1000.0F);
            return varianceScore;
         }
      }

      private double calculateHumanlikeScore(double frequency, double patternScore) {
         double frequencyScore = (double)1.0F;
         if (frequency > (double)20.0F) {
            frequencyScore = 0.1;
         } else if (frequency > (double)15.0F) {
            frequencyScore = 0.3;
         } else if (frequency > (double)10.0F) {
            frequencyScore = 0.7;
         }

         return (frequencyScore + patternScore) / (double)2.0F;
      }

      public Map<String, Double> getPatterns() {
         return new HashMap(this.patterns);
      }
   }

   public static class ClickSample {
      public final long timestamp = System.currentTimeMillis();
      public final long timeDelta;
      public final ClickType type;

      public ClickSample(ClickType type, long previousClickTime) {
         this.timeDelta = previousClickTime > 0L ? this.timestamp - previousClickTime : 0L;
         this.type = type;
      }
   }

   public static enum ClickType {
      LEFT_CLICK,
      RIGHT_CLICK,
      BLOCK_BREAK,
      BLOCK_PLACE;

      // $FF: synthetic method
      private static ClickType[] $values() {
         return new ClickType[]{LEFT_CLICK, RIGHT_CLICK, BLOCK_BREAK, BLOCK_PLACE};
      }
   }

   public static class Statistics {
      private final List<Double> samples = new ArrayList();
      public double mean = (double)0.0F;
      public double variance = (double)0.0F;
      public double stdDev = (double)0.0F;
      public double min = Double.MAX_VALUE;
      public double max = Double.MIN_VALUE;

      public void update(double value) {
         this.samples.add(value);
         if (this.samples.size() > 1000) {
            this.samples.remove(0);
         }

         this.mean = this.samples.stream().mapToDouble(Double::doubleValue).average().orElse((double)0.0F);
         this.variance = this.samples.stream().mapToDouble((v) -> Math.pow(v - this.mean, (double)2.0F)).average().orElse((double)0.0F);
         this.stdDev = Math.sqrt(this.variance);
         this.min = Math.min(this.min, value);
         this.max = Math.max(this.max, value);
      }

      public double getZScore(double value) {
         return this.stdDev > (double)0.0F ? (value - this.mean) / this.stdDev : (double)0.0F;
      }
   }

   public static enum Platform {
      JAVA,
      BEDROCK,
      UNKNOWN;

      // $FF: synthetic method
      private static Platform[] $values() {
         return new Platform[]{JAVA, BEDROCK, UNKNOWN};
      }
   }
}
