package com.anti.system.anticheat;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

public class AntiSystemReloadCommand implements CommandExecutor {
   private final AntiCheatPlugin plugin;

   public AntiSystemReloadCommand(AntiCheatPlugin plugin) {
      this.plugin = plugin;
   }

   public boolean onCommand(CommandSender sender, Command command, String label, String[] args2) {
      if (!sender.hasPermission("antisystem.reload")) {
         sender.sendMessage("§cYou don't have permission to use this command.");
         return true;
      } else {
         this.plugin.reloadConfig();
         if (this.plugin.getAntiCheatListener() != null) {
            this.plugin.getAntiCheatListener().reloadConfig(this.plugin);
         }

         sender.sendMessage("§aAntiSystem plugin and all systems reloaded!");
         return true;
      }
   }
}
