package com.anti.system.anticheat;

import java.lang.reflect.InvocationTargetException;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.plugin.java.JavaPlugin;

public class BedrockDebugCommand implements CommandExecutor {
   private final JavaPlugin plugin;

   public BedrockDebugCommand(JavaPlugin plugin) {
      this.plugin = plugin;
   }

   public boolean onCommand(CommandSender sender, Command command, String label, String[] args2) {
      if (!sender.hasPermission("antisystem.bedrock.debug")) {
         sender.sendMessage("§cYou don't have permission to use this command.");
         return true;
      } else if (args2.length == 0) {
         sender.sendMessage("§6=== Bedrock Debug Commands ===");
         sender.sendMessage("§e/bedrockdebug check <player> §7- Check if player is detected as Bedrock");
         sender.sendMessage("§e/bedrockdebug force <player> <true/false> §7- Force mark player as Bedrock/Java");
         sender.sendMessage("§e/bedrockdebug list §7- List all online players and their detected platform");
         return true;
      } else if (args2[0].equalsIgnoreCase("check")) {
         if (args2.length != 2) {
            sender.sendMessage("§cUsage: /bedrockdebug check <player>");
            return true;
         } else {
            Player target = null;

            for(Player p : Bukkit.getOnlinePlayers()) {
               if (p.getName().equalsIgnoreCase(args2[1])) {
                  target = p;
                  break;
               }
            }

            if (target == null) {
               sender.sendMessage("§cPlayer not found.");
               return true;
            } else {
               AntiCheatListener acl = new AntiCheatListener(this.plugin);
               boolean isBedrock = acl.isBedrock(target);
               sender.sendMessage("§6Player: §e" + target.getName());
               sender.sendMessage("§6Detected Platform: §e" + (isBedrock ? "Bedrock" : "Java"));
               sender.sendMessage("§6Client Brand: §e" + this.getClientBrandSafely(target));
               sender.sendMessage("§6Has Floodgate Metadata: §e" + target.hasMetadata("floodgate-player"));
               sender.sendMessage("§6Has Floodgate Permission: §e" + target.hasPermission("floodgate.legacy"));
               sender.sendMessage("§6Username Length: §e" + target.getName().length());
               return true;
            }
         }
      } else if (!args2[0].equalsIgnoreCase("force")) {
         if (args2[0].equalsIgnoreCase("list")) {
            sender.sendMessage("§6=== Online Players Platform Detection ===");
            AntiCheatListener acl = new AntiCheatListener(this.plugin);

            for(Player player : Bukkit.getOnlinePlayers()) {
               boolean isBedrock = acl.isBedrock(player);
               String platform = isBedrock ? "§cBedrock" : "§aJava";
               String forced = player.hasMetadata("antisystem.bedrock.forced") ? " §7(Forced)" : "";
               sender.sendMessage("§e" + player.getName() + "§7: " + platform + forced);
            }

            return true;
         } else {
            sender.sendMessage("§cUnknown subcommand. Use /bedrockdebug for help.");
            return true;
         }
      } else if (args2.length != 3) {
         sender.sendMessage("§cUsage: /bedrockdebug force <player> <true/false>");
         return true;
      } else {
         Player target = null;

         for(Player p : Bukkit.getOnlinePlayers()) {
            if (p.getName().equalsIgnoreCase(args2[1])) {
               target = p;
               break;
            }
         }

         if (target == null) {
            sender.sendMessage("§cPlayer not found.");
            return true;
         } else {
            boolean forceBedrock = Boolean.parseBoolean(args2[2]);
            target.setMetadata("antisystem.bedrock.forced", new FixedMetadataValue(this.plugin, forceBedrock));
            sender.sendMessage("§aPlayer §e" + target.getName() + "§a has been force-marked as §e" + (forceBedrock ? "Bedrock" : "Java"));
            target.sendMessage("§6[AntiSystem] §eYou have been force-marked as a §a" + (forceBedrock ? "Bedrock" : "Java") + "§e player by an admin.");
            return true;
         }
      }
   }

   private String getClientBrandSafely(Player player) {
      try {
         Object brand = player.getClass().getMethod("getClientBrandName").invoke(player);
         return brand != null ? brand.toString() : "Unknown";
      } catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException var3) {
         return "Unknown";
      }
   }
}
