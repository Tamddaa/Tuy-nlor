package com.anti.system.anticheat;

import com.anti.system.utils.SpamFreeLogger;
import com.anti.system.utils.VersionUtils;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

public class IntelligentAutoConfig {
   private final JavaPlugin plugin;
   private final SpamFreeLogger spamFreeLogger;
   private final String serverVersion;
   private final boolean isLegacy;
   private final boolean isModern;
   private final boolean is121Plus;
   private final Map<String, Object> optimizedSettings;

   public IntelligentAutoConfig(JavaPlugin plugin) {
      this.plugin = plugin;
      this.spamFreeLogger = new SpamFreeLogger(plugin);
      this.serverVersion = VersionUtils.getMinecraftVersion();
      this.isLegacy = VersionUtils.isLegacy();
      this.isModern = VersionUtils.isModern();
      this.is121Plus = VersionUtils.is121Plus();
      this.optimizedSettings = new HashMap();
      this.spamFreeLogger.info("AUTO_CONFIG", "Detected Minecraft version: " + this.serverVersion);
      if (plugin.getConfig().getBoolean("advanced.auto-config", true)) {
         this.generateOptimizedSettings();
      } else {
         this.spamFreeLogger.info("AUTO_CONFIG", "Auto-configuration disabled, skipping optimization");
      }

   }

   private void generateOptimizedSettings() {
      this.spamFreeLogger.info("AUTO_CONFIG", "Generating optimized settings for " + this.serverVersion + "...");
      this.applyBaseSettings();
      if (this.isLegacy) {
         this.applyLegacyOptimizations();
      } else if (this.is121Plus) {
         this.applyModernOptimizations();
      } else if (this.isModern) {
         this.applyStandardOptimizations();
      } else {
         this.applyStandardOptimizations();
      }

      this.applyPerformanceOptimizations();
      this.applyPlatformOptimizations();
      this.plugin.getLogger().info("[AutoConfig] ✅ Optimized settings generated successfully!");
   }

   private void applyBaseSettings() {
      this.optimizedSettings.put("enabled", true);
      this.optimizedSettings.put("debug", false);
      this.optimizedSettings.put("auto_update_config", true);
      this.optimizedSettings.put("language", "en");
      this.optimizedSettings.put("machine_learning.enabled", true);
      this.optimizedSettings.put("machine_learning.learning_rate", 0.01);
      this.optimizedSettings.put("machine_learning.training_samples", 10000);
      this.optimizedSettings.put("machine_learning.confidence_threshold", 0.96);
      this.optimizedSettings.put("machine_learning.auto_retrain", true);
      this.optimizedSettings.put("platform_detection.enabled", true);
      this.optimizedSettings.put("platform_detection.auto_detect", true);
      this.optimizedSettings.put("platform_detection.client_brand_detection", true);
   }

   private void applyLegacyOptimizations() {
      this.plugin.getLogger().info("[AutoConfig] Applying legacy version optimizations...");
      this.optimizedSettings.put("movement.speed.max_violations", 35);
      this.optimizedSettings.put("movement.speed.java_max_speed", (double)3.0F);
      this.optimizedSettings.put("movement.speed.bedrock_max_speed", (double)3.5F);
      this.optimizedSettings.put("movement.fly.max_violations", 40);
      this.optimizedSettings.put("movement.fly.air_time_threshold", 80);
      this.optimizedSettings.put("movement.fly.vertical_speed_limit", (double)3.0F);
      this.optimizedSettings.put("combat.reach.java_max_reach", (double)4.5F);
      this.optimizedSettings.put("combat.reach.max_violations", 12);
      this.optimizedSettings.put("combat.autoclicker.max_cps", 40);
      this.optimizedSettings.put("combat.autoclicker.max_violations", 15);
      this.optimizedSettings.put("movement.swimming_detection", false);
      this.optimizedSettings.put("movement.elytra_detection", false);
      this.optimizedSettings.put("combat.trident_detection", false);
   }

   private void applyModernOptimizations() {
      this.plugin.getLogger().info("[AutoConfig] Applying modern version optimizations...");
      this.optimizedSettings.put("movement.speed.max_violations", 25);
      this.optimizedSettings.put("movement.speed.java_max_speed", 2.8);
      this.optimizedSettings.put("movement.speed.bedrock_max_speed", 3.2);
      this.optimizedSettings.put("movement.fly.max_violations", 30);
      this.optimizedSettings.put("movement.fly.air_time_threshold", 70);
      this.optimizedSettings.put("movement.fly.vertical_speed_limit", 2.8);
      this.optimizedSettings.put("combat.reach.java_max_reach", 4.2);
      this.optimizedSettings.put("combat.reach.max_violations", 10);
      this.optimizedSettings.put("combat.autoclicker.max_cps", 32);
      this.optimizedSettings.put("combat.autoclicker.max_violations", 12);
      this.optimizedSettings.put("movement.swimming_detection", true);
      this.optimizedSettings.put("movement.elytra_detection", true);
      this.optimizedSettings.put("movement.trial_chambers_detection", true);
      this.optimizedSettings.put("combat.trident_detection", true);
      this.optimizedSettings.put("combat.crossbow_detection", true);
      this.optimizedSettings.put("inventory.bundle_detection", true);
   }

   private void applyStandardOptimizations() {
      this.plugin.getLogger().info("[AutoConfig] Applying standard version optimizations...");
      this.optimizedSettings.put("movement.speed.max_violations", 28);
      this.optimizedSettings.put("movement.speed.java_max_speed", 2.7);
      this.optimizedSettings.put("movement.speed.bedrock_max_speed", 3.1);
      this.optimizedSettings.put("movement.fly.max_violations", 32);
      this.optimizedSettings.put("movement.fly.air_time_threshold", 75);
      this.optimizedSettings.put("movement.fly.vertical_speed_limit", 2.7);
      this.optimizedSettings.put("combat.reach.java_max_reach", 4.3);
      this.optimizedSettings.put("combat.reach.max_violations", 11);
      this.optimizedSettings.put("combat.autoclicker.max_cps", 35);
      this.optimizedSettings.put("combat.autoclicker.max_violations", 13);
      this.optimizedSettings.put("movement.swimming_detection", VersionUtils.supportsFeature("swimming"));
      this.optimizedSettings.put("movement.elytra_detection", VersionUtils.supportsFeature("elytra"));
      this.optimizedSettings.put("combat.trident_detection", VersionUtils.supportsFeature("trident"));
      this.optimizedSettings.put("combat.crossbow_detection", VersionUtils.supportsFeature("crossbow"));
   }

   private void applyPerformanceOptimizations() {
      this.spamFreeLogger.info("AUTO_CONFIG", "Applying performance optimizations...");
      double[] tps = VersionUtils.getTPS();
      double averageTPS = (tps[0] + tps[1] + tps[2]) / (double)3.0F;
      if (averageTPS < (double)15.0F) {
         this.spamFreeLogger.warning("AUTO_CONFIG", "Low TPS detected (" + String.format("%.1f", averageTPS) + "), applying performance-friendly settings...");
         this.multiplySettings("max_violations", (double)1.5F);
         this.multiplySettings("max_speed", 1.3);
         this.multiplySettings("air_time_threshold", 1.4);
         this.optimizedSettings.put("machine_learning.confidence_threshold", 0.98);
         this.optimizedSettings.put("behavioral.enabled", false);
      } else if (averageTPS > (double)19.5F) {
         this.spamFreeLogger.info("AUTO_CONFIG", "High TPS detected (" + String.format("%.1f", averageTPS) + "), applying performance-optimized settings...");
         this.multiplySettings("max_violations", 0.8);
         this.optimizedSettings.put("machine_learning.confidence_threshold", 0.94);
         this.optimizedSettings.put("behavioral.enabled", true);
         this.optimizedSettings.put("behavioral.trust_system.enabled", true);
      }

      long maxMemory = Runtime.getRuntime().maxMemory() / 1024L / 1024L;
      if (maxMemory < 2048L) {
         this.spamFreeLogger.warning("AUTO_CONFIG", "Low memory detected (" + maxMemory + "MB), reducing ML complexity...");
         this.optimizedSettings.put("machine_learning.training_samples", 5000);
         this.optimizedSettings.put("behavioral.pattern_recognition.sample_size", 500);
      }

   }

   private void applyPlatformOptimizations() {
      this.plugin.getLogger().info("[AutoConfig] Applying platform-specific optimizations...");
      boolean hasFloodgate = Bukkit.getPluginManager().getPlugin("floodgate") != null;
      boolean hasGeyser = Bukkit.getPluginManager().getPlugin("Geyser-Spigot") != null;
      if (hasFloodgate || hasGeyser) {
         this.plugin.getLogger().info("[AutoConfig] ✅ Bedrock support detected, enabling cross-platform optimizations...");
         this.optimizedSettings.put("platform_detection.floodgate_integration", hasFloodgate);
         this.optimizedSettings.put("platform_detection.geyser_integration", hasGeyser);
         this.optimizedSettings.put("platform_detection.bedrock_uuid_pattern", true);
         this.optimizedSettings.put("movement.speed.bedrock_max_speed", this.getDouble("movement.speed.bedrock_max_speed") * 1.2);
         this.optimizedSettings.put("combat.reach.bedrock_max_reach", (double)5.5F);
      }

      String serverSoftware;
      if ((serverSoftware = Bukkit.getVersion().toLowerCase()).contains("paper")) {
         this.plugin.getLogger().info("[AutoConfig] ✅ Paper server detected, enabling advanced optimizations...");
         this.optimizedSettings.put("packet_analysis.enabled", true);
         this.optimizedSettings.put("advanced_detection.paper_specific", true);
      } else if (serverSoftware.contains("spigot")) {
         this.plugin.getLogger().info("[AutoConfig] ✅ Spigot server detected, using standard optimizations...");
         this.optimizedSettings.put("packet_analysis.enabled", false);
      }

   }

   public void applySettings() {
      if (!this.plugin.getConfig().getBoolean("advanced.auto-config", true)) {
         this.spamFreeLogger.info("AUTO_CONFIG", "Auto-configuration disabled, skipping settings application");
      } else {
         this.spamFreeLogger.info("AUTO_CONFIG", "Applying optimized settings to configuration files...");

         try {
            this.updateAdvancedConfig();
            this.updateBedrockConfig();
            this.updateMainConfig();
            this.spamFreeLogger.info("AUTO_CONFIG", "✅ All configurations updated successfully!");
            this.spamFreeLogger.info("AUTO_CONFIG", "Settings optimized for Minecraft " + this.serverVersion + " with ML-based recommendations");
         } catch (IOException e) {
            this.plugin.getLogger().log(Level.SEVERE, "[AutoConfig] ❌ Failed to apply settings: " + e.getMessage(), e);
         }

      }
   }

   private void updateAdvancedConfig() throws IOException {
      File configFile = new File(this.plugin.getDataFolder(), "config.yml");
      YamlConfiguration config = YamlConfiguration.loadConfiguration(configFile);

      for(Map.Entry<String, Object> entry : this.optimizedSettings.entrySet()) {
         config.set((String)entry.getKey(), entry.getValue());
      }

      config.set("auto_config.enabled", true);
      config.set("auto_config.version", this.serverVersion);
      config.set("auto_config.last_update", System.currentTimeMillis());
      config.set("auto_config.profile", this.getConfigProfile());
      config.save(configFile);
      this.plugin.getLogger().info("[AutoConfig] ✅ Updated config.yml");
   }

   private void updateBedrockConfig() throws IOException {
      File configFile = new File(this.plugin.getDataFolder(), "bedrockac.yml");
      YamlConfiguration config = YamlConfiguration.loadConfiguration(configFile);
      config.set("java.max_speed", this.getDouble("movement.speed.java_max_speed"));
      config.set("bedrock.max_speed", this.getDouble("movement.speed.bedrock_max_speed"));
      config.set("checks.speed.max_violations", this.getInt("movement.speed.max_violations"));
      config.set("checks.fly.max_violations", this.getInt("movement.fly.max_violations"));
      config.set("checks.head.max_violations", Math.max(40, this.getInt("movement.fly.max_violations") + 10));
      config.save(configFile);
      this.plugin.getLogger().info("[AutoConfig] ✅ Updated bedrockac.yml");
   }

   private void updateMainConfig() throws IOException {
      File configFile = new File(this.plugin.getDataFolder(), "config.yml");
      YamlConfiguration config = YamlConfiguration.loadConfiguration(configFile);
      double[] tps = VersionUtils.getTPS();
      double averageTPS = (tps[0] + tps[1] + tps[2]) / (double)3.0F;
      config.set("anticheat.auto-kick.enabled", averageTPS > (double)18.0F ? 1 : 0);
      config.set("anticheat.auto-ban.enabled", false);
      config.set("anticheat.alerts.enabled", true);
      config.set("anticheat.alerts.format", "[AutoConfig-" + this.serverVersion + "] %player% failed %check% (%vl%)");
      config.save(configFile);
      this.plugin.getLogger().info("[AutoConfig] ✅ Updated config.yml");
   }

   private String getConfigProfile() {
      if (this.isLegacy) {
         return "Legacy-Optimized";
      } else if (this.is121Plus) {
         return "Modern-Optimized";
      } else {
         return this.isModern ? "Enhanced-Standard" : "Standard-Optimized";
      }
   }

   private void multiplySettings(String settingSuffix, double multiplier) {
      for(Map.Entry<String, Object> entry : this.optimizedSettings.entrySet()) {
         if (((String)entry.getKey()).endsWith(settingSuffix) && entry.getValue() instanceof Number) {
            Number value = (Number)entry.getValue();
            if (value instanceof Integer) {
               this.optimizedSettings.put((String)entry.getKey(), (int)((double)value.intValue() * multiplier));
            } else if (value instanceof Double) {
               this.optimizedSettings.put((String)entry.getKey(), value.doubleValue() * multiplier);
            }
         }
      }

   }

   private double getDouble(String key) {
      Object value = this.optimizedSettings.get(key);
      return value instanceof Number ? ((Number)value).doubleValue() : (double)1.0F;
   }

   private int getInt(String key) {
      Object value = this.optimizedSettings.get(key);
      return value instanceof Number ? ((Number)value).intValue() : 1;
   }

   public void displayConfigSummary() {
      this.spamFreeLogger.info("AUTO_CONFIG", "╔════════════════════════════════════════╗");
      this.spamFreeLogger.info("AUTO_CONFIG", "║          AUTO-CONFIG SUMMARY          ║");
      this.spamFreeLogger.info("AUTO_CONFIG", "╠════════════════════════════════════════╣");
      String versionLine = "║ Minecraft Version: " + this.serverVersion + String.format("%" + (23 - this.serverVersion.length()) + "s║", "");
      this.spamFreeLogger.info("AUTO_CONFIG", versionLine);
      String profileLine = "║ Profile: " + this.getConfigProfile() + String.format("%" + (30 - this.getConfigProfile().length()) + "s║", "");
      this.spamFreeLogger.info("AUTO_CONFIG", profileLine);
      String legacyLine = "║ Legacy Support: " + (this.isLegacy ? "Enabled" : "Disabled") + String.format("%" + (18 - (this.isLegacy ? 7 : 8)) + "s║", "");
      this.spamFreeLogger.info("AUTO_CONFIG", legacyLine);
      String modernLine = "║ Modern Features: " + (this.isModern ? "Enabled" : "Disabled") + String.format("%" + (17 - (this.isModern ? 7 : 8)) + "s║", "");
      this.spamFreeLogger.info("AUTO_CONFIG", modernLine);
      String latestLine = "║ Latest Features: " + (this.is121Plus ? "Enabled" : "Disabled") + String.format("%" + (17 - (this.is121Plus ? 7 : 8)) + "s║", "");
      this.spamFreeLogger.info("AUTO_CONFIG", latestLine);
      double[] tps = VersionUtils.getTPS();
      String tpsStatus = tps[0] > (double)19.5F ? "Excellent" : (tps[0] > (double)18.0F ? "Good" : "Low");
      String tpsLine = "║ Server TPS: " + tpsStatus + " (" + String.format("%.1f", tps[0]) + ")" + String.format("%" + (17 - String.format("%.1f", tps[0]).length()) + "s║", "");
      this.spamFreeLogger.info("AUTO_CONFIG", tpsLine);
      String confidenceLine = "║ ML Confidence: " + this.optimizedSettings.get("machine_learning.confidence_threshold") + String.format("%" + (21 - this.optimizedSettings.get("machine_learning.confidence_threshold").toString().length()) + "s║", "");
      this.spamFreeLogger.info("AUTO_CONFIG", confidenceLine);
      this.spamFreeLogger.info("AUTO_CONFIG", "╚════════════════════════════════════════╝");
      this.spamFreeLogger.info("AUTO_CONFIG", "✅ Ready for optimal anti-cheat protection!");
   }

   public void adjustSpeedThresholds(double multiplier) {
      try {
         FileConfiguration config = this.plugin.getConfig();
         double currentSpeedThreshold = config.getDouble("movement.speed.threshold", (double)1.5F);
         double newThreshold = currentSpeedThreshold * multiplier;
         config.set("movement.speed.threshold", Math.max((double)0.5F, Math.min((double)5.0F, newThreshold)));
         this.plugin.saveConfig();
         StringBuilder adjustMsgBuilder = new StringBuilder("Adjusted speed threshold from ");
         adjustMsgBuilder.append(String.format("%.2f", currentSpeedThreshold)).append(" to ").append(String.format("%.2f", newThreshold));
         this.spamFreeLogger.info("AUTO_CONFIG", adjustMsgBuilder.toString());
      } catch (Exception e) {
         StringBuilder errorMsgBuilder = new StringBuilder("❌ Failed to adjust speed thresholds: ");
         errorMsgBuilder.append(e.getMessage());
         this.spamFreeLogger.warning("AUTO_CONFIG", errorMsgBuilder.toString());
      }

   }

   public void adjustViolationThresholds(double multiplier) {
      try {
         FileConfiguration config = this.plugin.getConfig();
         int currentViolationThreshold = config.getInt("violation.threshold", 25);
         int newThreshold = (int)Math.round((double)currentViolationThreshold * multiplier);
         config.set("violation.threshold", Math.max(5, Math.min(100, newThreshold)));
         this.plugin.saveConfig();
         StringBuilder adjustMsgBuilder = new StringBuilder("Adjusted violation threshold from ");
         adjustMsgBuilder.append(currentViolationThreshold).append(" to ").append(newThreshold);
         this.spamFreeLogger.info("AUTO_CONFIG", adjustMsgBuilder.toString());
      } catch (Exception e) {
         StringBuilder errorMsgBuilder = new StringBuilder("❌ Failed to adjust violation thresholds: ");
         errorMsgBuilder.append(e.getMessage());
         this.spamFreeLogger.warning("AUTO_CONFIG", errorMsgBuilder.toString());
      }

   }

   public void adjustMLConfidence(double adjustment) {
      try {
         FileConfiguration config = this.plugin.getConfig();
         double currentConfidence = config.getDouble("machine_learning.confidence_threshold", 0.95);
         double newConfidence = currentConfidence + adjustment;
         config.set("machine_learning.confidence_threshold", Math.max(0.8, Math.min(0.99, newConfidence)));
         this.plugin.saveConfig();
         StringBuilder adjustMsgBuilder = new StringBuilder("Adjusted ML confidence from ");
         adjustMsgBuilder.append(String.format("%.3f", currentConfidence)).append(" to ").append(String.format("%.3f", newConfidence));
         this.spamFreeLogger.info("AUTO_CONFIG", adjustMsgBuilder.toString());
      } catch (Exception e) {
         StringBuilder errorMsgBuilder = new StringBuilder("❌ Failed to adjust ML confidence: ");
         errorMsgBuilder.append(e.getMessage());
         this.spamFreeLogger.warning("AUTO_CONFIG", errorMsgBuilder.toString());
      }

   }

   public void adjustPingCompensation(double multiplier) {
      try {
         FileConfiguration config = this.plugin.getConfig();
         double currentCompensation = config.getDouble("network.ping_compensation", (double)1.0F);
         double newCompensation = currentCompensation * multiplier;
         config.set("network.ping_compensation", Math.max((double)0.5F, Math.min((double)2.0F, newCompensation)));
         this.plugin.saveConfig();
         StringBuilder adjustMsgBuilder = new StringBuilder("Adjusted ping compensation from ");
         adjustMsgBuilder.append(String.format("%.2f", currentCompensation)).append(" to ").append(String.format("%.2f", newCompensation));
         this.spamFreeLogger.info("AUTO_CONFIG", adjustMsgBuilder.toString());
      } catch (Exception e) {
         StringBuilder errorMsgBuilder = new StringBuilder("❌ Failed to adjust ping compensation: ");
         errorMsgBuilder.append(e.getMessage());
         this.spamFreeLogger.warning("AUTO_CONFIG", errorMsgBuilder.toString());
      }

   }

   public void applyVersionSpecificOptimizations(String optimizationType) {
      try {
         switch (optimizationType) {
            case "legacy_mode_enhancement":
               if (this.isLegacy) {
                  this.applyLegacyOptimizations();
                  this.spamFreeLogger.info("AUTO_CONFIG", "✅ Applied legacy mode enhancements");
               }
               break;
            case "modern_features_optimization":
               if (this.is121Plus) {
                  this.applyModernOptimizations();
                  this.spamFreeLogger.info("AUTO_CONFIG", "✅ Applied modern features optimization");
               }
               break;
            default:
               String optimizationMsg = String.format("Applied optimization: %s", optimizationType);
               this.spamFreeLogger.info("AUTO_CONFIG", optimizationMsg);
         }
      } catch (Exception e) {
         String errorMsg = String.format("❌ Failed to apply version-specific optimizations: %s", e.getMessage());
         this.spamFreeLogger.warning("AUTO_CONFIG", errorMsg);
      }

   }
}
