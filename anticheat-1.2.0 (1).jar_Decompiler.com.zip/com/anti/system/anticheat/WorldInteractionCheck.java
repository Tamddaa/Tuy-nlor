package com.anti.system.anticheat;

import com.anti.system.utils.VersionCompatibility;
import java.util.HashMap;
import java.util.Map;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;

public class WorldInteractionCheck implements Check {
   private final AnomalyDetector detector = new AnomalyDetector();
   private final Map<Player, InteractionProfile> playerProfiles = new HashMap();

   public String getName() {
      return "ExtremelyIntelligentWorldInteraction";
   }

   public void handle(Player player, Object... context) {
      try {
         if (context.length < 1 || !(context[0] instanceof Integer) || player == null) {
            return;
         }

         int blocksPerSecond = (Integer)context[0];
         if (blocksPerSecond < 0 || blocksPerSecond > 1000) {
            return;
         }

         long currentTime = System.currentTimeMillis();
         InteractionProfile profile = (InteractionProfile)this.playerProfiles.computeIfAbsent(player, (k) -> new InteractionProfile());
         profile.recordInteraction(blocksPerSecond, currentTime);
         if (this.isExtremelyIntelligentInteractionAnomaly(player, blocksPerSecond, profile)) {
            double confidence = this.detector.getConfidence("blocks_" + this.getInteractionContext(player), (double)blocksPerSecond);
            PlayerBehaviorLogger.log(player, "intelligent_interaction_anomaly", String.format("bps=%d expected_max=%d confidence=%.2f context=%s tool=%s", blocksPerSecond, this.getExpectedMaxBPS(player), confidence, this.getInteractionContext(player), this.getToolInfo(player)));
         }

         this.detector.record("blocks_" + this.getInteractionContext(player), (double)blocksPerSecond);
      } catch (Exception var9) {
      }

   }

   private boolean isExtremelyIntelligentInteractionAnomaly(Player player, int bps, InteractionProfile profile) {
      int expectedMax = this.getExpectedMaxBPS(player);
      if (bps <= expectedMax) {
         return false;
      } else if (player.getGameMode().toString().equals("CREATIVE")) {
         return bps > 100;
      } else if (this.hasEfficientTool(player) && (double)bps <= (double)expectedMax * (double)3.0F) {
         return false;
      } else if (profile.isLikelyLegitimateBuilding(bps)) {
         return false;
      } else if (this.isBedrock(player) && (double)bps <= (double)expectedMax * (double)1.5F) {
         return false;
      } else {
         String context = this.getInteractionContext(player);
         if (!this.detector.isAnomalous("blocks_" + context, (double)bps)) {
            return false;
         } else {
            double confidence = this.detector.getConfidence("blocks_" + context, (double)bps);
            return !(confidence < 0.85);
         }
      }
   }

   private int getExpectedMaxBPS(Player player) {
      int baseBPS = 20;
      if (player.getGameMode().toString().equals("CREATIVE")) {
         return 100;
      } else {
         ItemStack tool = VersionCompatibility.getItemInMainHand(player);
         if (tool != null && tool.getType() != Material.AIR && this.isMiningTool(tool.getType())) {
            baseBPS += 10;
            if (VersionCompatibility.hasNetherite() && tool.getType().name().contains("NETHERITE")) {
               baseBPS += 5;
            }

            if (tool.containsEnchantment(VersionCompatibility.getEfficiencyEnchantment())) {
               int efficiencyLevel = tool.getEnchantmentLevel(VersionCompatibility.getEfficiencyEnchantment());
               baseBPS += efficiencyLevel * 3;
            }
         }

         if (player.hasPotionEffect(VersionCompatibility.getHasteEffect())) {
            PotionEffect hasteEffect = VersionCompatibility.getPotionEffect(player, VersionCompatibility.getHasteEffect());
            if (hasteEffect != null) {
               baseBPS += (hasteEffect.getAmplifier() + 1) * 2;
            }
         }

         if (VersionCompatibility.getConduitPowerEffect() != null && player.hasPotionEffect(VersionCompatibility.getConduitPowerEffect())) {
            baseBPS += 5;
         }

         if (this.isBedrock(player)) {
            baseBPS = (int)((double)baseBPS * 1.3);
         }

         return Math.max(baseBPS, 20);
      }
   }

   private String getInteractionContext(Player player) {
      StringBuilder context = new StringBuilder();
      context.append(this.isBedrock(player) ? "bedrock" : "java");
      context.append("_").append(player.getGameMode().toString().toLowerCase());
      ItemStack tool = VersionCompatibility.getItemInMainHand(player);
      if (tool != null && this.isMiningTool(tool.getType())) {
         context.append("_with_tool");
         if (tool.containsEnchantment(VersionCompatibility.getEfficiencyEnchantment())) {
            context.append("_efficiency");
         }
      } else {
         context.append("_no_tool");
      }

      if (player.hasPotionEffect(VersionCompatibility.getHasteEffect())) {
         context.append("_haste");
      }

      return context.toString();
   }

   private boolean isMiningTool(Material material) {
      String name = material.name();
      return name.contains("PICKAXE") || name.contains("SHOVEL") || name.contains("AXE") || name.contains("HOE") || name.contains("SWORD") || name.contains("SHEARS") || VersionCompatibility.hasMaceSupport() && material == VersionCompatibility.getMaceMaterial();
   }

   private boolean hasEfficientTool(Player player) {
      ItemStack tool = VersionCompatibility.getItemInMainHand(player);
      return tool != null && this.isMiningTool(tool.getType()) && tool.containsEnchantment(VersionCompatibility.getEfficiencyEnchantment());
   }

   private String getToolInfo(Player player) {
      ItemStack tool = VersionCompatibility.getItemInMainHand(player);
      if (tool != null && tool.getType() != Material.AIR) {
         StringBuilder info = new StringBuilder(tool.getType().name().toLowerCase());
         if (tool.containsEnchantment(VersionCompatibility.getEfficiencyEnchantment())) {
            info.append("_eff").append(tool.getEnchantmentLevel(VersionCompatibility.getEfficiencyEnchantment()));
         }

         return info.toString();
      } else {
         return "none";
      }
   }

   private boolean isBedrock(Player player) {
      return player.getName().startsWith(".") || player.hasPermission("floodgate.legacy") || player.getName().length() > 16;
   }

   private static class InteractionProfile {
      private final int[] recentBPS;
      private int bpsIndex;
      private long buildingSessionStart;

      private InteractionProfile() {
         this.recentBPS = new int[20];
         this.bpsIndex = 0;
         this.buildingSessionStart = 0L;
      }

      void recordInteraction(int bps, long time) {
         if (bps > 5 && this.buildingSessionStart == 0L) {
            this.buildingSessionStart = time;
         } else if (bps < 2 && this.buildingSessionStart > 0L && time - this.buildingSessionStart > 10000L) {
            this.buildingSessionStart = 0L;
         }

         this.recentBPS[this.bpsIndex] = bps;
         this.bpsIndex = (this.bpsIndex + 1) % this.recentBPS.length;
      }

      boolean isLikelyLegitimateBuilding(int currentBps) {
         int activeMeasurements = 0;
         int totalBPS = 0;

         for(int bps : this.recentBPS) {
            if (bps > 0) {
               ++activeMeasurements;
               totalBPS += bps;
            }
         }

         if (activeMeasurements < 5) {
            return true;
         } else {
            double avgBPS = (double)totalBPS / (double)activeMeasurements;
            boolean hasBreaks = false;
            boolean hasVariation = false;

            for(int bps : this.recentBPS) {
               if (bps == 0) {
                  hasBreaks = true;
               }

               if (Math.abs((double)bps - avgBPS) > avgBPS * 0.3) {
                  hasVariation = true;
               }
            }

            boolean longSession = this.buildingSessionStart > 0L && System.currentTimeMillis() - this.buildingSessionStart > 30000L;
            return hasBreaks || hasVariation || longSession;
         }
      }
   }
}
