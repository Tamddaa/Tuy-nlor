package com.anti.system.anticheat;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;

public class CheckManager {
   private final List<Check> checks = new ArrayList();
   private final Map<String, Boolean> checkEnabled = new HashMap();
   private final Map<String, Integer> checkThresholds = new HashMap();
   private final AntiCheatPlugin plugin;

   public CheckManager(AntiCheatPlugin plugin) {
      this.plugin = plugin;
      this.initializeDefaults();
   }

   public AntiCheatPlugin getPlugin() {
      return this.plugin;
   }

   private void initializeDefaults() {
      this.checkEnabled.put("reach", true);
      this.checkEnabled.put("killaura", true);
      this.checkEnabled.put("criticals", true);
      this.checkEnabled.put("antivelocity", true);
      this.checkEnabled.put("aimbot", true);
      this.checkEnabled.put("triggerbot", true);
      this.checkEnabled.put("hitbox", true);
      this.checkEnabled.put("fly", true);
      this.checkEnabled.put("speed", true);
      this.checkEnabled.put("jesus", true);
      this.checkEnabled.put("phase", true);
      this.checkEnabled.put("step", true);
      this.checkEnabled.put("crystalaura", true);
      this.checkEnabled.put("anchoraura", true);
      this.checkEnabled.put("bedaura", true);
      this.checkEnabled.put("autototem", true);
      this.checkEnabled.put("auto32k", true);
      this.checkEnabled.put("autotrap", true);
      this.checkEnabled.put("autoburrow", true);
      this.checkEnabled.put("autofill", true);
      this.checkEnabled.put("fastbreak", true);
      this.checkEnabled.put("fastplace", true);
      this.checkEnabled.put("nuker", true);
      this.checkEnabled.put("scaffold", true);
      this.setDefaultThresholds();
   }

   private void setDefaultThresholds() {
      this.checkThresholds.put("reach", 2);
      this.checkThresholds.put("killaura", 3);
      this.checkThresholds.put("criticals", 4);
      this.checkThresholds.put("hitbox", 1);
      this.checkThresholds.put("crystalaura", 2);
      this.checkThresholds.put("anchoraura", 3);
      this.checkThresholds.put("bedaura", 2);
      this.checkThresholds.put("autototem", 4);
      this.checkThresholds.put("auto32k", 1);
      this.checkThresholds.put("autotrap", 3);
      this.checkThresholds.put("autoburrow", 2);
      this.checkThresholds.put("autofill", 4);
      this.checkThresholds.put("fly", 5);
      this.checkThresholds.put("speed", 6);
      this.checkThresholds.put("jesus", 4);
      this.checkThresholds.put("phase", 3);
      this.checkThresholds.put("step", 5);
      this.checkThresholds.put("fastbreak", 6);
      this.checkThresholds.put("fastplace", 7);
      this.checkThresholds.put("nuker", 3);
      this.checkThresholds.put("scaffold", 5);
   }

   public void register(Check check2) {
      this.checks.add(check2);
   }

   public void handle(Player player, Object... context) {
      for(Check check2 : this.checks) {
         if (this.isEnabled(check2.getName())) {
            check2.handle(player, context);
         }
      }

   }

   public boolean isEnabled(String checkName) {
      return (Boolean)this.checkEnabled.getOrDefault(checkName.toLowerCase(), false);
   }

   public void setEnabled(String checkName, boolean enabled) {
      this.checkEnabled.put(checkName.toLowerCase(), enabled);
      this.saveConfiguration();
   }

   public int getThreshold(String checkName) {
      return (Integer)this.checkThresholds.getOrDefault(checkName.toLowerCase(), 5);
   }

   public void setThreshold(String checkName, int threshold) {
      this.checkThresholds.put(checkName.toLowerCase(), threshold);
      this.saveConfiguration();
   }

   public int getActiveChecksCount() {
      return this.checkEnabled.values().stream().mapToInt((enabled) -> enabled ? 1 : 0).sum();
   }

   public void enableAllChecks() {
      for(String checkName : this.checkEnabled.keySet()) {
         this.checkEnabled.put(checkName, true);
      }

      this.saveConfiguration();
   }

   public void disableAllChecks() {
      for(String checkName : this.checkEnabled.keySet()) {
         this.checkEnabled.put(checkName, false);
      }

      this.saveConfiguration();
   }

   public List<String> getCheckNames() {
      return new ArrayList(this.checkEnabled.keySet());
   }

   public Map<String, Boolean> getAllCheckStates() {
      return new HashMap(this.checkEnabled);
   }

   private void saveConfiguration() {
      FileConfiguration config = this.plugin.getConfig();

      for(Map.Entry<String, Boolean> entry : this.checkEnabled.entrySet()) {
         config.set("checks." + (String)entry.getKey() + ".enabled", entry.getValue());
      }

      for(Map.Entry<String, Integer> entry : this.checkThresholds.entrySet()) {
         config.set("checks." + (String)entry.getKey() + ".threshold", entry.getValue());
      }

      this.plugin.saveConfig();
   }

   public void handleViolation(Player player, String checkName, String reason, int violationLevel) {
      DiscordWebhookManager discordManager = this.plugin.getDiscordManager();
      if (discordManager != null && discordManager.isEnabled() && violationLevel >= this.plugin.getConfig().getInt("discord.notifications.min_violation_level", 10)) {
         discordManager.sendViolationAlert(player, checkName, reason, violationLevel);
      }

      if (this.plugin.getDatabaseManager() != null) {
         this.plugin.getDatabaseManager().logViolation(player.getUniqueId(), player.getName(), checkName, reason);
      }

      String alertFormat = this.plugin.getConfig().getString("anticheat.alerts.format", "[AutoConfig] %player% failed %check% (%vl%)");
      if (alertFormat != null) {
         String alert = alertFormat.replace("%player%", player.getName()).replace("%check%", checkName).replace("%vl%", String.valueOf(violationLevel)).replace("%reason%", reason);
         this.plugin.getServer().getOnlinePlayers().stream().filter((p) -> p.hasPermission("antisystem.alerts")).forEach((staff) -> staff.sendMessage(alert));
      }

   }

   public void loadConfiguration() {
      FileConfiguration config = this.plugin.getConfig();

      for(String checkName : this.checkEnabled.keySet()) {
         if (config.contains("checks." + checkName + ".enabled")) {
            this.checkEnabled.put(checkName, config.getBoolean("checks." + checkName + ".enabled"));
         }

         if (config.contains("checks." + checkName + ".threshold")) {
            this.checkThresholds.put(checkName, config.getInt("checks." + checkName + ".threshold"));
         }
      }

   }
}
