package com.anti.system.anticheat;

import com.anti.system.utils.VersionCompatibility;
import com.anti.system.utils.VersionUtils;
import java.util.HashMap;
import java.util.Map;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public class MovementCheck implements Check {
   private final Map<Player, Long> lastAlertTime = new HashMap();
   private final AnomalyDetector detector = new AnomalyDetector();
   private final Map<Player, MovementProfile> playerProfiles = new HashMap();
   private final CheckManager checkManager;
   private static final double SPEED_MULTIPLIER = 1.02;
   private static final double STRAFE_MULTIPLIER = 1.01;
   private static final double FLIGHT_TOLERANCE = 0.98;
   private static final int MAX_VIOLATIONS_BEFORE_ACTION = 2;
   private static final long ALERT_COOLDOWN = 1000L;

   public MovementCheck(CheckManager checkManager) {
      this.checkManager = checkManager;
   }

   public String getName() {
      return "ExtremelyIntelligentMovement";
   }

   public void handle(Player player, Object... context) {
      try {
         if (context.length < 2 || !(context[0] instanceof Double) || !(context[1] instanceof Double)) {
            return;
         }

         double speed = (Double)context[0];
         double strafeSpeed = (Double)context[1];
         long currentTime = System.currentTimeMillis();
         if (!this.isValidSpeed(speed) || !this.isValidSpeed(strafeSpeed)) {
            return;
         }

         MovementProfile profile = (MovementProfile)this.playerProfiles.computeIfAbsent(player, (k) -> new MovementProfile());
         profile.recordMovement(speed, currentTime);
         profile.recordLocation(player.getLocation());
         boolean flagged = false;
         String flagReason = null;
         double confidence = (double)0.0F;
         double expectedMaxSpeed = this.getExpectedSpeed(player);
         if (speed > expectedMaxSpeed * 1.02) {
            confidence = this.detector.getConfidence("speed_" + this.getMovementContext(player), speed);
            flagReason = String.format("Speed cheat detected: %.3f/%.3f (%.1f%% over limit)", speed, expectedMaxSpeed * 1.02, (speed / (expectedMaxSpeed * 1.02) - (double)1.0F) * (double)100.0F);
            flagged = true;
         }

         double expectedStrafe = expectedMaxSpeed * 0.85;
         if (!flagged && strafeSpeed > expectedStrafe * 1.01) {
            confidence = this.detector.getConfidence("strafe_" + this.getMovementContext(player), strafeSpeed);
            flagReason = String.format("Strafe cheat detected: %.3f/%.3f (%.1f%% over limit)", strafeSpeed, expectedStrafe * 1.01, (strafeSpeed / (expectedStrafe * 1.01) - (double)1.0F) * (double)100.0F);
            flagged = true;
         }

         if (!flagged && this.isFlightCheat(player, speed, profile)) {
            confidence = 0.95;
            flagReason = String.format("Flight cheat detected: %.3f speed while airborne for %.1fs", speed, (double)profile.getAirTime() / (double)1000.0F);
            flagged = true;
         }

         Material block = player.getLocation().getBlock().getType();
         double maxWaterSpeed;
         if (!flagged && this.isWaterMaterial(block) && !player.isFlying() && speed > (maxWaterSpeed = this.calculateMaxWaterSpeed(player))) {
            confidence = 0.9;
            flagReason = String.format("Water walk cheat: %.3f/%.3f in water", speed, maxWaterSpeed);
            flagged = true;
         }

         if (!flagged && this.isPhaseCheat(player, speed)) {
            confidence = 0.95;
            flagReason = "Phase cheat: moving through solid blocks";
            flagged = true;
         }

         if (!flagged && profile.hasRapidSpeedChanges()) {
            confidence = 0.85;
            flagReason = "Rapid speed changes detected: potential timer/speed hack";
            flagged = true;
         }

         if (flagged && flagReason != null && !profile.hasRecentLagSpike() && !profile.isTemporarySpeedBoost(speed)) {
            this.handleViolation(player, flagReason, confidence, profile);
         }

         this.recordMovementData(player, speed, strafeSpeed, block);
      } catch (Exception var21) {
      }

   }

   private boolean isValidSpeed(double speed) {
      return !Double.isNaN(speed) && !Double.isInfinite(speed) && speed >= (double)0.0F && speed < (double)100.0F;
   }

   private void handleViolation(Player player, String reason, double confidence, MovementProfile profile) {
      long currentTime = System.currentTimeMillis();
      long lastAlert = (Long)this.lastAlertTime.getOrDefault(player, 0L);
      if (currentTime - lastAlert >= 1000L) {
         this.lastAlertTime.put(player, currentTime);
         profile.incrementViolation();
         if (profile.getViolationCount() < 2 && !(confidence > 0.8)) {
            if (player.isOp() || player.hasPermission("antisystem.staff.alerts")) {
               this.checkManager.handleViolation(player, "Movement", reason, profile.getViolationCount());
            }
         } else if (!player.isOp() && !player.hasPermission("antisystem.staff")) {
            Location safeLocation = this.findSafeLocation(player);
            if (safeLocation != null) {
               player.teleport(safeLocation);
            }
         } else {
            this.checkManager.handleViolation(player, "Movement", reason, profile.getViolationCount());
         }

         PlayerBehaviorLogger.log(player, "movement_cheat", reason);
      }
   }

   private boolean isFlightCheat(Player player, double speed, MovementProfile profile) {
      if (!player.getAllowFlight() && !player.isFlying() && player.getGameMode() != GameMode.CREATIVE && player.getGameMode() != GameMode.SPECTATOR) {
         boolean isOnGround = this.isPlayerOnGround(player);
         if (isOnGround) {
            profile.resetAirTime();
            return false;
         } else {
            profile.incrementAirTime();
            double maxFlightSpeed = 0.09604;
            if (profile.getAirTime() > 3000L && speed > maxFlightSpeed) {
               return true;
            } else if (profile.isStraightLineFlight()) {
               return true;
            } else {
               double verticalSpeed = Math.abs(player.getVelocity().getY());
               return verticalSpeed > 0.588 && profile.getAirTime() > 1000L;
            }
         }
      } else {
         return false;
      }
   }

   private double calculateMaxWaterSpeed(Player player) {
      double baseWaterSpeed = 0.08;
      if (player.getInventory().getBoots() != null) {
         try {
            if (player.getInventory().getBoots().containsEnchantment(Enchantment.DEPTH_STRIDER)) {
               int level = player.getInventory().getBoots().getEnchantmentLevel(Enchantment.DEPTH_STRIDER);
               baseWaterSpeed += (double)level * 0.03;
            }
         } catch (Exception var6) {
         }
      }

      if (VersionUtils.isSwimming(player)) {
         baseWaterSpeed *= 1.2;
      }

      try {
         PotionEffectType dolphinsGrace = VersionCompatibility.getDolphinsGraceEffect();
         if (dolphinsGrace != null && player.hasPotionEffect(dolphinsGrace)) {
            baseWaterSpeed *= 1.3;
         }
      } catch (Exception var5) {
      }

      return baseWaterSpeed;
   }

   private boolean isPhaseCheat(Player player, double speed) {
      if (speed < 0.1) {
         return false;
      } else {
         Location loc = player.getLocation();
         Block currentBlock = loc.getBlock();
         if (currentBlock.getType().isSolid() && !this.isPassableBlock(currentBlock.getType())) {
            return true;
         } else {
            Block headBlock = loc.add((double)0.0F, (double)1.0F, (double)0.0F).getBlock();
            return headBlock.getType().isSolid() && !this.isPassableBlock(headBlock.getType());
         }
      }
   }

   private boolean isPassableBlock(Material material) {
      return VersionCompatibility.isAir(material) || VersionCompatibility.isWater(material) || VersionCompatibility.isLava(material) || material.name().contains("SIGN") || material.name().contains("DOOR") || material.name().contains("GATE") || material.name().contains("PRESSURE_PLATE") || material.name().contains("BANNER") || material.name().contains("CARPET") || material.name().contains("TORCH") || material.name().contains("LEVER");
   }

   private void recordMovementData(Player player, double speed, double strafeSpeed, Material block) {
      String context = this.getMovementContext(player);
      this.detector.record("speed_" + context, speed);
      this.detector.record("strafe_" + context, strafeSpeed);
      if (this.isWaterMaterial(block)) {
         this.detector.record("water_" + context, speed);
      }

      if (player.isFlying()) {
         this.detector.record("flight_" + context, speed);
      }

   }

   private Location findSafeLocation(Player player) {
      Location current = player.getLocation();

      for(int y = current.getBlockY(); y > 0; --y) {
         Location testLoc = new Location(current.getWorld(), current.getX(), (double)y, current.getZ());
         if (testLoc.getBlock().getType().isSolid() && testLoc.add((double)0.0F, (double)1.0F, (double)0.0F).getBlock().getType() == Material.AIR && testLoc.add((double)0.0F, (double)2.0F, (double)0.0F).getBlock().getType() == Material.AIR) {
            return testLoc.add((double)0.0F, (double)1.0F, (double)0.0F);
         }
      }

      return player.getWorld().getSpawnLocation();
   }

   private double getExpectedSpeed(Player player) {
      double baseSpeed = 0.15;
      if (player.isSprinting()) {
         baseSpeed *= (double)1.25F;
      }

      if (player.isFlying()) {
         baseSpeed = (double)(player.getFlySpeed() * 8.0F);
      }

      if (player.hasPotionEffect(PotionEffectType.SPEED)) {
         PotionEffect speedEffect = VersionCompatibility.getPotionEffect(player, PotionEffectType.SPEED);
         if (speedEffect != null) {
            int amplifier = speedEffect.getAmplifier();
            baseSpeed *= (double)1.0F + 0.15 * (double)Math.min(amplifier + 1, 3);
         }
      }

      if (player.hasPotionEffect(VersionCompatibility.getSlownessEffect())) {
         PotionEffect slownessEffect = VersionCompatibility.getPotionEffect(player, VersionCompatibility.getSlownessEffect());
         if (slownessEffect != null) {
            int amplifier = slownessEffect.getAmplifier();
            baseSpeed *= Math.max(0.1, (double)1.0F - 0.15 * (double)(amplifier + 1));
         }
      }

      PotionEffectType dolphinsGrace = VersionCompatibility.getDolphinsGraceEffect();
      if (dolphinsGrace != null && player.hasPotionEffect(dolphinsGrace)) {
         PotionEffect effect = VersionCompatibility.getPotionEffect(player, dolphinsGrace);
         if (effect != null) {
            baseSpeed *= (double)1.5F;
         }
      }

      if (VersionCompatibility.isVersionOrHigher(1, 16)) {
         try {
            ItemStack boots = player.getInventory().getBoots();
            if (boots != null && boots.hasItemMeta()) {
               Enchantment soulSpeed = VersionCompatibility.getSoulSpeedEnchantment();
               if (soulSpeed != null && boots.containsEnchantment(soulSpeed)) {
                  Material blockBelow = player.getLocation().subtract((double)0.0F, (double)1.0F, (double)0.0F).getBlock().getType();
                  if (this.isSoulSandMaterial(blockBelow)) {
                     int level = boots.getEnchantmentLevel(soulSpeed);
                     baseSpeed *= (double)1.0F + (double)level * 0.105;
                  }
               }
            }
         } catch (Exception var12) {
         }
      }

      if (VersionCompatibility.isVersionOrHigher(1, 19)) {
         try {
            ItemStack leggings = player.getInventory().getLeggings();
            if (leggings != null && leggings.hasItemMeta() && player.isSneaking()) {
               Enchantment swiftSneak = VersionCompatibility.getSwiftSneakEnchantment();
               if (swiftSneak != null && leggings.containsEnchantment(swiftSneak)) {
                  int level = leggings.getEnchantmentLevel(swiftSneak);
                  baseSpeed *= (double)1.0F + (double)level * 0.15;
               }
            }
         } catch (Exception var11) {
         }
      }

      Material blockType = player.getLocation().getBlock().getType();
      if (VersionCompatibility.isWater(blockType)) {
         try {
            ItemStack boots = player.getInventory().getBoots();
            if (boots != null && boots.hasItemMeta()) {
               Enchantment depthStrider = Enchantment.getByName("DEPTH_STRIDER");
               if (depthStrider != null && boots.containsEnchantment(depthStrider)) {
                  int level = boots.getEnchantmentLevel(depthStrider);
                  baseSpeed *= (double)1.0F + (double)level * 0.33;
               }
            }
         } catch (Exception var10) {
         }
      }

      if (this.isBedrock(player)) {
         baseSpeed *= 1.15;
      }

      try {
         int ping = VersionCompatibility.getPing(player);
         if (ping > 300) {
            baseSpeed *= 1.1;
         }
      } catch (Exception var9) {
      }

      return baseSpeed;
   }

   private boolean isSoulSandMaterial(Material material) {
      String name = material.name();
      return name.contains("SOUL_SAND") || name.contains("SOUL_SOIL");
   }

   private boolean isPlayerOnGround(Player player) {
      try {
         return !player.isFlying() && player.getLocation().getY() % (double)1.0F == (double)0.0F;
      } catch (Exception var6) {
         try {
            Location loc = player.getLocation();
            Block below = loc.subtract((double)0.0F, (double)1.0F, (double)0.0F).getBlock();
            return below.getType().isSolid();
         } catch (Exception var5) {
            return player.getLocation().getY() % (double)1.0F == (double)0.0F;
         }
      }
   }

   private String getMovementContext(Player player) {
      StringBuilder context = new StringBuilder();
      context.append(this.isBedrock(player) ? "bedrock" : "java");
      if (player.isFlying()) {
         context.append("_flying");
      } else if (player.isSprinting()) {
         context.append("_sprinting");
      } else {
         context.append("_walking");
      }

      Material ground = player.getLocation().subtract((double)0.0F, (double)1.0F, (double)0.0F).getBlock().getType();
      if (this.isIceMaterial(ground)) {
         context.append("_ice");
      } else if (this.isSlowMaterial(ground)) {
         context.append("_slow");
      }

      try {
         int ping = VersionCompatibility.getPing(player);
         if (ping > 200) {
            context.append("_highping");
         } else if (ping > 100) {
            context.append("_medping");
         }
      } catch (Exception var5) {
      }

      return context.toString();
   }

   private boolean isBedrock(Player player) {
      return player.getName().startsWith(".") || player.hasPermission("floodgate.legacy") || player.getName().length() > 16;
   }

   private boolean isWaterMaterial(Material material) {
      return VersionCompatibility.isWater(material);
   }

   private boolean isIceMaterial(Material material) {
      if (material == Material.ICE) {
         return true;
      } else {
         try {
            if (material == Material.valueOf("PACKED_ICE")) {
               return true;
            }

            if (VersionCompatibility.hasBlueIceMaterial() && material == VersionCompatibility.getBlueIceMaterial()) {
               return true;
            }

            if (material == Material.valueOf("FROSTED_ICE")) {
               return true;
            }
         } catch (IllegalArgumentException var3) {
         }

         return false;
      }
   }

   private boolean isSlowMaterial(Material material) {
      if (material == Material.SOUL_SAND) {
         return true;
      } else {
         try {
            if (material == Material.valueOf("SOUL_SOIL")) {
               return true;
            }

            if (material == Material.valueOf("HONEY_BLOCK")) {
               return true;
            }

            if (material == Material.valueOf("MUD")) {
               return true;
            }

            if (material == Material.valueOf("MUDDY_MANGROVE_ROOTS")) {
               return true;
            }
         } catch (IllegalArgumentException var3) {
         }

         return false;
      }
   }

   private static class MovementProfile {
      private final double[] recentSpeeds;
      private final long[] speedTimestamps;
      private final Location[] recentLocations;
      private int speedIndex;
      private int locationIndex;
      private long lastLagSpike;
      private int violationCount;
      private long airTimeStart;
      private boolean isInAir;

      private MovementProfile() {
         this.recentSpeeds = new double[20];
         this.speedTimestamps = new long[20];
         this.recentLocations = new Location[10];
         this.speedIndex = 0;
         this.locationIndex = 0;
         this.lastLagSpike = 0L;
         this.violationCount = 0;
         this.airTimeStart = 0L;
         this.isInAir = false;
      }

      void recordMovement(double speed, long time) {
         if (this.speedIndex > 0) {
            double prevSpeed = this.recentSpeeds[(this.speedIndex - 1 + this.recentSpeeds.length) % this.recentSpeeds.length];
            if (prevSpeed < 0.1 && speed > (double)0.5F) {
               this.lastLagSpike = time;
            }
         }

         this.recentSpeeds[this.speedIndex] = speed;
         this.speedTimestamps[this.speedIndex] = time;
         this.speedIndex = (this.speedIndex + 1) % this.recentSpeeds.length;
      }

      void recordLocation(Location location) {
         this.recentLocations[this.locationIndex] = location.clone();
         this.locationIndex = (this.locationIndex + 1) % this.recentLocations.length;
      }

      void incrementViolation() {
         ++this.violationCount;
      }

      int getViolationCount() {
         return this.violationCount;
      }

      void resetAirTime() {
         this.isInAir = false;
         this.airTimeStart = 0L;
      }

      void incrementAirTime() {
         if (!this.isInAir) {
            this.isInAir = true;
            this.airTimeStart = System.currentTimeMillis();
         }

      }

      long getAirTime() {
         return !this.isInAir ? 0L : System.currentTimeMillis() - this.airTimeStart;
      }

      boolean isStraightLineFlight() {
         if (this.recentLocations.length < 5) {
            return false;
         } else {
            int validLocations = 0;

            for(Location loc : this.recentLocations) {
               if (loc != null) {
                  ++validLocations;
               }
            }

            if (validLocations < 5) {
               return false;
            } else {
               double totalDeviation = (double)0.0F;
               Location start = null;
               Location end = null;

               for(Location loc : this.recentLocations) {
                  if (loc != null) {
                     if (start == null) {
                        start = loc;
                     }

                     end = loc;
                  }
               }

               if (start != null && end != null && !start.equals(end)) {
                  double expectedDistance = start.distance(end);
                  if (expectedDistance < (double)3.0F) {
                     return false;
                  } else {
                     for(Location loc : this.recentLocations) {
                        if (loc != null && !loc.equals(start) && !loc.equals(end)) {
                           double distanceFromLine = this.calculateDistanceFromLine(start, end, loc);
                           totalDeviation += distanceFromLine;
                        }
                     }

                     double avgDeviation = totalDeviation / (double)validLocations;
                     return avgDeviation < 0.1 && expectedDistance > (double)5.0F;
                  }
               } else {
                  return false;
               }
            }
         }
      }

      private double calculateDistanceFromLine(Location start, Location end, Location point) {
         double x1 = start.getX();
         double y1 = start.getZ();
         double x2 = end.getX();
         double y2 = end.getZ();
         double x0 = point.getX();
         double y0 = point.getZ();
         double numerator = Math.abs((y2 - y1) * x0 - (x2 - x1) * y0 + x2 * y1 - y2 * x1);
         double denominator = Math.sqrt(Math.pow(y2 - y1, (double)2.0F) + Math.pow(x2 - x1, (double)2.0F));
         return denominator == (double)0.0F ? (double)0.0F : numerator / denominator;
      }

      boolean hasRecentLagSpike() {
         long currentTime = System.currentTimeMillis();
         return currentTime - this.lastLagSpike < 1000L;
      }

      boolean isTemporarySpeedBoost(double speed) {
         double avgRecentSpeed = (double)0.0F;
         int count = 0;

         for(int i = 0; i < this.recentSpeeds.length - 1; ++i) {
            if (this.recentSpeeds[i] > (double)0.0F) {
               avgRecentSpeed += this.recentSpeeds[i];
               ++count;
            }
         }

         if (count < 3) {
            return true;
         } else {
            double var7;
            return speed > (var7 = avgRecentSpeed / (double)count) * (double)1.5F && var7 < 0.2;
         }
      }

      boolean hasRapidSpeedChanges() {
         int rapidChanges = 0;

         for(int i = 1; i < this.recentSpeeds.length; ++i) {
            int prevIndex = (i - 1 + this.recentSpeeds.length) % this.recentSpeeds.length;
            if (this.speedTimestamps[i] != 0L && this.speedTimestamps[prevIndex] != 0L) {
               long timeDiff = this.speedTimestamps[i] - this.speedTimestamps[prevIndex];
               double speedDiff = Math.abs(this.recentSpeeds[i] - this.recentSpeeds[prevIndex]);
               if (timeDiff < 50L && speedDiff > 0.3) {
                  ++rapidChanges;
               }
            }
         }

         return rapidChanges >= 3;
      }
   }
}
