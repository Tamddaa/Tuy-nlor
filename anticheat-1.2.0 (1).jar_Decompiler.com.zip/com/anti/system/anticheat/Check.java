package com.anti.system.anticheat;

import org.bukkit.entity.Player;

public interface Check {
   String getName();

   void handle(Player var1, Object... var2);

   default int getViolationThreshold() {
      return 20;
   }

   default boolean shouldNotifyDiscord(int violationLevel) {
      return violationLevel >= this.getViolationThreshold() / 2;
   }

   default String getDescription() {
      return "Anti-cheat detection for " + this.getName();
   }

   default boolean isEnabled() {
      return true;
   }
}
