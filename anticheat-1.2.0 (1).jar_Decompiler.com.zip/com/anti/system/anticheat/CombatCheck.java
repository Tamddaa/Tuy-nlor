package com.anti.system.anticheat;

import com.anti.system.utils.VersionCompatibility;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.util.Vector;

public class CombatCheck implements Check {
   private final AnomalyDetector detector = new AnomalyDetector();
   private final Map<Player, CombatProfile> playerProfiles = new HashMap();
   private static final double MAX_LEGITIMATE_CPS = (double)15.0F;
   private static final double SUSPICIOUS_CPS_THRESHOLD = (double)20.0F;
   private static final long COMBAT_CONTEXT_WINDOW = 10000L;

   public String getName() {
      return "ExtremelyIntelligentCombat";
   }

   public void handle(Player player, Object... context) {
      try {
         if (context.length < 1 || player == null) {
            return;
         }

         if (context[0] instanceof Double) {
            this.handleCPSDetection(player, (Double)context[0]);
         } else if (context[0] instanceof Entity) {
            this.handleReachDetection(player, (Entity)context[0]);
         }
      } catch (Exception var4) {
      }

   }

   private void handleCPSDetection(Player player, double cps) {
      if (!Double.isNaN(cps) && !Double.isInfinite(cps) && !(cps < (double)0.0F) && !(cps > (double)100.0F)) {
         long currentTime = System.currentTimeMillis();
         CombatProfile profile = (CombatProfile)this.playerProfiles.computeIfAbsent(player, (k) -> new CombatProfile());
         profile.recordClick(currentTime, cps);
         double suspiciousCPS = (double)20.0F;
         if (VersionCompatibility.isVersionOrHigher(1, 9)) {
            suspiciousCPS = (double)12.0F;
            if (this.isAttackCooldownBypass(player, cps)) {
               PlayerBehaviorLogger.log(player, "attack_cooldown_bypass", String.format("CPS: %.2f (cooldown bypass detected)", cps));
            }
         }

         if (this.isExtremelyIntelligentAnomaly(player, cps, profile)) {
            PlayerBehaviorLogger.log(player, "intelligent_autoclicker_detected", String.format("CPS: %.2f, Pattern: %s", cps, profile.getPattern()));
         }

         if (cps > suspiciousCPS) {
            PlayerBehaviorLogger.log(player, "autoclicker_detected", String.format("CPS: %.2f (limit: %.1f)", cps, suspiciousCPS));
         }

         profile.cleanOldData(currentTime, 10000L);
         this.detector.record("cps_" + this.getPlayerCategory(player), cps);
      }
   }

   private boolean isAttackCooldownBypass(Player player, double cps) {
      if (!VersionCompatibility.isVersionOrHigher(1, 9)) {
         return false;
      } else {
         try {
            Object handle = player.getClass().getMethod("getHandle").invoke(player);
            Method getCooledAttackStrengthMethod = handle.getClass().getMethod("getCooledAttackStrength", Float.TYPE);
            float cooldownProgress = (Float)getCooledAttackStrengthMethod.invoke(handle, 0.5F);
            return cps > (double)6.0F && (double)cooldownProgress < 0.9;
         } catch (IllegalAccessException | InvocationTargetException | ClassCastException | NoSuchMethodException var7) {
            return cps > (double)10.0F;
         }
      }
   }

   private void handleReachDetection(Player attacker, Entity target) {
      if (target instanceof LivingEntity) {
         double distance = this.calculateReachDistance(attacker, target);
         double maxReach = this.calculateMaxReach(attacker);
         if (distance > maxReach) {
            CombatProfile profile = (CombatProfile)this.playerProfiles.computeIfAbsent(attacker, (k) -> new CombatProfile());
            profile.recordReachViolation(distance);
            String reason = String.format("Reach cheat: %.2f/%.2f blocks (%.1f%% over limit)", distance, maxReach, (distance / maxReach - (double)1.0F) * (double)100.0F);
            PlayerBehaviorLogger.log(attacker, "reach_cheat", reason);
            if (!attacker.isOp() && !attacker.hasPermission("antisystem.staff")) {
               Vector direction = attacker.getLocation().getDirection().multiply(-0.3);
               attacker.setVelocity(direction);
            }
         }

         this.detector.record("reach_" + this.getPlayerCategory(attacker), distance);
      }
   }

   private double calculateMaxReach(Player player) {
      double baseReach = 3.05;
      if (this.isBedrock(player)) {
         baseReach = 3.15;
      }

      if (player.getGameMode() == GameMode.CREATIVE) {
         baseReach = (double)5.0F;
      }

      if (VersionCompatibility.hasTridentSupport()) {
         try {
            ItemStack mainHand = VersionCompatibility.getItemInMainHand(player);
            if (mainHand != null && mainHand.getType().name().equals("TRIDENT")) {
               Enchantment riptide = VersionCompatibility.getRiptideEnchantment();
               if (riptide != null && mainHand.containsEnchantment(riptide)) {
                  ++baseReach;
               }
            }
         } catch (Exception var8) {
         }
      }

      if (VersionCompatibility.hasMaceSupport()) {
         try {
            ItemStack mainHand = VersionCompatibility.getItemInMainHand(player);
            if (mainHand != null && mainHand.getType() == VersionCompatibility.getMaceMaterial()) {
               baseReach += (double)0.5F;
            }
         } catch (Exception var7) {
         }
      }

      try {
         int ping = VersionCompatibility.getPing(player);
         if (ping > 150) {
            baseReach += 0.1;
         }

         if (ping > 300) {
            baseReach += 0.2;
         }
      } catch (Exception var6) {
      }

      return baseReach;
   }

   private boolean isBedrock(Player player) {
      return player.getName().startsWith(".") || player.hasPermission("floodgate.legacy") || player.getName().length() > 16;
   }

   private double calculateReachDistance(Player attacker, Entity target) {
      Location attackerLoc = attacker.getEyeLocation();
      Location targetLoc = target.getLocation();
      targetLoc.add((double)0.0F, this.getEntityHeight(target) / (double)2.0F, (double)0.0F);
      double distance = attackerLoc.distance(targetLoc);
      distance -= 0.3;
      return Math.max((double)0.0F, distance - this.getEntityWidth(target) / (double)2.0F);
   }

   private boolean isExtremelyIntelligentAnomaly(Player player, double cps, CombatProfile profile) {
      double legitimateLimit = (double)15.0F;
      if (VersionCompatibility.isVersionOrHigher(1, 9)) {
         legitimateLimit = (double)8.0F;
      }

      if (cps < legitimateLimit) {
         return false;
      } else if (profile.isConsistentPattern()) {
         return false;
      } else if (profile.hasRecentCombat() && cps < (double)22.5F) {
         return false;
      } else {
         String category = this.getPlayerCategory(player);
         if (!this.detector.isAnomalous("cps_" + category, cps)) {
            return false;
         } else {
            double confidence = this.detector.getConfidence("cps_" + category, cps);
            return !(confidence < 0.8);
         }
      }
   }

   private String getPlayerCategory(Player player) {
      if (!player.getName().startsWith(".") && !player.hasPermission("floodgate.legacy")) {
         try {
            int ping = VersionCompatibility.getPing(player);
            if (ping > 200) {
               return "high_ping";
            }

            if (ping > 100) {
               return "medium_ping";
            }
         } catch (Exception var3) {
         }

         return "java_low_ping";
      } else {
         return "bedrock";
      }
   }

   private double getEntityHeight(Entity entity) {
      if (entity instanceof Player) {
         return 1.8;
      } else if (entity instanceof LivingEntity) {
         switch (entity.getType().name()) {
            case "ZOMBIE":
            case "SKELETON":
            case "VILLAGER":
               return 1.95;
            case "CREEPER":
               return 1.7;
            case "ENDERMAN":
               return 2.9;
            case "SPIDER":
               return 0.9;
            case "COW":
            case "PIG":
               return 1.4;
            default:
               return (double)1.5F;
         }
      } else {
         return (double)1.0F;
      }
   }

   private double getEntityWidth(Entity entity) {
      if (entity instanceof Player) {
         return 0.6;
      } else if (entity instanceof LivingEntity) {
         switch (entity.getType().name()) {
            case "ZOMBIE":
            case "SKELETON":
            case "VILLAGER":
            case "PLAYER":
               return 0.6;
            case "CREEPER":
               return 0.6;
            case "ENDERMAN":
               return 0.6;
            case "SPIDER":
               return 1.4;
            case "COW":
               return 0.9;
            case "PIG":
               return 0.9;
            default:
               return 0.6;
         }
      } else {
         return (double)0.5F;
      }
   }

   private static class CombatProfile {
      private long lastClickTime;
      private final double[] recentCPS;
      private final long[] clickTimestamps;
      private int cpsIndex;
      private int timestampIndex;
      private boolean hasRecentCombat;
      private long lastCombatTime;

      private CombatProfile() {
         this.lastClickTime = 0L;
         this.recentCPS = new double[10];
         this.clickTimestamps = new long[20];
         this.cpsIndex = 0;
         this.timestampIndex = 0;
         this.hasRecentCombat = false;
         this.lastCombatTime = 0L;
      }

      void recordClick(long currentTime, double cps) {
         this.lastClickTime = currentTime;
         long lastTime;
         if (this.timestampIndex > 0 && (lastTime = this.clickTimestamps[(this.timestampIndex - 1 + this.clickTimestamps.length) % this.clickTimestamps.length]) > 0L) {
            this.clickTimestamps[this.timestampIndex] = currentTime - lastTime;
         }

         this.recentCPS[this.cpsIndex] = cps;
         this.cpsIndex = (this.cpsIndex + 1) % this.recentCPS.length;
         this.timestampIndex = (this.timestampIndex + 1) % this.clickTimestamps.length;
         this.hasRecentCombat = true;
         this.lastCombatTime = currentTime;
      }

      void recordReachViolation(double distance) {
      }

      void cleanOldData(long currentTime, long contextWindow) {
         if (currentTime - this.lastCombatTime > contextWindow) {
            this.hasRecentCombat = false;
         }

         if (currentTime - this.lastClickTime > contextWindow) {
            for(int i = 0; i < this.recentCPS.length; ++i) {
               if (this.recentCPS[i] > (double)0.0F) {
                  this.recentCPS[i] = (double)0.0F;
               }
            }
         }

      }

      boolean isConsistentPattern() {
         double sum = (double)0.0F;
         int count = 0;

         for(double cps : this.recentCPS) {
            if (cps > (double)0.0F) {
               sum += cps;
               ++count;
            }
         }

         if (count < 3) {
            return true;
         } else {
            double mean = sum / (double)count;
            double variance = (double)0.0F;

            for(double cps : this.recentCPS) {
               if (cps > (double)0.0F) {
                  variance += Math.pow(cps - mean, (double)2.0F);
               }
            }

            boolean hasNaturalTiming = this.hasNaturalClickTiming();
            return variance / (double)count > (double)0.5F && hasNaturalTiming;
         }
      }

      private boolean hasNaturalClickTiming() {
         int validTimings = 0;
         long totalInterval = 0L;

         for(long interval : this.clickTimestamps) {
            if (interval > 0L && interval < 2000L) {
               totalInterval += interval;
               ++validTimings;
            }
         }

         if (validTimings < 5) {
            return true;
         } else {
            double avgInterval = (double)totalInterval / (double)validTimings;
            double variance = (double)0.0F;
            int varianceCount = 0;

            for(long interval : this.clickTimestamps) {
               if (interval > 0L && interval < 2000L) {
                  variance += Math.pow((double)interval - avgInterval, (double)2.0F);
                  ++varianceCount;
               }
            }

            if (varianceCount > 0) {
               return variance / (double)varianceCount > (double)10000.0F;
            } else {
               return true;
            }
         }
      }

      boolean hasRecentCombat() {
         long currentTime = System.currentTimeMillis();
         return this.hasRecentCombat && currentTime - this.lastCombatTime < 5000L;
      }

      String getPattern() {
         double sum = (double)0.0F;
         int count = 0;

         for(double cps : this.recentCPS) {
            if (cps > (double)0.0F) {
               sum += cps;
               ++count;
            }
         }

         if (count == 0) {
            return "no_data";
         } else {
            double avg = sum / (double)count;
            boolean consistent = this.isConsistentPattern();
            return String.format("avg=%.1f consistent=%s recent_combat=%s", avg, consistent, this.hasRecentCombat);
         }
      }
   }
}
