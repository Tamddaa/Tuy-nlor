package com.anti.system.anticheat;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

public class ReportCommand implements CommandExecutor, TabCompleter {
   private final ReportSystem reportSystem;

   public ReportCommand(ReportSystem reportSystem) {
      this.reportSystem = reportSystem;
   }

   public boolean onCommand(CommandSender sender, Command command, String label, String[] args2) {
      if (sender == null) {
         return false;
      } else if (!(sender instanceof Player)) {
         sender.sendMessage("§cThis command can only be used by players!");
         return true;
      } else {
         Player player = (Player)sender;
         if (args2.length == 0) {
            this.reportSystem.openReportGUI(player);
            return true;
         } else {
            switch (args2[0].toLowerCase()) {
               case "gui":
                  this.reportSystem.openReportGUI(player);
                  break;
               case "player":
                  if (args2.length < 2) {
                     player.sendMessage("§cUsage: /report player <player>");
                     return true;
                  }

                  this.reportSystem.openCategoryGUI(player, args2[1]);
                  break;
               case "list":
                  if (!player.hasPermission("antisystem.staff.reports")) {
                     player.sendMessage("§cNo permission!");
                     return true;
                  }

                  this.reportSystem.openStaffReportsGUI(player);
                  break;
               case "view":
                  if (!player.hasPermission("antisystem.staff.reports")) {
                     player.sendMessage("§cNo permission!");
                     return true;
                  }

                  if (args2.length < 2) {
                     player.sendMessage("§cUsage: /report view <id>");
                     return true;
                  }

                  try {
                     int reportId = Integer.parseInt(args2[1]);
                     this.reportSystem.openReportDetailGUI(player, reportId);
                  } catch (NumberFormatException var10) {
                     player.sendMessage("§cInvalid report ID!");
                  }
                  break;
               default:
                  this.sendHelpMessage(player);
            }

            return true;
         }
      }
   }

   private void sendHelpMessage(Player player) {
      player.sendMessage("§6§l=== Report System Help ===");
      player.sendMessage("§e/report §7- Open report GUI");
      player.sendMessage("§e/report gui §7- Open report GUI");
      player.sendMessage("§e/report player <name> §7- Report a specific player");
      if (player.hasPermission("antisystem.staff.reports")) {
         player.sendMessage("§6§lStaff Commands:");
         player.sendMessage("§e/report list §7- View all open reports");
         player.sendMessage("§e/report view <id> §7- View specific report");
      }

   }

   public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args2) {
      if (!(sender instanceof Player)) {
         return new ArrayList();
      } else {
         Player player = (Player)sender;
         if (args2.length == 1) {
            ArrayList<String> completions = new ArrayList(Arrays.asList("gui", "player", "help"));
            if (player.hasPermission("antisystem.staff.reports")) {
               completions.addAll(Arrays.asList("list", "view"));
            }

            return (List)completions.stream().filter((s) -> s.toLowerCase().startsWith(args2[0].toLowerCase())).collect(Collectors.toList());
         } else {
            return (List<String>)(args2.length == 2 && args2[0].equalsIgnoreCase("player") ? (List)Bukkit.getOnlinePlayers().stream().map(OfflinePlayer::getName).filter((name) -> !name.equals(player.getName())).filter((name) -> name.toLowerCase().startsWith(args2[1].toLowerCase())).collect(Collectors.toList()) : new ArrayList());
         }
      }
   }
}
