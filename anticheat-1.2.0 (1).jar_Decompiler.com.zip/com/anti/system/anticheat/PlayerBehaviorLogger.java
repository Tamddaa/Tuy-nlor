package com.anti.system.anticheat;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDateTime;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.bukkit.entity.Player;

public class PlayerBehaviorLogger {
   private static final String LOG_FILE = "player_behavior.log";
   private static final Logger LOGGER = Logger.getLogger(PlayerBehaviorLogger.class.getName());

   public static void log(Player player, String action, String details) {
      try {
         PrintWriter out = new PrintWriter(new FileWriter("player_behavior.log", true));

         try {
            out.printf("%s,%s,%s,%s\n", LocalDateTime.now(), player.getUniqueId(), action, details);
         } catch (Throwable var7) {
            try {
               out.close();
            } catch (Throwable var6) {
               var7.addSuppressed(var6);
            }

            throw var7;
         }

         out.close();
      } catch (IOException e) {
         LOGGER.log(Level.SEVERE, "Failed to write to player behavior log file: player_behavior.log", e);
      }

   }
}
