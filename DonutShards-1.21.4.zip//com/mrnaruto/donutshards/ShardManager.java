package com.mrnaruto.donutshards;

import java.io.File;
import java.io.IOException;
import java.util.UUID;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

public class ShardManager {
   private Main plugin;
   private File dataFile;
   private FileConfiguration data;

   public ShardManager(Main plugin) {
      this.plugin = plugin;
      this.loadData();
   }

   public void loadData() {
      this.dataFile = new File(this.plugin.getDataFolder(), "data.yml");
      if (!this.dataFile.exists()) {
         this.dataFile.getParentFile().mkdirs();
         this.plugin.saveResource("data.yml", false);
      }

      this.data = YamlConfiguration.loadConfiguration(this.dataFile);
   }

   public void saveData() {
      try {
         this.data.save(this.dataFile);
      } catch (IOException var2) {
         var2.printStackTrace();
      }

   }

   public double getShards(UUID uuid) {
      return this.data.getDouble("players." + String.valueOf(uuid) + ".shards", 0.0D);
   }

   public void setShards(UUID uuid, double amount) {
      this.data.set("players." + String.valueOf(uuid) + ".shards", amount);
      this.saveData();
   }

   public void addShards(UUID uuid, double amount) {
      this.setShards(uuid, this.getShards(uuid) + amount);
   }

   public boolean removeShards(UUID uuid, double amount) {
      double current = this.getShards(uuid);
      if (current >= amount) {
         this.setShards(uuid, current - amount);
         return true;
      } else {
         return false;
      }
   }
}
