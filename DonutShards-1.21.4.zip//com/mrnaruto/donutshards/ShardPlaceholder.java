package com.mrnaruto.donutshards;

import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.entity.Player;

public class ShardPlaceholder extends PlaceholderExpansion {
   private final Main plugin;

   public ShardPlaceholder(Main plugin) {
      this.plugin = plugin;
   }

   public String getIdentifier() {
      return "donutshards";
   }

   public String getAuthor() {
      return (String)this.plugin.getDescription().getAuthors().get(0);
   }

   public String getVersion() {
      return this.plugin.getDescription().getVersion();
   }

   public String onPlaceholderRequest(Player player, String identifier) {
      if (player == null) {
         return "";
      } else if (!identifier.equalsIgnoreCase("amount") && !identifier.equalsIgnoreCase("shards_amount")) {
         return null;
      } else {
         double shards = this.plugin.getShardManager().getShards(player.getUniqueId());
         return String.valueOf((int)shards);
      }
   }
}
