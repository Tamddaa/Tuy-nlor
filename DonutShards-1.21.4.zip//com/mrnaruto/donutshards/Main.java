package com.mrnaruto.donutshards;

import org.bukkit.plugin.java.JavaPlugin;

public class Main extends JavaPlugin {
   private ShardManager shardManager;

   public void onEnable() {
      this.saveDefaultConfig();
      this.shardManager = new ShardManager(this);
      new ShardsCommand(this, this.shardManager);
      if (this.getServer().getPluginManager().getPlugin("PlaceholderAPI") != null) {
         (new ShardPlaceholder(this)).register();
         this.getLogger().info("Hooked into PlaceholderAPI!");
      }

      this.getLogger().info("DonutShards v" + this.getDescription().getVersion() + " enabled!");
   }

   public void onDisable() {
      this.shardManager.saveData();
      this.getLogger().info("DonutShards disabled!");
   }

   public ShardManager getShardManager() {
      return this.shardManager;
   }
}
