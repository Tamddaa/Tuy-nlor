package com.mrnaruto.donutshards;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import me.clip.placeholderapi.PlaceholderAPI;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

public class ShardsCommand implements CommandExecutor, TabCompleter {
   private Main plugin;
   private ShardManager shardManager;

   public ShardsCommand(Main plugin, ShardManager shardManager) {
      this.plugin = plugin;
      this.shardManager = shardManager;
      plugin.getCommand("shards").setExecutor(this);
      plugin.getCommand("shards").setTabCompleter(this);
   }

   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
      Player target;
      int shards;
      String msg;
      if (args.length == 0) {
         if (!(sender instanceof Player)) {
            sender.sendMessage(String.valueOf(ChatColor.RED) + "Only players can check their own shards!");
            return true;
         } else {
            target = (Player)sender;
            shards = (int)this.shardManager.getShards(target.getUniqueId());
            msg = this.plugin.getConfig().getString("messages.balance_self").replace("%shards_amount%", String.valueOf(shards));
            msg = PlaceholderAPI.setPlaceholders(target, msg);
            target.sendMessage(ChatColor.translateAlternateColorCodes('&', msg));
            return true;
         }
      } else if (args.length == 1) {
         target = Bukkit.getPlayerExact(args[0]);
         if (target == null) {
            sender.sendMessage(ChatColor.translateAlternateColorCodes('&', this.plugin.getConfig().getString("messages.player_not_found")));
            return true;
         } else if (!sender.hasPermission("donutshards.view")) {
            sender.sendMessage(ChatColor.translateAlternateColorCodes('&', this.plugin.getConfig().getString("messages.no_permission")));
            return true;
         } else {
            shards = (int)this.shardManager.getShards(target.getUniqueId());
            msg = this.plugin.getConfig().getString("messages.balance_other").replace("%player%", target.getName()).replace("%shards_amount%", String.valueOf(shards));
            msg = PlaceholderAPI.setPlaceholders(target, msg);
            sender.sendMessage(ChatColor.translateAlternateColorCodes('&', msg));
            return true;
         }
      } else if (args.length == 3) {
         if (!sender.hasPermission("donutshards.admin")) {
            sender.sendMessage(ChatColor.translateAlternateColorCodes('&', this.plugin.getConfig().getString("messages.no_permission")));
            return true;
         } else {
            String action = args[0].toLowerCase();
            Player target = Bukkit.getPlayerExact(args[1]);
            if (target == null) {
               sender.sendMessage(ChatColor.translateAlternateColorCodes('&', this.plugin.getConfig().getString("messages.player_not_found")));
               return true;
            } else {
               int amount;
               try {
                  amount = Integer.parseInt(args[2]);
               } catch (NumberFormatException var10) {
                  sender.sendMessage(ChatColor.translateAlternateColorCodes('&', this.plugin.getConfig().getString("messages.invalid_amount")));
                  return true;
               }

               byte var9 = -1;
               switch(action.hashCode()) {
               case -934610812:
                  if (action.equals("remove")) {
                     var9 = 2;
                  }
                  break;
               case 113762:
                  if (action.equals("set")) {
                     var9 = 1;
                  }
                  break;
               case 3173137:
                  if (action.equals("give")) {
                     var9 = 0;
                  }
               }

               switch(var9) {
               case 0:
                  this.shardManager.addShards(target.getUniqueId(), (double)amount);
                  sender.sendMessage(ChatColor.translateAlternateColorCodes('&', this.plugin.getConfig().getString("messages.give_success").replace("%player%", target.getName()).replace("%amount%", String.valueOf(amount))));
                  break;
               case 1:
                  this.shardManager.setShards(target.getUniqueId(), (double)amount);
                  sender.sendMessage(ChatColor.translateAlternateColorCodes('&', this.plugin.getConfig().getString("messages.set_success").replace("%player%", target.getName()).replace("%amount%", String.valueOf(amount))));
                  break;
               case 2:
                  if (this.shardManager.removeShards(target.getUniqueId(), (double)amount)) {
                     sender.sendMessage(ChatColor.translateAlternateColorCodes('&', this.plugin.getConfig().getString("messages.remove_success").replace("%player%", target.getName()).replace("%amount%", String.valueOf(amount))));
                  } else {
                     sender.sendMessage(String.valueOf(ChatColor.RED) + "Player does not have enough shards!");
                  }
                  break;
               default:
                  sender.sendMessage(String.valueOf(ChatColor.RED) + "Unknown action! Use give/set/remove.");
               }

               return true;
            }
         }
      } else {
         sender.sendMessage(String.valueOf(ChatColor.RED) + "Invalid usage! /shards <player|give|set|remove>");
         return true;
      }
   }

   public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
      List<String> completions = new ArrayList();
      if (args.length == 1) {
         if (sender.hasPermission("donutshards.admin")) {
            completions.add("give");
            completions.add("set");
            completions.add("remove");
         }

         Iterator var6 = Bukkit.getOnlinePlayers().iterator();

         while(var6.hasNext()) {
            Player p = (Player)var6.next();
            completions.add(p.getName());
         }
      }

      return completions;
   }
}
